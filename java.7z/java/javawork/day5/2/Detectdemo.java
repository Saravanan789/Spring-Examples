class Account
{
	public void display()
	{
		System.out.println("account class");
	}
}
class detect
{
	public static void detectclass(Account account)
	{
		account.display();
	}
}
class Detectdemo
{
	public static void main(String[] args)
	{
	Account obj=new Account();
	detect.detectclass(obj);
	Class c1;
	c1=obj.getClass();
	System.out.println(c1);
	
	}
}