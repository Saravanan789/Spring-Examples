class Account
{
	public void display()
	{
		System.out.println("account class");
	}
}
class detect
{
	public static void detect(Account account)
	{
		account.display();
	}
}
class Detectdemo
{
	public static void main(String[] args)
	{
	Accouont obj=new Account();
	obj.detect(obj);
	}
}