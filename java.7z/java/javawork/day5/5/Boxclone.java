import java.util.*;
class Box implements Cloneable
{

int length;
int weight;
int height;
int breadth;
Day dateofmanufacture;

Box(){}
Box(int length, int weight, int height,int breadth,Day dateofmanufacture){

this.length = length;
this.weight = weight;
this.height = height;
this.breadth =breadth;
this.dateofmanufacture=dateofmanufacture;

}
public String toString(){

return getClass().getName() +" " +
       "length = " + length+ " " +
       "width = " + weight+ " " +
       "height = " + height + ""+"breadth="+breadth+"dateofmanufacture"+dateofmanufacture;

}
public boolean equals(Object obj)
{
	if(!(obj.getClass()==this.getClass()))
	{
		System.out.println("incompatible equal");
		return false;
	}
	else
	{
		Box b1=(Box)obj;
		return (this.length==b1.length)&&(this.weight==b1.weight)&&(this.breadth==b1.breadth)&&(this.height==b1.height);
	}

}
public Object clone()
{
	try
	{
		Box b=(Box)super.clone();
		b.dateofmanufacture=(Day)dateofmanufacture.clone();
		return b;
	}
	catch(CloneNotSupportedException b)
	{
		b.printStackTrace();
		return null;
	}
}	
}

class Boxclone
{
  public static void main(String[] args)
  {  
  Box b1 = new Box(10,20,30,40,new Day(1989,10,1));
  System.out.println("The Box data is " + b1);
  Box b2=new Box(10,20,30,40,new Day(1989,10,1));
 System.out.println(b1.equals(b2));
 Box b1copy=(Box)b1.clone();
 System.out.println("The Box data is " + b1copy);
 




  }

}



//some point actually what program do when we print object it show some hash code that time the to string method invoked so that we have to inherith that method and print whatever we want

