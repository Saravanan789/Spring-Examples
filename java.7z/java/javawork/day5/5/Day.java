 
 import java.util.*;
 import java.io.*;
 

 public class Day implements Cloneable, Serializable
 {  
     
    public Day()
    {  GregorianCalendar todaysDate 
          = new GregorianCalendar();
       year = todaysDate.get(Calendar.YEAR);
       month = todaysDate.get(Calendar.MONTH) + 1;
       day = todaysDate.get(Calendar.DAY_OF_MONTH);
    }
 
   
     
    public Day(int yyyy, int m, int d) 
    {  year = yyyy;
       month = m;
       day = d;
       if (!isValid()) 
          throw new IllegalArgumentException();
    }
 
    public void setDate(int yyyy, int m, int d)
    {  year = yyyy;
       month = m;
       day = d;
       if (!isValid()) 
          throw new IllegalArgumentException();
    }
   
 
    public void advance(int n)
    {  fromJulian(toJulian() + n);
    }
 
   
    public int getDay()
    {  return day;
    }
 
   
 
    public int getMonth()
    { return month;
    }
 
    
 
    public int getYear()
    { return year;
    }
    
   
     
    public int weekday() 
    {  return (toJulian() + 1) % 7 + 1; 
    }
    
   
    
    public int daysBetween(Day b)
    {  return toJulian() - b.toJulian();
    }
 
   
    
    public String toString()
    {  return "Day[" + year + "," + month + "," + day + "]";
    }
 
    
    
    public Object clone()
    {  try
       {  return super.clone();
       } catch (CloneNotSupportedException e)
       {  
 	// this shouldn't happen, since we are Cloneable
          return null;
       }   
    }
 
    
 
    public boolean equals(Object obj)
    {  if (!getClass().equals(obj.getClass())) 
 	return false;
       Day b = (Day)obj;
       return day  == b.day && month == b.month 
 	  && year == b.year;
    }
 
   
     
    private boolean isValid()
    {  Day t = new Day();
       t.fromJulian(this.toJulian());
       return t.day == day && t.month == month 
          && t.year == year;
    }
 
    
 
    private int toJulian()
    {  int jy = year;
       if (year < 0) jy++;
       int jm = month;
       if (month > 2) jm++;
       else
       {  jy--;
          jm += 13;
       }
       int jul = (int) (java.lang.Math.floor(365.25 * jy) 
 	         + java.lang.Math.floor(30.6001*jm) 
 		 + day + 1720995.0);
 
       int IGREG = 15 + 31*(10+12*1582);
          // Gregorian Calendar adopted Oct. 15, 1582
 
       if (day + 31 * (month + 12 * year) >= IGREG)
          // change over to Gregorian calendar
       {  int ja = (int)(0.01 * jy);
          jul += 2 - ja + (int)(0.25 * ja);
       }
       return jul;
    }
 
    
 
    private void fromJulian(int j)
    {  int ja = j;
       int JGREG = 2299161;
         
 
       if (j >= JGREG)
         
       {  
        int jalpha = 
 	(int)(((float)(j - 1867216) - 0.25) / 36524.25);
          ja += 1 + jalpha - (int)(0.25 * jalpha);
       }
       int jb = ja + 1524;
       int jc = (int)(6680.0 
 	+ ((float)(jb-2439870) - 122.1)/365.25);
       int jd = (int)(365 * jc + (0.25 * jc));
       int je = (int)((jb - jd)/30.6001);
       day = jb - jd - (int)(30.6001 * je);
       month = je - 1;
       if (month > 12) month -= 12;
       year = jc - 4715;
       if (month > 2) --year;
       if (year <= 0) --year;
    }
 
    public static int SUNDAY = 1;
    public static int MONDAY = 2;
    public static int TUESDAY = 3;
    public static int WEDNESDAY = 4;
    public static int THURSDAY = 5;
    public static int FRIDAY = 6;
    public static int SATURDAY = 7;
 
 
    private int day;
  
    private int month;

    private int year;
 }
