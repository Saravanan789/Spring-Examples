abstract class Account
{
private int accountno;
private String customername;
private String customeraddress;
 double balanceamt;
int  rate;
public Account(int accountno,String customername,String customeraddress,double balanceamt,int rate)
{
	setAccountNo(accountno);
	setCustomerName(customername);
	setCustomerAddress(customeraddress);
	setBalanceAmt(balanceamt);
	setRate(rate);
	
}
public void setAccountNo(int accountno)
{
this.accountno=accountno;
}
public int getAccountNo()
{
	return accountno;
}
public void setCustomerName(String customername)
{
this.customername=customername;
}
public String getCustomername()
{
	return customername;
}
public void setCustomerAddress(String customeraddress)
{
this.customeraddress=customeraddress;
}
public String getCustomerAddress()
{
	return customeraddress;
}
public void setBalanceAmt(double balanceamt)
{
this.balanceamt=balanceamt;
}
public double getBalanceAmt()
{
	return balanceamt;
}
public void setRate(int rate)
{
this.rate=rate;
}
public int getRate()
{
	return rate;
}
abstract void Deposite(double amt);
abstract void WithDraw(double amt);
abstract void PrintDetail();
public void dp()
{
	System.out.println("hi");
}
public void GetCustomerDetail(String name,String address)
{
	System.out.println("\nname ="+customername+"address "+customeraddress);
}
}
class Savingaccount extends Account
{
	public Savingaccount(int accountno,String customername,String customeraddress,double balanceamt,int rate)
	{
	  super(accountno,customername,customeraddress,balanceamt,rate);
	}

public void Deposite(double amt)
{
	setBalanceAmt(getBalanceAmt()+amt);

}
public void WithDraw(double amt)
{
	
	setBalanceAmt(getBalanceAmt()-amt);
}
public void PrintDetail()
{
	
	System.out.println("name="+getCustomername()+"\nbalance amount="+getBalanceAmt());
}
}
	
class Currentaccount extends Account
{
	public Currentaccount(int accountno,String customername,String customeraddress,double balanceamt,int rate)
	{
	  super(accountno,customername,customeraddress,balanceamt,rate);
	}
	
	
public void Deposite(double amt)
{
	setBalanceAmt(getBalanceAmt()+amt);


}
public void WithDraw(double amt)
{
	
	setBalanceAmt(getBalanceAmt()-amt);
}
public void PrintDetail()
{
	
	System.out.println("name="+getCustomername()+"\nbalance amount="+getBalanceAmt());
}
}


	
	
	

public class Accountdemo
{
	public static void main(String[] args)
	{
		Savingaccount s=new Savingaccount(12345,"saravanan","chennai",27898,6);
		Currentaccount c=new Currentaccount(45678,"vishnu","t nagar",70000,8);
		System.out.println("\nSaving Account");
		s.PrintDetail();
		s.Deposite(4000);
		s.WithDraw(1000);
		s.PrintDetail();
		System.out.println("\nCurrent Account");
		c.PrintDetail();
		c.Deposite(4000);
		c.WithDraw(1000);
		c.PrintDetail();
		c.dp();
		System.out.println(GetCustomerDetail);
		c.GetCustomerDetail("k","l");
		
		
	}
}











 	