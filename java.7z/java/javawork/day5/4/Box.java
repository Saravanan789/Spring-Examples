import java.util.*;
class Box{

int length;
int weight;
int height;
int breadth;

Box(){}
Box(int length, int weight, int height,int breadth){

this.length = length;
this.weight = weight;
this.height = height;
this.breadth =breadth;

}
public String toString(){

return getClass().getName() +" " +
       "length = " + l+ " " +
       "width = " + w+ " " +
       "height = " + h + "\n";

}

}
class ToStringDemo{

  public static void main(String[] args){

  Box c = new Box(10,20,30);
  System.out.println("The Box data is " + c);

  Box[] b =  new Box[3];

  b[0] = new Box(1,2,3);
  b[1] = new Box(5,6,7);
  b[2] = new Box(10,11,12);

System.out.println("Arrays is " + b);













System.out.println("Arrays is " + Arrays.toString(b));




  }

}



//some point actually what program do when we print object it show some hash code that time the to string method invoked so that we have to inherith that method and print whatever we want

