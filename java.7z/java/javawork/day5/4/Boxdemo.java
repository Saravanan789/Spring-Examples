import java.util.*;
class Box{

int length;
int weight;
int height;
int breadth;

Box(){}
Box(int length, int weight, int height,int breadth){

this.length = length;
this.weight = weight;
this.height = height;
this.breadth =breadth;

}
public String toString(){

return getClass().getName() +" " +
       "length = " + length+ " " +
       "width = " + weight+ " " +
       "height = " + height + ""+"breadth="+breadth;

}
public boolean equals(Object obj)
{
	if(!(obj.getClass()==this.getClass()))
	{
		System.out.println("incompatible equal");
		return false;
	}
	else
	{
		Box b1=(Box)obj;
		return (this.length==b1.length)&&(this.weight==b1.weight)&&(this.breadth==b1.breadth)&&(this.height==b1.height);
	}

}
}
class Boxdemo{

  public static void main(String[] args){

  Box b1 = new Box(10,20,30,40);
  System.out.println("The Box data is " + b1);
  Box b2=new Box(10,20,30,40);
 System.out.println(b1.equals(b2));




  }

}



//some point actually what program do when we print object it show some hash code that time the to string method invoked so that we have to inherith that method and print whatever we want

