interface Account
{

 void Deposite(double amt);
void WithDraw(double amt);
 

}
class Ssavingaccount implements Account
{

public void Deposite(double amt)
{
	System.out.println("total"+(amt+100));

}
public void WithDraw(double amt)
{
	
	System.out.println("total1"+(amt+100));
}

}
	
class Ccurrentaccount implements Account
{
	public void Deposite(double amt)
{
	System.out.println("tota3"+(amt+100));

}
public void WithDraw(double amt)
{
	
	System.out.println("total4"+(amt+100));
}
public void display()
{
	System.out.println("------------------");
}

	
}


	
	
	

public class Accountinterfacedemo
{
	public static void main(String[] args)
	{
	Account s=new Ssavingaccount();
		Account c=new Ccurrentaccount();
		 ((Ccurrentaccount)c).display();
		System.out.println("\nSaving Account");
		
		s.Deposite(4000);
		s.WithDraw(1000);
		
		System.out.println("\nCurrent Account");
		
		c.Deposite(4000);
		c.WithDraw(1000);
	
		
		
	}
}











 	