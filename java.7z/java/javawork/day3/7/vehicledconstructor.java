class Vehicle
{
	String type;
	String brand;
	float price;
  public Vehicle(String type,String brand,float price)
	{
		this(brand,price);
		this.type=type;
		
	}
	 public Vehicle(String brand,float price)
	{
		this(price);
		this.brand=brand;
	}
	 public Vehicle(float price)
	{
		this.price=price;
	}
	public Vehicle()
	{
	}	
	public void start()
	{
		System.out.println("Starting");
		
	}
	public void brake()
	{
		System.out.println("breaking");
	}
	public void accelerate()
	{
		System.out.println("Acclerating");
	}
	public void printdetail()
	{
		System.out.println("type="+type+"\nbrand="+brand+"\nprice"+price);
}
}
public class Vehicledconstructor
{
	public static void main(String[] args)
	{
		
	Vehicle s1=new Vehicle("two wheelar","yamaha",7000f);
	Vehicle s2=new Vehicle("two wheelar","suziki",80000f);
	s1.start();
	s1.brake();
	s1.accelerate();
	s1.printdetail();
	s2.start();
	s2.brake();
	s2.accelerate();
	s2.printdetail();
	}
	
}