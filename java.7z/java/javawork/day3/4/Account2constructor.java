class Accountdetails
{
	private int accountNo;
	private String customerName;
	private float currentBalance;
	public  Accountdetails(int accountNo,float currentBalance)
	{
		this.accountNo=accountNo;
		this.currentBalance=currentBalance;
		
	}
	public  Accountdetails(int accountNo,String customerName,float currentBalance)
	{
		this.accountNo=accountNo;
		this.currentBalance=currentBalance;
		this.customerName=customerName;
	}
		
	
	
	
	public void setCustomername(String customerName)
	{
		this.customerName=customerName;
	}
	public String getCustomername()
	{
		return customerName;
	}
	
	
	public void deposite(int amount)
	{
		currentBalance=currentBalance+amount;
		System.out.println("\n"+amount+".rs deposite successfully");
	}
	public void withdraw(int amount)
	{
		
		if(currentBalance-amount>=1000)
		{
		currentBalance=currentBalance-amount;
		System.out.println("\n"+amount+".rs withdraw successfully");
		}
		else
		{
			System.out.println("\nshoud maintain minimum 1000rs");
		}
	}
	public void printDetail()
	{
		
		System.out.println("\naccount no="+accountNo+"\nname="+customerName+"\ncurrentbalance="+currentBalance);
		
		
	}
}
public class Account2constructor
{
	public static void main(String[] args)
	{
		Accountdetails s1=new Accountdetails(234567,20000f);
		Accountdetails s2=new Accountdetails(1234567,"vishnu",15000f);
		
	
		s1.setCustomername("saravanan");
		s1.printDetail();
		s1.deposite(1000);
		System.out.println("after deposite");
		s1.printDetail();
		s1.withdraw(2000);
		System.out.println("after withdraw");
		s1.printDetail();
		s2.printDetail();
		s2.deposite(3000);
		System.out.println("after deposite");
		s2.printDetail();
		s2.withdraw(5000);
		System.out.println("after withdraw");
		s2.printDetail();
		
	}
}
		
	
	
	
	
	
	