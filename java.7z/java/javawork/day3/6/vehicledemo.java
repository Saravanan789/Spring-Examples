class Vehicle
{
	String type;
	String brand;
	float price;
  public Vehicle(String type,String brand,float price)
	{
		this.type=type;
		this.brand=brand;
		this.price=price;
	}
	public void start()
	{
		System.out.println("Starting");
		
	}
	public void brake()
	{
		System.out.println("breaking");
	}
	public void accelerate()
	{
		System.out.println("Acclerating");
	}
	public void printdetail()
	{
		System.out.println("type="+type+"\nbrand="+brand+"\nprice"+price);
}
}
public class Vehicledemo
{
	public static void main(String[] args)
	{
		
	Vehicle s1=new Vehicle("two wheelar","yamaha",7000f);
	s1.start();
	s1.brake();
	s1.accelerate();
	s1.printdetail();
	}
	
}