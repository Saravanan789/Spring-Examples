class Testinit
{
	int n1;
	Integer n2;
	String n3;
	float n4;
	char n5;
	double n6;
	
	public void print()
	{
		String n8;
		int n9;
		System.out.println(n8+n9);
	}
  public void print1()
  {
	  System.out.println(n1+n2+n3+n4+n5+n6);
  }
}
public class Testinitdemo
{
	public static void main(String args[])
	{
		
	Testinitdemo s1=new Testinitdemo();
	s1.print1();
	s1.print();
	}
}