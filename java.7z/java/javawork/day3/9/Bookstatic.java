class Book
{
	String bookname;
	int isbn;
	String author;
	int edition;
	float price;
	static int inc=0;
	public Book(String bookname,int isbn,String author,int edition,float price)
	{
		this.bookname=bookname;
		this.isbn=isbn;
		this.author=author;
		this.edition=edition;
		this.price=price;
		increment();
	}
	public void increment()
	{
		inc++;
		System.out.println("book="+inc);
	}
}
public class Bookstatic
{
	public static void main(String[] args)
	{
		Book s1=new Book("wings of fire",12789,"abj",1997,200f);
		Book s2=new Book("wings",12789,"me",1996,300f);
	}
}
		
		