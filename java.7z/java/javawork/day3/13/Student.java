
class Student
{
	int[] studentid={1,2,3,4,5,6,7,8};
	int[] password={2,3,4,5,6,7,8,9};
	
	public  static int id=0;
	
	
	public void login()
	{
		System.out.println("enter the userid=");
		int j=Console.readInt();
		for(int i=0;i<8;i++)
		{
			if(j==studentid[i])
			{  
		          id=j;
				System.out.println("Enter the password");
				
					int k=Console.readInt();
					if(k==password[i])
					{
						System.out.println("login successfully");
					}
					else
					{
						System.out.println("invalid password");
					}
			}
		}
		       
	}
}