class Teacher
{
	int[] teacherid={1,2,3,4,5,6};
	int[] password={2,3,4,5,6,7};
	String[] teachername={"vishnu","ahoke","arun","vimal","vinoth","kannan"};
	String[] handlingcourse={"java","python","c","c#","java","python"};
	public void login()
	{
		System.out.println("enter the username=");
		int j=Console.readInt();
		for(int i=0;i<6;i++)
		{
			if(j==teacherid[i])
			{
				System.out.println("Enter the password");
				
					int k=Console.readInt();
					if(k==password[i])
					{
						System.out.println("login successfully");
					}
					else
					{
						System.out.println("invalid password");
					}
			}
			
		}
	}
	public void teacherInfo()
	{
		System.out.println("list of teacher");
		for(int i=0;i<6;i++)
		{
			System.out.println(teachername[i]);
		}
		System.out.println("select the teacher");
		String ch=Console.readString();
		System.out.println("handling courses");
		for(int i=0;i<6;i++)
		{
			if(ch.equals(teachername[i]))
			{
				
					System.out.println(handlingcourse[i]);
				
			}
		}
	}
}
			