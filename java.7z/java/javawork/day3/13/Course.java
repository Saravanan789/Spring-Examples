class Course
{
	static public String str="";
	String[] coursename={"1.java","2.python","3.c","4.c#","c++"};
	String[] javac={"INDRODUCTION","BASIC","CLASS","CONSTRUCTOR"};
	String[] python={"INDRODUCTION","BASIC","CLASS","CONSTRUCTOR"};
	String[] c={"INDRODUCTION","BASIC","CLASS","CONSTRUCTOR"};
	String[] cs={"INDRODUCTION","BASIC","CLASS","CONSTRUCTOR"};
	public void courseInfo()
	{
	System.out.println("COURSE INFORMATION");
	for(int i=0;i<4;i++)
	{
		System.out.println(coursename[i]);
	}
	
	System.out.println("select the course");
	
	String choice=Console.readString();
		for(int i=0;i<4;i++)
	   {
		 if(choice.equals(coursename[i]))
		{
			str=coursename[i];
			System.out.println("n");
		}		
	  }
	System.out.print("availabl topics");
	
	if(choice.equals("java"))
	{
		for(int i=0;i<4;i++)
	{
		System.out.println(javac[i]);
	}
	}
	else if(choice.equals("python"))
	{	
		for(int i=0;i<4;i++)
	     {
		System.out.println(python[i]);
	     }
	}
	else if(choice.equals("c"))
	{   for(int i=0;i<4;i++)
	    {
		System.out.println(c[i]);
	      }
	
	}
	else if(choice.equals("cs"))
	{
		for(int i=0;i<4;i++)
	    {
		System.out.println(cs[i]);
	    }
	}
     else
	 {
		 System.out.println("in");
	  }
	}
}
	
	
	
	
	
	
	
	
	
	
	