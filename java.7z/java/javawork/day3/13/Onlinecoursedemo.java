public class Onlinecoursedemo
{
	public static void main(String[] args)
	{
		Student s=new Student();
		Teacher t=new Teacher();
		Course c=new Course();
		Enrollment e=new Enrollment();
		
		System.out.println("=====Welcome to elearning=====");
		System.out.println("Select the user type");
		System.out.println("\n1.STUDENT"+"\n2.TEACHER");
		int choice=Console.readInt();
		switch(choice)
		{
			case 1:
			s.login();
			c.courseInfo();
			t.teacherInfo();
			
			e.print();
			break;
			
			case 2:
			t.login();
			t.teacherInfo();
			e.print();
			
		}
	
		
	}
}
			
			
		