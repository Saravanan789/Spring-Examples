
 public class Enrollment
{
		public void print()
		{
	System.out.println("student id="+Student.id+"course name"+Course.str);
	}
}
