
class Container
{
	int length;
	int breadth;
	int hight;
	static String shift;
	public container( int length,int height,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
		this.height=height;
		
	
	public void setShift()
	
		        GregorianCalendar calendar = new GregorianCalendar();
            if (calendar.get(Calendar.AM_PM) == Calendar.AM)
				{
                   shift =”AM”
               } else 
			   {
                    shift =”PM”;
                }
	}
	public void getShift()
	{
		return shift;
	}
}
public class Containerdemo
{
	public static void main(String args[])
	{
		container s1=new container(10,20,30);
		System.out.println(s1.getshift());
	}
}

		