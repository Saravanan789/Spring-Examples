import java.util.*;
class Container
{
	int length;
	int breadth;
	int height;
	static String shift;
	public Container( int length,int height,int breadth)
	{
		this.length=length;
		this.height=height;
		this.breadth=breadth;
		
	}
	public void setShift()
	
	{        GregorianCalendar calendar = new GregorianCalendar();
            if (calendar.get(Calendar.AM_PM) == Calendar.AM)
				{
                   shift ="AM";
               } else 
			   {
                    shift ="PM";
                }
	}
	public String getShift()
	{
		return shift;
	}
}
public class Containerdemo
{
	public static void main(String args[])
	{
		Container s1=new Container(10,20,30);
		s1.setShift();
		System.out.println(s1.getShift());
	}
}

		