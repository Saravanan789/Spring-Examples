class Accountdetails
{
	private int accountNo;
	private String customerName;
	private float currentBalance;
	public void setAccountno(int accountNo)
	{
		this.accountNo=accountNo;
		
	}
	
	public void setCustomername(String customerName)
	{
		this.customerName=customerName;
	}
	
	public void setCurrentbalance(float currentBalance)
	{
		this.currentBalance=currentBalance;
	}
	
	public void deposite(int amount)
	{
		currentBalance=currentBalance+amount;
		System.out.println("\n"+amount+".rs deposite successfully");
	}
	public void withdraw(int amount)
	{
		
		if(currentBalance-amount>=1000)
		{
		currentBalance=currentBalance-amount;
		System.out.println("\n"+amount+".rs withdraw successfully");
		}
		else
		{
			System.out.println("\nshoud maintain minimum 1000rs");
		}
	}
	public void printDetail()
	{
		
		System.out.println("\naccount no="+accountNo+"\nname="+customerName+"\ncurrentbalance="+currentBalance);
		
		
	}
}
public class Account
{
	public static void main(String[] args)
	{
		Accountdetails s1;
		Accountdetails s2;
		s1=new Accountdetails();
		s2=new Accountdetails();
		s1.setAccountno(123445);
		s1.setCustomername("saravanan");
		s1.setCurrentbalance(90000f);
		s1.printDetail();
		s1.deposite(1000);
		System.out.println("after deposite");
		s1.printDetail();
		s1.withdraw(2000);
		System.out.println("after withdraw");
		s1.printDetail();
		s2.setAccountno(1234);
		s2.setCustomername("vishnu");
		s2.setCurrentbalance(80000f);
		s2.printDetail();
		s2.deposite(2000);
		System.out.println("after deposite");
		s2.printDetail();
		s2.withdraw(2000);
		System.out.println("after withdraw");
		s2.printDetail();
	}
}
		
	
	
	
	
	
	