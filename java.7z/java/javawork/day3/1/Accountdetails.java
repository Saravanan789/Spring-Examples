class Accountdetails
{
	private int accountnNo;
	private String customerName;
	private float currentBalance;
	public void setAccount(int accountNo,String customerName,float currentBalance)
	{
		this.accountNo=accountNo;
		this.customerName=customerName;
		this.currentBalance=currentBalance;
	}
	public void deposite(int amount)
	{
		currentBalance=currentBalance+amount;
	}
	public void withdraw()
	{
		
		if(currenBalance-amount=>1000)
		{
		currentBalance=currentBalance-amount;
		}
		else
		{
			System.out.println("shoud maintain minimum 1000rs");
		}
	}
	public void printDetail()
	{
		
		System.out.println("account no="+accountNo);
		
		
	}
}
public class Account
{
	public static void main(String[] args)
	{
		Accountdetails s1;
		s1=new Accountdetails();
		s1.setAccount(1234,"saravanan",50000);
		s1.deposite(1000);
		s1.withdraw(2000);
	}
}
		
	
	
	
	
	
	