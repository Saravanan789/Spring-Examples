class Missiledemo
{
	missile1 m[]=new missile1[10];
	public static void main(String[] args)
	{
		if (Missile.count<=3)
		{
			for(int i=0;i<3;i++)
			{
				System.out.println("enter the missile number");
				int mno=console.readInt();
				System.out.println("enter the name");
				String mna=console.readString();
				System.out.println("enter the payload");
				int mpl=console.readInt();
				System.out.println("enter the distance");
				int mdi=console.readInt();
				m[i]=new missile(mno,mna,mpl,mdi);
			}
			
				
				