  public class Missiledemo
{
	
	 static Missile1 m[]=new Missile1[10];
	public static void main(String[] args)
	{
		for(int i=1;i<=5;i++)
		
		{
			
		       if (Missile1.j<3)
			{
				
				System.out.println("enter the missile number");
				int mno=Console.readInt();
				System.out.println("enter the name");
				String mna=Console.readString();
				System.out.println("enter the payload");
				int mpl=Console.readInt();
				System.out.println("enter the distance");
				int mdi=Console.readInt();
			   m[i]=new Missile1(mno,mna,mpl,mdi);
			   m[i].print();
			}
			else
			{
				System.out.println(i+"attempt");
				m[i]=m[i-3];
				m[i].print();
			}
			
		}
		

	}
}
				
			
				
				