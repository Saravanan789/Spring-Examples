class Missile1
{
	static int j=0;
	int mnumber;
	String mname;
	int mpayload;
	int mdistance;
	
	public Missile1(int mnumber,String mname,int mpayload,int mdistance)
	{
		this.mnumber=mnumber;
		this.mname=mname;
		this.mpayload=mpayload;
		this.mdistance=mdistance;
		j++;
	}
	public void  launch()
	{
		System.out.println("Launched");
	}
	public void deactivate()
	{
		System.out.println("deactivated");
	}
	public void  print()
	{
		System.out.println("\nmissilename="+mname+"\nmissilenumber="+mnumber+"\nMissile payload"+mpayload+"\nmdistance="+mdistance);
	}
}
	