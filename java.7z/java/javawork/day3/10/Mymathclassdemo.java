class Mymathclass
{
	static int add(int a,int b)
	{
		return a+b;
	}
	static int sub(int a,int b)
	{
		return a-b;
	}
	static int mul(int a,int b)
	{
		return a*b;
	}
	static int div(int a,int b)
	{
		return a/b;
	}
}
public class Mymathclassdemo
{
	public static void main(String[] args)
	{
		System.out.println(Mymathclass.add(5,8));
		System.out.println(Mymathclass.sub(8,7));
		System.out.println(Mymathclass.mul(5,8));
		System.out.println(Mymathclass.div(8,2));
	}
}
		
	