class Sequalcheck
{
	public static void main(String[] args)
	{
		String str1="saravanan";
		String str2="saravanan";
		
		if(str1==str2)
		{
			System.out.println("both are equal");
		}
		else
		{
			System.out.println("String are not from same ref");
		}
		if(str1.equals(str2))
		{
			System.out.println("String are equal");
		}
		else
		{
			System.out.println("string are not equal");
		}
	}
}