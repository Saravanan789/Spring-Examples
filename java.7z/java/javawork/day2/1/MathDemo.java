import gh.Console;

class MathDemo
{
	public static void main(String[] args)
	{
		int n1,n2;
		double n3;
		double noInDegrees,noInRadians;
		double base,power;
		System.out.println("The mathematival constant");
		System.out.println("E ="+ Math.E);
		System.out.println("PI ="+ Math.PI);
		System.out.println("\n Finding maximum value");
		System.out.println("\n Enter the First Number");
		n1=Console.readInt();
		System.out.println("\nEnter the second Number");
		n2=Console.readInt();
	    System.out.println("Maximum ofv two number"+Math.max(n1,n2));
		System.out.println("\nfinding of minimum number");
		System.out.println("Enter the First number");
		n1=Console.readInt();
		System.out.println("Enter the second number");
		n2=Console.readInt();
		System.out.println("Minimum of two number="+Math.min(n1,n2));
		System.out.println("finding absoluet value");
		n1=Console.readInt();
		System.out.println("absolute value"+Math.abs(n1));
	}
}
		
		