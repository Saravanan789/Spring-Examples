class Bufferconcept
{
	public static void main(String[] args)
	{
		StringBuffer name=new StringBuffer("saravanan");
		String companyname="nextsphere";
		System.out.println("\ncompany name="+companyname+"name="+name);
		String name1=name.toString();
		StringBuffer companyname1=new StringBuffer(companyname);
		System.out.println("\ncompany name="+companyname1+"name="+name1);
	}
}