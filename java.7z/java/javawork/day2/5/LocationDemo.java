class Location
{
	private String loc;
	public String setWelcome(String loc)
	{
		this.loc=loc;
		StringBuffer sp=new StringBuffer(loc);
		System.out.println("Welcome saravanan to"+sp);
		String np="welcome saravanan to"+sp;
		return np;
	}	
	
	
}
	
	public class LocationDemo
	{
		
	public static void main(String[] args)
	{
		Location city=new Location();
		String tar=city.setWelcome("chennai");
		System.out.println("result is"+tar);
	}
		
	}