import java.util.*;
class Twodimensional
{
	public static void main(String[] args)
	{
		int[][]studentdetail=new int[11][6];
		
		int[] marks=new int[10];
		System.out.println("Enter the student details rollno and marks one by one");
		
        for (int i=0; i<= 10; i++)
        {
			int total=0;
			studentdetail[i][0]=Console.readInt();
			
            for (int j=1; j<=5; j++)
            {
                studentdetail[i][j] = Console.readInt();
                total=studentdetail[i][j]+total; 
                 marks[j]=studentdetail[i][j];			 
            }
			System.out.println("rollno"+studentdetail[i][0]);
			for(int j=1;j<=5;j++)
			{
				System.out.println("mark"+j+"="+marks[j]);
			}
			System.out.println("total="+total);
			System.out.println("average="+(total/5));
			
        }
    }
}
