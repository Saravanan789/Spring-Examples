
import java.util.*;
class Copyarray
{
	public static void main(String[] args)
	{
		int[] array1={10,20,30,40,50};
	System.out.println(Arrays.toString(array1));
		int[] array2=array1;
	System.out.println(Arrays.toString(array2));
	}
}