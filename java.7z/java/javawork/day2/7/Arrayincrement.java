import java.util.*;
class Arrayincrement
{
	public static void main(String[] args)
	{
		int[] arr1={10,20,30,40,50,60,70,80,90,100};
		System.out.println("arr1"+Arrays.toString(arr1));
		int[] arr2=arr1;
		System.out.println("arr1"+Arrays.toString(arr2));
	      arr2[3]=arr2[3]*2;
		  arr2[7]=arr2[7]*2;
		  arr2[9]=arr2[9]*2;
		  System.out.println("arr1"+Arrays.toString(arr1));
		  System.out.println("arr1"+Arrays.toString(arr2));
	}
}