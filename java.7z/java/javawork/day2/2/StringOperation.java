class StringOperation
{
	public static void main(String[] args)
	{
		System.out.println("Exatracting Substring");
		String str="Java is platform independent";
		System.out.println("\nsub string(0,4)="+str.substring(0,4)+"\nsubstring(6,8)="+str.substring(5,7)+"\nsubstring(10,17)="+str.substring(8,16)+"\nsubstring(19,29)="+str.substring(17,28));
		System.out.println("the lenth of string is="+str.length());
		System.out.println("concatenated string is"+str+"also object oriented");
		System.out.println("the first occurance of p"+str.indexOf('p'));
	}
}
