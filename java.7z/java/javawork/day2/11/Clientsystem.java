 class ClientSystem
{
public static void main(String args[])
{
	String[][] client={{"saravanan","979067790"},{"vishnu","987558768"},{"mr.dgxhd","7777777558"},{"ms.sarn","4647880890"},{"mr.arun","6438749873"},{"ashoke","4654"},{"ms.uihihioio","8765657777"},{"mr.kamal","368668"},{"hdiuhdi","43747449848"},{"shsshsijo","7439408489"},{"mr.dgxhd","7777777558"},{"ms.sat","9809876545"},{"mr.sekar","7549759808"},{"ms.fghsf","4674789409"},{"mr.vijay","8937373890"},{"huddijoiss","74897399388"},{"vinay","65894748933"},{"vignesh","97547798798"},{"mr.vimal","748588589"},{"mr.surya","7590485675"}};
	for(int i=0;i<20;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(client[i][0].substring(0,3).equalsIgnoreCase("Mr.")||client[i][0].substring(0,3).equalsIgnoreCase("Ms."))
			{
				int count=0;
				count++;
			}
			else
			{
				System.out.println("please provide the gender");
				String gender=Console.readString();
				if(gender.equalsIgnoreCase("Male"))
				{
					client[i][0]="Mr."+client[i][0];
				}
				else if(gender.equalsIgnoreCase("Female"))
				{
					client[i][0]="Ms."+client[i][0];
				}
				else
				{
					System.out.println("wrong array");
				}
			}
			}
			if(client[i][1].length()!=10)
			{
				do
				{
				System.out.println("please enter correct phone number");
				client[i][1]=Console.readString();
				}while(client[i][1].length()!=10);
			}
		}
		for(int i=0;i<20;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("\t"+client[i][j]);
			}
		}
	}
	
}
				
				
			
			
			
			
			
			