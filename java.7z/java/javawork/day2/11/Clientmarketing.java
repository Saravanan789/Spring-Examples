class Clientmarketing
{
	String name;
	int mnumber;
	public void setCheck(String name,int mnumber)
	{
		this.name=name;
		this.mnumber=mnumber;
		String check=name.subString(0,3);
		if(check.equls("mr");
		{    
		else if(check.equals("ms")
		{
		else
			System.out.println("provide gender detail");
		    setc
		