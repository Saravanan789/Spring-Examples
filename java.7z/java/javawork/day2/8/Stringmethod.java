 class Stringmethod
 {
   public static void main(String args[])
   {
     String name1 = new String("Saravanan");    
     String name  = "Vijay";                      
   
     String name1welcome = name1 + " welcome";   
     String name2 = new String("Saravanan");
    
     System.out.print("name1 == name2 is ");
     System.out.print( name1 ==  name2);

     System.out.print("\n name1 equals name2 is "); 
     System.out.print( name1.equals( name2));

     String name3 = "Saravanan";
     System.out.print("\n name1 == name3 is ");      
     System.out.print( name1 ==  name3);

     String name4 = "Saravanan";
     System.out.print("\n name3 == name4 is ");      
     System.out.print( name3 ==  name4);

     String wiseMan = "kumar";
     wiseMan.toUpperCase();

    
     System.out.println("\n wiseMan.equals(\"KUMAR\") " + wiseMan.equals("KUMAR"));   
  
     System.out.println("\n wise man again is " + wiseMan);

 	
   }
 }
