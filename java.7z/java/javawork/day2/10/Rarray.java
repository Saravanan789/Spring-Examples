import java.util.*;
class Rarray
{
	public static void main(String[] args)
	{
		int[][]myarray={{33,71},{3,5,6,7,8},{19,45,87,90,100}};
		System.out.println("Array element"+Arrays.deepToString(myarray));
	}
}

			            