class Person
{
	String name;
	String gender;
	int age;
	String city;
	public Person()
	{
	}
	public Person(String name,String gender,int age,String city)
	{
		this.name=name;
		this.gender=gender;
		this.age=age;
		this.city=city;
	}
	
	
	
	
	
	public class Persondemo
	{
		
		