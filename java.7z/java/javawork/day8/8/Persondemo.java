class Person extends Thread
{
	String name;
	String gender;
	int age;
	String city;
	public Person()
	{
	}
	public Person(String name,String gender,int age,String city)
	{
		this.name=name;
		this.gender=gender;
		this.age=age;
		this.city=city;
	}
	public void run()
	{
		System.out.println(Thread.currentThread());
	}
	public String toString()
	{
		
		return "name"+name;
	}
}
	
	
	
	
	public class Persondemo
	{
		public static void main(String[] args)
		{
			Person[] p=new Person[3];
				p[0]=new Person("saravanan","male",21,"chennai");
		        p[1]=new Person("arun","male",21,"chennai");
		        p[2]=new Person("kamal","male",21,"chennai");
		p[0].start();
		p[1].start();
		p[2].start();
		}
		
	}
	
	
		