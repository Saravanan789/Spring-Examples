import java.io.IOException;
class Box extends Thread
{
	int height;
	int width;
	public Box()
	{
	}
	public Box(int height,int width)
	{
		this.height=height;
		this.width=width;
		 setDaemon(true);
		
	}
	public void run()
 {
	  Box n2=new Box(50,60);
	  //n2.setDaemon(true);
	   n2.start();
	 if(Thread.currentThread().isDaemon())
	 {
		 System.out.println("deamon thread");
	 }
	 else
	 {
		 System.out.println("user thread");
	 }
	 
			 System.out.println(height);
			 System.out.println(width);
		 
 }
}
 public class Threadanother
 {
	 public static void main(String[] args)
	 {
		 Box n1=new Box(10,20);
		
		  //n1.setDaemon(true);
		 n1.start();
		
		 
		 
		 
		
	 }
 }
		 
	 
	 
	 
	 
	 
	 