class Mythread extends Thread
{
	String title;
	String name;
 public Mythread()
 {
 }
 public Mythread(String title,String name)
 {
	 this.title=title;
	 this.name=name;
 }
 public void run()
 {
 }
 System.out.println("title"+title+"Name"+name)
 
 
 publlic class Mythreaddemo
 {
	 public static void main(String[] args)
	 {
		 