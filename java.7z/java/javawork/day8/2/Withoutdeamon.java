import java.io.IOException;
class Mythread extends Thread
{
	String title;
	String name;
 public Mythread()
 {
 }
 public Mythread(String title,String name)
 {
	 this.title=title;
	 this.name=name;
	
 }
 public void run()
 {
	 try
	 {
		 while(true)
		 {
			 System.out.println(title);
			 sleep(1000);
			 System.out.println(name +"\n");
		 }
	 }
 
 catch(InterruptedException e)
 {
	 System.out.println(title + name + e);
 }
}
}
	 
	 
	 
	 
 
 
 
 
 public class Withoutdeamon
 {
	 public static void main(String[] args)
	 {
		 Mythread t1=new Mythread("mr","saravanan");
		 Mythread t2=new Mythread("ms","aaaaaaa");
		 
		 t1.start();
		 t2.start();
		 try
		 {
			 System.in.read();
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		 System.out.println("ending of main()");
	 }
 }