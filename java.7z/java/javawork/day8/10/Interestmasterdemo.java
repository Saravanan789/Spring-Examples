class Interestmaster 
{
	public static void main(String[] args)
	{
		
	int p,n,r;
	r=Console.readInt();
	n=Console.readInt();
	r=Console.readInt();
	Intcalculate k=new Intcalculat(p,n,r);
	k.start();
	System.out.println(Amount());
	}
}
class Intcalculat extends Thread
{
	int p,n,r;
	public Intcalculat()
	{
	}
	public Intcalculat(int p,int n,int r)
	{
		this.p=p;
		this.n=n;
		this.r=r;
	}
	public void run()
	{
		int amount=p*n*r;
	}
	public int Amount()
	{
		return amount;
	}
	
}
		
		