import java.io.IOException;
class Intcalculate extends Thread
{
	int p,n,r;
	double amount;
	public Intcalculate()
	{
	}
	public Intcalculate(int p,int n,int r)
	{
		this.p=p;
		this.n=n;
		this.r=r;
	}
	public void run()
	{
		amount=(double)(p*n*r)/100;
	}
	public double Amount()
	{
		return amount;
	}
	
}
class Interestmaster 
{
	public static void main(String[] args)
	{
		
	int p,n,r;
	p=Console.readInt();
	n=Console.readInt();
	r=Console.readInt();
	Intcalculate k=new Intcalculate(p,n,r);
	k.start();
	
	
	try
		 {
			 System.in.read();
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		 System.out.println("ending of main()");
		 System.out.println(k.Amount());
}
	
}

		
		