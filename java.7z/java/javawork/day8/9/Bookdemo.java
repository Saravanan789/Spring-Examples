import java.io.IOException;
class Book extends Thread
{
	String name;
	public Book()
	{
	}
	public Book(String name)
	{
		this.name=name;
	}
	
	public void run()
	{
		if(Bookdemo.totalBookIssued<3)
		{
			
		  issueBook();
		  System.out.println(name);
		}
		else
		{
			
			Thread.currentThread().stop();
		}
	}
	public void issueBook()
	{
		
		Bookdemo.totalBookIssued++;
		
	}
}
public class Bookdemo
{
	public static int totalBookIssued=0;
	public static void main(String[] args)
	{
	Book b1=new Book("book1");
	b1.start();
	Book b2=new Book("book2");
	b2.start();
	Book b3=new Book("book3");
	b3.start();
	Book b4=new Book("book4");
	b4.start();
	Book b5=new Book("book5");
	
	
	
	
	b5.start();
	 try
		 {
			 System.in.read();
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		System.out.println("exceed limit"+totalBookIssued);

	}
	
}
	
	
	
	


