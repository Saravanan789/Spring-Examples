class Hello implements Runnable
{
	String word1;
	String word2;
	
	public Hello(String word1,String word2)
	{
		this.word1=word1;
		this.word2=word2;
	}
	public void run()
	{
		try
		{
			while(true)
			{
				System.out.println(word1);
				Thread.sleep(1000);
				System.out.println(word2);
			}
		}
		catch(InterruptedException e)
		{
			System.out.println(word1 + word2);
		}
	}
	
}
public class Hellodemo
{
	public static void main(String[] args)
	{
		
	Hello a=new Hello("good","boy");
	Thread a1=new Thread(a);
	Hello b=new Hello("bad","boy");
	Thread b1=new Thread(b);
	a1.start();
	b1.start();
	}
}

	
	
	
	
	
	