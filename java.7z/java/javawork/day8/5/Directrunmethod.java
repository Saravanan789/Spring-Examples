import java.io.IOException;
class Mythread extends Thread
{
	String title;
	String name;
 public Mythread()
 {
 }
 public Mythread(String title,String name)
 {
	 this.title=title;
	 this.name=name;
	 setDaemon(true);
 }
 public void run()
 {
	 int i=0;
	 try
	 {
		 while(i<4)
		 {
			 System.out.println(title);
			 sleep(1000);
			 System.out.println(name +"\n");
			 i++;
		 }
	 }
 
 catch(InterruptedException e)
 {
	 System.out.println(title + name + e);
 }
}
}
	 
	 
	 
	 
 
 
 
 
 public class Directrunmethod
 {
	 public static void main(String[] args)
	 {
		 Mythread t1=new Mythread("mr","saravanan");
		 Mythread t2=new Mythread("ms","aaaaaaa");
		 
		 t1.run();
		 t2.run();
		 try
		 {
			 System.in.read();
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		 System.out.println("ending of main()");
	 }
 }
	//if you give directlt acccess the run it becoms multiprocessing its like method access here normal prigram
		 
		 
		 