import java.io.IOException;
class Box extends Thread
{
	int height;
	int width;
	public Box()
	{
	}
	public Box(int height,int width)
	{
		this.height=height;
		this.width=width;
		
	}
	public void run()
 {
	 if(Thread.currentThread().isDaemon())
	 {
		 System.out.println("deamon thread");
	 }
	 else
	 {
		 System.out.println("user thread");
	 }
	 
			 System.out.println(height);
			 System.out.println(width);
		 
 }
}
 public class Boxthread
 {
	 public static void main(String[] args)
	 {
		 Box n1=new Box(10,20);
		 Box n2=new Box(50,60);
		  n1.setDaemon(true);
		 n1.start();
		 n2.start();
		 
		 
		 
		
	 }
 }
		 
	 
	 
	 
	 
	 
	 