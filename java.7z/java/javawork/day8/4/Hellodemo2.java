import java.io.IOException;
class Hello implements Runnable
{
	String word1;
	String word2;
	
	public Hello(String word1,String word2)
	{
		this.word1=word1;
		this.word2=word2;
		
	}
	public void run()
	{
		try
		{
			while(true)
			{
				
				System.out.println(word1);
				for(int i=0;i<=1000;i++);
				System.out.println(word2);
			}
		}
		catch(InterruptedException e)
		{
			System.out.println(word1 + word2);
		}
	}
	
}
public class Hellodemo2
{
	public static void main(String[] args)
	{
		
	Hello a=new Hello("good","boy");
	Thread a1=new Thread(a);
	Hello b=new Hello("bad","boy");
	Thread b1=new Thread(b);
	a1.setDaemon(true);
	b1.setDaemon(true);
	a1.start();
	b1.start();
	 try
		 {
			 System.in.read();
		 }
		 catch(IOException e)
		 {
			 System.out.println(e);
		 }
		 System.out.println("ending of main()");
	}
}

	
	
	
	
	
	