class AcceptDetail2
{
	public static void main(String[] args)
	{
		String name=args[0];
		System.out.println(" welcome to training"+args[0]);
	}
}