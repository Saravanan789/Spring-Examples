package p2;
import p1.*;
public class Object
{
	public static void main(String[] args)
	{
		FirstPrint s=new FirstPrint();
		s.setPrint();
	}
}