 class Student3
{
	int rollno;
	String name;
	String course;
	String college;
	public void setRollno(int rollno)
	{
		this.rollno=rollno;
	}
	public int getRollno()
	{
		return rollno;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setCourse(String course)
	{
		this.course=course;
	}
	public  String getCourse()
	{
		return course;
	}
	public void setCollege(String college)
	
	{
		this.college=college;
	}
	public String getCollege()
	{
		return college;
	}
	public void printDetail()
	{
		System.out.println("rollno is "+getRollno()+"name is="+getName()+"course is"+getCourse()+"college is"+getCollege());
	}
}
	
	public class Student3Demo
	{
		public static void main(String[] args)
		{
			Student3 s1;
			Student3 s2;
			Student3 s3;
			Student3 s4;
			s1=new Student3();
			s2=new Student3();
			s3=new Student3();
			s4=new Student3();
			s1.setRollno(101);
			s1.setName("saran");
			s1.setCourse("B.E");
			s1.setCollege("stjosep");
			s1.printDetail();
			s2.setRollno(102);
			s2.setName("vinoth");
			s2.setCourse("B.e");
			s2.setCollege("sathayabama");
			s2.printDetail();
			s3.setRollno(103);
			s3.setName("ajith");
			s3.setCourse("b.tech");
			s3.setCollege("annauni");
			s3.printDetail();
			s4.setRollno(104);
			s4.setName("arun");
			s4.setCourse("B.sc");
			s4.setCollege("vvit");
			s4.printDetail();
		}
	}
	
	
	
	
	
	
	
	
	
	