public class StudentDemo
{
	public static void main(String[] args)
	{
		CollegeName cn=new CollegeName();
		CollegeCode cc=new CollegeCode();
		Location lo=new Location();
		DurationTime dt=new DurationTime();
		ManagingDirector md=new ManagingDirector();
		NoOfStaff nos=new NoOfStaff();
		NoOfStudent non=new NoOfStudent();
		CourseName crn=new CourseName();
		NoOfBranch nob=new NoOfBranch();
		CourseFee cf=new CourseFee();
		cn.setName("st.joseph college");
		cc.setCode(3124103);
		lo.setLocation("navalur");
		dt.setTime("7.30-3.00");
		md.setName("babumanaogar");
		nos.setStaff(200);
		non.setStudent(2000);
		crn.setName("engineering");
		nob.setBranch(7);
		cf.setFee(84000);
		System.out.println("colllege detail\nname ="+cn.getName()+"\nCODE="+cc.getCode()+"\nlocation="+lo.getLocation()+"\nname of md="+md.getName()+"\nduration time="+dt.getTime()+"\nno of staff="+nos.getStaff()+"\nno of student="+non.getStudent()+"\ncourse name="+crn.getName()+"\nno of branch="+nob.getBranch()+"\ncourse fee="+cf.getFee());
	}
}
		
		