class NoOfStaff
{
	private int no;
	public void setStaff(int no)
	{
		this.no=no;
	}
	public int getStaff()
	{
		return no;
	}
}
