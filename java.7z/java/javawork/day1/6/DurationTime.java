class DurationTime
{
	private String time;
	public void setTime(String time)
	{
		this.time=time;
	}
	public String getTime()
	{
		return time;
	}
}
