class NoOfStudent
{
	private int no;
	public void setStudent(int no)
	{
		this.no=no;
	}
	public int getStudent()
	{
		return no;
	}
}