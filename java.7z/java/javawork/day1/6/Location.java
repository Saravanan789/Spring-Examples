class Location
{
  private String loc;
	public void setLocation(String loc)
	{
		this.loc=loc;
	}
	public String getLocation()
	{
		return loc;
	}
}