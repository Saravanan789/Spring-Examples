class CourseFee
{
	private int fee;
	public void setFee(int fee)
	{
		this.fee=fee;
	}
	public int getFee()
	{
		return fee;
	}
}