class NoOfBranch
{
  private int numb;
  public void setBranch(int numb)
  {
    this.numb=numb;
  }
  public int getBranch()
  {
	  return numb;
  }
}