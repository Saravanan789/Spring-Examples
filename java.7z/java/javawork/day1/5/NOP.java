class NOP
{
private int num;
public void setNOP(int num)
{
this.num=num;
}
public int getNOP()
{
return num;
}
}