public class Detail
{
	public static void main(String[] args)
	{
		Train tr;
		Station st;
		Staff sf;
		Dtime dt;
		Atime at;
		NOC nc;
		NOP np;
		TrainType tt;
		Speed sp;
		Tprice tp;
		tr=new Train();
		st=new Station();
		sf=new Staff();
        dt=new Dtime();
        at=new Atime();
		nc=new NOC();
		np=new NOP();
		tt=new TrainType();
		sp=new Speed();
		tp=new Tprice();
		tt.setType("Express");
		tr.setName("NELLAI Express");
		nc.setNOC(289);
		np.setNOP(1000);
		dt.setTime(7.30f);
		at.setTime(9.30f);
		sp.setSpeed(130);
		tp.setPrice(25);
		st.setName("chengalpattu");
		sf.setId(101);
		System.out.println("end");
		System.out.println("\nname="+tr.getName()+"\ntype="+tt.getType()+"\nstation="+st.getName()+"\nstaff id="+sf.getId()+"\ndeparture time="+dt.getTime()+"\narrival time="+at.getTime()+"\nno of compart="+nc.getNOC()+"\nno of passanger="+np.getNOP()+"\nspeed="+sp.getSpeed()+"\nticket price="+tp.getPrice());
	}
}
		