class NOC
{
 private int number;
public void setNOC(int number)
{
this.number=number;
}
public int getNOC()
{
return number;
}
}