 class Dtime
{
	private float time;
	public void setTime(float time)
	{
		this.time=time;
	}
	public float getTime()
	
	{
		return time;
	}
}