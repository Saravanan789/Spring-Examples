class City
{
String name;
int population;
int nocl;
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return name;
}
public void setPopulation(int population)
{
this.population=population;
}
public int getPopulation()
{
return population;
}
public void setNoofcollege(int nocl)
{
this.nocl=nocl;
}
public int getNoofcollege()
{
return nocl;
}
public void printdetail()
{
System.out.println("name is"+getName()+"population"+getPopulation()+"no of collge"+getNoofcollege());
}
}
public class City4Demo
{
public static void main(String[] args)
{
	City c1;
	City c2;
	City c3;
	City c4;
 c1=new City();
 c2=new City();
 c3=new City();
 c4=new City();
 c1.setName("chennai");
 c1.setPopulation(1000);
 c1.setNoofcollege(5);
 c1.printdetail();
 c2.setName("navalur");
 c2.setPopulation(2000);
 c2.setNoofcollege(78);
 c2.printdetail();
 
 c3.setName("delhi");
 c3.setPopulation(6000);
 c3.setNoofcollege(56);
 c3.printdetail();
 
 c4.setName("dubai");
 c4.setPopulation(5799);
 c4.setNoofcollege(987);
 c4.printdetail();
 
 }
 }













