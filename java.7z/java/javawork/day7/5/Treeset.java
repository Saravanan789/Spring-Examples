import java.util.*;
public class Treeset 
{
	public static void main(String[] args)
	{
		SortedSet emp=new TreeSet();
		emp.add(new Employee("saran",101));
		emp.add(new Employee("vimal",102));
		emp.add(new Employee("arun",103));
		emp.add(new Employee("kamal",104));
		emp.add(new Employee("vijay",105));
		emp.add(new Employee("ajith",106));
		emp.add(new Employee("vishnu",107));
		emp.add(new Employee("ajith",106));
		System.out.println("tree set sorted by employee number");
		System.out.println(emp);
	

	
	  
}	}

		
class Employee implements Comparable
{
	int empno;
	String name;
	public Employee(String name,int empno)
	{
		this.empno=empno;
		this.name=name;
	}
	public String toString()
	{
		return "\nemployee no="+empno+"employee name"+name;
	}
	public boolean equals(Object other)
	{
		if(getClass()==other.getClass())
		{
			Employee otherEmployee=(Employee)other;
			return name.equals(otherEmployee.name)&&empno==otherEmployee.empno;
		}
		else
		{
			return false;
		}
	}
	public int hashCode()
	{
		return 13*name.hashCode()+17 * empno;
	}
	public int compareTo(Object other)
	{
		Employee otherEmployee=(Employee)other;
		return empno-otherEmployee.empno;
	}
	
	
}