class Employee implements Comparable
{
	int empno;
	String name;
	public Employee(String name,int empno)
	{
		this.empno=empno;
		this.name=name;
	}
	public String toString()
	{
		return "\nemployee no="+empno+"employee name"+name;
	}
	
}