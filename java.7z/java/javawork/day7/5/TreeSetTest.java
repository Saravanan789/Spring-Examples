
import java.util.*;

public class TreeSetTest
{  public static void main(String[] args)
   {  SortedSet parts = new TreeSet();     // SortedSet is an abstract class
      parts.add(new Item("Toaster", 1234));
      parts.add(new Item("Modem", 9912));

      System.out.println();
      System.out.println("Tree set sorted by partno...");
      System.out.println(parts);

      SortedSet sortByDescription = new TreeSet(
         new Comparator()
         {  public int compare(Object a, Object b)
            {  Item itemA = (Item)a;
               Item itemB = (Item)b;
               String descrA = itemA.getDescription();
               String descrB = itemB.getDescription();
               return descrA.compareTo(descrB);
            }
         });

      sortByDescription.addAll(parts);

      System.out.println();
      System.out.println("Tree set sorted by description...");
      System.out.println(sortByDescription);
   }
}

class Item implements Comparable
{  public Item(String aDescription, int aPartNumber)
   {  description = aDescription;
      partNumber = aPartNumber;
   }

   public String getDescription()
   {  return description;
   }

   public String toString()
   {  return "\n {descripion=" + description
         + ", partNumber=" + partNumber + "}";
   }

   public boolean equals(Object other)
   {  if (getClass() == other.getClass())
      {  Item otherItem = (Item)other;
         return description.equals(otherItem.description)
            && partNumber == otherItem.partNumber;
      }
      else
         return false;
   }

   public int hashCode()
   {  return 13 * description.hashCode() + 17 * partNumber;
   }

   public int compareTo(Object other)
   {  Item otherItem = (Item)other;
      return partNumber - otherItem.partNumber;
   }

   private String description;
   private int partNumber;
}

