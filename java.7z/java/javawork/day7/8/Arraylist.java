import java.util.*;

class Arraylist{
	public static void main(String[] args)
	{
		List l=new ArrayList(20);
		l.add(20);
		l.add(20);
		l.add(20);
		l.add(20);
		l.add(20);
		l.add(20);
		l.add(20);
		l.add(20);
		
		System.out.println(l);
		System.out.println(l.size());
	}
}