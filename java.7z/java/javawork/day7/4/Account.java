 import java.util.*;
import java.io.*;

abstract class Account1
{
 int accountno;
 String customername;
 String customeraddress;
 double balanceamt;
int  rate;
double amt;
public Account1(int accountno,String customername,String customeraddress,double balanceamt,int rate)
{
	this.amt=amt;
	this.accountno=accountno;
	this.customername=customername;
	this.customeraddress=customeraddress;
	this.balanceamt=balanceamt;
	this.rate=rate;



}
   public Account1(double amt)
   {
	   this.amt=amt;
   }
}
class Savingaccount extends Account1
{
	public Savingaccount(int accountno,String customername,String customeraddress,double balanceamt,int rate)
	{
	  super(accountno,customername,customeraddress,balanceamt,rate);
	}
	public String toString()
	{
		return "\nname="+customername+"accountno="+accountno+"balance amount="+balanceamt;
	}
}

	
class Currentaccount extends Account1
{
	public Currentaccount(int accountno,String customername,String customeraddress,double balanceamt,int rate)
	{
	  super(accountno,customername,customeraddress,balanceamt,rate);
	}
	public String toString()
	{
		return "\nname="+customername+"accountno="+accountno+"balance amount="+balanceamt;
	}

}
class Deposite extends Account1
{
	public Deposite(double amt)
	{
		super(amt);
	}
	public String toString()
	{
		return "deposite amt"+amt;
	}
}
	
	
	

public class Account
{
	public static void main(String[] args)
	{
		Set<Account1> a=new <Account1>HashSet();
		a.add(new Savingaccount(12345,"saravanan","chennai",27898,6));
		a.add(new Currentaccount(45678,"vishnu","t nagar",70000,8));
		a.add(new Deposite(29999));
		a.add(new Currentaccount(45678,"vishnu","t nagar",70000,8));
		a.add(Currentaccount(45678,"vishnu","t nagar",70000,8));
		
		System.out.println(a);
		
		
	}
}











 	