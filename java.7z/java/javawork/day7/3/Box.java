class Box
{
	String name;
	int height;
	int width;
	public Box(String name,int height,int width)
	{
		this.name=name;
		this.height=height;
		this.width=width;
	}
	public String toString()
	{
		return "\nname="+name+"height="+height+"width="+width;
	}
	public void print()
	{
		System.out.println("name"+name+"height"+height+"width"+width);
	}
}
	