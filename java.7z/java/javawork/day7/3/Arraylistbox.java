import java.util.*;
class Arraylistbox
{
	public static void main(String[] args)
	{
		ArrayList a=new ArrayList();
		a.add(new Box("box1",10,10));
		a.add(new Box("box2",20,20));
		a.add(new Box("box3",30,30));
		a.add(new Box("box4",40,40));
		a.add(new Box("box5",50,50));
		System.out.println(a);
		System.out.println(a.get(2));
		a.set(2,new Box("box new",110,110));
		System.out.println(a);
	}
}
		