import java.util.*;
public class Linkedlistcollection
{
	public static void main(String[] args)
	{
		List a=new LinkedList();
		a.add(new Dog("tiger",5));
		a.add(new Dog("tige",9));
		a.add(new Book("wings",1));
		a.add(new Box(10,20));
		System.out.println(a);
		System.out.println(a.get(0));
		System.out.println("for String object");
		List<String> b=new LinkedList<String>();
		b.add("1");
		b.add("boo2");
		b.add("box3");
		System.out.println(b);
	}
}