class Book 
{
	String bname;
	int bid;
public Book(String bname,int bid)
{
	this.bname=bname;
	this.bid=bid;
}
public void print()
{
	System.out.println("book name"+bname+"book id"+bid);
}
public String toString(){

 return bname + "   " + bid;
 }

}