class Dog
{
	String name;
	int age;
	public Dog (String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public void print()
	{
		System.out.println("name"+name+"age"+age);
		
	}
	public String toString()
	{

       return name +" "+ age;
     }

}