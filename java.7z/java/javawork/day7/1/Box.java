class Box 
{
	int height;
	int width;
public Box(int height ,int width)
{
	this.height=height;
	this. width= width;
}
public void print()
{
	System.out.println("box height"+height+"box width"+width);
}
public String toString(){

 return height +" "+ width;
 }

}