import java.util.*;
public class Insertionlist
{
	public static void main(String[] args)
	{
		List a=new LinkedList();
		a.add(new Dog("tiger",5));
		a.add(new Book("wings",1));
		a.add(new Box(10,20));
		a.add("4th element");
		System.out.println("before insertion");
		System.out.println(a);
		a.set(2,"saravanan");
		System.out.println("after insertion");
		System.out.println(a);
		a.remove(3);
		System.out.println("after deletion");
		System.out.println(a);
		
	}
}
class Dog
{
	String name;
	int age;
	public Dog (String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public void print()
	{
		System.out.println("name"+name+"age"+age);
		
	}
	public String toString()
	{

       return name +" "+ age;
     }

}
class Box 
{
	int height;
	int width;
public Box(int height ,int width)
{
	this.height=height;
	this. width= width;
}
public void print()
{
	System.out.println("box height"+height+"box width"+width);
}
public String toString(){

 return height +" "+ width;
 }

}
class Book 
{
	String bname;
	int bid;
public Book(String bname,int bid)
{
	this.bname=bname;
	this.bid=bid;
}
public void print()
{
	System.out.println("book name"+bname+"book id"+bid);
}
public String toString(){

 return bname + "   " + bid;
 }

}