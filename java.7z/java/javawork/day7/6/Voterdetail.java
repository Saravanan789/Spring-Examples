import java.util.*;
class Voterdetail
{
	public static void main(String[] args)
	{
		TreeMap ad=new TreeMap();
		ad.put("1",new Address(11,"a street","chennai",603102));
		ad.put("2",new Address(22,"b street","chennai",603103));
		ad.put("3",new Address(33,"v street","chennai",603106));
		ad.put("2",new Address(44,"s street","chennai",603107));
		ad.put("4",new Address(55,"i street","chennai",603109));
		ad.put("6",new Address(66,"p street","navalur",603102));
		System.out.println(ad);
	}
}
class Address
{
	
	int doorno;
	String street;
	String city;
	int pin;
	public Address(int doorno,String street,String city,int pin)
	{
		
		this.doorno=doorno;
		this.street=street;
		this.city=city;
		this.pin=pin;
	}
	public String toString()
	{
		return "\ndoor no"+doorno+"street"+street+"city"+city+"pin"+pin;
	}
}