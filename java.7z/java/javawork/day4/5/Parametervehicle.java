class Vehicle
{
	String type;
	String name;
	String make;
	int price;
	
	public Vehicle()
	{
	}

public Vehicle(String name,String type)
{
	this.type=type;
	this.name=name;
	
	System.out.println(type+"----"+name);
}
public  void speed()
{
  System.out.println("max or min");
}
}
 class Scooter extends Vehicle
{
	public Scooter(String type,String make)
	{
		this.type=type;
		this.make=make;
			System.out.println(type+make);
	}
		
  public void speed()
  {
	  System.out.println("max1");
  }
}
 class Bike extends Vehicle
{
  public void speed()
  {
	  System.out.println("max2");
  }
}
 class Car extends Vehicle
{
  public void speed()
  {
	  System.out.println("max3");
  }
}

public class Parametervehicle
{
	public static void main(String[] args)
	{
		Vehicle v=new Vehicle("yamaha","r15");
		v.speed();
		Scooter s=new Scooter("herohonda","steel");
		s.speed();
		Bike b=new Bike();
		b.speed();
		Car c=new Car();
		c.speed();
	}
}










