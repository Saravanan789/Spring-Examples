class Savingclass
{
	int sbNo;
	String clientName;
	double acbalance;
	int period;
	public void setAccno(int sbNo)
	{
		this.sbNo=sbNo;
	}
	public int get()
	{
		return sbNo;
	}
	public void setClientname(String clientName)
	{
		this.clientName=clientName;
	}
	public String getClientname()
	{
		return clientName;
	}
	public void setAbalance(double acbalance)
	{
		this.acbalance=acbalance;
	}
	public double getAbalance()
	{
		return acbalance;
		
	}
	public void setPeriod(int period)
	{
		this.period=period;
	}
	public int getPeriod()
	{
		return period;
	}
	public void Deposite(double depositeAmt)
	{
		acbalance=depositeAmt+acbalance;
	}
	public void Deposite(double depositeAmt,int period1)
	{
		acbalance=acbalance+depositeAmt;
		period=period1;
	}
	public void printDetail()
	{
		System.out.println("sbno="+sbNo+"client name="+clientName+"Balance account="+acbalance+"\nperiod="+period);
	
	}
}
	public class Savingclassdemo
	{
		public static void main(String[] args)
		{
			Savingclass s=new Savingclass();
			s.setAccno(1234567);
			s.setClientname("saravanan");
			s. setAbalance(65000);
			s.setPeriod(6);
			s.printDetail();
			s.Deposite(200000);
			s.Deposite(100000,8);
			s.printDetail();
		}
	}
			
		
		
		
		