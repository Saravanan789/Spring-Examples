class Monitor
{
	
	
	
}
class Colormonitor extends Monitor
{
	public void display()
	{
		
	System.out.println("COLOR MONITOR DISPLAY");
	
	}
}
class Monomonitor extends Monitor
{
	public void display()
	{
	
	System.out.println("MONO MONITOR DISPLAY");
	}
	
}
class LEDmonitor extends Monitor
{
	public void display()
	{
	System.out.println("LED MONITOR DISPLAY");
	}
	
	
}
class Monitortest
{
	
	public static void test(Monitor m)
	{
		m.display();
	}
	
	
	
}
pucblic class Monitortestdemo
{
	public static void main(String[] args)
	{
		
		Monitor m1=new Monitor();
		Colormonitor m2=new Colormonitor();
		Monomonitor m3=new Monomonitor();
		LEDmonitor m4=new LEDmonitor();
		 Monitortest.test(m2);
		
		
		
	}
}
	
	
	
	
	
	