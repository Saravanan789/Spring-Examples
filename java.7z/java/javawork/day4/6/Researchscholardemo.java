class Student
{
	private int studentid;
	int grant=3000;
	public double computeGrant()
	{
		grant=grant+1000;
		return grant;
		
	}
}
		
		
 class Researchscholar extends Student
 {
	 public double computeGrant()
	{
	  return super.computeGrant();
	  
	}
 }
 
 public class Researchscholardemo
 {
	 public static void main(String[] args)
	 {
		 Researchscholar r=new Researchscholar();
		 System.out.println("total amount="+r.computeGrant());
	 }
 }