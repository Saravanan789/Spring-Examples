import java.util.*;
class MarkList
{
	int rollno;
	int year;
	int[] mark=new int[5];
	public void setRollNo(int rollno)
	{
		this.rollno=rollno;
	}
	public int getRollNo()
	{
		return rollno;
	}
	public void setYear(int year)
	{
		this.year=year;
	}
	public int getYear()
	{
		return year;
		
	}
	public void setMark(int mark,int i)
	{

		this.mark[i]=mark;
	}
	public int[] getMark()
	{
		return this.mark;
		
	}
	public void check()
	{
		if(rollno>=1000)
		{
			year=year+1;
			for(int i=0;i<5;i++)
			{
				mark[i]=mark[i]+10;
			}
		}
		else
		{
			year=0;
			for(int i=0;i<5;i++)
			{
				mark[i]=0;
			}
			
		}
			
	}
	
	public void printdetail()
	{
		System.out.println("\nrollno="+rollno+"\nyear="+year+"\nmarks="+Arrays.toString(mark));
		
	}
}
	public class Marklistdemo
	{
		public static void main(String[] args)
		{
			MarkList m=new MarkList();
			m.setRollNo(10000);
			m.setYear(1998);
			System.out.println("enter the marks");
			for(int i=0;i<5;i++)
			{
			  int g=Console.readInt();
			  m.setMark(g,i);
			}
			m.printdetail();
			m.check();
			m.printdetail();
		}
	}