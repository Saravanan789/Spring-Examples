class Vehicle
{
	String type;
	String brand;
	String name;
	int price;
	


public final void speed()
{
  System.out.println("max or min");
}
}
 class Scooter extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
 class Bike extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
 class Car extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}

public class Vehicledemo
{
	public static void main(String[] args)
	{
		Vehicle v=new Vehicle();
		v.speed();
		Vehicle s=new Scooter();
		s.speed();
		Vehicle b=new Bike();
		b.speed();
		Vehicle c=new Car();
		c.speed();
	}
}










