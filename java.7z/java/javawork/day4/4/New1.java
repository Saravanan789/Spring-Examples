class Vehicle
{
	String type;
	String brand;
	String name;
	int price=100;
public void speed()
{
  System.out.println("max or min");
}
}
 class Scooter extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
 class Bike extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
 class Car extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}

public class New1
{
	public static void main(String[] args)
	{
		Vehicle v=new Vehicle();
		v.speed();
		Scooter s=new Scooter();
		s.speed();
		System.out.println((((Vehicle) s)).price);
		Bike b=new Bike();
		b.speed();
		Car c=new Car();
		c.speed();
	}
}










