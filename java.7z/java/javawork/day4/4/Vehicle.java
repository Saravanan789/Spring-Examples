class Vehicle
{
	String type;
	String brand;
	String name;
	int price;
	
public vehicle(String type,String brand,String name,int price)
{
     this.type=type;
     this.brand=brand;
     this.name=name;
     this.price=price;
}
public void speed()
{
  System.out.println("max or min");
}
}
public class Scooter extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
public class Bike extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}
public class Car extends Vehicle
{
  public void speed()
  {
	  System.out.println("max1");
  }
}

public class Vechiledemo()
{
	public static void main(String[] args)
	{
		Vehicle v=new Vehicle();
		v.speed();
		Scooter s=new Scooter();
		s.speed();
		Bike b=new Bike();
		b.speed();
		Car c=new Car();
		c.speed();
	}
}










