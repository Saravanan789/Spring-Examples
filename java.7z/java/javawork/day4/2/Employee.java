class Employee
{
	int empno;
	String name;
	String job;
	double salary;
	int deptno;
	public Employee(int empno,String name,String job,double salary,int deptno)
	{
		this.name=name;
		this.empno=empno;
		this.job=job;
		this.salary=salary;
		this.deptno=deptno;
		
		
	}
	public Employee(int empno,String name,String job)
	{
		this(empno,name,job,20000,23);
	}
	public Employee(int empno,int deptno)
	{
		this(empno,"saravanan","se",56777,deptno);
	}
	public Employee(String name,String job)
	{
		this(12,name,job,89000,45);
	}
	public void updateSal(int percent)
	{
		salary=salary*(percent/100);
	}
	public void updateSal(double additionalsal)
	{
		salary=salary+additionalsal;
	}
	public void updateSal(int deptno1,int percent)
	{
		if(this.deptno=deptno1)
		{
			salary=salary*(percent/100);
		}
		else
		{
			salary=0;
		}
	}
	public void updateSal()
	{
		salary=salary+100;
	}
public void printdetail()
{
	System.out.println("Employee name="+name+"\nEmployee number="+empno+"\njob="+job+"\nsalary="+salary+"\nDepartment="+deptno);
}
}
public class Employeedemo
{
	public static void main(String[] args)
	{
		Employee e=new(1,"vimal","ceo");
		e.updateSal(2000);
		e.updateSal(300000.0);
		e.updateSal(11,1000);
		e.printdetail();
		Employee e1=new(1,20);
		e1.updateSal(2000);
		e1.updateSal(300000.0);
		e1.updateSal(20,1000);
		e1.printdetail();
		Employee e2=new("vimal","ceo");
		e2.updateSal(2000);
		e2.updateSal(300000.0);
		e2.updateSal(45,1000);
		e2.printdetail();
	}
}
		
	
	
	
	
	
	
	
	
	
	