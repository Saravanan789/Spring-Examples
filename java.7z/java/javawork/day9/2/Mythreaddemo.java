 
class Mythread extends Thread
{
	public Mythread()
	{
	}
	public void run()
	{
		
			for(int i=1;i<=10000;i++)
		       {
				    if (Thread.interrupted()) 
			          {
						  int j=i;
				        System.out.println("is interupted");
						while(j<i+10)
						{
							 System.out.println(j);
							 j++;
						}
						return;
					  }
			     System.out.println(i);
		        }
			
		}
		
	}

public class Mythreaddemo
{
	public static void main(String[] args)
	{
		Mythread m1=new Mythread();
		
		m1.start();
		try
		{
			System.in.read();
			m1.interrupt();
		}
		catch(Exception ex)
		{
			System.out.println("end main");
		}
	}
}
