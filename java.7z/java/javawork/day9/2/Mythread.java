class Mythread
{
	public Mythread()
	{
	}
	public void run()
	{
		for(int i=1;i<=10000;i++)
		{
			System.out.println(i);
		}
	}
}
public class Mythreaddemo
{
	public static void main()
	{
		Mythread m1=new Mythread()
		m1.start();
		m1.interupt();
	}
}
