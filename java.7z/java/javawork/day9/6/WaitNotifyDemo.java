// demontrates inter-thread communication

import java.io.*;

class Stock
{
	public int availableqty = 100;
	synchronized void issuebook(int qty)
	{
		boolean proceedissuebook= false; 
		while(proceedissuebook== false)
		{ 
			try
			{
				if (getQty()<= qty)
				{
					System.out.println("\n\n available qty"+getQty() + " issue qty =   "+qty + " so waiting for issue");
					wait();
                     				continue;
                   }		
 			}
			catch(InterruptedException ie)
			{
                      		ie.printStackTrace();
             } 
             proceedissuebook= true;
 		} 
		System.out.println("issueing="+qty);
         setQty(getQty() - qty); 
  	}

	synchronized void receivebook(int qty)
	{
		System.out.println("\n receiving " + qty);
		setQty(getQty() + qty);
		notifyAll(); 
	}
   
	int getQty()
	{
		return availableqty;
	}

  	void setQty(int qty)
	{
       		availableqty = qty;
 	 }
}

class Stock1 extends Thread
{ 
	Stock stock;
	Stock1(Stock stock, String name)
	{
		super(name);
		this.stock = stock;
	}

	public void run()
	{
		//System.out.println(currentThread().getName());
		String runningThread = currentThread().getName();
			if (runningThread.equals("jh1")){
				stock.issuebook(110);
			}
 			else
			{
     				stock.receivebook(40);

 			}
 	}

}

class WaitNotifyDemo{
	public static void main(String args[]) throws IOException, InterruptedException{
		Stock stock = new Stock ();
		Stock1 jh1 = new Stock1(stock,"jh1");
		Stock1 jh2 = new Stock1(stock,"jh2");
		jh1.start();
		jh2.start(); 
		jh1.join();
		jh2.join(); 
		System.out.println("\nThe final qty after issueing =  " +stock.getQty());

		}
}

