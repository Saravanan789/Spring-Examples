class Train extends Thread
{
	int speed;
	String name;
	public Train()
	{
	}
	public void run()
	{
		for(int i=0;i<200000;i++)
		{
			 if (Thread.interrupted()) 
			 {
				 return;
				 
			 }
			System.out.println(i);
		}
	}
}
public class Traindemo
{
	public static void main(String[] args)
	{
		Train t1=new Train();
		t1.start();
		try
		{
		  Thread.sleep(50);
		  t1.interrupt();
		}
		catch(Exception e)
		{
			System.out.println("from main()");
		}
		
		

	   
			
			
			
		 
		
	}
}
	
	
	