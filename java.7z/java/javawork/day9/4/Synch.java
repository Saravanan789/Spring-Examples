class Withdraw extends Thread
{
	int balance=4000;
	int amt;
	public Withdraw()
	{
	}
	
	public Withdraw(int amt)
	{
		this.amt=amt;
	}
	
	
	public void run()
	{
		Deposite();
	}
	public void Deposite()
	{
		balance=balance+amt;
		System.out.println("balance"+balance);
	}
}
	public class Synch
	{
		public static void main(String[] args)
		{
			Withdraw w1=new Withdraw(1000);
			Withdraw w2=new Withdraw(2000);
			Withdraw w3=new Withdraw(4000);
			
			w1.start();
			w2.start();
			w3 .start();
		}
	}