


import java.io.*;


class Account{
 
  private int balance = 2000;

   void withdraw(int amount){
    
       int currentBalance = getBalance();
 
          if (currentBalance >= amount){
             setBalance(currentBalance - amount);
            }
          else {
               System.out.println("the withdrawl amount has exceeded the current balance");
               }
    }

  int getBalance(){
    
    try{
        Thread.sleep(1000);
       }
    catch(Exception e){
    
        e.printStackTrace();
    }
   return balance;
  }

  void setBalance(int amount){
  
     balance = amount;
   
   }
}

class JointHolder extends Thread{ 
   
    Account account;

  JointHolder(Account account, String name){
    super(name);
    this.account = account;
    }

  public void run(){
   try{
        
           synchronized(account){
           account.withdraw(600);
           }
       }
      catch(Exception e){
         e.printStackTrace();
      }
  }

}
class SynchBlockDemo1 {
   
  public static void main(String args[]) throws IOException, InterruptedException{
  Account account = new Account();

  JointHolder jh1 = new JointHolder(account,"jointHolder1");
  JointHolder jh2 = new JointHolder(account,"jointHolder2");
  
  jh1.start();
  jh2.start(); 
  
  jh1.join();
  jh2.join(); 
  
  System.out.println(account.getBalance());

  }
}
//with synchronizartion code block

