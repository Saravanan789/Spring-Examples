Thread.MIN_PRIORITY 1
Thread.NORM_PRIORITY 5
Thread.MAX_PRIORITY 10


t1.setPriority(Thread.MAX_PRIORITY)


class Box extends Thread
{
	String name;
	int length;
	int breadth;
	int height;
	int v;
	public Box()
	{
	}
	public Box(String name,int length,int breadth,int height)
	{
		this.name=name;
		this.length=length;
		this.breadth=breadth;
		this.height=height;
	}
	public void Volume()
	{
		v=length*breadth*height;
		System.out.println("name"+name+"volume"+v);
	}
	public void run()
	{
		Volume();
	}
}
public class Boxdemo()
{
	public static void main(String[] args)
	{
		Box b1=new Box("box1",10,20,30);
		Box b2=new Box("box2",40,20,60);
		t1.setPriority(Thread.MAX_PRIORITY)
		