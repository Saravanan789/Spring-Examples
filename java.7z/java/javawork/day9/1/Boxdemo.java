
class Box extends Thread
{
	String name;
	int length;
	int breadth;
	int height;
	int v;
	public Box()
	{
	}
	public Box(String name,int length,int breadth,int height)
	{
		this.name=name;
		this.length=length;
		this.breadth=breadth;
		this.height=height;
	}
	public void Volume()
	{
		v=length*breadth*height;
		System.out.println("name"+name+"volume="+v);
	}
	public void run()
	{
		Volume();
	}
}
public class Boxdemo
{
	public static void main(String[] args)
	{
		Box b1=new Box("box1",10,20,30);
		Box b2=new Box("box2",40,20,60);
		Box b3=new Box("box3",50,80,20);
		b2.setPriority(Thread.MAX_PRIORITY);
		b1.setPriority(Thread.MIN_PRIORITY);
		b3.setPriority(Thread.NORM_PRIORITY);
		b1.start();
		b2.start();
		b3.start();
		System.out.println(b1.getPriority());
		
	}
}
		