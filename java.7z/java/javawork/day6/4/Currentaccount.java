class Currentaccount
{
	public static void main(String args[])
	{
		
	System.out.println("enter the withdraw amount");
	int w=Console.readInt();
	

	
		try
		{
			if(w>20000)
			{
				throw new LimitExceededException(w);
			}
			else
			{
				System.out.println("withdraw successfully");
			}
		}
		
		catch(LimitExceededException e)
		{
			e.getReport();
		}
		
	}
}

class LimitExceededException extends Exception
{
	int wa;
	public  LimitExceededException(int wa)
	{
		this.wa=wa;
	}
	public void getReport()
	{
		System.out.println("limit exceed");
	}
	
}