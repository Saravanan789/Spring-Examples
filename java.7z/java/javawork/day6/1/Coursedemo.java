class Course
{
	String name;
	int coursecode;
	int coursefee;
	
	public Course(String name,int coursecode,int coursefee)
	{
		setName(name);
		setCourseCode(coursecode);
		setCourseFee(coursefee);
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setCourseCode(int coursecode)
	{
		this.coursecode=coursecode;
	}
	public int getCourseCode()
	{
		return coursecode;
	}
	public void setCourseFee(int coursefee)
	{
		this.coursefee=coursefee;
	}
	public int getCourseFee()
	{
		return coursefee;
	}
	public void print()
	{
		System.out.println("\nname"+name+"\ncourse code"+coursecode+"\nCourse fee"+coursecode);
	}
}

public class Coursedemo
{
	public static void main(String[] args)
	{
		try
		{
		int j=Integer.parseInt(args[1]);
		int k=Integer.parseInt(args[2]);

		
		Course c=new Course(args[0],j,k);
		c.print();
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array index out of bound");
		}
		catch(NumberFormatException b)
		{
			System.out.println("number format exception");
		}
	}
}
		