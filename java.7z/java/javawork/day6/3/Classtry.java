class Classtry
{
	public static void main(String args[])
	{
		try
		{
	
		check();
		System.out.println("After the handling");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
	}
		
		public static void check() throws ClassNotFoundException
		{
			Class d=Class.forName("java.lang.Ineger");
		}	
}