class LpgCylinder
{
	public static void main(String args[])
	{
		int[] consumerno={101,102,103,104};
		int[] cap={8,6,5,9};
		System.out.println("\n enter the consumer no");
		int cn=Console.readInt();
		try
		{
			for(int i=0;i<4;i++)
			{
				if(cn==consumerno[i])
				{
					if(cap[i]>7)
					{
						throw new RefillQuotaExceededException(consumerno[i],cap[i]);
					}
					else
					{
						refillrequest(consumerno[i],cap[i]);
						break;
						
						
					}
				}
			}
		}
		catch(RefillQuotaExceededException e)
		{
			e.getErrordetail();
		}
	}
	public static void refillrequest(int n,int c)
	{
		char ch;
		int count;
		do
		{
			
			System.out.println("do you want to refill y/n");
			ch=Console.readChar();
			System.out.println("enter the refill increment value");
			count=Console.readInt();
			
			if((ch=='y')&&(count<=2))
			{
				c=c+count;
			}
			
			
			
			
		}while(c<=7);
		System.out.println("refill successfully completed");
		
		 
		
		
	}
}
class RefillQuotaExceededException extends Exception
{
	int cono;
	int capacity;
	public  RefillQuotaExceededException(int cono,int capacity)
	{
		this.cono=cono;
		this.capacity=capacity;
	}
	public void getErrordetail()
	{
		System.out.println("RefillQuotaExceeded for consumerno"+cono);
	}
}
		
	
	
		