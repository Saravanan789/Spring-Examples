class Arrayexception
{
	
	public static void main(String[] args)
	{
		String[] s=new String[4];
	try
		{
		int j=Integer.parseInt(args[1]);
		int k=Integer.parseInt(args[2]);

		
		Course c=new Course(args[0],j,k);
		
	
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			
			String s1=e.getMessage();
			s[0]=s1;
		}
			try
			{
				int k=Integer.parseInt("hai");

				
				
			}
			
		catch(Exception e1)
		{
		      String s2=e1.getMessage();
			s[1]=s2;
		}
		try
			{
				
				int j=10/0;
				
			}
		catch(ArithmeticException e2)
		{
			String s3=e2.getMessage();
			s[2]=s3;
		}
		try
		{
			String r=null;
			int p=r.length();
		}
		catch(Exception e3)
		{
			String s4=e3.getMessage();
			s[3]=s4;
		}
		for(int i=0;i<4;i++)
	    {
		System.out.println("error=  "+s[i]);
	     }
		
	}
	
}
class Course
{
	String name;
	int coursecode;
	int coursefee;
	
	public Course(String name,int coursecode,int coursefee)
	{
		this.name=name;
		this.coursecode=coursecode;
		this.coursefee=coursefee;
		
	}
}