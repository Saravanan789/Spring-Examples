import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class Insertitem
{
	public static void main(String[] args)
	{
		try
		{
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:127.0.0.1:1521:orcl","student","student");
			String query="insert into Item_maste values(?,?,?)";
			PreparedStatement pt=con.prepareStatement(query);
			int item_code=Integer.parseInt(args[0]);
			String item_name=args[1];
			int quantity=Integer.parseInt(args[2]);
			pt.setInt(1,item_code);
			pt.setString(2,item_name);
			pt.setInt(3,quantity);
			pt.executeUpdate();
			pt.close();
			con.close();
		}
		catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
	}
}