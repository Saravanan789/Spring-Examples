
import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;
public class Querytable
{
	public static void main(String[] args)
	{
	try
	{
		Connection con=getConnection();
		String query="delete from item_maste where item_code=?";
		PreparedStatement pt=con.prepareStatement(query);
		int item_code=Integer.parseInt(args[0]);
		pt.setInt(1,item_code);
		pt.executeUpdate();
		pt.close();
		con.close();
	}
	catch (Exception e)
	{
		System.out.println("erroroccured");
	}
	}
	public static Connection getConnection() throws SQLException,IOException   
	{
		Properties p=new Properties();
		String filename="updateParams.properties";
		FileInputStream in=new FileInputStream(filename);
		p.load(in);
		String driver=p.getProperty("jdbc.drivers");
		if(driver!=null)
			 System.setProperty("jdbc.drivers",driver);
			String url=p.getProperty("jdbc.url");
			String username=p.getProperty("jdbc.username");
			String password=p.getProperty("jdbc.password");
			return DriverManager.getConnection(url,username,password);
		}
		
	
}