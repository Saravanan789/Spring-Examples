//Simple JDBC program that demonstrates creating a table

import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class SimpleDB
{  public static void main (String args[])
   {  /*
         try {

            Class.forName("oracle.jdbc.driver.OracleDriver");

        } 
            catch (ClassNotFoundException cnf) {

            cnf.printStackTrace();
        }
*/
try{
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:127.0.0.1:1521:orcl","student","student");


         Statement stmt = con.createStatement();
         
         String command = "create table Stu(id number(10), name varchar2(30))";
          
                           System.out.println("command is:  " + command);
         stmt.executeUpdate(command);
                           System.out.println("command executed successfully");
         stmt.close();
         con.close();
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
      
   }

}



