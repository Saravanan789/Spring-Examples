import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;
public class Itemmas
{
	public static void main (String args[])
   {  
	try
	{
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:127.0.0.1:1521:orcl","student","student");
        Statement st=con.createStatement();
		String Command="create table Item_Maste(Item_code number(5),item_name varchar(20),quantity number(12,2))";
		System.out.println("the command is"+Command);
		st.executeUpdate(Command);
		System.out.println("command executed successfully");
		st.close();
		con.close();
	}
	catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
}
}
		
		