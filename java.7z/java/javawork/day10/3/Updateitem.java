import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class Updateitem
{
	public static void main(String[] args)
	{
		try
		{
		Connection con=getConnection();
		String query="update item_maste set quantity=? where item_code=?";
		PreparedStatement pt=con.prepareStatement(query);
		int quantity=Integer.parseInt(args[0]);
		int item_maste=Integer.parseInt(args[1]);
		pt.setInt(1,quantity);
		pt.setInt(2,item_maste);
		pt.executeUpdate();
		pt.close();
		con.close();
		}
		catch (Exception ex)
      { /* System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
		  */
      }
	}
	  public static Connection getConnection() throws SQLException,IOException   
	  {
		  Properties probs=new Properties();
		  String fileName="updateParams.properties";
		  FileInputStream in=new FileInputStream(fileName);
		  probs.load(in);
		  String drivers=probs.getProperty("jdbc.drivers");
		  if(drivers!=null)
			  System.setProperty("jdbc.drivers",drivers);
		  String url=probs.getProperty("jdbc.url");
		  String username=probs.getProperty("jdbc.username");
		  String password=probs.getProperty("jdbc.password");
		  return DriverManager.getConnection(url,username,password);
	  }
	
		  
		  
		  
		  
		  
		  
		  
		  
	  
	}
	