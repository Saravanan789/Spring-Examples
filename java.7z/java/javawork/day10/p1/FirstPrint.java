package p1;
public class FirstPrint
{
	public void setPrint()
	{
		System.out.println("i can access you");
	}
}