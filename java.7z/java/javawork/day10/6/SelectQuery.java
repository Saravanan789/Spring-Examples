
import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;
public class SelectQuery
{
	public static void main(String[] args)
	{
	try
	{
		Connection con=getConnection();
		String query="select * from ? where item_code=?";
		PreparedStatement pt=con.prepareStatement(query);
		int item_code=Integer.parseInt(args[0]);
		String table=args[1];
		pt.setInt(2,item_code);
		pt.setInt(1,table);
		pt.executeUpdate();
		ResultSet rs = pt.executeQuery();
      ResultSetMetaData rsmd = rs.getMetaData();
      int columnCount = rsmd.getColumnCount();
      while (rs.next())
	  {
		  for(int i=1;i<=columnCount;i++)
		  {
			  
			  System.out.println(rsmd.getColumnName(i)+""+rs.getString(i));
			  
		  }
	  }
			  
		pt.close();
		con.close();
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
	}
	public static Connection getConnection() throws SQLException,IOException   
	{
		Properties p=new Properties();
		String filename="updateParams.properties";
		FileInputStream in=new FileInputStream(filename);
		p.load(in);
		String driver=p.getProperty("jdbc.drivers");
		if(driver!=null)
			 System.setProperty("jdbc.drivers",driver);
			String url=p.getProperty("jdbc.url");
			String username=p.getProperty("jdbc.username");
			String password=p.getProperty("jdbc.password");
			return DriverManager.getConnection(url,username,password);
		}
		
	
}
	
	