var obj = {
	methodA : function() {
		console.log('Outer this is '+this); 
		function inner() {
			console.log('Inner this is '+this); 
		}
		inner(); 
	}
}
obj.methodA();

var obj = {
	methodA : function() {
		console.log('Outer this is '+this); 
		var that = this;
		function inner() {
			console.log('Inner this is '+that); 
		}
		inner(); 
	}
}
obj.methodA();


var obj = {
	methodA : function() {
		console.log('Outer this is '+this); 
		inner = function() {
			console.log('Inner this is '+this); 
		}.bind(this);
		inner(); 
	}
}
obj.methodA();