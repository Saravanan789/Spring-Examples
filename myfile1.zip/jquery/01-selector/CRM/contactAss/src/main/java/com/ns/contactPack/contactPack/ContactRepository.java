package com.ns.contactPack.contactPack;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactRepository extends JpaRepository<ContactDetails,String> {

}
