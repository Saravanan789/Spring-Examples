$(document).ready(function(){
    //Get
    $("#getAllContacts").click(function(event){
        event.preventDefault();
        alert("get ready called");
        ajaxGet();
    });
    //Post
    $('#contactForm').submit(function(event){
        event.preventDefault();
        ajaxPost();
    });
  })
function ajaxGet(){
        $.ajax({
            type:"GET",
            url:window.location+"/all",
            success:function(result){
                if(result.status=="Done"){
                    $('#getResultContacts ul').empty();
                    var contList="";
                    $.each(result.data,function(i,contact){
                        var conta="id "+i+" contactname "+contact.personName+"<br>";
                        $('#list').append(conta)
                      });
                  }
                  else{
                      $("#getResultContacts").html("<strong>Error</strong>");
                      $('#getResultContacts').text("Error");
                  }
                },
                error:function(e){
                    $("#getResultContacts").html("<strong>Error</strong>");
                    $('#getResultContacts').text("Error");
                }
            });
        }
function ajaxPost(){
    var formData={
        personName: $('#personName').val(),
        personPhone:$('#personPhone').val(),
        personEmail:$('#personEmail').val()
    }
    $.ajax({
        type:"POST",
        contentType:"application/json",
        url:window.location+"/save",
        data:JSON.stringify(formData),
        dataType:'json',
        success:function(result){
            if(result.status=="Done"){
                alert("Added successfully"+JSON.stringify(formData));
            }
            console.log(result);
        },
        error:function(e){
            alert("Error")
            console.log("Error:",e);
        }
    });
    resetData();
}
function resetData(){
    $('#contactName').val("");
    $('#phoneNo').val("");
    $('#eMail').val("");
}
