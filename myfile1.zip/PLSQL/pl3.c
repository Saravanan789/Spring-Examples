
(Covers Advanced Cursors)


1. Write a PL/SQL program which identifies those employees who have null and  zero commission and inserts the empno and comm (null or zero) of those rows  into an  error_table (to be created with a single column - error_text   varchar2(100)), using  cursor parameter for deptno.
(Treat zero and null comm as two different exceptions and insert them
 accordingly).
 
 
 declare
  cursor emp_cur(e_deptno number) is select * from emp where deptno=e_deptno;
	z exception;
	n exception;
	  
	  
	begin
	    for emp_rec in emp_cur(10)
		loop
		   begin
		       if emp_rec.comm=0 then
			         raise Z;
				end if;
				if emp_rec.comm is NULL then
			         raise N;
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emp_rec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emp_rec.comm|| 'it is null');
				end;
			end loop;
		 for emp_rec in emp_cur(20)
		loop
		   begin
		       if emp_rec.comm=0 then
			         raise Z;
				end if;
				if emp_rec.comm is NULL then
			         raise N;
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emp_rec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emp_rec.comm|| 'it is null');
				end;
			end loop;	
		 for emp_rec in emp_cur(30)
		loop
		   begin
		       if emp_rec.comm=0 then
			         raise Z;
				end if;
				if emp_rec.comm is NULL then
			         raise N;
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emp_rec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emp_rec.comm|| 'it is null');
				end;
			end loop;	
		end;			 			 	
					 
				
				
	
 
 
 
 
 
 

2. Write a PL/SQL program which processes the dept 30 rows as follows: Those who have joined in FEB will get an increase of 10%, SEP-20%, DEC 25% and MAY- 5%. Update the emptable with the new salary. Ensure no other user modifies these rows while your program is executing. Test  this by creating another session and attempt to update these rows.
// we cannot update the value when it use;
declare
  cursor emp_cur is select * from emp where deptno=30 for update;
	  
	begin
	    for emp_rec in emp_cur
		loop
		   begin
		       if emp_rec.hiredate like '%FEB%' then
			         emp_rec.sal:=emp_rec.sal+(0.1*emp_rec.sal);
				elsif emp_rec.hiredate like '%SEP%' then
			         emp_rec.sal:=emp_rec.sal+(0.2*emp_rec.sal);
				ELSIF emp_rec.hiredate like '%DEC%' then
			         emp_rec.sal:=emp_rec.sal+(0.25*emp_rec.sal);
				ELSIF emp_rec.hiredate like '%MAY%' then
			         emp_rec.sal:=emp_rec.sal+(0.05*emp_rec.sal);
				end if;	 
				   -- UPDATE emp SET SAL=emp_rec.sal where empno=emp_rec.empno;
					
				end;
			end loop;
	end;		





3. Create a cursor with a  join of emp and dept tables. Your PL SQL program will update the sal of the employees based on deptno for dept 20 alone. Ensure you lock emp table only. Test the lock status of the rows in emp and dept through another session. For testing purposes, remove the commit in your code temporarily.

declare
  cursor emp_cur is select y.deptno,sal,empno from emp x,dept y where x.deptno=y.deptno for update;
	  
	begin
	    for emp_rec in emp_cur
		loop
		  begin
		         if emp_rec.deptno=20 then
		       emp_rec.sal:=emp_rec.sal+100;
			   
			   end if;
			   end;
	     end loop;
	end;














4. Using a ref cursor,  increment the salary of the emp (your emp table), based on deptno. In the same program, use the same ref cursor to access the material receipts table and reduce 10% quantity towards evaporation/ wastage in transit. Execute the program verify the output.

DECLARE
v_emp_rec emp%ROWTYPE;
v_dept_rec materialreceipt%ROWTYPE;

TYPE ref_cur_type IS REF CURSOR;
ref_cur ref_cur_type;
BEGIN
	DBMS_OUTPUT.PUT_LINE('*** Accessing EMP table ***');
OPEN ref_cur FOR SELECT * FROM emp WHERE deptno=30;
LOOP
FETCH ref_cur into v_emp_rec;
EXIT WHEN ref_cur%NOTFOUND;

update emp set sal=v_emp_rec.sal+100 where empno=v_emp_rec.empno;
END LOOP;
CLOSE ref_cur;

DBMS_OUTPUT.PUT_LINE('*** Accessing materialreceipt table ***');
OPEN ref_cur FOR SELECT * FROM materialreceipt;
LOOP
FETCH ref_cur into v_dept_rec;
EXIT WHEN ref_cur%NOTFOUND;
update materialreceipt set qty=v_dept_rec.qty-(v_dept_rec.qty*0.1) where itemcode=v_dept_rec.itemcode;;
END LOOP;
CLOSE ref_cur;
END;   












5. Rewrite the above program by making the cursor as a strongly typed cursor and observe the behaviour of the program.


DECLARE
v_emp_rec emp%ROWTYPE;
v_dept_rec materialreceipt%ROWTYPE;

TYPE ref_cur_type IS REF CURSOR
return emp%rowtype;
ref_cur ref_cur_type;
BEGIN
	DBMS_OUTPUT.PUT_LINE('*** Accessing EMP table ***');
OPEN ref_cur FOR SELECT * FROM emp WHERE deptno=30;
LOOP
FETCH ref_cur into v_emp_rec;
EXIT WHEN ref_cur%NOTFOUND;

update emp set sal=v_emp_rec.sal+100 where empno=v_emp_rec.empno;
END LOOP;
CLOSE ref_cur;

DBMS_OUTPUT.PUT_LINE('*** Accessing materialreceipt table ***');
OPEN ref_cur FOR SELECT * FROM materialreceipt;
LOOP
FETCH ref_cur into v_dept_rec;
EXIT WHEN ref_cur%NOTFOUND;
update materialreceipt set qty=v_dept_rec.qty-(v_dept_rec.qty*0.1);
END LOOP;
CLOSE ref_cur;
END;  


ERROR at line 20:
ORA-06550: line 20, column 18:
PLS-00382: expression is of wrong type
ORA-06550: line 20, column 1:
PL/SQL: SQL Statement ignored
ORA-06550: line 22, column 1:
PLS-00394: wrong number of values in the INTO list of a FETCH statement
ORA-06550: line 22, column 1:
PL/SQL: SQL Statement ignored

strongly connected means a reference cursor can address only the reference table;
it used for multiple table access by using single cursor




