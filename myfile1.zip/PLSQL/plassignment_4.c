PL/SQL Assignments – Session 4 

(Covers Procedures, Functions)

1.	Create a procedure to insert into the employee table. This will be called from  SQL and the various column values will be passed to the procedure.
   
    create or replace
	procedure empi(p_empno in number,p_name in varchar2,p_job in varchar2,p_mgr in number,p_hiredate in date,p_sal in number,p_comm in number,p_deptno in number)
     as
	 verr number;
	 vemss varchar2(100);

    begin
	    insert into emp values(p_empno,p_name,p_job,p_mgr,p_hiredate,p_sal,p_comm,p_deptno);
         exception
		 when others then
		 verr := SQLCODE;
		 vemss := SUBSTR(SQLERRM,1,100);
		 insert into error13 values(verr || ' ' || vemss);
		 end;










2.	 Invoke the above procedure from PL/SQL

we hav e to use 
//
begin procedure name(val);
end;
///

    //in the above program we cannot insert new deptno values because emp which act as an child of parent dept.so that we can insert only deptno
	which is present in depatrtment table;

3.	Create a procedure which accepts deptno and increment_amount  and updates  the emp table.


    create or replace
	procedure empinc(p_deptno number,p_inc number)
	as
	verr number;
	vemss varchar2(100);
	begin
	   update emp set sal=sal+p_inc where deptno=p_deptno;
	exception
		 when others then
		 verr := SQLCODE;
		 vemss := SUBSTR(SQLERRM,1,100);
		 insert into error13 values(verr || ' ' || vemss);
		 end;

	
	
	
	
	

4.	Create another version of the above procedure with invoker privileges. Grant execute permission to scott. Connect as scott and invoke this procedure. Observe the outcome.



    create or replace
	procedure empinc(p_deptno number,p_inc number)
	as
	verr number;
	vemss varchar2(100);
	begin
	   update emp set sal=sal+p_inc where deptno=p_deptno;
	exception
		 when others then
		 verr := SQLCODE;
		 vemss := SUBSTR(SQLERRM,1,100);
		 insert into error13 values(verr || ' ' || vemss);
		 end;
student
SQL> alter user scott account unlock;

User altered.

SQL> grant execute on empinc to scott;

Grant succeeded.
scott:
Enter user-name: scott
Enter password:
ERROR:
ORA-28001: the password has expired


Changing password for scott
New password:
Retype new password:
SP2-0650: New passwords do not match
Password unchanged
Enter user-name: scott
Enter password:
ERROR:
ORA-28001: the password has expired


Changing password for scott
New password:
Retype new password:
Password changed
 execute student.empinc(30,500);
	
      to grant;
	  grant execute on empupdate to scott;


5.	Convert two of your PL/SQL programs into procedures and execute.
       (Hint: These converted procedures will not accept arguments)
	   
	 

6.	Create a function which returns the number of rows affected by an update   operation . Invoke it from SQL and later from PL/SQL.
       Hint: Use implicit cursor attribute.
	   create or replace function update1(p_deptno number,p_sal number)
	   return number
	   is
	   coun number(3);
	   begin
	        update emp set sal=sal+p_sal where deptno=p_deptno;
			coun:=sql%rowcount;
			return coun;
	end;
			
			
			 variable isal number
SQL> execute:isal:=update1(30,100);

PL/SQL procedure successfully completed.

SQL> print isal;

      ISAL
----------
         6
	   
	   
	   
	   
	   

7.	Create a function which updates stock of a given item with the given quantity  and  returns the updated value of stock.

create or replace function disquan(p_itemcode in number,p_qty number)
return number
is
count1 number(3);
begin
   update stock1 set qty=p_qty where itemcode=p_itemcode;
   select qty into count1 from stock1 where itemcode=p_itemcode;
   return count1;
   end;




8.	Create a function f_bonus which fetches the bonus details from the bonus table. The function should accept an empno and return the  bonus amount. Call this function through a SELECT statement (on emp table)  to display the employee details and bonus.

   create or replace function f_bonus(f_empno  number)
   return number
   is
   bonusv number(13);
   begin
   select bonus_amt into bonusv from bonus where empno=f_empno;
   return bonusv;
   end;



9.	Create  stored procedure which accepts a refcursor  of emp%rowtype and  incrementpercent as arguments. It will increment the sal in emp based on the second argument.  Invoke this procedure from another procedure which passes the appropriate arguments. Print the details and verify. Hint : define  strongly typed cursor in  a package and use it for this assignment.

10.	Create a table Associate (id, name, city, designation, office). Write a stored procedure which accepts these values as arguments and inserts into the table. City and office will have CHENNAI and ADYAR as default parameter values respectively. Invoke the procedure using named notation and verify the results.

  create or replace PROCEDURE(p_id number,p_name varchar2,p_city varchar2:='CHENNAI',p_desination varchar2,p_office varchar2='ADAYAR')
  AS


  BEGIN
       INSERT INTO ASSOCIATE values(p_id,p_name,p_city,p_designation,p_office);
	   exception
   end;




