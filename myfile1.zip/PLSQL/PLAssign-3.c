(Covers Advanced Cursors)1. Write a PL/SQL program which identifies those employees who have null and  zero commission and inserts the empno and comm (null or zero) of those rows  into an  error_table (to be created with a single column - error_text   varchar2(100)), using  cursor parameter for deptno.(Treat zero and null comm as two different exceptions and insert them accordingly).
 
 
 declare
  cursor emp_rec(e_deptno number) is select * from emp where deptno=e_deptno;
 cursor emp_cur is select empno,comm,sal from emp;
    v_empno number;
	v_comm number;
	v_errmsg varchar2(100);
	exception z;
	exception n;
	  
	  
	begin
	    for emp_rec in emp_cur(10)
		loop
		   begin
		       if emp.rec.comm=0 then
			         raise Z
				end if;
				if emp.rec.comm is NULL then
			         raise N
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emprec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emprec.comm|| 'it is null');
				end;
			end loop;
		 for emp_rec in emp_cur(20)
		loop
		   begin
		       if emp.rec.comm=0 then
			         raise Z
				end if;
				if emp.rec.comm is NULL then
			         raise N
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emprec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emprec.comm|| 'it is null');
				end;
			end loop;	
		 for emp_rec in emp_cur(30)
		loop
		   begin
		       if emp.rec.comm=0 then
			         raise Z
				end if;
				if emp.rec.comm is NULL then
			         raise N
				end if;
				
				EXCEPTION
				WHEN Z THEN
				     INSERT into error10 values(emprec.comm|| ' it is zero');
				when n then 
                     insert into error11 values(emprec.comm|| 'it is null');
				end;
			end loop;	
		end;			 			 	
					 
				
				
	
 
 
 
 
 
 2. Write a PL/SQL program which processes the dept 30 rows as follows: Those who have joined in FEB will get an increase of 10%, SEP-20%, DEC 25% and MAY- 5%. Update the emptable with the new salary. Ensure no other user modifies these rows while your program is executing. Test  this by creating another session and attempt to update these rows.3. Create a cursor with a  join of emp and dept tables. Your PL SQL program will update the sal of the employees based on deptno for dept 20 alone. Ensure you lock emp table only. Test the lock status of the rows in emp and dept through another session. For testing purposes, remove the commit in your code temporarily.4. Using a ref cursor,  increment the salary of the emp (your emp table), based on deptno. In the same program, use the same ref cursor to access the material receipts table and reduce 10% quantity towards evaporation/ wastage in transit. Execute the program verify the output.5. Rewrite the above program by making the cursor as a strongly typed cursor and observe the behaviour of the program.