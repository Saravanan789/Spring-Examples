﻿SQL

Hands-on Assignments – Day 2

Joins


1. Join the employee table and the department table so that your query displays the
   department name for each employee.

2. Design a query on the employee table which displays employee number, name,
    salary,department, manager no, manager name. 
    (Hint: use table aliases).
select x.empno,x.ename,x.sal,x.deptno,y.empno,y.ename manager from emp x,emp y where x.mgr=y.empno;s

3. Design a query on the employee  and department tables which displays the
    name,  no, salary, department no, department name for all employees who are
    not managers.
 select empno,ename,sal,dept.deptno,dept.DNAME, job from emp,dept where job not like 'MANAGER' and emp.deptno=dept.deptno;

4. Design a query on the employee  and department tables which displays the
    name,  no, salary, department no, department name for all employees who do
    not belong to research department.
      select empno,ename,sal,dept.deptno,dept.DNAME, job from emp,dept where DNAME not like 'RESEARCH' and emp.deptno=dept.deptno;

5. Design a query on the employee  and department tables which displays the
    name,  no, salary, department no, department name for all employees whose
    department number is greater than 20.
         select empno,ename,sal,dept.deptno,dept.DNAME, job from emp,dept where emp.deptno>20  and emp.deptno=dept.deptno;

6. Find out those employees who draw more salary than their managers.
    (Hint: Use self join to join the employees row with their respective managers
     and then find out employee.sal > manager.sal in the same query.)
      /select x.ename,x.sal,y.ename,y.sal from emp x,emp y where x.mgr=y.empno and x.sal>y.sal;

7. Create a query which lists the names of the employees, their department names,
    their respective managers along with the department names of those managers.
    (Hint: Use table alias/self join and equi join concepts.)

8. Write a query on emp and dept tables to display the names of the respective
    departments for every employee. In addition the query should also display the
    department nos in the dept table but not in emp table along with the name.
    (Hint: Use outer join.)
      /select x.ename,y.ename,y.deptno from emp x,dept y where x.deptno (+)=y.deptno;

9. Make use of natural join,  left and right outer join  for joining the emp and dept tables    
   after suitable modifications of data






SQL EXPRESSIONS AND DATATYPE FUNCTIONS

1. Display the employee number, name, salary, commission and salary+
    commission for those employees who are salesmen. Name the calculated
    column as ‘Gross’.
\select empno,ename,sal,comm,sal+comm GROSS from emp where job like 'SALESMAN';

2. Display the employee number, name, salary, commission and salary+ 10% of
    salary for those employees who are  not salesmen. Name the calculated column
    as ‘Revised_Pay’.
      \ select empno,ename,sal,comm,sal+0.15*sal revised_pay from emp where job not like 'SALESMAN';

3. Display the employee number, name, salary, commission for those employees
    whose salaries are greater than twice their commission.(Hint: use NVL function) 
        \ select empno,ename,sal,comm, from emp where sal>2*comm;

4. Display the employee number, name, salary, commission and salary multiplied
    by 1.1234  for those employees who are salesmen. (round off the calculated
    column to 2 digits after decimal).
  \select empno,ename,sal,comm,ROUND(sal*1.1234,2)CAL from emp where job like 'SALESMAN';


5. Display the employee number, name, salary, and salary multiplied by 12.975 for
    those employees who are  not salesmen. (truncate the calculated column to 2
    digits after decimal).
\ select empno,ename,sal,comm,TRUNC(sal*1.1234,2)NEWSAL from emp where job NOT like 'SALESMAN';

6. Display the average salary for every department in the employee table. 
 \select deptno,avg(sal) from emp group by deptno;
      
7. Display the total salary, average salary, maximum salary, no of rows and
   department no for every department in a single query.
\select deptno,sum(sal)total,min(sal) min,max(sal) max,count(*) count from emp sal group by deptno;


8. Modify the above query to display only for managers in each department.
\select deptno,sum(sal)total,avg(sal) average,min(sal) min,max(sal) max,count(*) count from emp where job='MANAGER' group by deptno;

9. Select the minimum and maximum salaries and commissions of all the
    employees departmentwise.
select deptno,min(sal) msal,max(sal) msal,min(comm),max(comm),min(comm) from emp group by deptno;

10. Use decode to get the names of the departments from the emp table.
         / select ename,deptno,decode(deptno,10,'sale',20,'acc','others')dname
  2  from emp;

11. Using DECODE display the null values in the comm column as ‘Not
      Applicable’. Values other than NULL should be displayed as such.
       / select ename,decode(comm,null,'notapplicable',comm) COMM  from emp;


12. Display the employee name in lower case,  length of the name and first three
      characters.
    select lower(ename) NAME,vsize(ename)VIZE,substr(ename,0,3)from emp;


13. Display the hiredate from employee in the format mm/dd/yyyy-hh:mi:ss.
 select to_char(hiredate,'mm/dd/yyyy-hh:mi:ss')date_time from emp;

14. Add 15 months to the hiredate in the select statement and display the new date.
        /  select hiredate hdt,ADD_MONTHS(hiredate,15) new from emp;


15. Find the number of months between 15-12-96 and 1-1-98.
/SELECT hiredate,MONTHS_BETWEEN('15-DEC-96','1-JAN-98') Mbet from emp;

16. Find the last date of the month for the hire dates in the employee table  .
   / select last_day(hiredate) from emp;

17. Find the date on which the next Sunday occurs.
/          select next_day(hiredate,'SUN') next_sunday from emp;

18. Design a query which rounds off sysdate to the nearest month, date and year.
/    select round(hiredate,'MM'),round(hiredate,'DD'),round(hiredate,'YY') from emp;

19. Design a query which truncates the sysdate month, date, yearwise respectively.
         select trunc(sysdate,'DD') ,trunc(sysdate,'MM'),trunc(sysdate,'YY') from dual;

20. Select sum of salaries from emp table departmentwise for sum(sal) more than
      twice the sum of comm of the respective departments.
  / select sum(sal) from emp group by deptno having sum(sal)>2*sum(nvl(comm,0));


21. Select sum of salaries of emp table empnowise and observe the results.
    /select sum(sal) from emp group by empno;

22. Find out the managers who draw more than twice/thrice the average salary of
      their subordinates. (Hint: Attempt it after learning about sub queries)
 
23. Display the decimal portion and the integer portion of the number 4345.232.
     /select round(4345.232),mod(4345.232,1) from dual;

24. Replace each occurrence of 'S' and 'A' with 'X' and 'Y' in ename column of emp  	table.
     /select replace(replace(ename,'S','X'),'A','Y') from emp;

25. Display the names of those employees whose name contain the letter 'E'.
    / select ename from emp where ename like '%E%';

26. Display the hiredate of the employees in the specified date format.
      (Hint: 02-JUN-01 as 2nd June of the year 2001)
      /SELECT HIREDATE,TO_CHAR(HIREDATE,'ddth "of" MONTH" of the year" YYYY') from emp;

27. Display the commission of the employees in words.
 SELECT TO_CHAR(TO_DATE(comm,'J'),'JSP') from emp where comm>0;

