import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CarRentalServiceService {


  private baseUrl = 'http://localhost:8080/api/Dealer';


  constructor(private http: HttpClient) { }

  
  AddCar(car: FormData): Observable<Object> {
    
    return this.http.post(`${this.baseUrl}` + `/car`, car);
  }
  
  getCarList(): Observable<any> {
    return this.http.get(this.baseUrl + `/cars`)
  }
  RemoveCarByNumber(carNumber: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/car` + `/${carNumber}`, { responseType: 'text' });
  }
  RemoveCarById(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/car` + `/${id}`, { responseType: 'text' });
  }
  
  UpdateCar(id: number, value: any): Observable<any> {

    // return this.http.put(`${this.baseUrl}/${id}`, value);
    return this.http.put(`${this.baseUrl}` + '/car/' + `${id}`,value);
  }

  getCar(id: number): Observable<any> {
    // return this.http.get(`${this.baseUrl}/${id}`);
    return this.http.get(`${this.baseUrl}` + '/car/' + `${id}`);
  }


  getCustomerList(): Observable<any> {
    return this.http.get(this.baseUrl + `/customers`)
  }


  BookingCar(bookingData: any): Observable<any> {
  
    return this.http.post(`${this.baseUrl}` + `/bookingData`, bookingData);
  }

  getBookingDetailBydealerId(dealerId: number): Observable<any> {


    return this.http.get(`${this.baseUrl}` + '/bookingData/' + `${dealerId}`);

  }

}
