export class CustomerModel{

  userName:String;
  password:String;
  conformPassword:String;
  email:String;
  phoneNumber:String;
  address:String;
  role:String

}