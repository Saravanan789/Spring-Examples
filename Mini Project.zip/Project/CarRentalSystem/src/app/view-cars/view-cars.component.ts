import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CarModel } from '../carModel/carModel';
import { CarRentalServiceService } from '../car-rental-service.service';
import { Router } from '@angular/router';
import { FinalBookingModel } from '../FinalBookingModel/final-booking-model';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-view-cars',
  templateUrl: './view-cars.component.html',
  styleUrls: ['./view-cars.component.css']
})
export class ViewCarsComponent implements OnInit {


  conform:false;
  cars:Observable<CarModel[]>;

  bookingData:FinalBookingModel=new FinalBookingModel()

  constructor(private customerService:CustomerServiceService,private carService:CarRentalServiceService,private routeobject:Router) { }

 
  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.cars = this.carService.getCarList();
  
    
      console.log(this.cars);

  }
  book(car:any){

    console.log(car);
    console.log(car.carId)

    this.bookingData.dealerId=car.dealerId;
    
    this.bookingData.carId=car.carId;
    this.bookingData.carName=car.carName;
     this.bookingData.carNumber=car.carNumber;
     this.bookingData.carImage= car.image;
     localStorage.setItem('costPerKm',JSON.stringify(car.costPerKm));
     

     console.log( this.bookingData.carImage);
     

    this.bookingData.customerId=JSON.parse(localStorage.getItem('customerid'));
    this.bookingData.phoneNumber=JSON.parse(localStorage.getItem('phoneNumber'));
    this.bookingData.email=JSON.parse(localStorage.getItem('email'));
    this.bookingData.pickUpLocation=JSON.parse(localStorage.getItem('pickUpLocation'));
    this.bookingData.dropLocation=JSON.parse(localStorage.getItem('dropLocation'));
    this.bookingData.pickUpDate=JSON.parse(localStorage.getItem('pickUpDate'));
    this.bookingData.dropDate=JSON.parse(localStorage.getItem('dropDate'));
    this.bookingData.pickUpTime=JSON.parse(localStorage.getItem('pickUpTime'));
    this.bookingData.dropTime=JSON.parse(localStorage.getItem('dropTime'));

    console.log(this.bookingData);
    localStorage.setItem('bookingData', JSON.stringify(this.bookingData));

    this.carService.BookingCar(this.bookingData)
    .subscribe(
      data => console.log(data),
     
    )

    this.routeobject.navigate(['/conformationPage']);
    

  }






    



  }

  
// customerId: number


//     phoneNumber: String


//     email: String;




//     carId: number;

//     carName: String;


//     carNumber: String

//     dealerId: number;




//     pickUpLocation: String;



//     dropLocation: String;

//     pickUpDate: String;




//     dropDate: String;



//     pickUpTime: String


//     dropTime: String



