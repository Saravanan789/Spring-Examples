import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomerModel } from '../Customer-model/customer-model';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  signupform:FormGroup;
  customer:CustomerModel;
  ExistingUser= false;
  

  constructor(private customerService:CustomerServiceService) {
   
   }

  ngOnInit() {
   
    this.signupform = new FormGroup({
   
      userName: new FormControl('',Validators.required),
      password: new FormControl('',[Validators.required,Validators.minLength(7)]),
      conformPassword: new FormControl('',[Validators.required,Validators.minLength(7)]),
      email:new FormControl('',[Validators.required,Validators.email]),
      address:new FormControl('',[Validators.required]),
      phoneNumber:new FormControl('',[Validators.required,Validators.minLength(10)]),
      role:new FormControl('',[Validators.required,Validators.minLength(10)])
    })
  }

  onSubmit(){

    this.savedetail();
  }


  //Adding customer
    savedetail(){
      this.customer=this.signupform.value;
      
    this.customerService.AddCustomer(this.customer)
      .subscribe(
        data =>{ console.log(data)
          if(data['errorCode'])
          {
            this.ExistingUser=true;

          }
          else{
            alert('signUp done successFully');
          }
        
        })
   
}
}
