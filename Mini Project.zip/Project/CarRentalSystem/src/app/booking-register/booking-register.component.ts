import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { BookingModel } from '../booking-model/booking-model';
import { CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-booking-register',
  templateUrl: './booking-register.component.html',
  styleUrls: ['./booking-register.component.css']
})
export class BookingRegisterComponent implements OnInit {
  BookingRegisterForm:FormGroup
  bookingData:BookingModel
  userName:string

  constructor(private customerService:CustomerServiceService ,private route:Router ) { }

  ngOnInit() {

    this.userName=JSON.parse(localStorage.getItem('USERNAME'));
    this.BookingRegisterForm = new FormGroup({
      pickUpTime: new FormControl(''),
      dropTime: new FormControl(''),
      pickUpLocation:new FormControl(''),
       dropLocation:new FormControl(''),
       pickUpDate:new FormControl(''),
       dropDate:new FormControl(''),
    });

  }
    onSubmit()
    {
      
      this.save();

      this.route.navigate(['/viewCars']);
    }

     save(){
      this.bookingData=this.BookingRegisterForm.value;
      localStorage.setItem('pickUpLocation', JSON.stringify(this.bookingData.pickUpLocation));
      localStorage.setItem('dropLocation', JSON.stringify(this.bookingData.pickUpLocation));
      localStorage.setItem('pickUpDate', JSON.stringify(this.bookingData.pickUpDate));
      localStorage.setItem('dropDate', JSON.stringify(this.bookingData.dropDate));
      localStorage.setItem('pickUpTime', JSON.stringify(this.bookingData.pickUpTime));
      localStorage.setItem('dropTime', JSON.stringify(this.bookingData.dropTime));

     }

}
