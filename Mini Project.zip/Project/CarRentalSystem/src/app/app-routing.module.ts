import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';

import { HomeComponent } from './home/home.component';
import { AddCarComponent } from './add-car/add-car.component';
import { RemoveCarComponent } from './remove-car/remove-car.component';
import { UpdateCarComponent } from './update-car/update-car.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CarListComponent } from './car-list/car-list.component';
import { BookingRegisterComponent } from './booking-register/booking-register.component';
import { AuthGuardGuard } from './auth-guard.guard';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { DealarDashboardComponent } from './dealar-dashboard/dealar-dashboard.component';
import { ViewCarsComponent } from './view-cars/view-cars.component';
import { CustomerBookingDetailComponent } from './customer-booking-detail/customer-booking-detail.component';
import { config } from 'rxjs';
import { ConformationPageComponent } from './conformation-page/conformation-page.component';
import { Admin1DashboardComponent } from './admin1-dashboard/admin1-dashboard.component';
import { AdminCustomerListComponent } from './admin-customer-list/admin-customer-list.component';
import { AdminCarListComponent } from './admin-car-list/admin-car-list.component';


const routes: Routes = [{ path: '', component:HomeComponent },
 { path: 'signup', component: SignUpComponent },
 { path: 'conformationPage', component:ConformationPageComponent },
 { path: 'CustomerBookingDetail', component:CustomerBookingDetailComponent},
 { path: 'viewCars', component: ViewCarsComponent }
,{ path: 'login', component:LoginComponent },
{path:'adminDashboard',component:Admin1DashboardComponent},
{path:'DealarDashboard',component:DealarDashboardComponent},
{ path: 'AdminCustomerList', component:AdminCustomerListComponent },
{ path: 'AdminCarList', component:AdminCarListComponent },
{ path: 'AddCar', component:AddCarComponent,canActivate:[AuthGuardGuard]},{ path: 'Removecar', component:RemoveCarComponent },
{ path: 'UpdateCar', component:UpdateCarComponent },{ path: 'BookingList', component:BookingListComponent },
{ path: 'CustomerList', component:CustomerListComponent },{ path: 'CarList', component:CarListComponent }
,{ path: 'AddCar/:carId', component: AddCarComponent,canActivate:[AuthGuardGuard]},
{ path: 'BookingRegister', component:BookingRegisterComponent,canActivate:[AuthGuardGuard]},{ path: '**', component: PageNotFoundComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
