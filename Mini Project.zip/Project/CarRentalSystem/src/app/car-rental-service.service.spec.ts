import { TestBed } from '@angular/core/testing';

import { CarRentalServiceService } from './car-rental-service.service';

describe('CarRentalServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CarRentalServiceService = TestBed.get(CarRentalServiceService);
    expect(service).toBeTruthy();
  });
});
