import { Component, OnInit } from '@angular/core';
import { CarModel } from '../carModel/carModel';
import { Observable } from 'rxjs';
import { CarRentalServiceService } from '../car-rental-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {
  cars:Observable<CarModel[]>;
  dealerid:any

  constructor(private carService:CarRentalServiceService,private routeobject:Router) { }

 
  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.dealerid=JSON.parse(localStorage.getItem('dealerid'));
    console.log( this.dealerid);
    this.cars = this.carService.getCarList();
  
    
      console.log(this.cars);

  }

  removeCar(carId:number){

    this.carService.RemoveCarById(carId)
    .subscribe(
      data => {
        console.log(data);
       

      }, error => console.log(error))
  }

updateCar(carId:number){

  console.log(carId)
  this.routeobject.navigate(['/AddCar/'+carId])

}


}
