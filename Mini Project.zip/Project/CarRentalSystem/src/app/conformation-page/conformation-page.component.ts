import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conformation-page',
  templateUrl: './conformation-page.component.html',
  styleUrls: ['./conformation-page.component.css']
})
export class ConformationPageComponent implements OnInit {


  conformationPageData:any
  costPerKm: any;

  constructor() { }

  ngOnInit() {

    this.reloadData();
  }

  reloadData(){

    this.conformationPageData=JSON.parse(localStorage.getItem( 'bookingData'));
    this.costPerKm=JSON.parse(localStorage.getItem( 'costPerKm'));

    console.log(this.conformationPageData.carImage)

  }

  

}
