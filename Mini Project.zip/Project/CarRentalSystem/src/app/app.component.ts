import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  nav1:boolean
  title = 'CarRentalSystem';


  constructor()
  {
    this.nav1=true;
  }
}
