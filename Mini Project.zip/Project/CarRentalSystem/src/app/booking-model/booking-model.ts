export class BookingModel{
   

    
    pickUpLocation:String;
    dropLocation:String;
    pickUpDate:String;
    dropDate:String;
    pickUpTime:String;
    dropTime:String;

}