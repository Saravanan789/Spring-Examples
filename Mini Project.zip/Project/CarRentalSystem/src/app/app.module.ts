import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import{Form,ReactiveFormsModule, FormsModule} from '@angular/forms';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AddCarComponent } from './add-car/add-car.component';
import { UpdateCarComponent } from './update-car/update-car.component';
import { RemoveCarComponent } from './remove-car/remove-car.component';
import { CarListComponent } from './car-list/car-list.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { BookingRegisterComponent } from './booking-register/booking-register.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AuthGuardGuard } from './auth-guard.guard';
import { DealarDashboardComponent } from './dealar-dashboard/dealar-dashboard.component';
import { ViewCarsComponent } from './view-cars/view-cars.component';
import { CustomerBookingDetailComponent } from './customer-booking-detail/customer-booking-detail.component';
import { ConformationPageComponent } from './conformation-page/conformation-page.component';
import { Admin1DashboardComponent } from './admin1-dashboard/admin1-dashboard.component';
import { AdminCustomerListComponent } from './admin-customer-list/admin-customer-list.component';
import { AdminCarListComponent } from './admin-car-list/admin-car-list.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    DealarDashboardComponent,
    AddCarComponent,
    UpdateCarComponent,
    RemoveCarComponent,
    CarListComponent,
    BookingListComponent,
    CustomerListComponent,
    HomeComponent,
    BookingRegisterComponent,
    PageNotFoundComponent,
    ViewCarsComponent,
    CustomerBookingDetailComponent,
    ConformationPageComponent,
    Admin1DashboardComponent,
    AdminCustomerListComponent,
    AdminCarListComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    
  ],
  providers: [AuthGuardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
