import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  private baseUrl = 'http://localhost:8080/api/Admin'

  constructor(private http: HttpClient) { }

  getCarList(): Observable<any> {
    return this.http.get(this.baseUrl + `/Cars`)
  }

  getCustomerList(): Observable<any> {
    return this.http.get(this.baseUrl + `/Customers`)
  }



}
