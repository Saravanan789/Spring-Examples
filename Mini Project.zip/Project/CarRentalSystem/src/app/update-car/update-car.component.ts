import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-car',
  templateUrl: './update-car.component.html',
  styleUrls: ['./update-car.component.css']
})
export class UpdateCarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
