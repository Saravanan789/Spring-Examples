export class CarModel{
  dealerId:number;
      carId:number;
    carName:String;
    carNumber:String;
    carImage:any
    fuelType:String;
    noOfSeats:number;
    noOfAirbags:number;
    gearType:String;
    costPerKm:number;

     


}