export class FinalBookingModel {

    
     
    bookingId: number;
    customerId: number
    phoneNumber: String
    email: String;
    carImage:any;
    carId: number;
    carName: String;
    carNumber: String
    dealerId: number;
    pickUpLocation: String;
    dropLocation: String;
    pickUpDate: String;
    dropDate: String;
    pickUpTime: String
    dropTime: String


}