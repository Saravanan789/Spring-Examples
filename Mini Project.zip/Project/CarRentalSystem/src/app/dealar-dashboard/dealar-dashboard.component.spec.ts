import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealarDashboardComponent } from './dealar-dashboard.component';

describe('DealarDashboardComponent', () => {
  let component: DealarDashboardComponent;
  let fixture: ComponentFixture<DealarDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealarDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealarDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
