import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealar-dashboard',
  templateUrl: './dealar-dashboard.component.html',
  styleUrls: ['./dealar-dashboard.component.css']
})
export class DealarDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
