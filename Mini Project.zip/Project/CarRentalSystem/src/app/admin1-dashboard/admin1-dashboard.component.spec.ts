import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Admin1DashboardComponent } from './admin1-dashboard.component';

describe('Admin1DashboardComponent', () => {
  let component: Admin1DashboardComponent;
  let fixture: ComponentFixture<Admin1DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Admin1DashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Admin1DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
