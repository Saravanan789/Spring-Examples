import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin1-dashboard',
  templateUrl: './admin1-dashboard.component.html',
  styleUrls: ['./admin1-dashboard.component.css']
})
export class Admin1DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
