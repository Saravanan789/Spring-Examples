import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
  private baseUrl = 'http://localhost:8080/api/Customer';

  constructor(private http: HttpClient) { }

  AddCustomer(customer: Object): Observable<Object> {
    

    return this.http.post(`${this.baseUrl}` + `/customer`, customer);
  }

  getUserData(userName: String): Observable<object> {
    return this.http.get(`${this.baseUrl}` + `/customer/` + userName);
  }


  getBookingDetailBycustomerId(customerId: number): Observable<any> {


    return this.http.get(`${this.baseUrl}` + '/bookingData/' + `${customerId}`);

  }

}
