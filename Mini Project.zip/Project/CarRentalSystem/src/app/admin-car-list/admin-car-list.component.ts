import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CarModel } from '../carModel/carModel';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-admin-car-list',
  templateUrl: './admin-car-list.component.html',
  styleUrls: ['./admin-car-list.component.css']
})
export class AdminCarListComponent implements OnInit {

  cars:Observable<CarModel[]>
  constructor(private adminService:AdminServiceService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    
    this.cars = this.adminService.getCarList();
  
    
    
  }
}
