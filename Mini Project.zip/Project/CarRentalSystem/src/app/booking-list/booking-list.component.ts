import { Component, OnInit } from '@angular/core';
import { FinalBookingModel } from '../FinalBookingModel/final-booking-model';
import { Observable } from 'rxjs';
import { CarRentalServiceService } from '../car-rental-service.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.css']
})
export class BookingListComponent implements OnInit {

  dealerId:number;
  bookingdetails:Observable<FinalBookingModel[]>;
  constructor(private dealerService:CarRentalServiceService) { }

  ngOnInit() {
    this.reloadBookingData();
  }

  reloadBookingData()
  {
   
    
   this.bookingdetails=this.dealerService.getBookingDetailBydealerId(JSON.parse(localStorage.getItem('dealerid')));

  }
   
}
