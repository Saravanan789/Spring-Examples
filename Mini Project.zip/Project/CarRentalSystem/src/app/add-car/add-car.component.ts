import { Component, OnInit } from '@angular/core';
import { CarModel } from '../carModel/carModel';
import { FormGroup, FormControl } from '@angular/forms';
import { CarRentalServiceService } from '../car-rental-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UpdateCarComponent } from '../update-car/update-car.component';
import { getNativeByIndex } from '@angular/core/src/render3/util';

@Component({
  selector: 'app-add-car',
  templateUrl: './add-car.component.html',
  styleUrls: ['./add-car.component.css']
})
export class AddCarComponent implements OnInit {

  car: CarModel;
  id: number;
  hide3 = true;
  hide4 = false;
  userFile: any = File;

  addCarForm;

  constructor(private carService: CarRentalServiceService, private route: ActivatedRoute, private router: Router) {

    console.log(localStorage.getItem('dealerid'));

  }

  ngOnInit() {

    this.listenparams();
    this.createCarForm();
    if (this.id) {
      this.hide3 = false;
      this.hide4 = true;
      this.getById();
    }


  }

  createCarForm(): void {
    this.addCarForm = new FormGroup({
      carId: new FormControl(''),
      carName: new FormControl(''),
      carNumber: new FormControl(''),
      fuelType: new FormControl(''),
      gearType: new FormControl(''),
      costPerKm: new FormControl(''),
      noOfSeats: new FormControl(''),
      noOfAirbags: new FormControl('')
    });
  }


  onSubmit() {
    this.Save();
  }


  onSelectFile(event) {
    const file = event.target.files[0];
    this.userFile = file;
  }


  Save() {
    // this.save(formData);

    this.car = this.addCarForm.value;
    this.car.dealerId = JSON.parse(localStorage.getItem('dealerid'));

    const formData = new FormData();
    formData.append('car', JSON.stringify(this.car));
    formData.append('file', this.userFile);
    console.log(formData);


    console.log(formData);
    this.carService.AddCar(formData)
      .subscribe(
        data => {
          console.log(data)
          // localStorage.setItem('carId', JSON.stringify(data['carId']));


        });
    //this.contact = new ContactModel();

  }


  listenparams(): void {
    this.route.paramMap.subscribe(param => {
      this.id = +param.get('carId');
      console.log(this.id);
    });
  }

  getById() {

    this.carService.getCar(this.id)
      .subscribe(
        data => {

          console.log(data);
          this.formbinding(data);

        }, error => console.log(error)



      )
  }



  UpdateCar() {

    this.car = this.addCarForm.value;
    console.log(this.car.carId);
    this.carService.UpdateCar(this.car.carId, this.car)
      .subscribe(
        data => {
          if (data) {

            console.log(data);
          }
        }, error => console.log(error))

  }


  formbinding(updateobject: CarModel) {

    this.addCarForm.controls['carId'].setValue(updateobject.carId);
    this.addCarForm.controls['carName'].setValue(updateobject.carName);
    this.addCarForm.controls['carNumber'].setValue(updateobject.carNumber);
    this.addCarForm.controls['noOfSeats'].setValue(updateobject.noOfSeats);
    this.addCarForm.controls['noOfAirbags'].setValue(updateobject.noOfAirbags);
    this.addCarForm.controls['fuelType'].setValue(updateobject.fuelType);
    this.addCarForm.controls['gearType'].setValue(updateobject.gearType);
    this.addCarForm.controls['costPerKm'].setValue(updateobject.costPerKm);


  }





}
