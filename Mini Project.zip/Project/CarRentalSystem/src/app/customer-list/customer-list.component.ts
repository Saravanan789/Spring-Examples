import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { CarRentalServiceService } from '../car-rental-service.service';
import { CustomerModel } from '../Customer-model/customer-model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  customers:Observable<CustomerModel[]>;

  constructor(private custService:CarRentalServiceService) { }

  ngOnInit() {
    this.reloadCustomerData()
  }

  reloadCustomerData()
  {
   this.customers= this.custService.getCustomerList();
  }
 




}
