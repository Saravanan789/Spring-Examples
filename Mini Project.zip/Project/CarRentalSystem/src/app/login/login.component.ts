import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../customer-service.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup;
  invalidUsername=false;
  invalidPassword=false;



  constructor(private route: Router, private service: CustomerServiceService) { }

  ngOnInit() {
    this.loginform = new FormGroup({

      username: new FormControl('', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(7)]),

    })
  }
  onSubmit() {
   
    console.log(this.loginform.controls['username'].value);
    if(this.loginform.controls['username'].value==="admin@gmail.com" && this.loginform.controls['password'].value==="12345678")
    {
      this.route.navigate(['/adminDashboard']);
      localStorage.setItem('LoggedIn','true');
    }
    else
    {

   
    this.getDataByUserName(this.loginform.controls['username'].value);
     }
  }

  getDataByUserName(username: string) {

    this.service.getUserData(username)
      .subscribe(
        data => {
          console.log(data);
          if(data['errorCode']===404)
          {
            console.log("username not exist");
            this.invalidUsername=true;
          }
          else
          {
          this.validation(data);
          }
        },
        error => console.log(error)
      );
  }

  validation(data1: object) {

    if (data1['password'] === this.loginform.controls['password'].value){
     
        if(data1['role']==="customer")
        {
          localStorage.setItem('LoggedIn','true');

          localStorage.setItem('customerid', JSON.stringify(data1['customerid']));
          localStorage.setItem('phoneNumber', JSON.stringify(data1['phoneNumber']));
          localStorage.setItem('email', JSON.stringify(data1['email']));
          localStorage.setItem('USERNAME',JSON.stringify(data1['userName']));
          this.route.navigate(['/BookingRegister']);
          // localStorage.setItem("name","saravanan");
          
        }
        else{
          localStorage.setItem('LoggedIn','true');
          localStorage.setItem('dealerid',JSON.stringify(data1['customerid']));
         
          this.route.navigate(['/DealarDashboard']);
        }
    }
    else
    {
      console.log("This is a unAuthenticated user");
      this.invalidPassword=true;
    }
  }
}
