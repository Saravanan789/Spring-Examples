import { Component, OnInit } from '@angular/core';
import { CarRentalServiceService } from '../car-rental-service.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-remove-car',
  templateUrl: './remove-car.component.html',
  styleUrls: ['./remove-car.component.css']
})
export class RemoveCarComponent implements OnInit {
  deleteform: FormGroup;

  constructor(private carService: CarRentalServiceService) { }

  ngOnInit() {

    this.deleteform = new FormGroup({

      carNumber: new FormControl('')

    });

  }

  onSubmit() {
    this.deleteCar(this.deleteform.controls['carNumber'].value);
  }

  deleteCar(carNumber: number) {


    this.carService.RemoveCarByNumber(carNumber)
      .subscribe(
        data => {
          console.log(data);
         

        }, error => console.log(error))


  }
}

