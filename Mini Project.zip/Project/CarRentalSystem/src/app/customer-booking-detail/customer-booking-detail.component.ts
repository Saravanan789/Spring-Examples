import { Component, OnInit } from '@angular/core';
import { CarRentalServiceService } from '../car-rental-service.service';
import { Observable } from 'rxjs';
import { FinalBookingModel } from '../FinalBookingModel/final-booking-model';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-customer-booking-detail',
  templateUrl: './customer-booking-detail.component.html',
  styleUrls: ['./customer-booking-detail.component.css']
})
export class CustomerBookingDetailComponent implements OnInit {



   bookingdetails:Observable<FinalBookingModel[]>

  constructor(private customerService:CustomerServiceService) { }

  ngOnInit() {
    this.reloadBookingData();
  }

  reloadBookingData()
  {
   
    
   this.bookingdetails=this.customerService.getBookingDetailBycustomerId(JSON.parse(localStorage.getItem('customerid')));

  }

}
