import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerBookingDetailComponent } from './customer-booking-detail.component';

describe('CustomerBookingDetailComponent', () => {
  let component: CustomerBookingDetailComponent;
  let fixture: ComponentFixture<CustomerBookingDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerBookingDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerBookingDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
