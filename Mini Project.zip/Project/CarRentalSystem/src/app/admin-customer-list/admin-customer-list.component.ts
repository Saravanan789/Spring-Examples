import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerModel } from '../Customer-model/customer-model';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-admin-customer-list',
  templateUrl: './admin-customer-list.component.html',
  styleUrls: ['./admin-customer-list.component.css']
})
export class AdminCustomerListComponent implements OnInit {

  customers:Observable<CustomerModel[]>;
  constructor(private adminService:AdminServiceService) { }

 
  ngOnInit() {
    this.reloadCustomerData();
  }

  reloadCustomerData()
  {
   this.customers= this.adminService.getCustomerList();
  }

}