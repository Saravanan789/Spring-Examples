package com.ns.CarRentalSystem.Model.Exception;

public class CustomerNotFound extends RuntimeException  {

    public CustomerNotFound (String exception) {
        super(exception);
    }

}
