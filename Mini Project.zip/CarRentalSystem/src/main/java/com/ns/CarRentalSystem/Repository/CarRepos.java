package com.ns.CarRentalSystem.Repository;

import org.springframework.data.repository.CrudRepository;


import com.ns.CarRentalSystem.Model.CarModel;

import javax.transaction.Transactional;

public interface CarRepos extends CrudRepository<CarModel,Long>{


@Transactional
       void deleteBycarNumber(String carNumber);



}
