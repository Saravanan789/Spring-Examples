package com.ns.CarRentalSystem.Model.Exception;

public class DataNotPresent extends  RuntimeException {
    public DataNotPresent (String exception) {
        super(exception);
    }

}
