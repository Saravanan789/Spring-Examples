package com.ns.CarRentalSystem.Model.Exception;

public class CarIdConflict extends RuntimeException{

    public CarIdConflict (String exception) {
        super(exception);
    }
}
