package com.ns.CarRentalSystem.Model.Exception;

public class BookingDataNotFound extends RuntimeException {


    public BookingDataNotFound (String exception) {
        super(exception);
    }
}
