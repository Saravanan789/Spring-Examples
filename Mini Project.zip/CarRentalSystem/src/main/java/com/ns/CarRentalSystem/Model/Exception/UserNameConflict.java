package com.ns.CarRentalSystem.Model.Exception;

public class UserNameConflict extends RuntimeException  {

    public UserNameConflict (String exception) {
        super(exception);
    }

}
