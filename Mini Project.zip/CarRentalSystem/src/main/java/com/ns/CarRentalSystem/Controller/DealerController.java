package com.ns.CarRentalSystem.Controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ns.CarRentalSystem.Model.*;
import com.ns.CarRentalSystem.Model.Exception.*;
import com.ns.CarRentalSystem.Repository.BookingDetailRepos;
import com.ns.CarRentalSystem.Repository.CarRepos;
import com.ns.CarRentalSystem.Repository.CustomerRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/Dealer")
public class DealerController {

    @Autowired
    CarRepos carrepository;
    @Autowired
    CustomerRepos customerrepository;

    @Autowired
    BookingDetailRepos bookingrepository;


        @PostMapping(value="/car")
        public ResponseEntity<CarModel> addNewcAr(@RequestParam("file") MultipartFile file, @RequestParam("car")String car)

        {
            try {
                CarModel c = new ObjectMapper().readValue(car, CarModel.class);
                c.setImage(file.getBytes());
                CarModel cardata = carrepository.save(c);
                return new ResponseEntity<>(cardata, HttpStatus.OK);
            }
            catch (DataIntegrityViolationException | IOException e)
            {

                throw new CarIdConflict("CarId Already Exist");
            }

        }

        @GetMapping("/cars")
     public ResponseEntity <List<CarModel>> getAllCars(){

                List<CarModel> cars = new ArrayList<>();
                carrepository.findAll().forEach(cars::add);
                if(cars.isEmpty())
                {
                    throw new DataNotPresent("No Data is present");
                }
                return new ResponseEntity<>(cars, HttpStatus.OK);


    }

//    @DeleteMapping("/car/{carNumber}")
//    public ResponseEntity<String> deleteCustomer(@PathVariable("carNumber") String carNumber) {
//            try {
//
//
//                carrepository.deleteBycarNumber(carNumber);
//                return new ResponseEntity<>("CustomerModel has been deleted!", HttpStatus.OK);
//            }
//            catch (Exception e) {
//
//                return new ResponseEntity<>("Error in deleting cars!", HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//    }

    @DeleteMapping("/car/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable("id") long id) {


                Optional<CarModel> carData = carrepository.findById(id);
                if(!carData.isPresent())
                {
                    throw new CarIdNotFound("Car id not exist");
                }
                carrepository.deleteById(id);
                return new ResponseEntity<>("Car has been deleted!", HttpStatus.OK);


    }

    @PutMapping("/car/{id}")
    public ResponseEntity<CarModel> updateCustomer(@PathVariable("id") long id, @RequestBody CarModel car) {


                System.out.println("Update CustomerModel with ID = " + id + "...");

                Optional<CarModel> carData = carrepository.findById(id);

                if (carData.isPresent()) {
                    CarModel car1 = carData.get();

                    car1.setCarName(car.getCarName());
                    car1.setCarNumber(car.getCarNumber());
                    car1.setNoOfSeats(car.getNoOfSeats());
                    car1.setNoOfAirbags(car.getNoOfAirbags());
                    car1.setFuelType(car.getFuelType());
                    car1.setGearType(car.getGearType());
                    car1.setCostPerKm(car.getCostPerKm());
                    return new ResponseEntity<>(carrepository.save(car1), HttpStatus.OK);
                } else {
                    throw new CarIdNotFound("Car id not exist");
                }


    }


    @GetMapping(value = "/car/{id}")
    public ResponseEntity<Optional<CarModel>> findById(@PathVariable long id) {


                Optional<CarModel> carData = carrepository.findById(id);
                if(!carData.isPresent())
                {
                    throw  new CarDataNotFound("Car Data Not Found");
                }
                return new ResponseEntity<>(carData, HttpStatus.OK);

    }

    @GetMapping("/customers")
    public ResponseEntity <List<CustomerModel>> getAllCustomers(){

                System.out.println("get all customers...");
                List<CustomerModel> customers = new ArrayList<>();
                customerrepository.findAll().forEach(customers::add);
                if(customers.isEmpty())
                {
                    throw new DataNotPresent("No Data is present");
                }
                return new ResponseEntity<>(customers, HttpStatus.OK);


    }

    @PostMapping(value="/bookingData")
    public ResponseEntity<BookingDetailDealer> postCustomer(@RequestBody BookingDetailDealer booking) {
            try {

                BookingDetailDealer bookingData = bookingrepository.save((new BookingDetailDealer(booking.getDealerId(), booking.getCarId(), booking.getCarName(),
                        booking.getCarNumber(), booking.getCustomerId(), booking.getPhoneNumber(), booking.getEmail(),
                        booking.getPickUpLocation(), booking.getDropLocation(), booking.getPickUpDate(), booking.getDropDate(),
                        booking.getPickUpTime(), booking.getDropTime(), booking.getCarImage())));

                return new ResponseEntity<>(bookingData, HttpStatus.OK);
            }
            catch(DataIntegrityViolationException e){

                throw new BookingIdConflict("DataIntegrityViolation problem in Booking the car");

            }

    }
    @GetMapping(value = "/bookingData/{dealerId}")
    public ResponseEntity <List<BookingDetailDealer>> findBydealerIdAll(@PathVariable("dealerId") int dealerId)  {


            List<BookingDetailDealer>bookingData =bookingrepository.findBydealerId(dealerId);
            if(bookingData.isEmpty())
            {
                throw new BookingDataNotFound("dealerId is not exist-" + dealerId);
            }
            return new ResponseEntity(bookingData,HttpStatus.OK);


    }









}


