package com.ns.CarRentalSystem.Repository;

import com.ns.CarRentalSystem.Model.BookingDetailDealer;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface BookingDetailRepos extends CrudRepository<BookingDetailDealer,Long> {


    List<BookingDetailDealer> findBydealerId(int dealerId);
    List<BookingDetailDealer> findBycustomerId(int customerId);


}
