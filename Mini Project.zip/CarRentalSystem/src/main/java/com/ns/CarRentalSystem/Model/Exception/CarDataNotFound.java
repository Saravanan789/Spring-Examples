package com.ns.CarRentalSystem.Model.Exception;

public class CarDataNotFound extends RuntimeException {

    public CarDataNotFound (String exception) {
        super(exception);
    }
}
