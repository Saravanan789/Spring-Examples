package com.ns.CarRentalSystem.Controller;

import com.ns.CarRentalSystem.Model.Exception.*;
import com.ns.CarRentalSystem.Model.ErrorResponse;
import com.ns.CarRentalSystem.Model.Exception.UserNameConflict;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

@RestController
@ControllerAdvice
public class ExceptionControllerAdvice {


//
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
//        ErrorResponse error = new ErrorResponse();
//        error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
//        error.setMessage("Internal Server Error");
//        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
//    }

    @ExceptionHandler(UserNameConflict.class)
    public ResponseEntity<ErrorResponse> exceptionHandler1(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.CONFLICT.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }

    @ExceptionHandler(CustomerNotFound.class)
    public ResponseEntity<ErrorResponse> exceptionHandler3(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.NOT_FOUND.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }


    @ExceptionHandler(BookingDataNotFound.class)
    public ResponseEntity<ErrorResponse> exceptionHandler5(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.NOT_FOUND.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }

    @ExceptionHandler(CarIdConflict.class)
    public ResponseEntity<ErrorResponse> exceptionHandler9(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.CONFLICT.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }

    @ExceptionHandler(CarIdNotFound.class)
    public ResponseEntity<ErrorResponse> exceptionHandler11(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.NOT_FOUND.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }
    @ExceptionHandler(CarDataNotFound.class)
    public ResponseEntity<ErrorResponse> exceptionHandler18(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.NOT_FOUND.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }

    @ExceptionHandler(DataNotPresent.class)
    public ResponseEntity<ErrorResponse> exceptionHandler12(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.BAD_REQUEST.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }
    @ExceptionHandler(BookingIdConflict.class)
    public ResponseEntity<ErrorResponse> exceptionHandler13(Exception ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(HttpStatus.CONFLICT.value());
        error.setMessage(ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
    }

}
