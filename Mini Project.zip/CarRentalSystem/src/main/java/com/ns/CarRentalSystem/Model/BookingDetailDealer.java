package com.ns.CarRentalSystem.Model;


import javax.persistence.*;

@Entity
@Table(name="BookingDetailDealer")
public class BookingDetailDealer {




    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long bookingId;

    private int dealerId;

    private int carId;

    private String carName;

    private String carNumber;


      private byte[] carImage;

    private int customerId;

    private String phoneNumber;

    private String email;







    private String pickUpLocation;

    private String dropLocation;

    private String pickUpDate;

    private String dropDate;

    private String pickUpTime;

    private String dropTime;


    public BookingDetailDealer() {
    }

    public BookingDetailDealer(int dealerId, int carId, String carName, String carNumber, int customerId, String phoneNumber, String email, String pickUpLocation, String dropLocation, String pickUpDate, String dropDate, String pickUpTime, String dropTime,byte[] carImage) {
        this.dealerId = dealerId;
        this.carId = carId;
        this.carName = carName;
        this.carNumber = carNumber;
        this.customerId = customerId;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.pickUpLocation = pickUpLocation;
        this.dropLocation = dropLocation;
        this.pickUpDate = pickUpDate;
        this.dropDate = dropDate;
        this.pickUpTime = pickUpTime;
        this.dropTime = dropTime;
        this.carImage=carImage;
    }

    public byte[] getCarImage() {
        return carImage;
    }

    public void setCarImage(byte[] carImage) {
        this.carImage = carImage;
    }

    public long getBookingId() {
        return bookingId;
    }

    public void setBookingId(long bookingId) {
        this.bookingId = bookingId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public int getDealerId() {
        return dealerId;
    }

    public void setDealerId(int dealerId) {
        this.dealerId = dealerId;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }

    public void setPickUpLocation(String pickUpLocation) {
        this.pickUpLocation = pickUpLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getPickUpDate() {
        return pickUpDate;
    }

    public void setPickUpDate(String pickUpDate) {
        this.pickUpDate = pickUpDate;
    }

    public String getDropDate() {
        return dropDate;
    }

    public void setDropDate(String dropDate) {
        this.dropDate = dropDate;
    }

    public String getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(String pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public String getDropTime() {
        return dropTime;
    }

    public void setDropTime(String dropTime) {
        this.dropTime = dropTime;
    }
}
