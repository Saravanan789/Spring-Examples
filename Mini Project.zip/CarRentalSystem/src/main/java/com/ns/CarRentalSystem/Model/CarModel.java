package com.ns.CarRentalSystem.Model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="car")
public class CarModel {




        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private long carId;

      @NotEmpty(message = "not empty")
      @NotBlank(message = "not blank")
      @NotNull(message = "not null")
        @Column(name="CarName")
        private String carName;



        private String dealerId;

          private byte[] image;



    @NotEmpty(message = "not empty")
        @NotBlank(message = "not blank")
        @NotNull(message = "not null")
        @Column(name="CarNumber",unique = true)
        private String carNumber;

       @NotEmpty(message = "not empty")
       @NotBlank(message = "not blank")
       @NotNull(message = "not null")
        @Column(name="NoOfSeats")
        private String noOfSeats;

      @NotEmpty(message = "not empty")
      @NotBlank(message = "not blank")
      @NotNull(message = "not null")
        @NotNull
        @Column(name="NoOfAirbags")
        private String noOfAirbags;

      @NotEmpty(message = "not empty")
      @NotBlank(message = "not blank")
      @NotNull(message = "not null")
      @Column(name="FuelType")
        private String fuelType;

    @NotEmpty(message = "not empty")
    @NotBlank(message = "not blank")
    @NotNull(message = "not null")
    @Column(name="GearType")
          private String gearType;

    @NotEmpty(message = "not empty")
    @NotBlank(message = "not blank")
    @NotNull(message = "not null")
        @Column(name="CostPerKm")
         private String costPerKm;






    public CarModel(byte[] image,@NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String carName, String dealerId, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String carNumber, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String noOfSeats, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") @NotNull String noOfAirbags, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String fuelType, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String gearType, @NotEmpty(message = "not empty") @NotBlank(message = "not blank") @NotNull(message = "not null") String costPerKm) {
        this.image = image;
        this.carName = carName;
        this.dealerId = dealerId;
        this.carNumber = carNumber;
        this.noOfSeats = noOfSeats;
        this.noOfAirbags = noOfAirbags;
        this.fuelType = fuelType;
        this.gearType = gearType;
        this.costPerKm = costPerKm;
    }

    public CarModel() {
    }

    public long getCarId() {
        return carId;
    }

    public void setCarId(long carId) {
        this.carId = carId;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerid(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    public String getNoOfAirbags() {
        return noOfAirbags;
    }

    public void setNoOfAirbags(String noOfAirbags) {
        this.noOfAirbags = noOfAirbags;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getGearType() {
        return gearType;
    }

    public void setGearType(String gearType) {
        this.gearType = gearType;
    }

    public String getCostPerKm() {
        return costPerKm;
    }

    public void setCostPerKm(String costPerKm) {
        this.costPerKm = costPerKm;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
