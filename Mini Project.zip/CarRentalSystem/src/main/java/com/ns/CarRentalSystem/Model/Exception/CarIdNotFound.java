package com.ns.CarRentalSystem.Model.Exception;

public class CarIdNotFound extends RuntimeException {

    public CarIdNotFound (String exception) {
        super(exception);
    }
}
