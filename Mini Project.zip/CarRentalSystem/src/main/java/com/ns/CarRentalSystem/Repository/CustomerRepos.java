package com.ns.CarRentalSystem.Repository;

import com.ns.CarRentalSystem.Model.CustomerModel;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface CustomerRepos extends CrudRepository<CustomerModel,Long> {


    @Override
    Optional<CustomerModel> findById(Long aLong);

    Optional<CustomerModel> findDataByUserName(String userName);

}
