package com.ns.CarRentalSystem.Model.Exception;

public class BookingIdConflict extends RuntimeException {
    public BookingIdConflict (String exception) {
        super(exception);
    }
}
