package com.ns.CarRentalSystem.Controller;


import com.ns.CarRentalSystem.Model.BookingDetailDealer;
import com.ns.CarRentalSystem.Model.Exception.BookingDataNotFound;
import com.ns.CarRentalSystem.Model.Exception.CustomerNotFound;
import com.ns.CarRentalSystem.Model.Exception.UserNameConflict;
import com.ns.CarRentalSystem.Model.CustomerModel;
import com.ns.CarRentalSystem.Model.Exception.UserNameConflict;
import com.ns.CarRentalSystem.Repository.BookingDetailRepos;
import com.ns.CarRentalSystem.Repository.CustomerRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/Customer")
public class CustomerController {
    @Autowired
    CustomerRepos repository;

    @Autowired
    BookingDetailRepos bookingRepository;

    @PostMapping(value="/customer")
    public ResponseEntity<CustomerModel> postCustomer(@RequestBody CustomerModel customer) {

        try {

            CustomerModel customerData = repository.save((new CustomerModel(customer.getUserName(), customer.getPassword(), customer.getConformPassword(), customer.getEmail(), customer.getPhoneNumber(), customer.getAddress(),customer.getRole())));
            return new ResponseEntity (customerData, HttpStatus.OK);
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            if(e.getMessage().contains("user_name_UNIQUE")){
                throw new UserNameConflict("Username Already Exist");
            }
            else{
                throw new UserNameConflict("Username Already Exist");
            }
        }

    }

    @GetMapping(value = "/customer/{userName}")
    public ResponseEntity<CustomerModel> getDataByUserName(@PathVariable("userName") String userName){


           Optional<CustomerModel>customer = repository.findDataByUserName(userName);
           if(!customer.isPresent())
           {
               throw new CustomerNotFound("userName not exist-" + userName);
           }
            return new ResponseEntity(customer,HttpStatus.OK);

    }

    @GetMapping(value = "/bookingData/{customerId}")
    public ResponseEntity <List<BookingDetailDealer>> findBydealerIdAll(@PathVariable("customerId") int customerId) {


               List<BookingDetailDealer>bookingData =bookingRepository.findBycustomerId(customerId);
               if(bookingData.isEmpty())
               {
                   throw new BookingDataNotFound("customerId is not exist-" + customerId);
               }
               return new ResponseEntity(bookingData,HttpStatus.OK);

    }

}
