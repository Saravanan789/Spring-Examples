package com.ns.CarRentalSystem.Controller;

import com.ns.CarRentalSystem.Model.CarModel;
import com.ns.CarRentalSystem.Model.CustomerModel;
import com.ns.CarRentalSystem.Model.Exception.DataNotPresent;
import com.ns.CarRentalSystem.Repository.CarRepos;
import com.ns.CarRentalSystem.Repository.CustomerRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/Admin")
public class AdminController {

    @Autowired
    CustomerRepos customerrepository;

    @Autowired
    CarRepos carrepository;

    @GetMapping("/customers")
    public ResponseEntity<List<CustomerModel>> getAllCustomers(){
        try {

            List<CustomerModel> customers = new ArrayList<>();
            customerrepository.findAll().forEach(customers::add);
            if(customers.isEmpty())
            {
                throw new DataNotPresent("No Data is present");
            }
            return new ResponseEntity<>(customers, HttpStatus.OK);
        }
        catch(Exception e){

            return new ResponseEntity("Error in Getting Customer List!", HttpStatus.CONFLICT);

        }
    }



    @GetMapping("/cars")
    public ResponseEntity <List<CarModel>> getAllCars(){
        try {

            List<CarModel> cars = new ArrayList<>();
            carrepository.findAll().forEach(cars::add);
            if(cars.isEmpty())
            {
                throw new DataNotPresent("No Data is present");
            }
            return new ResponseEntity<>(cars, HttpStatus.OK);
        }
        catch(Exception e)
        {
            return new ResponseEntity("Error in loading cars",HttpStatus.CONFLICT);
        }
    }





}
