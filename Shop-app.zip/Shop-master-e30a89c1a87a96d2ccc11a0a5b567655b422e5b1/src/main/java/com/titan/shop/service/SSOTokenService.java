package com.titan.shop.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.titan.portalutils.security.token.TokenManager;
import com.titan.shop.common.Constants;
import com.titan.shop.model.AppConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;

@Service
public class SSOTokenService {
    @Value("${shop.ssoClientID}")
    String ssoClientID;

    @Autowired
    private AppConfiguration appConfiguration;

//    @Value("${shop.guestUsername}")
//    private String guestUsername;
//
//    @Value("${shop.guestPassword}")
//    private String guestPassword;

    @Value("${shop.ssoTokenURL}")
    private String ssoTokenURL;

    @Value("${titan.security.offline.guest.enabled:false}")
    private Boolean isOfflineGuestTokenEnabled;

    @Autowired
    private TokenManager tokenManager;

    public String getGuestToken() {
        if (isOfflineGuestTokenEnabled) {
            return tokenManager.getOfflineGuestToken();
        }
        RestTemplate template = new RestTemplate();
        JsonParser jsonParser = new JsonParser();
        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.add(Constants.SSO.CONTENT_TYPE, Constants.SSO.URLENCODED_FORMAT);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(Constants.SSO.GRANT_TYPE, Constants.SSO.CLIENT_CREDENTIALS);
        map.add(Constants.SSO.CLIENT_ID, ssoClientID);
        map.add(Constants.SSO.CLIENT_ASSERTION_TYPE, Constants.SSO.CLIENT_ASSERTION_TYPE_VALUE);
        map.add(Constants.SSO.CLIENT_ASSERTION, appConfiguration.getClientAssertion());
//        map.add(Constants.SSO.USERNAME, guestUsername);
//        map.add(Constants.SSO.PASSWORD, guestPassword);
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);
        try {
            ResponseEntity response = template.exchange(ssoTokenURL, HttpMethod.POST, requestEntity, String.class);
            JsonObject jsonObject = jsonParser.parse(response.getBody().toString()).getAsJsonObject();
            return jsonObject.get(Constants.SSO.ACCESS_TOKEN).getAsString();
        } catch (Exception ex) {
            return null;
        }
    }
}
