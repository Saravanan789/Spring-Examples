package com.titan.shop.controller;

import com.nimbusds.jose.jwk.RSAKey;
import com.titan.portalutils.geolocation.misc.GeoLocation;
import com.titan.portalutils.geolocation.model.GeoLocationModel;
import com.titan.shop.model.*;
import com.titan.shop.service.ShopService;
import com.titan.shop.utils.CacheManager;
import com.titan.shop.utils.JWTKeyGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.method.annotation.AbstractJsonpResponseBodyAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class ShopRestController {

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private JWTKeyGenerator jwtKeyGenerator;

    @Autowired
    private CacheManager cacheManager;
    @Autowired
    private ShopService shopService;

    @Value("${cookie.cookieDomain}")
    String cookieDomain;

    @Value("${cookie.cookiePath}")
    String cookiePath;

    @Value("${ipStack.ipStackBaseUrl}")
    String ipStackBaseUrl;

    @Value("${ipStack.ipStackAccessKey}")
    String ipStackAccessKey;

    @Value("${payment.authorization}")
    private String authorization;

    @Value("${shop.apiGatewayURL}")
    private String apiGatewayURL;

    @ControllerAdvice(assignableTypes = {ShopRestController.class})
    private static class JsonpAdvice extends AbstractJsonpResponseBodyAdvice {
        public JsonpAdvice() {
            super("callback");
        }
    }
    
    @GetMapping(value = "stores1/{storeId}/country-code/{countryCode}/order-type/{orderType}/culture-code/{cultureCode}/payment-methods")
    public ResponseEntity<?> getPaymentMethodsList(@PathVariable("storeId") Long storeId,
                                                   @PathVariable("orderType") String orderType,
                                                   @PathVariable("cultureCode") String cultureCode,
                                                   @PathVariable("countryCode") String countryCode) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", authorization);
        String url = apiGatewayURL + "/payment/v1/stores/" + storeId + "/country-code/" + countryCode + "/order-type/" + orderType + "/culture-code/" + cultureCode + "/payment-methods";
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);
        return new ResponseEntity<>(respEntity.getBody(),HttpStatus.OK);
    }

    /**
     * @return
     */
    @GetMapping(value = "Configuration")
    public ConfigurationModel getConfiguration(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        String countryCode = httpServletRequest.getParameter("countryName");
        String country = StringUtils.isEmpty(countryCode) ? "usa" : countryCode;
        String language = "en-US";
        ConfigurationModel config = appConfiguration.getConfigByCountry(country);
        config.setLanguageCode(language);
        config.getApiConfiguration().setCountryCode(country);
        return config;
    }

    /**
     * @return
     */
    @Cacheable(cacheNames = "Shop", key = "'JwkResponse'")
    @GetMapping(value = "Jwks")
    public JwkResponseModel getJwks() {
        JwkResponseModel Keys = new JwkResponseModel();
        Jwk key = new Jwk();
        //gets RSA Private and Public Keys in Keys Model.
        RSAKeys keys = jwtKeyGenerator.getAssertionKeys();
        RSAKey jwk = new RSAKey.Builder(keys.getPublicKey()).build();
        key.setKid(jwk.getKeyID());
        key.setKty("RSA");
        key.setAlg("RS256");
        key.setUse("sig");
        key.setN(jwk.getModulus().toString());
        key.setE(jwk.getPublicExponent().toString());
        Keys.getKeys().add(key);
        return Keys;
    }

    @GetMapping(value = "/Clear-Client-Assertion-Cache")
    public boolean clearAssertion() {
        // cacheManager.clearAssertion();
        return true;
    }

    @GetMapping(value = "/Clear-Client-Assertion-Keys-Cache")
    public boolean clearAssertionKeys() {
        cacheManager.clearAssertionKeys();
        return true;
    }

    @GetMapping(value = "/Clear-Keycloak-Public-Certs-Cache")
    public boolean clearKeycloakPublicCerts() {
        cacheManager.clearKeycloakPublicCerts();
        return true;
    }

    @GetMapping(value = "/Clear-Jwk-Response-Cache")
    public boolean clearJWKResponse() {
        cacheManager.clearJWKResponse();
        return true;
    }

    @GetMapping(value = "/Clear-Cache")
    public void clearAllCache() {
        cacheManager.clearAllCache();
    }

    @GetMapping(value = "/Clear-Bots-Cache/{countryCode}/{itemNumber}")
    public boolean clearProductDetailForBots(@PathVariable String countryCode, @PathVariable String itemNumber) {
        return cacheManager.clearProductDetailForBots(countryCode, itemNumber);
    }

    @GetMapping(value = "/Clear-Bots-Cache")
    public boolean clearAllCacheForProducts() {
        return cacheManager.clearAllCacheForProducts();
    }

    @PostMapping(value = "/bots")
    public ProductDetailsForBots getProductInfoForBots(@RequestBody ProductDetailsForBots productDetailsForBots) {
        return null;
    }

    @GetMapping(value = "/guest-token")
    public ResponseEntity<?> getGuestToken() {
        GuestTokenModel response = appConfiguration.getGuestToken();
        return new ResponseEntity<>(response, Objects.nonNull(response.getGuestToken()) ? HttpStatus.OK : HttpStatus.UNAUTHORIZED);
    }

    @GetMapping(value = "/geolocation")
    public ResponseEntity<?> getGeoLocation(HttpServletRequest request, HttpServletResponse response) {
        GeoLocationModel geoLocationModel = GeoLocation.getClientGeoLocationDetails(request, response, ipStackBaseUrl, ipStackAccessKey, cookiePath, cookieDomain);
        return new ResponseEntity<>(geoLocationModel, Objects.nonNull(geoLocationModel) ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping(value = "/stores/{storeId}/country-code/{countryCode}/order-type/{orderType}/culture-code/{cultureCode}/payment-methods")
    public ResponseEntity<?> getPaymentMethodsByStore(@PathVariable("storeId") Long storeId,
                                                      @PathVariable("orderType") String orderType,
                                                      @PathVariable("cultureCode") String cultureCode,
                                                      @PathVariable("countryCode") String countryCode) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", authorization);
        String url = apiGatewayURL + "/payment/v1/stores/" + storeId + "/country-code/" + countryCode + "/order-type/" + orderType + "/culture-code/" + cultureCode + "/payment-methods";
        HttpEntity<String> entity = new HttpEntity<>(headers);
//        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);
        return new ResponseEntity<>("test", HttpStatus.OK);
    }

    @GetMapping(value = "/test-int")
    public ResponseEntity<?> getHelloWorledStr() {
        return new ResponseEntity<>("Testing new Test", HttpStatus.OK);
    }


}
