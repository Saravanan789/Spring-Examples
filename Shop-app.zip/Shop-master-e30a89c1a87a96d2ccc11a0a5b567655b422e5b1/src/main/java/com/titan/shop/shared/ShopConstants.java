package com.titan.shop.shared;

public class ShopConstants {
	public static final String AUTHORIZATION_HEADER_KEY = "Authorization";
	public static final String CONTENT_TYPE_HEADER_KEY = "Content-Type";
	public static final String ACCEPT_HEADER_KEY = "Accept";
	public static final String GRANT_TYPE_HEADER_KEY = "grant_type";
	public static final String USERNAME_KEY = "username";
	public static final String CLIENT_ID_KEY = "client_id";

	public static final String BEARER = "Bearer ";
	public static final String APPLICATION_JSON_TYPE = "application/json";
	public static final String APPLICATION_FORM_URL_ENCODED_TYPE = "application/x-www-form-urlencoded";
	public static final String ADMIN_CLIENT_ID = "admin-cli";
	public static final String COUNTRY_CODE_COOKIE_NAME = "countryCode";
	public static final String THUMBNAIL = "thumbnail";
	public static final String ZOOMEDIMAGE = "ZoomedImage";
	public static final String CATEGORY = "category";
	public static final String PURCHASE_FLOW = "purchaseFlowType";
	public static final String MEMBER_TITLE = "memberTitle";
	public static final String MEMBER_TITLE_ID = "memberTitleId";
	public static final String STORE_ID = "storeId";
	public static final String PRODUCT_ID = "productId";
	public static final String ISBOTS = "isBots";
	public static final String FBOID = "fboId";
	public static final String REPEAT_WEB_ORDER_NUMBER = "repeatWebOrderNumber";
	public static final String CART_SESSION_GUID = "cartSessionGuid";
	public static final String LANGUAGE_CODE = "languageCode";
	public static final String COUNTRY_CODE = "countryCode";
	public static final String LEGACY_LANGUAGE_CULTURE_CODE = "language";
	public static final String LEGACY_DISTRIBUTOR_ID = "distribID";
	public static final String LEGACY_STORE_COUNTRY_CODE = "store";
}
