package com.titan.shop.common;

import java.util.UUID;

/**
 *   Title: Constants
 * FileName: Constants.java
 *   @version 1.0
 *   @Created date: 06-01-2018
 *   @author Next Sphere Technologies
 *   Copyright: Copyright © Next Sphere Technologies 2018.
 */
public class Constants {
    private Constants() {
    }

    public static class Globals {
        public static final String UNIQUEIDENTIFIER = UUID.randomUUID().toString();
    }
    public static class SSO {
        public static final String CLIENT_ASSERTION_TYPE = "client_assertion_type";
        public static final String CLIENT_ASSERTION_TYPE_VALUE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";
        public static final String CLIENT_ASSERTION = "client_assertion";
        public static final String GRANT_TYPE = "grant_type";
        public static final String CONTENT_TYPE = "Content-Type";
        public static final String URLENCODED_FORMAT = "application/x-www-form-urlencoded";
        public static final String AUTHORIZATION="Authorization";
        public static final String BEARER = "Bearer";
        public static final String CLIENT_ID = "client_id";
        public static final String USERNAME = "username";
        public static final String ACCESS_TOKEN = "access_token";
        public static final String CLIENT_CREDENTIALS = "client_credentials";
    }
}
