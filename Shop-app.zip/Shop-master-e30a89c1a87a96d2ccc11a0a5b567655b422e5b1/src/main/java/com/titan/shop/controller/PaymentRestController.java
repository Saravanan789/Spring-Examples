//package com.titan.shop.controller;
//
//import com.titan.shop.model.payment.TokenResponse;
//import org.apache.http.*;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.*;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.client.RestTemplate;
//
//import javax.servlet.http.HttpServletRequest;
//
///**
// * Title: PaymentRestController
// * FileName: PaymentRestController.java
// *
// * @author Next Sphere Technologies
// * @version 1.0
// * @Created date: 23-08-2018
// * @Copyright: Copyright © Next Sphere Technologies 2018.
// */
//@CrossOrigin
//@RestController
//@RequestMapping("/api")
//public class PaymentRestController {
//
//    @Value("${payment.authorization}")
//    private String authorization;
//
//    @Value("${shop.apiGatewayURL}")
//    private String apiGatewayURL;
//
//    @RequestMapping(method = RequestMethod.GET, value = "/stores/{storeId}/country-code/{countryCode}/order-type/{orderType}/culture-code/{cultureCode}/payment-methods")
//    public ResponseEntity<?> getPaymentMethods(@PathVariable("storeId") Long storeId,
//                                                   @PathVariable("orderType") String orderType,
//                                                   @PathVariable("cultureCode") String cultureCode,
//                                                   @PathVariable("countryCode") String countryCode) {
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.set("Authorization", authorization);
//        String url = apiGatewayURL + "/payment/v1/stores/" + storeId + "/country-code/" + countryCode + "/order-type/" + orderType + "/culture-code/" + cultureCode + "/payment-methods";
//        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
//        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);
//        return new ResponseEntity<>(respEntity.getBody(),HttpStatus.OK);
//    }
//
//    @RequestMapping(method = RequestMethod.GET, value = "/payments/paymentMethods/{storeId}")
//    public ResponseEntity<?> getProcessorConfig(@PathVariable("storeId") Long storeId) {
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.set("Authorization", authorization);
//        String url = apiGatewayURL + "/payment/v1/payments/paymentMethods/"+storeId;
//        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
//        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);
//        return new ResponseEntity<>(respEntity.getBody(),HttpStatus.OK);
//    }
//
//    @RequestMapping(method = RequestMethod.POST, value = "/token")
//    public ResponseEntity<?> savePaymentTokenDetails(@RequestBody TokenResponse tokenResponse,
//                                                     HttpServletRequest servletRequest) {
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.set("Authorization", authorization);
//        String url = apiGatewayURL + "/payment/v1/payments/token";
//        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
//        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.POST, entity, Object.class);
//        return new ResponseEntity<>(respEntity.getBody(),HttpStatus.OK);
//    }
//
//    @RequestMapping(method = RequestMethod.POST, value = "/{orderId}/create-payment-checks")
//    public ResponseEntity<?> createPaymentCheck(@PathVariable String orderId,
//                                                @Validated(AuthorizeRequest.Authorize.class)
//                                                @RequestBody AuthorizeRequest authorizeRequest,
//                                                HttpServletRequest servletRequest ) {
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.set("Authorization", authorization);
//        String url = apiGatewayURL + "/payment/v1/payments/"+orderId+"/create-payment-checks";
//        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
////        ResponseEntity respEntity = restTemplate.exchange(url, HttpMethod.POST, entity, Object.class);
//        ResponseEntity respEntity = null;
//        return new ResponseEntity<>(respEntity,HttpStatus.OK);
//    }
//
//
//}
//
