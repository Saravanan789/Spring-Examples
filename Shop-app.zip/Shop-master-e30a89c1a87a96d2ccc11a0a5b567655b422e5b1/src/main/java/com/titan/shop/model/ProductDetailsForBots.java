package com.titan.shop.model;

public class ProductDetailsForBots {
	private String productDescription;
	private String url;
	private String imageUrl;
	private String title;
	private String itemNumber;
	private String countryCode;
	private Boolean isBots;
	
	/**
	 *  
	 * @return
	 */
	public Boolean getIsBots() {
		return isBots;
	}

	/**
	 * 
	 * @param isBots
	 */
	public void setIsBots(Boolean isBots) {
		this.isBots = isBots;
	}

	/**
	 * @return the productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}

	/**
	 * @param productDescription
	 *   
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *   
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
		
}
