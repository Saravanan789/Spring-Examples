package com.titan.shop.utils;

import com.sun.jersey.api.client.ClientResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Component;


@Component("CacheManager")
public class CacheManager {


    //Clears Client Assertion Cache
    @CacheEvict(cacheNames = {"Shop"}, key = "'ClientAssertion'")
    public void clearAssertion(){}

    //Clears Client Assertion Keys Cache
    @CacheEvict(cacheNames = {"Shop"}, key = "'AssertionKeys'")
    public void clearAssertionKeys(){}

    //Clears Keycloak Certs for public key Cache
    @CacheEvict(cacheNames = {"Shop"}, key = "'KeycloakPublicCerts'")
    public void clearKeycloakPublicCerts(){}

    //Clear Jwk Response Cache.
    @CacheEvict(cacheNames = {"Shop"}, key = "'JwkResponse'")
    public void clearJWKResponse(){}


    //Clear product detail Cache.
    @CacheEvict(cacheNames = {"Shop"}, key = "'id=' + #countryCode + #itemNumber")
    public boolean clearProductDetailForBots(String countryCode,String itemNumber){
        return true;
    }
    
    //Clears Entire Cache in Application Cache
    @CacheEvict(cacheNames = {"Shop"}, allEntries = true)
    public boolean clearAllCacheForProducts(){
        return true;
    }

    //Clears Entire Cache in Application Cache
    @CacheEvict(cacheNames = {"Shop"}, allEntries = true)
    public void clearAllCache(){   }


}
