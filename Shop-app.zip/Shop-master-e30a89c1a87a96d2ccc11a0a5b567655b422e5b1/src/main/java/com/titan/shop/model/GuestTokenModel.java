package com.titan.shop.model;

public class GuestTokenModel {
    private String guestToken;

    public String getGuestToken() {
        return guestToken;
    }

    public GuestTokenModel setGuestToken(String guestToken) {
        this.guestToken = guestToken;
        return this;
    }
}
