package com.titan.shop.model;

import java.util.List;

public class ProductDetailModel {
    private String itemNumber;
    private String shortDescription;
    private String storeName;
    private String name;
    private String productUrl;
    private String slug;
    
    public class ImageOptionsModel{
    	private String type;
    	private List<ImageModel> details;
    	
        public List<ImageModel> getDetails() {
            return details;
        }

        public void setDetails(List<ImageModel> details) {
            this.details = details;
        }
        
        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }
   
	public class ImageModel{
        private String url;
        private String type;

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
        
        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }
	
	public class CategoryModel{
        private String slug;

        public String getSlug() {
            return slug;
        }

        public void setSlug(String slug) {
            this.slug = slug;
        }
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getName() {
        return name;
    }

	public void setName(String name) {
        this.name = name;
    }

    public List<ImageOptionsModel> getImageModelList() {
        return imageModelList;
    }

    public void setImageModelList(List<ImageOptionsModel> imageModelList) {
        this.imageModelList = imageModelList;
    }
	
	public List<CategoryModel> getCategory() {
        return categories;
    }

    public void setCategory(List<CategoryModel> categories) {
        this.categories = categories;
    }
	
    public String getProductUrl() {
  		return productUrl;
  	}

  	public void setProductUrl(String productUrl) {
  		this.productUrl = productUrl;
  	}
  	
  	 public String getSlug() {
 		return slug;
 	}

 	public void setSlug(String slug) {
 		this.slug = slug;
 	}


    private List<ImageOptionsModel> imageModelList;
	private List<CategoryModel> categories;

}


