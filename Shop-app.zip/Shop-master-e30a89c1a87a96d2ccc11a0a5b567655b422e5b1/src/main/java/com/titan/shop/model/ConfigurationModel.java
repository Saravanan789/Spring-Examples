/**
 * 
 */
package com.titan.shop.model;
import java.util.List;
/**
 * @author NextSphere Technologies
 *
 */
public class ConfigurationModel {
	private String countryCode;
	private String languageCode;
	private String fboId;
	private String languageCultureCode;
	private String cartSessionGuid;
	private String repeatWebOrderNumber;
	private boolean loadConfiguration;
	private Double configVersion;
	private ApiConfigurationModel apiConfiguration;
	private String referralId;
	private ProductDetailsForBots productDetailsForBots;
	private String googleTagManager;
	
	/**
	 * 
	 * @return product details
	 */
	public ProductDetailsForBots getProductDetailsForBots() {
		return productDetailsForBots;
	}
	
	/**
	 * set product details
	 * @param productDetailsForBots
	 */
	public void setProductDetailsForBots(ProductDetailsForBots productDetailsForBots) {
		this.productDetailsForBots = productDetailsForBots;
	}
	/**
	 * @return the apiConfiguration
	 */
	public ApiConfigurationModel getApiConfiguration() {
		return apiConfiguration;
	}
	/**
	 * @param apiConfiguration
	 *            the apiConfiguration to set
	 */
	public void setApiConfiguration(ApiConfigurationModel apiConfiguration) {
		this.apiConfiguration = apiConfiguration;
	}
	/**
	 * @return the languageCode
	 */
	public String getLanguageCode() {
		return languageCode;
	}
	/**
	 * @param languageCode
	 *            the languageCode to set
	 */
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	private List<TemplateConfigurationModel> templateConfiguration;
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the templateConfiguration
	 */
	public List<TemplateConfigurationModel> getTemplateConfiguration() {
		return templateConfiguration;
	}
	/**
	 * @param templateConfiguration
	 *            the templateConfiguration to set
	 */
	public void setTemplateConfiguration(List<TemplateConfigurationModel> templateConfiguration) {
		this.templateConfiguration = templateConfiguration;
	}
	/**
	 * @return the loadConfiguration
	 */
	public boolean isLoadConfiguration() {
		return loadConfiguration;
	}
	/**
	 * @param loadConfiguration
	 *            the loadConfiguration to set
	 */
	public void setLoadConfiguration(boolean loadConfiguration) {
		this.loadConfiguration = loadConfiguration;
	}
	/**
	 * @return the configVersion
	 */
	public Double getConfigVersion() {
		return configVersion;
	}
	/**
	 * @param configVersion
	 *            the configVersion to set
	 */
	public void setConfigVersion(Double configVersion) {
		this.configVersion = configVersion;
	}
	/**
	 * @return the fboId
	 */
	public String getFboId() {
		return fboId;
	}
	/**
	 * @param fboId the fboId to set
	 */
	public void setFboId(String fboId) {
		this.fboId = fboId;
	}

	/**
	 * @return the languageCultureCode
	 */
	public String getLanguageCultureCode() {
		return languageCultureCode;
	}

	/**
	 * @param languageCultureCode the languageCultureCode to set
	 */
	public void setLanguageCultureCode(String languageCultureCode) {
		this.languageCultureCode = languageCultureCode;
	}

	/**
	 * @return the cartSessionGuid
	 */
	public String getCartSessionGuid() {
		return cartSessionGuid;
	}
	/**
	 * @param cartSessionGuid the cartSessionGuid to set
	 */
	public void setCartSessionGuid(String cartSessionGuid) {
		this.cartSessionGuid = cartSessionGuid;
	}
	
		/**
	 * @return the repeatWebOrderNumber
	 */
	public String getRepeatWebOrderNumber() {
		return repeatWebOrderNumber;
	}
	/**
	 * @param repeatWebOrderNumber the repeatWebOrderNumber to set
	 */
	public void setRepeatWebOrderNumber(String repeatWebOrderNumber) {
		this.repeatWebOrderNumber = repeatWebOrderNumber;
	}
	/**
	 * @return the referralId
	 */
	public String getReferralId() {
		return referralId;
	}
	/**
	 * @param referralId the referralId to set
	 */
	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}

	/**
	 * @return the googleTagManager
	 */
	public String getGoogleTagManager() {
		return googleTagManager;
	}
	/**
	 * @param googleTagManager to set the googleTagManager
	 */
	public void setGoogleTagManager(String googleTagManager) {
		this.googleTagManager = googleTagManager;
	}
}