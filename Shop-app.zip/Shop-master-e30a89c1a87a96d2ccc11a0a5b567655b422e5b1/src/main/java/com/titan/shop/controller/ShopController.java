/**
 *
 */
package com.titan.shop.controller;

import com.titan.portalutils.geolocation.misc.GeoLocation;
import com.titan.portalutils.geolocation.model.GeoLocationModel;
import com.titan.shop.model.AppConfiguration;
import com.titan.shop.model.ConfigurationModel;
import com.titan.shop.model.ProductDetailsForBots;
import com.titan.shop.service.ShopService;
import com.titan.shop.shared.ShopConstants;
import org.apache.commons.lang3.ArrayUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;

/**
* @author NextSphere Technologies
*/
@CrossOrigin
@Controller
public class ShopController implements ErrorController {
	@Autowired
	private ErrorAttributes errorAttributes;
	@Autowired
	private AppConfiguration appConfiguration;
	@Autowired
	private ShopService shopService;
	@Value("${shop.cdnURL}")
	private String baseHrefUrl;
	@Value("${cookie.cookieDomain}")
	String cookieDomain;
	@Value("${cookie.cookiePath}")
	String cookiePath;
	@Value("${ipStack.ipStackBaseUrl}")
	String ipStackBaseUrl;
	@Value("${ipStack.ipStackAccessKey}")
	String ipStackAccessKey;
	
	@Value("${shop.fileExtensions}")
	String[] fileExtensions;

	@Value("${robots.enable-disallow-all:true}")
	private Boolean isDisallowAllEnabled;

	@Value("${robots.allow-txt-file}")
	private String robotsTxt;

	@Value("${robots.disallow-all-txt-file:true}")
	private String robotsDisallowAllTxt;

	private static final Logger LOGGER = LoggerFactory.getLogger(ShopController.class);

	/**
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "/error" })
	public ModelAndView get(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			RedirectAttributes redirectAttributes) throws IOException {
		String countryCode = getCountryCodeFromParams(httpServletRequest);
		String languageCode = httpServletRequest.getParameter(ShopConstants.LANGUAGE_CODE);
		String languageCultureCode = httpServletRequest.getParameter(ShopConstants.LEGACY_LANGUAGE_CULTURE_CODE);
		String cartSessionGuid = httpServletRequest.getParameter(ShopConstants.CART_SESSION_GUID);
		String repeatWebOrderNumber = httpServletRequest.getParameter(ShopConstants.REPEAT_WEB_ORDER_NUMBER);
		String fboId = getFboIDFromParams(httpServletRequest);
		String[] originalPaths = httpServletRequest.getAttribute("originalUrl").toString().split("/");
		String requestCountryCode = (originalPaths.length > 2) ? originalPaths[1] : "usa";
		boolean isBots = Boolean.parseBoolean(httpServletRequest.getParameter(ShopConstants.ISBOTS));

		String path = getErrorAttributes(httpServletRequest, false).get("path").toString();
		String extension =  path.substring(path.lastIndexOf(".") + 1, path.length());
		String referralId = httpServletRequest.getParameter("referralId");
		if (getErrorAttributes(httpServletRequest, false).get("path") != null
				&&  !ArrayUtils.contains(fileExtensions, extension)) { 
			ModelAndView mv = new ModelAndView();
			mv.setViewName("index");
			mv.addObject("baseHrefUrl", baseHrefUrl + "/");
			httpServletResponse.setStatus(HttpStatus.OK.value());
			String country = StringUtils.isEmpty(countryCode) ? "usa" : countryCode;
			ConfigurationModel config = appConfiguration.getConfigByCountry(country);
			config.getApiConfiguration().setCountryCode(requestCountryCode);
			if (isBots) {
				ProductDetailsForBots productDetails = new ProductDetailsForBots();
				productDetails = getProductDetails(httpServletRequest, languageCode, countryCode, fboId);
				config.setProductDetailsForBots(productDetails);
			}

			if (!StringUtils.isEmpty(countryCode) && !StringUtils.isEmpty(languageCode)) {
				config.setLoadConfiguration(true);
				config.setLanguageCode(languageCode);
			} else {
				String language = StringUtils.isEmpty(languageCode) ? "en-us" : languageCode;
				config.setLanguageCode(language);
			}
			if (!StringUtils.isEmpty(fboId)) {
				config.setFboId(fboId);
			}
			if (!StringUtils.isEmpty(countryCode)) {
				config.setCountryCode(countryCode);
			}
			if (!StringUtils.isEmpty(referralId)) {
				config.setReferralId(referralId);
			}
			if (!StringUtils.isEmpty(cartSessionGuid)) {
				config.setCartSessionGuid(cartSessionGuid);
			}
			if (!StringUtils.isEmpty(repeatWebOrderNumber)) {
				config.setRepeatWebOrderNumber(repeatWebOrderNumber);
			}
			if (!StringUtils.isEmpty(languageCultureCode)) {
				config.setLanguageCultureCode(languageCultureCode);
			}
			mv.addObject("config", config);
			return mv;
		} else {
			int status = getErrorAttributes(httpServletRequest, false).get("status") != null
					? Integer.parseInt(getErrorAttributes(httpServletRequest, false).get("status").toString()) : 500;
			httpServletResponse.setStatus(status);
			ModelAndView mv = new ModelAndView();
			mv.addObject("baseHrefUrl", baseHrefUrl + "/");
			mv.setViewName("../notfound");
			return mv;
		}
	}

	/**
	 * To get the product details
	 *
	 * @param httpServletRequest
	 * @param languageCode
	 * @param countryCode
	 * @param fboId
	 * @return
	 */
	private ProductDetailsForBots getProductDetails(HttpServletRequest httpServletRequest, String languageCode,
			String countryCode, String fboId) {
		String purchaseFlowType = httpServletRequest.getParameter(ShopConstants.PURCHASE_FLOW);
		String memberTitle = httpServletRequest.getParameter(ShopConstants.MEMBER_TITLE);
		Long memberTitleId = Long.parseLong(httpServletRequest.getParameter(ShopConstants.MEMBER_TITLE_ID));
		Long storeId = Long.parseLong(httpServletRequest.getParameter(ShopConstants.STORE_ID));
		Long productId = Long.parseLong(httpServletRequest.getParameter(ShopConstants.PRODUCT_ID));

		return shopService.getProductInfoForBots(storeId, productId, languageCode, purchaseFlowType, countryCode, fboId,
				memberTitle,memberTitleId);
	}

	/**
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 */
	@RequestMapping(value = { "/" })
	public ModelAndView getView(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {

		String fboId = getFboIDFromParams(httpServletRequest);
		String cartSessionGuid = httpServletRequest.getParameter(ShopConstants.CART_SESSION_GUID);
		String referralId = httpServletRequest.getParameter("referralId");
		String repeatWebOrderNumber = httpServletRequest.getParameter(ShopConstants.REPEAT_WEB_ORDER_NUMBER);
		String languageCultureCode = httpServletRequest.getParameter(ShopConstants.LEGACY_LANGUAGE_CULTURE_CODE);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		ConfigurationModel config = appConfiguration.getConfigByCountry("");
		config.setLoadConfiguration(true);
		// Set Country Code Retrieved from IP stack in Cookie if Cookie value is
		// null or empty
		String countryCode = getCountryCodeFromRequest(httpServletRequest, httpServletResponse);
		LOGGER.info("Country Code from Ip stack: ", ESAPI.encoder().encodeForHTML(countryCode));
		config.getApiConfiguration().setCountryCode(countryCode);
		if (!StringUtils.isEmpty(fboId)) {
			config.setFboId(fboId);
		}
		if (!StringUtils.isEmpty(countryCode)) {
			config.setCountryCode(countryCode);
		}
		if (!StringUtils.isEmpty(cartSessionGuid)) {
			config.setCartSessionGuid(cartSessionGuid);
		}
		if (!StringUtils.isEmpty(referralId)) {
			config.setReferralId(referralId);
		}
		if (!StringUtils.isEmpty(repeatWebOrderNumber)) {
			config.setRepeatWebOrderNumber(repeatWebOrderNumber);
		}
		if (!StringUtils.isEmpty(languageCultureCode)) {
			config.setLanguageCultureCode(languageCultureCode);
		}
		mv.addObject("config", config);
		mv.addObject("baseHrefUrl", baseHrefUrl + "/");
		// httpServletResponse.setHeader("Cache-Control", "no-cache");
		return mv;
	}

	/**
	 * @param request
	 * @param includeStackTrace
	 * @return
	 */
	private Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
		RequestAttributes requestAttributes = new ServletRequestAttributes(request);
		return errorAttributes.getErrorAttributes(requestAttributes, includeStackTrace);
	}

	/**
	 * @return
	 */
	@GetMapping(value = {"/robots.txt", "/robot.txt", "/robots", "/robot"})
	public ResponseEntity robotsFile() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.valueOf(MediaType.TEXT_PLAIN_VALUE));
		return new ResponseEntity<>(isDisallowAllEnabled ? robotsDisallowAllTxt : robotsTxt, headers, HttpStatus.OK);
	}

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return "/";
	}

	/**
	 * Sets Country Code using Geolocation
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	private String getCountryCodeFromRequest(HttpServletRequest request, HttpServletResponse response) {
		String countryCode = getCountryCodeFromParams(request);
		Cookie cookie = WebUtils.getCookie(request, ShopConstants.COUNTRY_CODE_COOKIE_NAME);
		if (((Objects.nonNull(cookie) && StringUtils.isEmpty(cookie.getValue())) || Objects.isNull(cookie))
				&& StringUtils.isEmpty(countryCode)) {
			GeoLocationModel geoLocationModel = GeoLocation.getClientGeoLocationDetails(request, response,
					ipStackBaseUrl, ipStackAccessKey, cookiePath, cookieDomain);
			if (Objects.nonNull(geoLocationModel) && Objects.nonNull(geoLocationModel.getCountryCode())) {
				// Cookie cookie = WebUtils.getCookie(request,
				// ShopConstants.COUNTRY_CODE_COOKIE_NAME);
				// if ((Objects.nonNull(cookie) &&
				// StringUtils.isEmpty(cookie.getValue()))) {
				// cookie.setValue(geoLocationModel.getCountryCode().toLowerCase());
				// cookie.setDomain(cookieDomain);
				// cookie.setPath(cookiePath);
				// response.addCookie(cookie);
				// } else if (Objects.isNull(cookie)) {
				// Cookie cookie1 = new
				// Cookie(ShopConstants.COUNTRY_CODE_COOKIE_NAME,
				// geoLocationModel.getCountryCode().toLowerCase());
				// cookie1.setDomain(cookieDomain);
				// cookie1.setPath(cookiePath);
				// response.addCookie(cookie1);
				// }
				countryCode = geoLocationModel.getCountryCode().toLowerCase();
			}
		}
		return !StringUtils.isEmpty(countryCode) ? countryCode.toLowerCase() : "usa";
	}

	/**
	 * @param httpServletRequest
	 * @return
	 */
	private String getCountryCodeFromParams(HttpServletRequest httpServletRequest) {
		return !StringUtils.isEmpty(httpServletRequest.getParameter(ShopConstants.LEGACY_STORE_COUNTRY_CODE))
				? httpServletRequest.getParameter(ShopConstants.LEGACY_STORE_COUNTRY_CODE)
				: httpServletRequest.getParameter(ShopConstants.COUNTRY_CODE);
	}

	/**
	 * @param httpServletRequest
	 * @return
	 */
	private String getFboIDFromParams(HttpServletRequest httpServletRequest) {
		return !StringUtils.isEmpty(httpServletRequest.getParameter(ShopConstants.LEGACY_DISTRIBUTOR_ID))
				? httpServletRequest.getParameter(ShopConstants.LEGACY_DISTRIBUTOR_ID)
				: httpServletRequest.getParameter(ShopConstants.FBOID);
	}
}