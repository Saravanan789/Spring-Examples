package com.titan.shop.utils;

import com.titan.shop.model.RSAKeys;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;


@Component("JWTKeyGenerator")
public class JWTKeyGenerator {

    @Value("${shop.ssoApiURL}")
    String ssoApiURL;

    @Value("${shop.RSAPrivateKey}")
    String rsaPrivateKey;

    @Value("${shop.RSAPublicKey}")
    String rsaPublicKey;


    @Autowired
    private CacheManager cacheManager;


    /**
     * The Logger for this class.
     */
    private static final Logger logger = LoggerFactory.getLogger(JWTKeyGenerator.class);


    /**
     * @return RSA KEYS
     */
    @Cacheable(cacheNames = "Shop", key = "'AssertionKeys'")
    public RSAKeys getAssertionKeys() {
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec keySpecPKCS8 = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(rsaPrivateKey));
            RSAPrivateKey privateKey = (RSAPrivateKey)kf.generatePrivate(keySpecPKCS8);
            X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(Base64.getDecoder().decode(rsaPublicKey));
            RSAPublicKey publicKey = (RSAPublicKey) kf.generatePublic(keySpecX509);
            RSAKeys keys = new RSAKeys();
            keys.setPrivateKey(privateKey);
            keys.setPublicKey(publicKey);
            return keys;
        } catch (Exception ex) {
            logger.error(ESAPI.encoder().encodeForHTML(ex.getMessage()), ESAPI.encoder().encodeForHTML(ex.toString()));
            return null;
        }
    }

    /**
     * @return Keycloak JWK
     */
    @Cacheable(cacheNames = "Shop", key = "'KeycloakPublicCerts'")
    public Map getKeycloakPublicCerts() {
        HttpEntity requestEntity = new HttpEntity(new HttpHeaders());
        RestTemplate template = new RestTemplate();
        //rest Call to get Keycloak Certs.
        ResponseEntity response = template.exchange(ssoApiURL + "/certs", HttpMethod.GET, requestEntity, String.class, new Object[0]);
        JacksonJsonParser parser = new JacksonJsonParser();
        String userObject = (String) response.getBody();
        return parser.parseMap(userObject);
    }
}
