package com.titan.shop.model;

import java.util.ArrayList;
import java.util.List;

public class JwkResponseModel {
    public List<Jwk> keys = new ArrayList<>();

    public List<Jwk> getKeys() {
        return keys;
    }

    public void setKeys(List<Jwk> keys) {
        this.keys = keys;
    }
}
