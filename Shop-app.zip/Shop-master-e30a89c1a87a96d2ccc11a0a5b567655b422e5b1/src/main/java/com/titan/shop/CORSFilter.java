//package com.titan.shop;
//
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//
//import javax.servlet.*;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//
///**
//* Title: com.titan.productcatalog
//* FileName: com.titan.productcatalog.java
//*
//* @author Next Sphere Technologies
//* @version 1.0
//* @Copyright: Copyright © Next Sphere Technologies 2017.
//* @Created date: 29-05-2018
//*/
//@Component
//@Order(1)
//public class CORSFilter implements Filter {
//
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//            throws IOException, ServletException {
//        // TODO: Move properties to YML FIle
//        HttpServletResponse httpResponse = (HttpServletResponse) response;
//        httpResponse.setHeader("Access-Control-Allow-Origin", "*");
//        httpResponse.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE, PATCH, HEAD");
//        httpResponse.setHeader("Access-Control-Allow-Headers", "X-Auth-Token, Content-Type, X-Total-Count, UUID, Authentication");
//        httpResponse.setHeader("Access-Control-Expose-Headers", "X-Total-Count, UUID, Authentication");
//        httpResponse.setHeader("Access-Control-Allow-Credentials", "false");
//        httpResponse.setHeader("Access-Control-Max-Age", "4800");
//        chain.doFilter(request, response);
//    }
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//    }
//
//    @Override
//    public void destroy() {
//    }
//}
//
//
