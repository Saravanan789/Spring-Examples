package com.titan.shop.common;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *   Title: ExpiresFilter
 *   FileName: ExpiresFilter.java
 *   @version 1.0
 *   @Created date: 06-01-2018
 *   @author Next Sphere Technologies
 *   Copyright: Copyright © Next Sphere Technologies 2018.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ExpiresFilter implements Filter
{
    // add a five years expiry
    private Integer years = 2;

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        if (years > -1) {
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            c.add(Calendar.YEAR, years);

            // HTTP header date format: Thu, 01 Dec 1994 16:00:00 GMT
            String o = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss zzz")
                    .format(c.getTime());
            ((HttpServletResponse) response).setHeader("Expires", o);
        }
        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
}
