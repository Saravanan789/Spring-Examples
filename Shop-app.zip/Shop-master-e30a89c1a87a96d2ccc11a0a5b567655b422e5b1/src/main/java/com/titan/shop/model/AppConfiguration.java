/**
 * 
 */
package com.titan.shop.model;

import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.SignedJWT;
import com.titan.shop.common.Constants;
import com.titan.shop.service.SSOTokenService;
import com.titan.shop.utils.CacheManager;
import com.titan.shop.utils.ClientAssertionGenerator;
import com.titan.shop.utils.JWTKeyGenerator;
import org.apache.commons.lang3.StringUtils;
import org.keycloak.common.util.Base64Url;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.codec.Base64;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

/**
 * @author NextSphere Technologies
 *
 */
@Configuration
@EnableConfigurationProperties
public class AppConfiguration {

	@Value("${shop.apiGatewayURL}")
	String apiGatewayURL;

	@Value("${shop.ssoApiURL}")
	String ssoApiURL;

	@Value("${shop.ssoClientID}")
	String ssoClientID;

	@Value("${shop.s3BucketURL}")
	String s3BucketURL;

	@Value("${shop.enrollSiteURL}")
	String enrollSiteURL;

	@Value("${shop.accountSiteURL}")
	String accountSiteURL;

	@Value("${shop.ssoClientSecret}")
	String ssoClientSecret;

	@Value("${shop.corporateSiteUrl}")
	String corporateSiteUrl;

	@Value("${shop.customerName}")
	String customerName;

	// @Value("${shop.templateVersion}")
	String templateVersion;

	@Value("${shop.cdnURL}")
	String cdnURL;

	@Value("${shop.reBrandlyAPIKey}")
	String reBrandlyAPIKey;

	@Value("${shop.reportsURL}")
	String reportsURL;

	@Value("${shop.cookieDomain}")
	String cookieDomain;

	@Value("${shop.cookiePath}")
	String cookiePath;

	@Value("${shop.legacyURL}")
	String legacyURL;

	@Value("${shop.accessToken}")
	String accessToken;

	@Value("${shop.refreshToken}")
	String refreshToken;

	@Value("${shop.idNonce}")
	String idNonce;

	@Value("${shop.memberId}")
	String memberId;
	
	@Value("${shop.baseHrefURL}")
	String baseHrefURL;
	
	@Value("${shop.defaultFBOID}")
	String defaultFBOID;

	@Value("${shop.autoShipStartDay}")
	Integer autoShipStartDay;

	@Value("${shop.autoShipEndDay}")
	Integer autoShipEndDay;

	@Value("${shop.autoShipMaxMonths}")
	Integer autoShipMaxMonths;
	
	@Value("${shop.cookieExpiryDays}")
	Integer cookieExpiryDays;
	
	@Value("${shop.ssoApiUserURL}")
	String ssoApiUserURL;
	
	@Value("${shop.enableSponsorEligibilityCheck}")
	Boolean enableSponsorEligibilityCheck;

	@Value("${titan.security.headers.enable_authentication:false}")
	Boolean enableAuthentication;

	@Value("${titan.security.headers.enable_authorization:true}")
	Boolean enableAuthorization;

	@Value("${shop.remove_obsolete_cookies:true}")
	Boolean removeObsoleteCookies;
	@Value("${shop.environment_name}")
	String envName;

	@Value("${shop.legacyFboRedirectUrl}")
	String legacyFboRedirectUrl;

	@Value("${shop.legacyRetailRedirectUrl}")
	String legacyRetailRedirectUrl;

	@Value("${shop.trainingsMenuRedirectUrl}")
	String trainingsMenuRedirectUrl;

	@Value("${shop.starterPackUrl}")
	String starterPackUrl;


	@Value("${shop.googleTagManager}")
	String googleTagManager;

	@Value("${shop.longPollCount}")
	Integer longPollCount;

	@Value("${shop.enableLongPoll}")
	Boolean enableLongPoll;

	@Value("${shop.enableEasterEgg}")
	Boolean enableEasterEgg;

	@Value("${shop.legacyShopMobileRedirectUrl}")
	String legacyShopMobileRedirectUrl;

	@Value("${shop.cmsTemplateStylePath}")
	String cmsTemplateStylePath;

	@Value("${shop.cmsTemplateScriptPath}")
	String cmsTemplateScriptPath;

	@Value("${shop.cmsTemplateStyleIntegrity}")
	String cmsTemplateStyleIntegrity;

	@Value("${shop.cmsTemplateScriptIntegrity}")
	String cmsTemplateScriptIntegrity;
	@Value("${shop.paymentServiceKey}")
	String paymentServiceKey;

	@Value("${shop.paymentSecurityKey}")
	String paymentSecurityKey;

	@Value("${shop.paymentApiKey}")
	String paymentApiKey;

	@Value("${shop.recognitionMenuRedirectUrl}")
	String recognitionMenuRedirectUrl;

	@Value("${corporate.siteTrackerVersionNo:v1}")
	String siteTrackerVersionNo;


	public AppConfiguration(){
		this.templateVersion = Constants.Globals.UNIQUEIDENTIFIER;
	}

	/**
	 * The Logger for this class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AppConfiguration.class);

	@Autowired
	private ClientAssertionGenerator clientAssertionGenerator;

	@Autowired
	private JWTKeyGenerator jwtKeyGenerator;

	@Autowired
	private CacheManager cacheManager;

	@Autowired
	SSOTokenService ssoTokenService;

	/**
	 * @param country
	 * @return
	 */
	public ConfigurationModel getConfigByCountry(String country) {
		ConfigurationModel config = new ConfigurationModel();
		config.setCountryCode(country);
		config.setConfigVersion(1.2D);
		config.setApiConfiguration(getApiConfig());
		config.setGoogleTagManager(googleTagManager);
		return config;
	}

	/**
	 * @return
	 */
	private ApiConfigurationModel getApiConfig() {
		ApiConfigurationModel apiConfig = new ApiConfigurationModel();
		apiConfig.setApiGatewayURL(apiGatewayURL);
		apiConfig.setSsoApiURL(ssoApiURL);
		apiConfig.setSsoClientID(ssoClientID);
		apiConfig.setS3BucketURL(s3BucketURL);
		apiConfig.setEnrollSiteURL(enrollSiteURL);
		apiConfig.setAccountSiteURL(accountSiteURL);
		apiConfig.setSsoClientSecret(ssoClientSecret);
		apiConfig.setCorporateSiteUrl(corporateSiteUrl);
		apiConfig.setCustomerName(customerName);
		apiConfig.setTemplateVersion(templateVersion);
		apiConfig.setSsoInternalKey(getPublicKey());
		apiConfig.setSsoClientAssertion(getClientAssertion());
		apiConfig.setReBrandlyAPIKey(reBrandlyAPIKey);
		apiConfig.setReportsURL(reportsURL);
		apiConfig.setCookieDomain(cookieDomain);
		apiConfig.setCookiePath(cookiePath);
		apiConfig.setCdnURL(cdnURL);
		apiConfig.setLegacyURL(legacyURL);
		apiConfig.setAccessToken(accessToken);
		apiConfig.setRefreshToken(refreshToken);
		apiConfig.setIdNonce(idNonce);
		apiConfig.setMemberId(memberId);
		apiConfig.setBaseHrefURL(baseHrefURL);
		apiConfig.setDefaultFBOID(defaultFBOID);
		apiConfig.setAutoShipStartDay(autoShipStartDay);
		apiConfig.setAutoShipEndDay(autoShipEndDay);
		apiConfig.setAutoShipMaxMonths(autoShipMaxMonths);
		apiConfig.setCookieExpiryDays(cookieExpiryDays);
		apiConfig.setSsoApiUserURL(ssoApiUserURL);
		apiConfig.setEnableAuthentication(enableAuthentication);
		apiConfig.setEnableAuthorization(enableAuthorization);
		apiConfig.setEnableSponsorEligibilityCheck(enableSponsorEligibilityCheck);
		apiConfig.setRemoveObsoleteCookies(removeObsoleteCookies);
		apiConfig.setEnvName(envName);
		apiConfig.setLegacyFboRedirectUrl(legacyFboRedirectUrl);
		apiConfig.setLegacyRetailRedirectUrl(legacyRetailRedirectUrl);
		apiConfig.setCmsTemplateStylePath(cmsTemplateStylePath);
		apiConfig.setCmsTemplateScriptPath(cmsTemplateScriptPath);
		apiConfig.setCmsTemplateStyleIntegrity(cmsTemplateStyleIntegrity);
		apiConfig.setCmsTemplateScriptIntegrity(cmsTemplateScriptIntegrity);
		apiConfig.setTrainingsMenuRedirectUrl(trainingsMenuRedirectUrl);
		apiConfig.setStarterPackUrl(starterPackUrl);
		apiConfig.setEnableLongPoll(enableLongPoll);
		apiConfig.setLongPollCount(longPollCount);
		apiConfig.setEnableEasterEgg(enableEasterEgg);
		apiConfig.setLegacyShopMobileRedirectUrl(legacyShopMobileRedirectUrl);
		apiConfig.setPaymentApiKey(paymentApiKey);
		apiConfig.setPaymentSecurityKey(paymentSecurityKey);
		apiConfig.setPaymentServiceKey(paymentServiceKey);
		apiConfig.setRecognitionMenuRedirectUrl(recognitionMenuRedirectUrl);
		apiConfig.setSiteTrackerVersionNo(siteTrackerVersionNo);
		GuestTokenModel guestToken = this.getGuestToken();
		if(Objects.nonNull(guestToken) && StringUtils.isNotBlank(guestToken.getGuestToken())){
			apiConfig.setGuestToken(guestToken.getGuestToken());
		}
		return apiConfig;
	}

	// gets Public Key
	public String getPublicKey() {
		// Gets JWS From Keycloak Certs End point
		Map json = jwtKeyGenerator.getKeycloakPublicCerts();
		ArrayList<Map> keys = (ArrayList<Map>) json.get("keys");
		Map key = keys.get(0);
		String base64encoded = "";
		try {
			// gets modulus from response
			String mod = (String) key.get("n");
			// gets exponent from response
			String exp = (String) key.get("e");
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			// Conversion of modulus and exponent into BigInteger
			BigInteger modulus = new BigInteger(1, Base64Url.decode(mod));
			BigInteger publicExponent = new BigInteger(1, Base64Url.decode(exp));
			// generating publickey specification from modulus and exponent
			RSAPublicKeySpec spec = new RSAPublicKeySpec(modulus, publicExponent);
			// generating public key String from RSApublic key
			PublicKey pub = keyFactory.generatePublic(spec);
			byte[] data = pub.getEncoded();
			base64encoded = new String(Base64.encode(data));
		} catch (Exception ex) {
			LOGGER.error(ESAPI.encoder().encodeForHTML(ex.getMessage()), ESAPI.encoder().encodeForHTML(ex.toString()));
		}
		// returns public key
		return base64encoded;
	}

	// gets ClientAssertion
	public String getClientAssertion() {
		// gets Assertion from Cache if not available Generates New Assertion.
		String assertion = clientAssertionGenerator.getClientAssertion();
		try {
			SignedJWT signedJWT = null;
			// Parses Assertion
			signedJWT = SignedJWT.parse(assertion);
			// Generates JWSVerifier using Public Key.
			JWSVerifier verifier = new RSASSAVerifier(jwtKeyGenerator.getAssertionKeys().getPublicKey());
			if (!(signedJWT.verify(verifier) && new Date().before(signedJWT.getJWTClaimsSet().getExpirationTime()))) {
				// Client Assertion is Invalid.
				// Clears Assertion previously saved in Cache.
				cacheManager.clearAssertion();
				// Generates New Assertion
				assertion = clientAssertionGenerator.getClientAssertion();
			}
		} catch (Exception ex) {
			// Client Assertion is Invalid.
			// Clears Assertion previously saved in Cache.
			cacheManager.clearAssertion();
			// Generates New Assertion
			assertion = clientAssertionGenerator.getClientAssertion();
			LOGGER.error(ESAPI.encoder().encodeForHTML(ex.getMessage()), ESAPI.encoder().encodeForHTML(ex.toString()));
		}
		// return Assertion
		return assertion;

	}

	public GuestTokenModel getGuestToken() {
		return new GuestTokenModel().setGuestToken(ssoTokenService.getGuestToken());
	}

}
