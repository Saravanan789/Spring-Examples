package com.titan.shop.utils;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.titan.shop.model.RSAKeys;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component("ClientAssertionGenerator")
public class ClientAssertionGenerator {

    @Value("${shop.ssoApiURL}")
    String ssoApiURL;

    @Value("${shop.ssoClientID}")
    String ssoClientID;

    @Value("${shop.clientAssertionLifeSpan}")
    int clientAssertionLifeSpan;



    /**
     * The Logger for this class.
     */
    private static final Logger logger = LoggerFactory.getLogger(ClientAssertionGenerator.class);

    @Autowired
    private JWTKeyGenerator jwtKeyGenerator;

    //Generates Client Assertion.
    @Cacheable(cacheNames = "Shop", key = "'ClientAssertion'")
    public String getClientAssertion(){
        try {
            //gets RSA Private and Public Keys in Keys Model.
            RSAKeys keys = jwtKeyGenerator.getAssertionKeys();
            // Prepare JWT with claims set
            // Create RSA-signer with the private key
            JWSSigner signer = new RSASSASigner(keys.getPrivateKey());
            //Creating Claim set for Assertion
            JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                    .subject(ssoClientID)
                    .expirationTime(new Date(new Date().getTime() + clientAssertionLifeSpan * 1000))
                    .audience(ssoApiURL.split("/protocol")[0])
                    .issueTime(new Date(new Date().getTime()))
                    .build();
            SignedJWT signedJWT = new SignedJWT(
                    new JWSHeader(JWSAlgorithm.RS256),
                    claimsSet);
            // Compute the RSA signature
            signedJWT.sign(signer);
            // To serialize to compact form.
            return signedJWT.serialize();
        }
        catch(Exception ex) {
            logger.error(ESAPI.encoder().encodeForHTML(ex.getMessage()), ESAPI.encoder().encodeForHTML(ex.toString()));
            return null;
        }
    }
}
