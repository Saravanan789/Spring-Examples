package com.titan.shop.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.ClientResponse;
import com.titan.shop.model.ProductDetailModel;
import com.titan.shop.model.ProductDetailsForBots;
import com.titan.shop.shared.ShopConstants;
import com.titan.shop.utils.Utilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;

@Service
@Component("ShopServiceV1")
public class ShopService {

	@Autowired
	@Qualifier("Utilities")
	private Utilities utilities;

	@Value("${shop.apiGatewayURL}")
	String apiGatewayURL;
	
    @Value("${shop.cdnURL}")
    private String cdnURL;

	public ProductDetailsForBots getProductInfoForBots(Long storeId, Long productId, String languageCode,
			String purchaseFlowType, String countryCode, String fboId, String memberTitle,Long memberTitleId) {
		ProductDetailsForBots productDetailsForBots = new ProductDetailsForBots();
		if (Objects.nonNull(languageCode) && Objects.nonNull(purchaseFlowType) && Objects.nonNull(countryCode)) {
			ClientResponse response = utilities.get(constructProductRequestURL(storeId, productId, languageCode,
					purchaseFlowType, countryCode, memberTitle,memberTitleId));
			if (response.getStatus() == HttpStatus.OK.value()) {
				String output = response.getEntity(String.class);
				Type type = new TypeToken<List<ProductDetailModel>>() {
				}.getType();
				List<ProductDetailModel> productDetailModels = new Gson().fromJson(output, type);
				if (Objects.nonNull(productDetailModels) && !productDetailModels.isEmpty()) {
					productDetailsForBots.setCountryCode(productDetailModels.get(0).getStoreName());
					productDetailsForBots.setItemNumber(productDetailModels.get(0).getItemNumber());
					if (Objects.nonNull(productDetailModels.get(0).getShortDescription())) {
						productDetailsForBots.setProductDescription(
								productDetailModels.get(0).getShortDescription().replaceAll("\\<.*?\\>", ""));
					}
					productDetailsForBots.setTitle(productDetailModels.get(0).getName());
					if (Objects.nonNull(productDetailModels.get(0).getImageModelList())
							&& !productDetailModels.get(0).getImageModelList().isEmpty() && !productDetailModels.get(0).getImageModelList().get(0).getDetails().isEmpty()) {
						productDetailsForBots
								.setImageUrl(cdnURL +"/"+ productDetailModels.get(0).getImageModelList().stream().filter(z->z.getType().equalsIgnoreCase(ShopConstants.ZOOMEDIMAGE)).findFirst().get()
															.getDetails().stream().filter(x->x.getType().equalsIgnoreCase(ShopConstants.CATEGORY)).findAny().get().getUrl());
					}
					
					if (Objects.nonNull(fboId) && !fboId.isEmpty()) {
						if (Objects.nonNull(productDetailModels.get(0).getCategory())
							&& !productDetailModels.get(0).getCategory().isEmpty()) {
						productDetailsForBots.setUrl("/" + countryCode + "/" + languageCode.toLowerCase() + "/products/" + productDetailModels.get(0).getCategory().get(0).getSlug() + "/" + productDetailModels.get(0).getSlug()
								+ "?fboId=" + fboId);
							} else {
								productDetailsForBots.setUrl("/" + countryCode + "/" + languageCode.toLowerCase() + "/products/" + productDetailModels.get(0).getSlug()
								+ "?fboId=" + fboId);
					}
					} else {
						if (Objects.nonNull(productDetailModels.get(0).getCategory())
							&& !productDetailModels.get(0).getCategory().isEmpty()) {
						productDetailsForBots.setUrl("/" + countryCode + "/" + languageCode.toLowerCase() + "/products/" + productDetailModels.get(0).getCategory().get(0).getSlug() + "/" + productDetailModels.get(0).getSlug()
					);
							} else {
						productDetailsForBots.setUrl("/" + countryCode + "/" + languageCode.toLowerCase() + "/products/" + productDetailModels.get(0).getSlug()
					);
					}
					}
				}
			}
		}
		return productDetailsForBots;
	}

	/**
	 * method to construct Products Request for REST Call
	 * 
	 * @param storeId
	 * @param productId
	 * @param languageCode,
	 * @param purchaseFlowType,
	 * @param countryCode
	 * @return
	 */
	private String constructProductRequestURL(Long storeId, Long productId, String languageCode,
			String purchaseFlowType, String countryCode, String memberTitle,Long memberTitleId) {
		boolean wholesaleQualified = false;
		if(memberTitleId == 1 || memberTitleId == 2) {
			wholesaleQualified = false;
		} else{
			wholesaleQualified = true;
		}
		return apiGatewayURL + "/product/v1/stores/" + storeId + "/products/" + productId + "?languageCode="
				+ languageCode + "&purchaseFlowType=" + purchaseFlowType + "&countryCode=" + countryCode
				//+ "&memberTitle=" + memberTitle;
				+ "&memberTitleId=" + memberTitleId + "&wholesaleQualified=" + wholesaleQualified;

	}
}
