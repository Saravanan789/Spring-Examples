package com.titan.shop.utils;

import java.util.UUID;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.titan.shop.service.SSOTokenService;

@Component("Utilities")
public class Utilities {

	@Autowired
	private SSOTokenService ssoTokenService;

	/**
	 * Description: Accepts Get request
	 *
	 * @param url
	 * @return web response
	 */
	public ClientResponse get(String url) {
		Client client = Client.create();
		WebResource webResource = client.resource(url);
		ClientResponse response = webResource.header("Authentication", "Bearer " + ssoTokenService.getGuestToken() + "&&3")
				.header("UUID", UUID.randomUUID().toString())
				.type(MediaType.APPLICATION_JSON_TYPE).get(ClientResponse.class);
		return response;
	}
}
