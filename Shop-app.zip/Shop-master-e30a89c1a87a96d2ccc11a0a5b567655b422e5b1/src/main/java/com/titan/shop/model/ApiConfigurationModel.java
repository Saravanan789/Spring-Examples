package com.titan.shop.model;

public class ApiConfigurationModel {
	private String apiGatewayURL;
	private String ssoApiURL;
	private String ssoClientID;
	private String ssoClientSecret;
	private String s3BucketURL;
	private String enrollSiteURL;
	private String accountSiteURL;
	private String corporateSiteUrl;
	private String customerName;
	private String templateVersion;
	private String reBrandlyAPIKey;
	private String reportsURL;
	private String cookieDomain;
	private String cookiePath;
	private String ssoInternalKey;
	private String ssoClientAssertion;
	private String cdnURL;
	private String legacyURL;
	private String accessToken;
	private String refreshToken;
	private String idNonce;
	private String memberId;
	private String baseHrefURL;
	private Integer autoShipStartDay;
	private Integer autoShipEndDay;
	private Integer autoShipMaxMonths;
	private Integer cookieExpiryDays;
	private String countryCode;
	private String ssoApiUserURL;
	private Boolean enableAuthentication;
	private Boolean enableAuthorization;
	private Boolean enableSponsorEligibilityCheck;
	private Boolean removeObsoleteCookies;
	private String envName;
	private String legacyFboRedirectUrl;
	private String legacyRetailRedirectUrl;
	private String trainingsMenuRedirectUrl;
	private String starterPackUrl;
	private String defaultFBOID;

	private Boolean enableLongPoll;
	private Integer longPollCount;
	private String legacyShopMobileRedirectUrl;
	private Boolean enableEasterEgg;
	private String cmsTemplateStylePath;
	private String cmsTemplateScriptPath;
	private String cmsTemplateStyleIntegrity;
	private String cmsTemplateScriptIntegrity;
	private String paymentSecurityKey;
	private String paymentServiceKey;
	private String paymentApiKey;
	private String recognitionMenuRedirectUrl;
	private String siteTrackerVersionNo;
	private String guestToken;
	public String getGuestToken() {
		return guestToken;
	}
	public void setGuestToken(String guestToken) {
		this.guestToken = guestToken;
	}

	public String getSiteTrackerVersionNo() {
		return siteTrackerVersionNo;
	}

	public void setSiteTrackerVersionNo(String siteTrackerVersionNo) {
		this.siteTrackerVersionNo = siteTrackerVersionNo;
	}

	public String getLegacyShopMobileRedirectUrl() {
		return legacyShopMobileRedirectUrl;
	}

	public void setLegacyShopMobileRedirectUrl(String legacyShopMobileRedirectUrl) {
		this.legacyShopMobileRedirectUrl = legacyShopMobileRedirectUrl;
	}

	public Boolean getEnableEasterEgg() {
		return enableEasterEgg;
	}

	public void setEnableEasterEgg(Boolean enableEasterEgg) {
		this.enableEasterEgg = enableEasterEgg;
	}

	public Boolean getEnableLongPoll() {
		return enableLongPoll;
	}

	public void setEnableLongPoll(Boolean enableLongPoll) {
		this.enableLongPoll = enableLongPoll;
	}

	public Integer getLongPollCount() {
		return longPollCount;
	}

	public void setLongPollCount(Integer longPollCount) {
		this.longPollCount = longPollCount;
	}

	public Boolean getRemoveObsoleteCookies() {
		return removeObsoleteCookies;
	}

	public void setRemoveObsoleteCookies(Boolean removeObsoleteCookies) {
		this.removeObsoleteCookies = removeObsoleteCookies;
	}

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}
	
	/**
 	 * @return the cookieExpiryDays
 	 */
 	public Integer getCookieExpiryDays() {
 		return cookieExpiryDays;
 	}
 
 	/**
 	 * @param cookieExpiryDays
 	 * the cookieExpiryDays to set
 	 */
 	public void setCookieExpiryDays(Integer cookieExpiryDays) {
 		this.cookieExpiryDays = cookieExpiryDays;
 	} 
	/**
	 * @return the cdnURL
	 */
	public String getCdnURL() {
		return cdnURL;
	}

	/**
	 * @param cdnURL the cdnURL to set
	 */
	public void setCdnURL(String cdnURL) {
		this.cdnURL = cdnURL;
	}

	public String getSsoInternalKey() {
		return ssoInternalKey;
	}

	public void setSsoInternalKey(String ssoInternalKey) {
		this.ssoInternalKey = ssoInternalKey;
	}

	public String getSsoClientAssertion() {
		return ssoClientAssertion;
	}

	public void setSsoClientAssertion(String ssoClientAssertion) {
		this.ssoClientAssertion = ssoClientAssertion;
	}

	/**
	 * @return the accountSiteURL
	 */
	public String getAccountSiteURL() {
		return accountSiteURL;
	}

	/**
	 * @param accountSiteURL
	 *            the accountSiteURL to set
	 */
	public void setAccountSiteURL(String accountSiteURL) {
		this.accountSiteURL = accountSiteURL;
	}

	/**
	 * @return the apiGatewayURL
	 */
	public String getApiGatewayURL() {
		return apiGatewayURL;
	}

	/**
	 * @param apiGatewayURL
	 *            the apiGatewayURL to set
	 */
	public void setApiGatewayURL(String apiGatewayURL) {
		this.apiGatewayURL = apiGatewayURL;
	}

	/**
	 * @return the ssoApiURL
	 */
	public String getSsoApiURL() {
		return ssoApiURL;
	}

	/**
	 * @param ssoApiURL
	 *            the ssoApiURL to set
	 */
	public void setSsoApiURL(String ssoApiURL) {
		this.ssoApiURL = ssoApiURL;
	}

	/**
	 * @return the ssoClientID
	 */
	public String getSsoClientID() {
		return ssoClientID;
	}

	/**
	 * @param ssoClientID
	 *            the ssoClientID to set
	 */
	public void setSsoClientID(String ssoClientID) {
		this.ssoClientID = ssoClientID;
	}

	/**
	 * @return the ssoClientSecret
	 */
	public String getSsoClientSecret() {
		return ssoClientSecret;
	}

	/**
	 * @param ssoClientSecret
	 *            the ssoClientSecret to set
	 */
	public void setSsoClientSecret(String ssoClientSecret) {
		this.ssoClientSecret = ssoClientSecret;
	}

	/**
	 * @return the s3BucketURL
	 */
	public String getS3BucketURL() {
		return s3BucketURL;
	}

	/**
	 * @param s3BucketURL
	 *            the s3BucketURL to set
	 */
	public void setS3BucketURL(String s3BucketURL) {
		this.s3BucketURL = s3BucketURL;
	}

	/**
	 * @return the enrollSiteURL
	 */
	public String getEnrollSiteURL() {
		return enrollSiteURL;
	}

	/**
	 * @param enrollSiteURL
	 *            the enrollSiteURL to set
	 */
	public void setEnrollSiteURL(String enrollSiteURL) {
		this.enrollSiteURL = enrollSiteURL;
	}

	/**
	 * @return the corporateSiteUrl
	 */
	public String getCorporateSiteUrl() {
		return corporateSiteUrl;
	}

	/**
	 * @param corporateSiteUrl
	 *            the corporateSiteUrl to set
	 */
	public void setCorporateSiteUrl(String corporateSiteUrl) {
		this.corporateSiteUrl = corporateSiteUrl;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the templateVersion
	 */
	public String getTemplateVersion() {
		return templateVersion;
	}

	/**
	 * @param templateVersion
	 *            the templateVersion to set
	 */
	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}

	public String getReBrandlyAPIKey() {
		return reBrandlyAPIKey;
	}

	public void setReBrandlyAPIKey(String reBrandlyAPIKey) {
		this.reBrandlyAPIKey = reBrandlyAPIKey;
	}

	/**
	 * gets reports url
	 *
	 * @return
	 */
	public String getReportsURL() {
		return reportsURL;
	}

	/**
	 * sets reports url
	 *
	 * @param reportsURL
	 */
	public void setReportsURL(String reportsURL) {
		this.reportsURL = reportsURL;
	}

	public String getCookieDomain() {
		return cookieDomain;
	}

	public void setCookieDomain(String cookieDomain) {
		this.cookieDomain = cookieDomain;
	}

	public String getCookiePath() {
		return cookiePath;
	}

	public void setCookiePath(String cookiePath) {
		this.cookiePath = cookiePath;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getLegacyURL() {
		return legacyURL;
	}

	public void setLegacyURL(String legacyURL) {
		this.legacyURL = legacyURL;
	}

	public String getIdNonce() {
		return idNonce;
	}

	public void setIdNonce(String idNonce) {
		this.idNonce = idNonce;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the baseHrefURL
	 */
	public String getBaseHrefURL() {
		return baseHrefURL;
	}

	/**
	 * @param baseHrefURL the baseHrefURL to set
	 */
	public void setBaseHrefURL(String baseHrefURL) {
		this.baseHrefURL = baseHrefURL;
	}
	
	public String getDefaultFBOID() {
		return defaultFBOID;
	}

	public void setDefaultFBOID(String fboID) {
		this.defaultFBOID = fboID;
	}

	public Integer getAutoShipStartDay() {
		return autoShipStartDay;
	}

	public void setAutoShipStartDay(Integer autoShipStartDay) {
		this.autoShipStartDay = autoShipStartDay;
	}

	public Integer getAutoShipEndDay() {
		return autoShipEndDay;
	}

	public void setAutoShipEndDay(Integer autoShipEndDay) {
		this.autoShipEndDay = autoShipEndDay;
	}

	public Integer getAutoShipMaxMonths() {
		return autoShipMaxMonths;
	}

	public void setAutoShipMaxMonths(Integer autoShipMaxMonths) {
		this.autoShipMaxMonths = autoShipMaxMonths;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public ApiConfigurationModel setCountryCode(String countryCode) {
		this.countryCode = countryCode;
		return this;
	}

	/**
	 * @return the ssoApiUserURL
	 */
	public String getSsoApiUserURL() {
		return ssoApiUserURL;
	}

	/**
	 * @param ssoApiUserURL the ssoApiUserURL to set
	 */
	public void setSsoApiUserURL(String ssoApiUserURL) {
		this.ssoApiUserURL = ssoApiUserURL;
	}

	public Boolean getEnableAuthentication() {
		return enableAuthentication;
	}

	public void setEnableAuthentication(Boolean enableAuthentication) {
		this.enableAuthentication = enableAuthentication;
	}

	public Boolean getEnableAuthorization() {
		return enableAuthorization;
	}

	public void setEnableAuthorization(Boolean enableAuthorization) {
		this.enableAuthorization = enableAuthorization;
	}
	
	public Boolean getEnableSponsorEligibilityCheck() {
		return enableSponsorEligibilityCheck;
	}

	public void setEnableSponsorEligibilityCheck(Boolean enableSponsorEligibilityCheck) {
		this.enableSponsorEligibilityCheck = enableSponsorEligibilityCheck;
	}

	public String getLegacyFboRedirectUrl() {
		return legacyFboRedirectUrl;
	}

	public ApiConfigurationModel setLegacyFboRedirectUrl(String legacyFboRedirectUrl) {
		this.legacyFboRedirectUrl = legacyFboRedirectUrl;
		return this;
	}

	public String getLegacyRetailRedirectUrl() {
		return legacyRetailRedirectUrl;
	}

	public ApiConfigurationModel setLegacyRetailRedirectUrl(String legacyRetailRedirectUrl) {
		this.legacyRetailRedirectUrl = legacyRetailRedirectUrl;
		return this;
	}

	public String getTrainingsMenuRedirectUrl() {
		return trainingsMenuRedirectUrl;
	}

	public void setTrainingsMenuRedirectUrl(String trainingsMenuRedirectUrl) {
		this.trainingsMenuRedirectUrl = trainingsMenuRedirectUrl;
	}
	
	public String getStarterPackUrl() {
		return starterPackUrl;
	}

	public void setStarterPackUrl(String starterPackUrl) {
		this.starterPackUrl = starterPackUrl;
	}

	public String getCmsTemplateStylePath() {
		return cmsTemplateStylePath;
	}

	public void setCmsTemplateStylePath(String cmsTemplateStylePath) {
		this.cmsTemplateStylePath = cmsTemplateStylePath;
	}

	public String getCmsTemplateScriptPath() {
		return cmsTemplateScriptPath;
	}

	public void setCmsTemplateScriptPath(String cmsTemplateScriptPath) {
		this.cmsTemplateScriptPath = cmsTemplateScriptPath;
	}

	public String getCmsTemplateStyleIntegrity() {
		return cmsTemplateStyleIntegrity;
	}

	public void setCmsTemplateStyleIntegrity(String cmsTemplateStyleIntegrity) {
		this.cmsTemplateStyleIntegrity = cmsTemplateStyleIntegrity;
	}

	public String getCmsTemplateScriptIntegrity() {
		return cmsTemplateScriptIntegrity;
	}

	public void setCmsTemplateScriptIntegrity(String cmsTemplateScriptIntegrity) {
		this.cmsTemplateScriptIntegrity = cmsTemplateScriptIntegrity;
	}
	
	public String getPaymentSecurityKey() {
		return paymentSecurityKey;
	}

	public void setPaymentSecurityKey(String paymentSecurityKey) {
		this.paymentSecurityKey = paymentSecurityKey;
	}


	public String getPaymentServiceKey() {
		return paymentServiceKey;
	}

	public void setPaymentServiceKey(String paymentServiceKey) {
		this.paymentServiceKey = paymentServiceKey;
	}

	public String getPaymentApiKey() {
		return paymentApiKey;
	}

	public void setPaymentApiKey(String paymentApiKey) {
		this.paymentApiKey = paymentApiKey;
	}

	public String getRecognitionMenuRedirectUrl() {
		return recognitionMenuRedirectUrl;
	}

	public void setRecognitionMenuRedirectUrl(String recognitionMenuRedirectUrl) {
		this.recognitionMenuRedirectUrl = recognitionMenuRedirectUrl;
	}
}
