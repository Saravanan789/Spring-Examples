/**
 * 
 */
package com.titan.shop.model;

/**
 * @author NextSphere Technologies
 *
 */
public class TemplateConfigurationModel {

	public TemplateConfigurationModel(String componentName, String templateName) {
		this.componentName = componentName;
		this.templateName = templateName;
	}

	private String componentName;
	private String templateName;

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName
	 *            the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 *            the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

}
