export interface PayvisionBillingAddress {
    country: string;
    state: string;
    city: string;
    postcode: string;
    street1: string;
    street2: string;
}

export interface PayvisionMandatoryBillingAddressFields {
    country: boolean;
    state: boolean;
    city: boolean;
    postcode: boolean;
    street1: boolean;
    street2: boolean;
}
