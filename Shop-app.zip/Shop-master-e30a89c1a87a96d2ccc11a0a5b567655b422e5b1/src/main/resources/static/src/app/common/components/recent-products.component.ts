
import { Product } from '../../products/interfaces/product.interface';
import { CommonService } from '../../shared/services/common.service';
import { UserTitleType } from '../../shared/enums/user-title-type.enum';
import { CartService } from '../../shared/services/cart.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CacheService } from '../../shared/services/cache.service';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import * as _ from 'lodash';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Cart } from '../../shared/models/cart.model';
import { ImageType } from '../../products/enums/image-type.enum';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { TranslateService } from '@ngx-translate/core';
import { Item } from '../../shared/models/item.model';
import { AppMessageService } from '../../app-message.service';
import { Member } from '../../shared/interfaces/member.interface';
import { NotificationType } from '../enums/notification-type.enum';
import { NotificationService } from '../../shared/services/notification.service';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { QuickviewComponent } from '../../products/components/quickview.component';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ProductType } from '../../products/enums/product-types.enum';
import { DataShareService, ActiveSessionService } from '../../shared/services';
import { MemberLevel } from '../../shared/enums';
import { CookieBannerType } from '../../shared/enums/cookie-banner-type';
import { CookieBannerResponse } from '../../shared/interfaces/cookie-banner-reponse';
import { TranslateParam } from '../interfaces';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'recent-products',
  templateUrl:
    '../templates/template3/views/recent-products.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/recent-products.component.less'
  ]
})
export class RecentProductsComponent implements OnInit {
  store: StoreConfig;
  productId: number;
  products: Product[];
  imageTypes: any = ImageType;
  productType = ProductType;
  languageCode: string;
  errorMessages: any = [];
  userLoggedIn: Member;
  storeId: number;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  isoCountryCode: string;
  isAutoshipEnabled: boolean;
  personalPurchaseFlow: string;
  bsModalRef: BsModalRef;
  isEnableWishList: boolean;
  translateParams: TranslateParam;

  public sliderConfig: SwiperConfigInterface = {
    slidesPerView: 3,
    touchRatio: 0.2,
    navigation: true,
    breakpoints: {
      1200: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      930: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      640: {
        slidesPerView: 1,
        spaceBetween: 10
      }
    }
  };

  constructor(
    private _cacheService: CacheService,
    private _commonService: CommonService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _configurationService: ConfigurationService,
    private _translatePipe: TranslateService,
    private _cartService: CartService,
    private _appMessageService: AppMessageService,
    private _notificationService: NotificationService,
    private modalService: BsModalService,
    private _dataService: DataShareService,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    this.personalPurchaseFlow = this.isAutoshipEnabled ? PurchaseFlow.AUTOSHIP : PurchaseFlow.PERSONAL;
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.getStoreData();
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this._route.params.subscribe(params => {
      this.productId = +params['productid']; // (+) converts string 'id' to a number
    });
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.getRecentProducts();
  }

  /**
   * to get all recent proudcts to display
   * @param  {number} storeId
   */
  getRecentProducts() {
    let productIds: number[] = [];
    const browsedProducts = this._cacheService.get(CacheKey.RecentlyViewedProductsIds);
    if (browsedProducts && browsedProducts.length > 0) {
      productIds = browsedProducts.map(x => x.productId).reverse();
    }
    if (this.productId) {
      const productId = this.productId;
      productIds = _.remove(productIds, function (n) {
        return n !== productId;
      });
    }
    if (productIds && productIds.length > 0) {
      productIds = productIds.slice(0, 10);
      this._commonService
        .getProductsByIds(productIds, this.languageCode, this.storeId)
        .subscribe(response => {
          if (response && response.length > 0) {
            this.products = response;
            this.products.forEach(x => {
              if (!(x.backOrderAllowed || (x.manageStock && x.stockQuantity > 0))) {
                x.productQuantity = 0;
              } else {
                x.productQuantity = 1;
              }
              x.disableDecrement = x.disableDecrement || true;
              x.commissionableVolume=!x.literature?x.commissionableVolume:0;
            });
            setTimeout(() => {
              this.loadWishListProducts();
            }, 1000);
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }

  setSelectedCategory(selectedCategory: any) {
    this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
  }

  toProductDetail(product: Product) {
  }

  /**
  * Show Modal popup
  * @param product
  */
  showModalPopup(product: Product) {
    const initialState = {
      productDetails: product
    };
    this.bsModalRef = this.modalService.show(QuickviewComponent, { class: 'modal-lg modal-dialog-centered', initialState });
    this.bsModalRef.content.product = product;
  }


  /**
   * navigate to product detail page
   * @param  {number} id
   */
  goToProductDetail(id: number) {
    this._router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + id);
  }

  /**
   * @description get store data
   * @memberof RecentProductsComponent
   */
  getStoreData() {
    const result: StoreConfig = this._configurationService.getStoreData();
    if (result != null) {
      this.store = result;
      this.storeId = this.store.id;
      this.isEnableWishList = this.store.enableWishlist;
    }
  }

  /**
   * @description show cart / Product detail based on variant.
   * @param {Product} product
   * @param {number} cartType
   * @memberof RecentProductsComponent
   */
  addToCart(product: Product, cartType: number): void {
    if (product && product.options.length === 0) {
      if (!product.addingToCart) {
        this.getShippingRestrictedProducts(product.itemNumber);
        this.manageShoppingCart(product, cartType);
      }
    } else if (product.productTypeMasterId === ProductType.Variable && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      this._router.navigate(['/', this.isoCountryCode.toLowerCase(), this.languageCode.toLowerCase(), 'products', product.slug]);
    }
  }

  /**
   * @description method to manage shopping cart
   * @private
   * @param {Product} product
   * @param {CartTypes} cartType
   * @returns
   * @memberof RecentProductsComponent
   */
  private manageShoppingCart(product: Product, cartType: CartTypes) {
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      this._notificationService.createNotification('', 'Item added to Autoship Cart', NotificationType.SUCCESS);
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('Item added to cart');
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    const item: Item = this._cartService.convertProductToItemMappper(product, cartSessionInfo);
    if (cartSessionInfo) {
      const cartItem = cartSessionInfo.items.filter(x => x.productId === item.productId)[0];
      if (cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > product.stockQuantity && product.manageStock && !product.backOrderAllowed) {
          item.quantity = cartItem.quantity;
          product.errorMessage = true;
          setTimeout(() => {
            product.errorMessage = false;
          }, 2000);
          this.outofStockNotification(product);
          return;
        }
      }
    }
    product.addingToCart = true;
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      const autoshipCart = new Cart(cartSessionInfo, this.store);
      const cartItemDetails = {
        count: autoshipCart.itemsCount,
        cartType: cartType
      };
      product.addingToCart = false;
      this._appMessageService.setMiniCart(cartSession);
      this._appMessageService.setCartItemsChanges(cartItemDetails);
      this._commonService.scrollTo('cart-component', 500);
      this._commonService.focusTargetElement('minicart-shop-msg');
    } else if (cartSessionInfo) {
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: Cart) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          const shoppingCart = new Cart(cartSessionInfo, this.store);
          const cartItemDetails = {
            count: shoppingCart.itemsCount,
            cartType: cartType
          };
          this._appMessageService.setCartItemsChanges(cartItemDetails);
          this._commonService.scrollTo('cart-component', 500);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: Cart) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          const shoppingCart = new Cart(cartSessionInfo, this.store);
          const cartItemDetails = {
            count: shoppingCart.itemsCount,
            cartType: cartType
          };
          this._appMessageService.setCartItemsChanges(cartItemDetails);
          this._commonService.scrollTo('cart-component', 500);
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }

  /**
* @description Increment the product Quantity
* @returns void
*/
  incrementQuantity(prod): void {
    prod.productQuantity = ++prod.productQuantity;
    prod.disableDecrement = false;
    if (prod.productQuantity > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      this.outofStockNotification(prod);
    }
  }

  /**
   * @description Decrement the product Quantity
   * @returns void
   */
  decrementQuantity(prod): void {
    if (prod.productQuantity > 1) {
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      // this.quantity = +this.quantity - 1;
    }
    if (prod.productQuantity === 1) {
      prod.disableDecrement = true;
    }
  }

  /**
   * @description method to update quantity
   * @param {(Product | any)} prod
   * @memberof RecentProductsComponent
   */
  updateQuantity(prod: Product | any) {
    const qty = parseInt(prod.productQuantity, 10);
    if (qty > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = prod.stockQuantity;
      this.outofStockNotification(prod);
    } else {
      prod.productQuantity = qty || null;
    }
    prod.disableDecrement = prod.productQuantity > 1 ? false : true;
  }

  /**
   * @description method to show out of stock notfication
   * @param {Product} product
   * @memberof RecentProductsComponent
   */
  outofStockNotification(product: Product) {
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">'
      + product.stockQuantity + '</span>', NotificationType.ERROR);
  }


  /**
   * @description verifying whether the product is shippable to the selected shipping address or not
   * @param {string} itemNumber
   * @returns {*}
   * @memberof RecentProductsComponent
   */
  getShippingRestrictedProducts(itemNumber: string): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (userDefaultAddressDetails) {
      const getShippingRestrictedProductsData = this._commonService.getShippingRestrictedProducts(itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            this._notificationService.createNotification('', response.productModels[0].errorDescription, NotificationType.ERROR);
          }
        });
    }
  }

  /**
 * redirect to sso login url
 * @param  {boolean} isLogin
 * @returns void
*/
  gotoLogin(isLogin: boolean, product: Product): void {
    this._cacheService.set(CacheKey.WishListProduct, product);
    this._cacheService.set(CacheKey.RedirectToFavourites, true);
    this._appMessageService.setNotifyLoginStatus(isLogin);
  }

  /**
   * @description to add an item
   * @param {Product} product
   * @returns {void}
   * @memberof RecentProductsComponent
   */
  addToWishList(product: Product): void {
    // TODO amruth - need to move text to s3 and translate
    if (!this.userLoggedIn) {
      // commenting code due to showing pop-over . No need for cookie banner
      // const cookieBannerData = {
      //   title: null,
      //   timeout: false,
      //   time: 2000,
      //   description: 'Please login or create an account in your first purchase to add products to your Favorites',
      //   notificationType: CookieBannerType.CartItemNotification
      // };
      // this._appMessageService.setCookieBannerData(cookieBannerData);
      return;
    }
    if (this.userLoggedIn && product.options && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('quickview.Item added to Favorites');
      const itemDeletedNotification: any = this._translatePipe.get('quickview.Item removed from Favorites');
      product.wishListItem = !product.wishListItem ? true : false;
      product.productQuantity = 1;
      const item: Item = this._cartService.convertProductToItemMappper(product);
      let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
      if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length >= 0 && wishListCart.sessionGuid) {
        const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .updateCart([item], CartTypes.WishlistCart, wishListCart)
          .subscribe((response: Cart) => {
            if (response) {
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          });
      } else if (product.wishListItem) {
        this._cartService
          .saveCart([item], CartTypes.WishlistCart)
          .subscribe((response: Cart) => {
            if (response) {
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          });
      } else if (!product.wishListItem) {
        const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .removeCartItem(wishListCart.sessionGuid, cartItem.id)
          .subscribe(response => {
            //    this._commonService.createNotification('', itemDeletedNotification.value, 'success');
            wishListCart = new Cart(wishListCart, this.store);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          });
      }
    }
  }

  /**
   * @description method to navigate to product details
   * @param {*} prod
   * @memberof RecentProductsComponent
   */
  navigateToProductDetail(prod) {
    const storedRecentViewProductIds = this._cacheService.get(CacheKey.RecentlyViewedProductsIds);
    if (storedRecentViewProductIds) {
      const storedCategoryForProduct = storedRecentViewProductIds.find((x) => x.productId === prod.id);
      if (storedCategoryForProduct.customCatalogName && storedCategoryForProduct.categories.length > 0) {
        const selectedCategory = {
          productCategoryId: storedCategoryForProduct.customCatalogId,
          categoryName: storedCategoryForProduct.customCatalogName,
        };
        this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      }
      if (prod.parentProductSlug) {
        prod.slug = prod.parentProductSlug;
        this._dataService.variableProductOption = prod.selectedOption;
      }
      if (storedCategoryForProduct && storedCategoryForProduct.category && storedCategoryForProduct.category.slug) {
        this._cacheService.set(CacheKey.SelectedCategoryState, storedCategoryForProduct.category);
        this._router.navigate
          (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase()
            + '/products/' + storedCategoryForProduct.category.slug + '/' + prod.slug]);
      } else {
        this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + prod.slug]);
      }
    }
  }
  /** ADA on focus out product review
   * @param  {} {document.getElementById('recent-product-name'
   * @param  {} .focus(
   */
  onFocusProductName(index: number, event: any): void {
    document.getElementById('recent-product-name' + index).focus();
    event.preventDefault();
  }

  /** ADA on focus to review
   * @param  {number} index
   * @param  {any} event
   */
  moveFocusOnReviews(index: number, event: any): void {
    document.getElementById('recent-product-review' + index).focus();
    event.preventDefault();
  }

  /**ADA -- Move focus to next slide
   * @param  {number} index
   * @param  {any} event
   */
  onFocusNextSlide(index: number, event: any): void {
    const addBagElement = document.getElementById('recent-addtobag' + index);
    if (addBagElement) {
      const element = addBagElement.closest('.swiper-slide');

      if (!(element.classList.contains('swiper-slide-next')) && !(element.classList.contains('swiper-slide-active'))) {
        const nextSlideElement: any = document.querySelector('[aria-label="Next slide"]');
        if (nextSlideElement) {
          nextSlideElement.focus();
        }
      }
    }

  }

  /**
   * @description load wishlist products
   * @memberof RecentProductsComponent
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      this.products.forEach(x => {
        x.productQuantity = x.productQuantity ? x.productQuantity : 1;
        wishListCart.items.forEach(y => {
          if (y.productId === x.id) {
            x.wishListItem = true;
          }
        });
      });
    }
  }
}
