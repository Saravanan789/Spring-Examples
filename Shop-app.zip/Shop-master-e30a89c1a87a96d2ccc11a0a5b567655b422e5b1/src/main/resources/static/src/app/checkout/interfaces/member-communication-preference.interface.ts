export interface MemberCommunicationPreference {
    email: boolean;
    phone: boolean;
}
