
export class PaymentConstants {
    public static paymentMethodMaskCode = 'ALL';
    public static PLACEORDER_TC = 'By clicking Place Order, I agree to the Terms & Conditions';
    public static PayVisionScriptID = 'payVisionScriptID';
    public static PaymentErrorCodeParam = 'errorCode';
    public static PaymentErrorMessageParam = 'errorMessage';
    public static PaymentProcessorParam = 'processor';
    public static CommunationError = 'Payment Communication Error';
    public static SecureError = 'PaymentGateway 3D Secure Error';
    public static ExternalBankError = 'Transaction Declined Error';
    public static OtherError = 'Payment Gateway Error';
    public static InvalidCheckoutIdError = 'InvalidCheckoutIdError';
    public static PciIframeSubmitError = 'PciIframeSubmitError';
    public static PuertoRico = 'PR';
    public static VirginIslands = 'VI';
    public static MarshallIslands = 'MHL';
}
