import { TaxBreakDown } from '../../shared/models/taxbreakdown.model';
export class TaxItems {
    lineNumber: number;
    itemNumber: string;
    taxablePrice: number;
    quantity: number;
    taxCode: string;
    description: string;
    taxInclusive: boolean;
    resale: boolean;
    resalePrice: number;
    taxBreakDown: TaxBreakDown;
    productIdentifier: string;
    retailPrice: number;
    paidPrice: number;
    wholeSalePrice: number;
    salesTax: number;
    itemWeight: number;
    revisionNumber: string;
    importedMeasurementUnit: string;
}
