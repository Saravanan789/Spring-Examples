import { Autoship } from './autoship.interface';
import { HttpServiceResponse } from '../../shared/interfaces';

export interface AutoshipProfileResponse extends HttpServiceResponse {
    body: Autoship[];
}
