import { Subscription } from 'rxjs/Subscription';
import { AppMessageService } from '../../app-message.service';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { CartService } from '../../shared/services/cart.service';
import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { CacheService } from '../../shared/services/cache.service';
import * as _ from 'lodash';
import { CommonService } from '../../shared/services/common.service';
import { ImageType } from '../../products/enums/image-type.enum';
import { Router } from '@angular/router';
import { Product } from '../../products/interfaces/product.interface';
import { TranslateService } from '@ngx-translate/core';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Cart } from '../../shared/models/cart.model';
import { Item } from '../../shared/models/item.model';
import { OrderRulesResponse } from '../../shared/interfaces/order-rules-response.interface';
import { ValueType } from '../../shared/enums/value-type.enum';
import { Member } from '../../shared/interfaces/member.interface';
import { MemberOrderCCInfo } from '../../shared/interfaces/member-order-cc-info';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationType } from '../../common/enums/notification-type.enum';
import { NotificationService } from '../../shared/services/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { Autoship } from '../../checkout/interfaces/autoship.interface';
import { MemberType, MemberLevel } from '../../shared/enums';
import { DocumentLibrary } from '../../payment/interfaces';
import { MemberMetaData, Country, State } from '../../shared/interfaces';
import { MemberMetaDataEnum, DocumentLibraryMemberId, RowStatus, DisplaySectionId } from '../../common/enums';
import {
  WholesaleQualifiedResponse, ShippingOptionsResponse,
  ShippingOptionsRequest, ShippingProductModel, CheckoutInformation, ProductShippingRestriction, RestrictedProduct
} from '../../checkout/interfaces';
import { DataShareService, ActiveSessionService } from '../../shared/services';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { CountryName } from '../../common/enums/country-name.enum';
import { ShippingMethodService } from '../../checkout/services';
import {
  ProductWeightMetric, OrderSourceType, ShippingOrderType,
  ShippingMemberTitle, ShippingType, ShippingMemberType
} from '../../checkout/enums';
import { Address, TranslateParam } from '../../common/interfaces';
import { AddressService } from '../../common/services/address.service';
import { PromotionsTypes } from '../../checkout/enums/autoship-frequency.enum';
import { PromotionalParentProduct } from '../../shared/interfaces/product-promotions.interface';
import { AppSectionSpinnerService } from '../../common/services/section-spinner.service';
import { Categories } from '../../products/interfaces/categories.interface';

@Component({
  selector: 'app-cart',
  templateUrl: '../templates/template3/views/cart.component.html',
  styleUrls: ['../templates/template3/themes/default/less/cart.less']
})
export class CartComponent implements OnInit, OnDestroy {
  @Input() placeHolderId: string;
  @Input() sitemapId: string;
  shoppingCart: Cart;
  cartHoverValue: boolean;
  quantity = 1;
  public isModalShown = false;
  cartSubscription: Subscription;
  country: string;
  confirmProduct: any;
  decrementDisable: boolean;
  imageTypes = ImageType;
  hideWishListItems = true;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  Impersonation: boolean;
  language: string;
  savedPrice = 0;
  wishListSubscription: Subscription;
  @ViewChild('autoShownModal') public autoShownModal: AppModalDirective;
  storeId: number;
  store: StoreConfig;
  isoCountryCode: string;
  autoshipCart: Cart;
  wishListCart: Cart;
  hasAutoshipPurchaseFlow = false;
  cookieService: CookieService = new CookieService(document);

  orderRules: OrderRulesResponse;
  memberOrderCCInfo: MemberOrderCCInfo;
  valueTypes = ValueType;
  thresholdCrossed = false;
  memberCCLimitExceeded = false;
  userInfo: Member;
  isAutoshipEnabled: boolean;
  autoshipName: string;
  autoshipDate: Date;
  cardsContent: any[];
  countryName = CountryName;
  // tslint:disable-next-line:max-line-length
  siteMapIds: any[] = [{ 'countryCode': this.countryName.USA, 'siteMapId': 1066 }, { 'countryCode': this.countryName.GBR, 'siteMapId': 1116 },
  { 'countryCode': this.countryName.CAN, 'siteMapId': 1166 }, { 'countryCode': this.countryName.LUX, 'siteMapId': 1216 },
  { 'countryCode': this.countryName.BEL, 'siteMapId': 1266 }, { 'countryCode': this.countryName.NLD, 'siteMapId': 1316 }];
  siteMapId: number;
  languageCode: string;
  selectedItem = -1;
  minDate: Date;
  maxDate: Date;
  removeItem: boolean;
  clearBag: boolean;
  errorAutoShipMessages: string;
  showAutoShipErrorMessage = false;

  isWholeSaleQualified: boolean;
  isWholeSaleEligibility: boolean;
  showOptInMessage: boolean;
  availableCC: number;
  memberSkipCount = 0;
  hideFpcOptinMessage: boolean;
  isFPCOptIn = false;
  portalId = 4;
  fpcDocuments: DocumentLibrary[];
  existingCC: number;
  countries: Country[];
  states: State[];
  shippingAddress: Address;
  autoshipPreference: Autoship;
  isAddAllItemsToAutoship = false;
  isDisabledAutoship = false;
  clickTimeout: any = {};
  isCheckoutClicked: boolean;
  cartItemChanged: boolean;
  isFPCOptInEligible: boolean;
  isShowLoader: boolean;
  isQuantityUpdateLoader: boolean;
  agreementCheckError: boolean;
  isCheckoutSubmitted: boolean;
  isDateOffset = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
  starterPackUrl = environment.starterPackUrl;
  translateParams: TranslateParam;
  productShippingRestriction: ProductShippingRestriction;
  restrictedProducts: RestrictedProduct[];
  @ViewChild('shippingRestrictionModal') public shippingRestrictionModal: AppModalDirective;

  constructor(
    private _cacheService: CacheService,
    private _commonService: CommonService,
    private _cartService: CartService,
    private _appMessageService: AppMessageService,
    private router: Router,
    private _sanitizer: DomSanitizer,
    private _configurationService: ConfigurationService,
    private _translatePipe: TranslateService,
    private _notificationService: NotificationService,
    private _dataService: DataShareService,
    private _shippingService: ShippingMethodService,
    private _sectionSpinnerService: AppSectionSpinnerService,
    private _activeSessionService: ActiveSessionService,
    private _addressService: AddressService,
    private _translateService: TranslateService
  ) {

  }

  ngOnInit() {
    if (environment.dataLayer && environment.dataLayer.length > 0) {
      environment.dataLayer[0].pageCategory = 'shop-cart';
    }
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    if (this._cacheService.get(CacheKey.Impersonation) === true) {
      this.Impersonation = true;
    }
    if (document.getElementsByClassName('cart-menu')[0]
      && document.getElementsByClassName('cart-menu')[0].classList
      && document.getElementsByClassName('cart-menu')[0].classList.length > 0) {
      document.getElementsByClassName('cart-menu')[0].classList.remove('onFocusCart');
    }
    document.getElementById('mainContent').focus();

    this.country = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.language = this._commonService.getLanguageCode();
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.userInfo = this._cacheService.get(CacheKey.UserInfo);
    this.isWholeSaleQualified = this.userInfo ? this.userInfo.wholesaleQualified : false;
    this.clearAutoshipBag();
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.enableFPCToFBOOptIn();
    this.getStoreData();
    this.getCountriesLookup();
    const cartElement = document.getElementsByClassName('cart-menu')[0];
    if (this.country === 'usa' && cartElement) {
      cartElement.classList.remove('onFocusCart');
    }
    this.getAgreementDocuments();
    // get the CartItems while refreshing
    this.orderRules = this._cacheService.get(CacheKey.OrderRules);
    this.memberOrderCCInfo = this._cacheService.get(CacheKey.MemberOrderRules);
    // get the CartItems while refreshing
    this.getCartSessionInfo();
    this.getAutoshipDetails();
    this.getWishlistProducts();
    this.getWishListSubject();
    this.getDates();
    this.siteMapIds.forEach(element => {
      if (element.countryCode === this.isoCountryCode) {
        this.siteMapId = element.siteMapId;
      }
    });
    if (this.siteMapId) {
      this.getCardsContent(this.siteMapId);
    }
  }

  /**
 * @description Clear auto ship cart when user not loggedin
 * @private
 * @memberof CartComponent
 */
  clearAutoshipBag(): void {
    const autoshipSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    if (autoshipSession && autoshipSession.items && autoshipSession.items.length > 0 && !this.userInfo) {
      this._cacheService.remove(CacheKey.AutoshipCart);
      this._cacheService.remove(CacheKey.AutoshipDate);
    }
  }

  /**
 * @description Get Countries
 * @date 2018-07-19
 * @private
 * @memberof ShippingAddressNewComponent
 */
  private getCountriesLookup(): void {
    if (this._cacheService.get(CacheKey.Countries)) {
      this.countries = this._cacheService.get(CacheKey.Countries);
      const selectedCountry =
        this.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
          this.isoCountryCode.toLowerCase());
      if (selectedCountry && selectedCountry.countryId) {
        this.getStatesLookup(selectedCountry.countryId);
      }
    } else {
      this._commonService.getCountries().subscribe((countries: Country[]) => {
        if (countries && countries.length > 0) {
          this.countries = countries;
          this._cacheService.set(CacheKey.Countries, this.countries);
          const selectedCountry = this.countries.
            find((x: Country) => x.isocodeThree.toLowerCase() === this.isoCountryCode.toLowerCase());
          if (selectedCountry && selectedCountry.countryId) {
            this.getStatesLookup(selectedCountry.countryId);
          }
        }
      });
    }
  }

  /**
 * @description get States
 * @date 2018-07-19
 * @param {number} countryId
 * @memberof ShippingAddressNewComponent
 */
  private getStatesLookup(countryId: number) {
    const storedStates = this._cacheService.get(
      decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
    if (storedStates && storedStates.length > 0) {
      this.states = storedStates;
    } else if (countryId) {
      this._commonService.getStatesByCountry(countryId).subscribe((states: State[]) => {
        this.states = states;
      }, (err: any) => {
      });
    }
  }


  /**
 * @description get Autoship profile details
 * @date 2018-09-11
 * @memberof CheckoutNewComponent
 */
  getAutoshipDetails(): void {
    if (this.userInfo) {
      const autoshipDetails = this._cacheService.get(CacheKey.AutoshipCart);
      if (autoshipDetails) {
        this.autoshipCart = autoshipDetails;
      }
      this.isAddAllItemsToAutoship = this.validateAutoshipSelectedItem();
      if (this.isAutoshipEnabled && autoshipDetails) {
        this._appMessageService.setMiniCart(autoshipDetails);
      }
      this.getAutoshipProfileDetails(autoshipDetails);
    }
  }

  /**
* @description Exisiting Autoship Detials
* @date 2018-09-06
* @memberof CheckoutNewComponent
*/
  getAutoshipProfileDetails(autoshipCart: Cart): void {
    this._commonService
      .getAutoShipByMemberId(this.userInfo.memberId)
      .subscribe((res) => {
        if (res && res[0].body && res[0].body.length > 0) {
          const autoshipPreferences = res[0].body;
          const autoship = autoshipPreferences.find((x) => x.rowStateId === RowStatus.Active);
          if (autoship) {
            this.getAutoshipDate(autoship);
            this.autoshipPreference = JSON.parse(JSON.stringify(autoship));
            this._cacheService.set(CacheKey.AutoshipDetails, this.autoshipPreference);
            this.getAutoshipShippingAddressDetails(this.autoshipPreference);
          }
        } else {
          this.getAutoshipDate();
          this._cacheService.set(CacheKey.AutoshipCart, autoshipCart);
          this._cacheService.remove(CacheKey.AutoshipDetails);
        }
      });
  }

  /**
   * @description get Autoship Date
   * @date 2018-10-03
   * @param {Autoship} [autoship]
   * @memberof CartComponent
   */
  getAutoshipDate(autoship?: Autoship): void {
    const date = this._cacheService.get(CacheKey.AutoshipDate);
    if (date) {
      this.autoshipDate = date;
    } else {
      if (autoship && (autoship.startDate || autoship.nextAutoshipRunDate)) {
        // Setting AutoShip date based on AutoShip Display Date
        this.autoshipDate = autoship.autoShipDisplayDate ?
          this._commonService.getDateObject(autoship.autoShipDisplayDate) : null;
        // Setting AutoShip date based on nextAutoshipRunDate if autoShipDisplayDate is not retrieved
        this.autoshipDate = this.autoshipDate ? this.autoshipDate
          : new Date(autoship.startDate || autoship.nextAutoshipRunDate.toString());
      } else {
        this.getNextAutoshipRunDate();
      }
    }
    this._cacheService.set(CacheKey.AutoshipDate, this.autoshipDate);
  }

  /**
   *
   * This method is used for getting company policy agreement documents
   * getAgreementDocuments
   * @memberof CartComponent
   */
  getAgreementDocuments(): void {
    const customerTypeId = DocumentLibraryMemberId.Distributor;
    const displaySetionId = DisplaySectionId.Shopping_Bag;
    this._cartService.getDocuments(this.portalId, customerTypeId, displaySetionId)
      .subscribe(response => {
        if (response && response[0].body) {
          response[0].body = _.orderBy(response[0].body, ['documentUrl'], ['asc']);
          this.fpcDocuments = response[0].body;
          const documents = this._cacheService.get(CacheKey.FBOTerms);
          this.validateDocuments(documents);
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
  }

  /**
   *
   * This method is used for validate the documents
   * getAgreementDocuments
   * @memberof CartComponent
   */
  validateDocuments(documents: any): void {
    const fpcCachekeKey = this._cacheService.get(CacheKey.FPCOptIn);
    const fpcOpcIn = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
    if (documents && documents.fboOptInDocuments && fpcOpcIn) {
      const selectedDocuments = documents.fboOptInDocuments.filter(document => document.isSelected);
      if (selectedDocuments && selectedDocuments.length > 0) {
        this.fpcDocuments.forEach(document => document.isSelected = true);
      } else {
        this.fpcDocuments.forEach(document => document.isSelected = false);
      }
    } else {
      this.fpcDocuments.forEach(document => document.isSelected = false);
    }
  }

  /**
   * @description Method to check FPC Opt-In
   * @param index
   */
  checkFpcOptIn(index: number): void {
    this.fpcDocuments[index].isSelected = !this.fpcDocuments[index].isSelected;
    this.checkDocumentsSelected();
  }

  /**
   * @description check weather the documents are selected
   * @date 2019-03-28
   * @memberof CartComponent
   */
  checkDocumentsSelected(): void {
    const unSelectedDocuments = this.fpcDocuments.filter(x => x.isSelected === false);
    if (unSelectedDocuments && unSelectedDocuments.length === 0) {
      this.isFPCOptIn = true;
      this.agreementCheckError = false;
    } else if (unSelectedDocuments.length !== this.fpcDocuments.length) {
      this.agreementCheckError = true;
      this.isFPCOptIn = false;
    } else if (unSelectedDocuments.length === this.fpcDocuments.length) {
      this.isFPCOptIn = false;
      this.agreementCheckError = false;
    }
  }
  /**
   * Upgrade - FPC to FPO - Displaying optin message
   * validateOptInMessage
   * @memberof CartComponent
   */
  validateOptInMessage(): void {
    const fpcCachekeKey = this._cacheService.get(CacheKey.HideFPCOptIn);
    this.hideFpcOptinMessage = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
    const fpcOptinCountKey = this._cacheService.get(CacheKey.SkipCountIncreased);
    const fpcOptinCount = fpcOptinCountKey ? JSON.parse(fpcOptinCountKey) : false;
    if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
      && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()
      && !this.hideFpcOptinMessage) {
      const ignoreOptInSkipCount: boolean = this._cacheService.get(CacheKey.IgnoreOptInSkipCount);
      const hideFPCOptIn = this._cacheService.getCookieValue(CacheKey.HideFPCOptInMessage);
      this.memberSkipCount = this.getMemberSkipCount();
      if (this.store.distributorSkipCount <= this.memberSkipCount && !ignoreOptInSkipCount || hideFPCOptIn) {
        this.showOptInMessage = false;
      } else {
        this.showOptInMessage = true;
        if (this.userInfo.wholesaleQualified && !fpcOptinCount
          && !ignoreOptInSkipCount) {
          this.memberSkipCount = this.memberSkipCount + 1;
          this.updateSkipCount(this.userInfo.memberId, this.memberSkipCount);
        }
      }
    }
  }

  /**
   * This method used for updating Account settings for optin message display
   * Make skip count as 0
   * hideOptInMessage
   * @memberof CartComponent
   */
  hideOptInMessage(): void {
    this.isWholeSaleEligibility = false;
    this.hideFpcOptinMessage = true;
    this.isFPCOptIn = false;
    this.memberSkipCount = this.store.distributorSkipCount;
    this._cacheService.set(CacheKey.FPCOptIn, JSON.stringify(false));
    this._cacheService.set(CacheKey.HideFPCOptIn, JSON.stringify(true));
    this._cacheService.setCookieValue(CacheKey.HideFPCOptInMessage, true);
    this.updateSkipCount(this.userInfo.memberId, this.memberSkipCount);
  }

  /**
   * This method used for updating skip count
   * updateSkipCount
   * @memberof CartComponent
   */
  updateSkipCount(memberId: number, memberSkippedCount: number): void {
    this._cartService.updateMemberSkipCount(memberId, memberSkippedCount)
      .subscribe(response => {
        if (response && response.isSuccess) {
          this._cacheService.set(CacheKey.SkipCountIncreased, JSON.stringify(true));
          this._cacheService.set(CacheKey.MemberOptinCount, memberSkippedCount);
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
  }

  /**
   * This method used for getting updated member skipped count
   * getMemberSkipCount
   * @returns
   * @memberof CartComponent
   */
  getMemberSkipCount() {
    const memberMetaData: MemberMetaData = this.userInfo.memberMetaData.find(x =>
      x.customKey === MemberMetaDataEnum.UPGRADESKIPPEDCOUNT);
    let memberSkippedCount = 0;
    if (memberMetaData && memberMetaData.customValue) {
      memberSkippedCount = Number(memberMetaData.customValue);
    }
    const updateMemberSkippedCount = this._cacheService.get(CacheKey.MemberOptinCount);
    if (updateMemberSkippedCount && updateMemberSkippedCount > memberSkippedCount) {
      memberSkippedCount = Number(updateMemberSkippedCount);
    }
    return memberSkippedCount;
  }

  /**
   * @description Method to get cards content
   * @param sitemapId
   */
  getCardsContent(sitemapId: any) {
    this._commonService.getCardsContentBySitemapId(sitemapId).subscribe(response => {
      if (response) {
        this.cardsContent = response;
        const cards: any = document.querySelectorAll('div[data-t-card]');
        if (cards) {
          for (const card in cards) {
            if (Number(card) >= 0) {
              const temp = cards[card].getAttribute('data-t-card');
              if (this.cardsContent) {
                for (const place in this.cardsContent) {
                  if (place) {
                    const placeholder = this.cardsContent[place];
                    if (placeholder && placeholder.indexId === temp) {
                      if (placeholder.cardContent !== '') {
                        cards[card].innerHTML = placeholder.cardContent;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }, (error: any) => {
      this.translateParams = this._commonService.handleError(error);
    });
  }

  /**
   * @returns void
   */
  private getCartSessionInfo(): void {
    this.cartSubscription = this._appMessageService.getCartItemsChanges().subscribe((response) => {
      this.getCartItems(response);
      // To uncomment this please check with Team
      // this._cacheService.removeCookieValue(CacheKey.CartSessionGuid);
    });
  }

  /**
 * @returns void
 */
  getWishListSubject(): void {
    this.wishListSubscription = this._appMessageService.getWishListItems().subscribe(response => {
      this.getWishlistProducts();
    });
  }

  /**
  * to display wishlist products
  * @param  {number} productId
  * @param  {number} storeid
  */
  getWishlistProducts() {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart) {
      this.wishListCart = new Cart(wishListCart, this.store);
    }
  }

  /**
   * load cart items based on cart session guid
   * @returns void
   */
  getCartItems(cartTypeDetails?: any, reLoadCart?: boolean): void {
    let cartSession: Cart;
    if (cartTypeDetails && cartTypeDetails.cartType === CartTypes.AutoshipCart) {
      cartSession = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      cartSession = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    if (cartSession && cartSession.items && cartSession.items.length > 0 && cartSession.items[0].name) {
      cartSession.items = cartSession.items.map(x => {
        return this.getAutoshipEnableForItem(x);
      });
      if (cartTypeDetails && cartTypeDetails.cartType === CartTypes.AutoshipCart) {
        this.autoshipCart = new Cart(cartSession, this.store);
        this.autoshipCart.items.forEach((product) => product.disableDecrement = product.quantity > 1 ? false : true);
      } else {
        this.shoppingCart = new Cart(cartSession, this.store);
        this.shoppingCart.items.forEach((product) => product.disableDecrement = product.quantity > 1 ? false : true);
        const fboEligibleItems = this.shoppingCart.items.filter(x => x.fboEligible);
        if (fboEligibleItems && fboEligibleItems.length === 0) {
          this.isFPCOptInEligible = false;
          this._cacheService.set(CacheKey.IsFPCOptInEligible, 'false');
        } else {
          this.isFPCOptInEligible = true;
          this._cacheService.set(CacheKey.IsFPCOptInEligible, 'true');
        }
        if (this._cacheService.get(CacheKey.AutoshipCart)) {
          const autoshipCartSession = this._cacheService.get(CacheKey.AutoshipCart);
          if (autoshipCartSession && autoshipCartSession.items && autoshipCartSession.items.length > 0 && this.shoppingCart &&
            this.shoppingCart.items && this.shoppingCart.items.length > 0) {
            _.remove(autoshipCartSession.items, (item: Item) => {
              if (!item.isPromotionalProduct) {
                return !this.shoppingCart.items.find(x => x.productId === item.productId);
              }
            });
          }
          this.autoshipCart = new Cart(autoshipCartSession, this.store);
          this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
        }
      }
      //  disable All autoship checkbox If item is not eligible for autoship
      this.disabledAllAutoship();
      // Calculate remaining CC for FPC to FBO flow
      if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
        && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()
        && !this.userInfo.wholesaleQualified && !this.isFPCOptInEligible) {
        this.getAvailableCC();
      }
      if (this.userInfo && (this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
        || this.userInfo.memberTypeId === MemberType.DISTRIBUTOR)) {
        const validateOrderRule = this._commonService.verifyOrderRules();
        this.thresholdCrossed = validateOrderRule.thresholdCrossed;
        this.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
      }
      if (this.autoshipCart && this.autoshipCart.items && this.autoshipCart.items.length === 0) {
        this.removeAutoshipValidation();
      }
      this.isAddAllItemsToAutoship = this.validateAutoshipSelectedItem();
    }
  }

  disabledAllAutoship(): void {
    if (this.shoppingCart && this.shoppingCart.items.length > 0) {
      const notEligibleItems = this.shoppingCart.items.filter(item => !item.autoshipEnabled);
      if (notEligibleItems && notEligibleItems.length === this.shoppingCart.items.length) {
        this.isDisabledAutoship = true;
      }
    }
  }
  /**
   *@description Calculating remaining cc based cart items
   * @memberof CartComponent
   */

  getAvailableCC(): void {
    if ((this.shoppingCart && this.shoppingCart.totalPoints
      || this.autoshipCart && this.autoshipCart.totalPoints) && this.store && this.store.distributorMaxCC) {
      const currentCC = this.shoppingCart.totalPoints || this.autoshipCart.totalPoints;
      this.availableCC = this.existingCC ? this.existingCC - currentCC : this.store.distributorMaxCC - currentCC;
      if (this.availableCC <= 0 || this.availableCC >= this.store.distributorMaxCC) {
        if (this.fpcDocuments) {
          this.fpcDocuments.forEach(document => {
            document.isSelected = false;
          });
          const unSelectedDocuments = this.fpcDocuments.filter(x => x.isSelected === false);
          if (unSelectedDocuments && unSelectedDocuments.length === 0) {
            this.isFPCOptIn = true;
          } else {
            this.isFPCOptIn = false;
          }
        }
        this.isWholeSaleEligibility = true;
      } else {
        this.isFPCOptIn = false;
        this.isWholeSaleEligibility = false;
      }
      this._cacheService.set(CacheKey.WholeSaleEligibility, JSON.stringify(this.isWholeSaleEligibility));
    }
  }

  /**
     * @description getWholesaleQualified method used to
     * check balance CC needed to be eligible for Opt-in
     * @date 2018-07-19
     * @memberof CartSummaryComponent
     */
  getWholesaleQualified(): void {
    setTimeout(() => {
      this.isShowLoader = true;
      this._sectionSpinnerService.start('optin-message');
    });
    this._commonService.getWholsesaleQualifiedDetails(
      this.userInfo.distributorId,
      this.store.operatingCountry)
      .subscribe((res: WholesaleQualifiedResponse) => {
        if (res.response && res.response.toLowerCase() === 'true') {
          this.isWholeSaleEligibility = true;
        } else {
          try {
            this.isWholeSaleEligibility = JSON.parse(res.response);
          } catch (error) {
            this.isWholeSaleEligibility = false;
          }
        }
        if (!this.isWholeSaleEligibility) {
          let balance;
          try {
            balance = Number(res.balance);
          } catch {
            balance = this.store.distributorMaxCC;
          }
          if (!balance) {
            balance = this.store.distributorMaxCC;
          }
          this.existingCC = balance;
          this.getAvailableCC();
        }
        this.validateOptInMessage();
        setTimeout(() => {
          this._sectionSpinnerService.stop('optin-message');
        });
        this.isShowLoader = false;
        // this.getCartItems();
      }, error => {
        this.existingCC = this.store.distributorMaxCC;
        this.validateOptInMessage();
        this.getCartItems();
        this._sectionSpinnerService.stop('optin-message');
        this.isShowLoader = false;
      });
  }

  /**
   * Remove the Cart Item from the minicart.
   * @param  {boolean} isConfirm
   * @param  {number} productId
   */
  confirm(isConfirm: boolean, productId: number, wishListItem: boolean = false, isAutoshipItem: boolean = false, event?: any) {
    if ((event && event.keyCode === 13) || !event) {
      if (isConfirm && productId && !wishListItem && !isAutoshipItem) {
        this.removeCartItem(productId);
      } else if (productId && wishListItem) {
        this.removeWishListItem(productId, true);
      } else if (productId && isAutoshipItem) {
        this.removeAutoshipItem(productId);
      }
      this.showModalPopup(false);
      const seletedIndex = this.selectedItem + 1;
      const element = document.getElementById('product-name' + seletedIndex);
      if (element && event) {
        element.focus();
        event.preventDefault();
      }
    }
  }

  /**
   * @description Get Image method
   * @param image
   */
  public sanitizeImage(image: string): any {
    image = environment.cdnURL + image;
    return this._sanitizer.bypassSecurityTrustStyle(`url(${image})`);
  }

  /**
  * removing product from mini cart
  * @param  {string} index
  */
  removeCartItem(productId: number) {
    const cartSessionInfo: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
    if (cartSessionInfo && cartSessionInfo.items.length > 0) {
      const cartItem: Item = cartSessionInfo.items.find(x => x.productId === productId);
      cartSessionInfo.items = _.remove(cartSessionInfo.items, function (n) {
        return n.productId !== productId;
      });
      this._cartService
        .removeCartItem(cartSessionInfo.sessionGuid, cartItem.id)
        .subscribe((response: boolean) => {
          if (response) {
            this.shoppingCart = new Cart(cartSessionInfo, this.store);
            this._cacheService.set(CacheKey.CartSessionInfo, this.shoppingCart);
            const fboEligibleItems = this.shoppingCart.items.filter(x => x.fboEligible);
            if (fboEligibleItems && fboEligibleItems.length === 0) {
              this.isFPCOptInEligible = false;
              this._cacheService.set(CacheKey.IsFPCOptInEligible, 'false');
            } else {
              this.isFPCOptInEligible = true;
              this._cacheService.set(CacheKey.IsFPCOptInEligible, 'true');
            }
            const autoshipCart: Cart = this._cacheService.get(CacheKey.AutoshipCart);
            if (autoshipCart && autoshipCart.items && autoshipCart.items.length > 0 && this.shoppingCart &&
              this.shoppingCart.items && this.shoppingCart.items.length > 0) {
              this.shoppingCart.items.forEach(element => {
                element.enableAutoship = autoshipCart.items.find(x => x.productId === element.productId) ? true : false;
              });
              this.removeAutoshipItemsFromCart(autoshipCart, productId);
              this.autoshipCart = new Cart(autoshipCart, this.store);
              this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
            } else {
              this._cacheService.remove(CacheKey.AutoshipCart);
            }
            const cartSession = {
              sessionInfo: cartSessionInfo.sessionGuid,
              reloadMemberCart: false
            };
            this._appMessageService.setMiniCart(cartSession);
            if (this.userInfo && (this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
              || this.userInfo.memberTypeId === MemberType.DISTRIBUTOR)) {
              const validateOrderRule = this._commonService.verifyOrderRules();
              this.thresholdCrossed = validateOrderRule.thresholdCrossed;
              this.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
            }
            if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
              && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()
              && !this.userInfo.wholesaleQualified) {
              this.getAvailableCC();
            }
            if (!this.isAutoshipEnabled) {
              if (this.shoppingCart && this.shoppingCart.items && this.shoppingCart.items.length === 0) {
                this.router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products');
              }
            }
            this.disabledAllAutoship();
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }

  /**
   * add item to wishlist
   * @param  {Product} product
   */
  removeWishListItem(productId: number, showNotification: boolean): void {
    const cartItem: Item = this.wishListCart.items.find(x => x.productId === productId);
    this.wishListCart.items = _.remove(this.wishListCart.items, function (n) {
      return n.productId !== productId;
    });
    if (this.wishListCart && this.wishListCart.sessionGuid && cartItem && cartItem.id) {
      this._cartService.removeCartItem(this.wishListCart.sessionGuid, cartItem.id)
        .subscribe(response => {
          this.wishListCart = new Cart(this.wishListCart, this.store);
          this._cacheService.set(CacheKey.WishListSession, this.wishListCart);
          if (showNotification) {
            // this._commonService.createNotification('', itemDeletedNotification.value, 'success');
          }
        });
    }
  }

  /**
   * @description Remove Autoship Item
   * @date 2018-09-28
   * @param {number} productId
   * @memberof CartComponent
   */
  removeAutoshipItem(productId: number) {
    const autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    if (autoshipSessionInfo && autoshipSessionInfo.items && autoshipSessionInfo.items.length > 0) {
      this.removeAutoshipItemsFromCart(autoshipSessionInfo, productId);
      this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
      if (this.autoshipCart && this.autoshipCart.items
        && this.autoshipCart.items.length === 0) {
        this._cacheService.remove(CacheKey.AutoshipCart);
      } else {
        this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
      }
      if (this.shoppingCart && this.shoppingCart.items && this.shoppingCart.items.length > 0) {
        this.shoppingCart.items.forEach(element => {
          if (element.productId === productId) {
            element.enableAutoship = false;
            this.isAddAllItemsToAutoship = false;
          }
        });
      }
      this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
      this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
      this.getCartItems();
      const cartSession = {
        sessionInfo: autoshipSessionInfo.sessionGuid,
        reloadMemberCart: false
      };
      this._appMessageService.setMiniCart(cartSession);
      if (this.isAutoshipEnabled) {
        if (this.autoshipCart && this.autoshipCart.items && this.autoshipCart.items.length === 0) {
          this._cacheService.remove(CacheKey.AutoshipCart);
          this._cacheService.remove(CacheKey.AutoshipDetails);
          this._cacheService.remove(CacheKey.AutoshipDate);
          this.router.navigateByUrl('/' + this.isoCountryCode + '/' + this.languageCode.toLowerCase() + '/products');
        }
      }
      this.autoShownModal.hide();
    }
  }

  /**
 * @description remove autoship Item
 * @date 2019-01-24
 * @param {Cart} autoshipSessionInfo
 * @param {number} productId
 * @memberof CartComponent
 */
  removeAutoshipItemsFromCart(autoshipSessionInfo: Cart, productId: number): void {
    let isPromotionalProductCount = false;
    autoshipSessionInfo.items.forEach(x => {
      if (x.promotionalParentProducts && x.promotionalParentProducts.length > 1) {
        const promotionalProductId = x.promotionalParentProducts.find(prod => prod.parentProductId === productId);
        if (promotionalProductId) {
          const product = autoshipSessionInfo.items.find(z => z.productId === productId);
          if (product) {
            x.quantity = x.quantity - product.quantity;
          }
          x.promotionalParentProducts = x.promotionalParentProducts.filter(y => y.parentProductId !== productId);
          isPromotionalProductCount = true;
          return;
        }
      }
    });
    autoshipSessionInfo.items = _.remove(autoshipSessionInfo.items, function (n) {
      return n.productId !== productId || n.isPromotionalProduct;
    });
    if (!isPromotionalProductCount) {
      autoshipSessionInfo.items = _.remove(autoshipSessionInfo.items, function (item) {
        return (item.promotionalParentProducts &&
          (item.promotionalParentProducts.findIndex(ele => ele.parentProductId === productId)) === -1)
          || !item.promotionalParentProducts;
      });
    }
  }

  /**
   * @description find the index of element
   * @date 2019-01-24
   * @param {PromotionalParentProduct[]} promotionalParentProducts
   * @param {number} productId
   * @memberof CartComponent
   */
  findProductIndex(promotionalParentProducts: PromotionalParentProduct[], productId: number): number {
    const index = promotionalParentProducts.findIndex(ele => {
      return ele.parentProductId === productId;
    });
    return index;
  }

  /**
   * @description Show and hide the modal popup
   * @param {boolean} show
   * @param {boolean} [fromView]
   * @memberof MiniCartComponent
   */
  showModalPopup(show: boolean, fromView?: boolean): void {
    if (show) {
      // this._commonService.jumpingScroll(show);
      this.autoShownModal.show();
    } else {
      this.autoShownModal.hide();
      if (fromView) {
        this.confirmProduct = null;
        // will resolve the screen flickering while showing modal popup
        // this._commonService.jumpingScroll(show);
      }
    }
  }

  /**
   * @description To show remove pop-up method
   * @param productId
   * @param product
   * @param wishListItem
   * @param autoshipItem
   */
  showRemovePopUp(productId: string, product: Product, wishListItem: boolean = false, autoshipItem: boolean = false) {
    this.removeItem = true;
    this.clearBag = false;
    this.showModalPopup(true);
    this.confirmProduct = product;
    this.confirmProduct.wishListItem = wishListItem;
    this.confirmProduct.autoshipItem = autoshipItem;
  }

  /**
   * to update item quantity
   */
  updateQuantity(cartItem: Item, $evt: any): void {
    this.cartItemChanged = true;
    clearTimeout(this.clickTimeout[cartItem.id]);
    if ($evt && $evt.currentTarget.value) {
      cartItem.quantity = $evt.currentTarget.value;
      cartItem.disableDecrement = false;
      cartItem.disableIncrement = false;
      if (cartItem.quantity > cartItem.stockQuantity && !cartItem.backOrderAllowed) {
        cartItem.disableIncrement = true;
        cartItem.errorMessage = true;
        setTimeout(() => {
          cartItem.errorMessage = false;
        }, 2000);
        cartItem.quantity = cartItem.stockQuantity;
        $evt.currentTarget.value = cartItem.quantity;
        this.outofStockNotification(cartItem);
        //   this._commonService.createNotification('', this.cartStockError, 'error');
      } else {
        cartItem.disableIncrement = false;
      }
      if (!cartItem.disableIncrement) {
        this.isQuantityUpdateLoader = true;
        this.updateCart(cartItem);
      }
      cartItem.disableDecrement = cartItem.quantity > 1 ? false : true;
    }
  }

  /**
   * @description Method to show notification when product is out of stock
   * @param product
   */
  outofStockNotification(product: Item) {
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">'
      + product.stockQuantity + '</span>', NotificationType.ERROR);
  }

  /**
   * Trackby will change the DOM
   *  for only added or removed element(not entire DOM Collection)
   * @param  {number} index
   * @param  {Product} item
   * @returns number
   */
  trackProductBy(index: number, product: Product): number {
    return index;
  }

  /**
  * decrement Autoship quantity
  * @param item
  */
  decrementAutoshipQuantity(item: Item): void {
    item.quantity = !isNaN(item.quantity) ? item.quantity : 1;
    if (item.quantity > 1) {
      item.quantity = +item.quantity - 1;
      this.manageAutoshipCart(item, false, true);
    }
    if (item.quantity === 1) {
      item.disableDecrement = true;
    }
    item.disableIncrement = false;
  }

  /**
   * Increment Autoship quantity
   * @param item
   */
  incrementAutoshipQuantity(item: Item): void {
    item.quantity = !isNaN(item.quantity) ? item.quantity : 1;
    item.quantity = ++item.quantity;
    const quantityFieldLength = item.quantity ? item.quantity.toString().length : 0;
    item.disableIncrement = false;
    // Condition to check whether quantity has no.of digits more than 3 digits , hence disabling increment
    if (quantityFieldLength > 3) {
      item.disableIncrement = true;
      item.quantity = item.quantity - 1;
      return;
    }
    item.disableDecrement = false;
    if (item.quantity > item.stockQuantity && !item.backOrderAllowed) {
      item.disableIncrement = true;
      item.quantity = item.quantity - 1;
      // this._commonService.createNotification('', this.cartStockError, 'error');
    }
    if (!item.disableIncrement) {
      this.manageAutoshipCart(item);
    }
  }

  /**
  * update Autoship item quantity
  * @param item
  * @param
  */
  updateAutoshipQuantity(item: Item, $evt: any): void {
    if ($evt && $evt.currentTarget.value) {
      item.quantity = $evt.currentTarget.value;
      item.disableDecrement = false;
      item.disableIncrement = false;
      if (item.quantity > item.stockQuantity && !item.backOrderAllowed) {
        item.disableIncrement = true;
        item.quantity = item.stockQuantity;
        $evt.currentTarget.value = item.quantity;
        //  this._commonService.createNotification('', this.cartStockError, 'error');
      } else {
        item.disableIncrement = false;
      }
      if (!item.disableIncrement) {
        const autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
        const cartItem: Item = autoshipSessionInfo.items.find(x => x.productId === item.productId && !x.isPromotionalProduct);
        let isDecrement: boolean;
        item.quantity = +item.quantity;
        if (item.quantity < cartItem.quantity) {
          isDecrement = true;
        }
        this.manageAutoshipCart(item, false, isDecrement ? isDecrement : false);
      }
    }
  }


  /**
   * Increment the item Quantity
   * @returns void
   */
  incrementQuantity(item: Item): void {
    this.isQuantityUpdateLoader = true;
    item.quantity = +item.quantity + 1;
    const quantityFieldLength = item.quantity ? item.quantity.toString().length : 0;
    item.disableIncrement = false;
    clearTimeout(this.clickTimeout[item.id]);
    if (quantityFieldLength > 3) {
      this.isQuantityUpdateLoader = false;
      item.disableIncrement = true;
      item.quantity = item.quantity - 1;
      return;
    }
    item.disableDecrement = false;
    if (item.quantity > item.stockQuantity && !item.backOrderAllowed) {
      item.disableIncrement = true;
      item.errorMessage = true;
      setTimeout(() => {
        item.errorMessage = false;
      }, 2000);
      item.quantity = item.quantity - 1;
      this.outofStockNotification(item);
      // this._commonService.createNotification('', this.cartStockError, 'error');
    } else {
      this.clickTimeout[item.id] = setTimeout(() => {
        this.updateCart(item); // replace with your update code
      }, 800);
    }
  }


  /**
   * Decrement the item Quantity
   * @returns void
   */
  decrementQuantity(item: Item): void {
    clearTimeout(this.clickTimeout[item.id]);
    if (item.quantity > 1) {
      this.isQuantityUpdateLoader = true;
      item.quantity = +item.quantity - 1;
      this.clickTimeout[item.id] = setTimeout(() => {
        this.updateCart(item);
      }, 800);
    }
    if (item.quantity === 1) {
      item.disableDecrement = true;
    }
    item.disableIncrement = false;
  }

  /**
   * @param  {any} item
   */
  updateCart(item: Item): void {
    this.manageShoppingCart(item, CartTypes.OrderCart);
  }


  /**
   * add wishlist item to cart
   * @param  {Item} item
   * @returns void
   */
  addWishListItemToCart(item: Item): void {
    this.manageShoppingCart(item, CartTypes.OrderCart, true);
    this.removeWishListItem(item.productId, false);
  }
  /**
   * on click of checkout
   * @memberof CartComponent
   */
  checkoutClick(): void {
    if (this.userInfo && this.autoshipPreference && this.autoshipCart) {
      this.getShippingRestrictionsForAutoshipProducts();
    } else {
      this.navigateToCheckout();
    }
  }

  /**
   * @description
   * @date 2019-05-15
   * @memberof CartComponent
   */
  navigateToCheckout(): void {
    this.isCheckoutSubmitted = true;
    if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
      && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()
      && this.isWholeSaleQualified || this.isWholeSaleEligibility || this.isFPCOptInEligible) {
      if (!this.agreementCheckError) {
        if (!this.cartItemChanged) {
          this.goToCheckout();
        } else {
          this.isCheckoutClicked = true;
        }
      } else {
        this._commonService.scrollTo('agreementBlock', 500);
      }
    } else {
      if (!this.cartItemChanged) {
        this.goToCheckout();
      } else {
        this.isCheckoutClicked = true;
      }
    }
  }

  /**
   * checking whether user is logged in or not
   */
  goToCheckout(): void {
    const addItemNotification: any = this._translatePipe.get('quickview.Add items to cart');
    // tslint:disable-next-line:max-line-length
    const exceedMonthlyCCPopup: any = this._translatePipe.get('common.Your cart contains a case credit value that brings your total monthly case credits above the limit');
    if (this.autoshipDate) {
      this._cacheService.set(CacheKey.AutoshipDate, this.autoshipDate);
    }
    if (!this.isAutoshipEnabled) {
      if (this.shoppingCart && this.shoppingCart.items && this.shoppingCart.items.length > 0) {
        this.orderRules = this._cacheService.get(CacheKey.OrderRules);
        this.memberOrderCCInfo = this._cacheService.get(CacheKey.MemberOrderRules);
        let validateOrderRule;
        if (this.userInfo && (this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
          || this.userInfo.memberTypeId === MemberType.DISTRIBUTOR)) {
          validateOrderRule = this._commonService.verifyOrderRules();
          this.thresholdCrossed = validateOrderRule.thresholdCrossed;
          this.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
        }
        if (!this.isAutoshipEnabled) {
          if (((this.orderRules && !this.thresholdCrossed) || !this.orderRules) &&
            ((this.memberOrderCCInfo && !this.memberCCLimitExceeded) || !this.memberOrderCCInfo)) {
            this.checkDocumentsSelected();
            if ((this.isWholeSaleEligibility || this.isWholeSaleQualified || this.isFPCOptInEligible)
              && this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
              && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()) {
              this._cacheService.set(CacheKey.FPCOptIn, JSON.stringify(this.isFPCOptIn));
              const documents = { fboOptInDocuments: this.fpcDocuments, paymentPolicies: [] };
              this._cacheService.set(CacheKey.FBOTerms, documents);
            } else {
              this._cacheService.set(CacheKey.FPCOptIn, JSON.stringify(false));
            }
            const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
            if (!this.isFPCOptInEligible && this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
              && checkoutInformation && checkoutInformation.personalInformation) {
              this._cacheService.remove(CacheKey.CheckoutInformation);
            }
            this._commonService.navigateToCheckout();
          }
          if (this.memberCCLimitExceeded) {
            const monthlyCCContent = exceedMonthlyCCPopup.value + ' <b class="helvetica-bold">' + validateOrderRule.monthlyCCValue + '</b>';
            this._notificationService.createNotification('', monthlyCCContent, NotificationType.ERROR);
          }
        }
      }
    } else {
      if ((this.isWholeSaleEligibility || this.isWholeSaleQualified || this.isFPCOptInEligible)
        && this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
        && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()) {
        this._cacheService.set(CacheKey.FPCOptIn, JSON.stringify(this.isFPCOptIn));
      } else {
        this._cacheService.set(CacheKey.FPCOptIn, JSON.stringify(false));
      }
      this._commonService.navigateToCheckout();
      // this._commonService.createNotification('', addItemNotification.value, 'success');
    }
  }

  /**
  * @param  {Product} product
  * @returns void
  */
  navigateToProductDetail(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = product.categories[0];
    }
    if (product.customCatalogName && product.categories.length > 0) {
      selectedCategory = {
        productCategoryId: product.customCatalogId,
        categoryName: product.customCatalogName,
      };
    }
    if (selectedCategory) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
    }
    if (product.parentProductSlug) {
      product.slug = product.parentProductSlug;
      this._dataService.variableProductOption = product.selectedOption;
    }
    if (selectedCategory && selectedCategory.slug) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      this.router.navigate
        (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase()
          + '/products/' + selectedCategory.slug + '/' + product.slug]);
    } else {
      this.router.navigate(['/' + this.isoCountryCode.toLowerCase() +
        '/' + this.languageCode.toLowerCase() + '/products/' + product.slug]);
    }
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(item: Item, cartType: CartTypes, wishListItem: boolean = false) {
    const itemAddedNotification: any = this._translatePipe.get('quickview.Item added to cart');
    let cartSessionInfo: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
    if (cartSessionInfo) {
      const cartItem: Item = cartSessionInfo.items.find(x => x.productId === item.productId);
      if (wishListItem && cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get
            ('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > cartItem.stockQuantity && !item.backOrderAllowed) {
          item.quantity = cartItem.stockQuantity;
          item.errorMessage = true;
          setTimeout(() => {
            item.errorMessage = false;
          }, 2000);
          // this._commonService.createNotification('', this.cartStockError, 'error');
          this.outofStockNotification(item);
          return;
        }
      }
      const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: Cart) => {
        if (response) {
          this.isQuantityUpdateLoader = false;
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          this._cacheService.set(CacheKey.hasCartItems, true);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this.getCartItems();
          this.cartItemChanged = false;
          if (this.isCheckoutClicked) {
            this.goToCheckout();
            this.isCheckoutClicked = false;
          }
        }
      }, (error: any) => {
        this.cartItemChanged = false;
        this.translateParams = this._commonService.handleError(error);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: Cart) => {
        if (response) {
          // this._commonService.createNotification('', itemAddedNotification.value, 'success');
          this.isQuantityUpdateLoader = false;
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          this._cacheService.set(CacheKey.hasCartItems, true);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this.getCartItems();
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }


  /**
   * focus back to close delete item confirmation pop up when using keyboard access
   */
  focusBackToCloseDeleteItemPopUp() {
    document.getElementById('dismissModal').focus();
  }

  //#region autoship functionality for order

  /**
  * get Next run dates for the Autoship
  */
  getNextAutoshipRunDate(): void {
    const currentDate = new Date();
    const autoshipStartDate = new Date();
    const autoshipEndDate = new Date();
    autoshipStartDate.setDate(environment.autoShipStartDay);
    autoshipEndDate.setDate(environment.autoShipEndDay);
    if (currentDate < autoshipStartDate) {
      this.autoshipDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, environment.autoShipStartDay);
    } else if (currentDate > autoshipEndDate) {
      this.autoshipDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, environment.autoShipEndDay);
    } else {
      this.autoshipDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, currentDate.getDate());
    }
  }

  /**
   * Change Autoship Details
   * @param autoshipName
   * @param autoshipDate
   */
  changeAutoshipNameAndDate(autoshipDate: Date) {
    this._cacheService.set(CacheKey.AutoshipDate, autoshipDate);
  }

  /**
    * get cart items autoship enabled or not
    * @param  {Item} cartItem
    * @returns Item
    */
  getAutoshipEnableForItem(cartItem: Item): Item {
    const autoshipCartSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    if (autoshipCartSession && autoshipCartSession.items) {
      cartItem.enableAutoship =
        autoshipCartSession.items.find(x => x.productId === cartItem.productId && !x.isPromotionalProduct) ? true : false;
    }
    return cartItem;
  }

  /**
   * @description Add Items to the autoshipcart
   * @date 2018-08-30
   * @param {Item} cartItem
   * @memberof CartComponent
   */
  enableItemForAutoship(item: Item): void {
    const autoshipCartInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    // Autoship checkbox is checked
    if (item.enableAutoship) {
      const autoshipCartItem: Item = this._cartService.convertItemToItemMapper(item);
      this.manageAutoshipCart(autoshipCartItem);
      const message: any = this._translatePipe.get('shoppingcart.Item added To Autoship bag');
      this._notificationService.createNotification('', message.value, NotificationType.SUCCESS);
    } else if (autoshipCartInfo &&  // Unchecked the Autoship checkbox to remove the item
      autoshipCartInfo.items && autoshipCartInfo.items.length > 0) {
      this.removeAutoshipItemsFromCart(autoshipCartInfo, item.productId);
      this.isAddAllItemsToAutoship = false;
      this.autoshipCart = new Cart(autoshipCartInfo, this.store);
      // weather the items are present in the auotship list or not,
      // if items are empty remove the the autoship profile or update the cache value
      if (this.autoshipCart && this.autoshipCart.items
        && this.autoshipCart.items.length === 0) {
        this._cacheService.remove(CacheKey.AutoshipCart);
      } else {
        this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
      }
    }
    this.isAddAllItemsToAutoship = this.validateAutoshipSelectedItem();
  }


  /**
   * validate All autoship checkbox while adding items to autoship bag
   *
   * @returns {boolean}
   * @memberof CartComponent
   */
  validateAutoshipSelectedItem(): boolean {
    if (this.autoshipCart && this.autoshipCart.items
      && this.autoshipCart.items.length > 0) {
      const shoppingCartInfo: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
      // Autoship checkbox is checked
      if (shoppingCartInfo && shoppingCartInfo.items && shoppingCartInfo.items.length > 0) {
        const totalCartItems = shoppingCartInfo.items.filter(item => item.autoshipEnabled);
        const autoshipCount = this.autoshipCart.items.filter(item => !item.isPromotionalProduct);
        if (totalCartItems && totalCartItems.length === autoshipCount.length) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * @description Add All Items To Autoship Cart
   * @date 2018-12-12
   * @memberof CartComponent
   */
  addAllItemsToAutoship(isAddAllItemsToAutoship: boolean): void {
    const shoppingCartInfo: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
    // Autoship checkbox is checked
    if (isAddAllItemsToAutoship) {
      this._cacheService.remove(CacheKey.AutoshipCart);
      if (shoppingCartInfo && shoppingCartInfo.items && shoppingCartInfo.items.length > 0) {
        shoppingCartInfo.items.forEach(item => {
          if (item.autoshipEnabled) {
            const autoshipCartItem: Item = this._cartService.convertItemToItemMapper(item);
            this.manageAutoshipCart(autoshipCartItem, true);
          }
        });
        const autoshipSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
        shoppingCartInfo.items.forEach(item => {
          if (item && item.promotions && item.promotions.length > 0) {
            this.promotionalProductChanges(autoshipSession, item, null);
          }
        });
        const message: any = this._translatePipe.get('shoppingcart.Items added To Autoship bag');
        this._notificationService.createNotification('', message.value, NotificationType.SUCCESS);
      }
    } else if (!isAddAllItemsToAutoship) {
      this.autoshipCart = null;
      if (this.shoppingCart && this.shoppingCart.items && this.shoppingCart.items.length > 0) {
        this.shoppingCart.items.forEach(element => {
          element.enableAutoship = false;
        });
      }
      this._cacheService.remove(CacheKey.AutoshipCart);
    }
  }

  /**
   * @description Manage autoship cart items
   * @date 2018-08-30
   * @private
   * @param {Item} item
   * @param {CartTypes} cartType
   * @memberof CartComponent
   */
  private manageAutoshipCart(item: Item, isAddAllItemsToAutoship?: boolean, isDecrement?: boolean): void {
    let autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    let cartItemIndex = -1;
    let modifiedQty: number;
    if (autoshipSessionInfo && autoshipSessionInfo.items
      && autoshipSessionInfo.items.length > 0) {
      const cartItem: Item = autoshipSessionInfo.items.find(x => x.productId === item.productId && !x.isPromotionalProduct);
      cartItemIndex = autoshipSessionInfo.items.findIndex(x => x.productId === item.productId);
      if (cartItem) {
        modifiedQty = this.differenceofTwoQty(item.quantity, cartItem.quantity);
        cartItem.quantity = item.quantity;
        autoshipSessionInfo.items.splice(autoshipSessionInfo.items.indexOf(cartItem), 1);
      }
    }

    autoshipSessionInfo = this.prepareAutoshipCart(item, CartTypes.AutoshipCart, autoshipSessionInfo
      ? autoshipSessionInfo : new Cart(null, this.store), cartItemIndex);
    this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
    const cartSession = {
      reloadMemberCart: false
    };
    this.shoppingCart.items.forEach(element => {
      element.enableAutoship = autoshipSessionInfo.items.find(x => x.productId === element.productId
        && !x.isPromotionalProduct) ? true : false;
    });
    this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
    this._appMessageService.setMiniCart(cartSession);
    if (item && item.promotions && item.promotions.length > 0 && !isAddAllItemsToAutoship) {
      this.promotionalProductChanges(autoshipSessionInfo, item, modifiedQty, isDecrement);
    }
  }

  /**
   * @description this methhod will give the dieffer amount
   * @date 2019-01-22
   * @param {number} preQty
   * @param {number} newQty
   * @returns {number}
   * @memberof CartComponent
   */
  differenceofTwoQty(preQty: number, newQty: number): number {
    return (preQty > newQty) ? preQty - newQty : newQty - preQty;
  }


  /**
   * @description changes done to parent Product applying to the promotional product
   * @date 2019-01-14
   * @param {Cart} autoshipSessionInfo
   * @param {Item} item
   * @memberof CartComponent
   */
  promotionalProductChanges(autoshipSessionInfo: Cart, item: Item, modifiedQty: number, isDecrement?: boolean): void {
    const promotionalProduct = item.promotions.find(x => x.promotionTypeId === PromotionsTypes.Autoship);
    if (promotionalProduct) {
      let isProductExists = autoshipSessionInfo.items.find(prod =>
        prod.productId === promotionalProduct.complementaryProductId && prod.isPromotionalProduct);
      if (!isProductExists) {
        isProductExists = autoshipSessionInfo.items.find(prod =>
          prod.productId === promotionalProduct.alternateComplementaryProductId
          && (prod.promotionalParentProducts && prod.promotionalParentProducts.length
            && prod.promotionalParentProducts.find(x => x.isAlternatePromotionalProduct === true))
          && prod.isPromotionalProduct);

        if (!isProductExists) {
          this.addPromotionalProduct(item);
        }
      }
      if (isProductExists) {
        autoshipSessionInfo.items.forEach(x => {
          if (x.productId === isProductExists.productId && x.isPromotionalProduct) {
            if (isDecrement) {
              x.quantity = x.quantity - (modifiedQty ? modifiedQty : 0);
            } else {
              x.quantity = x.quantity + (modifiedQty ? modifiedQty : 0);
            }
            const promotionalProductIndex = this.findProductIndex(x.promotionalParentProducts, item.productId);
            if (x.promotionalParentProducts && promotionalProductIndex === -1) {
              x.quantity = x.quantity + item.quantity;
              const promotionalProd: PromotionalParentProduct = {
                parentProductId: item.productId,
                isAlternatePromotionalProduct: true
              };
              x.promotionalParentProducts.push(promotionalProd);
              return x;
            }
          }
        });
        this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
        this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
      }
    }
  }


  /**
   * @description add Promotional Products
   * @date 2019-01-14
   * @param {Item} item
   * @param {Cart} autoshipSessionInfo
   * @memberof CartComponent
   */
  addPromotionalProduct(item: Item): void {
    const productIds: number[] = [];
    let alternatePromotionalProduct = false;
    if (item && item.promotions && item.promotions.length > 0) {
      const promotionalProduct = item.promotions.find(x => x.promotionTypeId === PromotionsTypes.Autoship);
      if (promotionalProduct && promotionalProduct.complementaryProductId) {
        productIds.push(promotionalProduct.complementaryProductId);
      }
      if (promotionalProduct && productIds && productIds.length === 0 && promotionalProduct.alternateComplementaryProductId) {
        productIds.push(promotionalProduct.alternateComplementaryProductId);
        alternatePromotionalProduct = true;
      }
    }
    this.getPromotionalProductDetails(productIds, item, alternatePromotionalProduct);
  }

  /**
   * @description get promotional product details
   * @date 2019-01-15
   * @param {number[]} productId
   * @memberof AutoshipPreferenceComponent
   */
  getPromotionalProductDetails(productId: number[], item: Item, alternatePromotionalProduct: boolean,
    isrestrictedProducts?: boolean): void {
    let promotionalProd: Item = null;
    this._commonService.getProductsByIds(productId, this.languageCode, this.storeId, true).subscribe((response) => {
      if (response && response.length > 0) {
        let autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
        response.forEach((prod) => {
          let promotionalProduct = null;
          promotionalProd = this._cartService.convertProductToItemMappper(prod);
          promotionalProd.CV = 0;
          promotionalProd.totalPrice = 0;
          promotionalProd.isPromotionalProduct = true;
          promotionalProd.applicablePrice = 0;
          promotionalProd.totalPoints = 0;
          promotionalProd.disableDecrement = true;
          promotionalProd.disableIncrement = true;
          promotionalProd.quantity = item.quantity;
          let promotionalParentProduct: PromotionalParentProduct = null;
          if (item && item.promotions && item.promotions.length > 0 && !isrestrictedProducts) {
            promotionalProduct = item.promotions.find(x => x.promotionTypeId === PromotionsTypes.Autoship);
            promotionalProd.alternatePromotionalProductId =
              promotionalProduct ? promotionalProduct.alternateComplementaryProductId : null;
          } else if (isrestrictedProducts) {
            const prodPromotions = this.getQuantity(promotionalProd.productId);
            if (prodPromotions) {
              promotionalParentProduct = this.mapParentToPromotionalProduct(prodPromotions.productId, true);
              promotionalProd.quantity = prodPromotions.quantity;
            }
          }
          if (!promotionalParentProduct) {
            promotionalParentProduct = {
              parentProductId: promotionalProduct ? promotionalProduct.qualifyingProductId : null,
              isAlternatePromotionalProduct: alternatePromotionalProduct
            };
          }
          promotionalProd.promotionalParentProducts.push(promotionalParentProduct);
          promotionalProd.isAlternatePromotionalProduct = alternatePromotionalProduct;
          const isPromotionalProductExists = this.checkIsPromotionalProductExist(autoshipSessionInfo, promotionalProd);
          if (!isPromotionalProductExists) {
            autoshipSessionInfo = this.prepareAutoshipCart(promotionalProd, CartTypes.AutoshipCart, autoshipSessionInfo
              ? autoshipSessionInfo : new Cart(null, this.store), null);
          }
          this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
          this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
        });
        const autoshipDetails: Autoship = this._cacheService.get(CacheKey.AutoshipDetails);
        if (!alternatePromotionalProduct && autoshipDetails) {
          this.checkProductRestrictions(promotionalProd);
        }
      }
    });
  }

  /**
 * @description map parent id to promotional product
 * @date 2019-01-27
 * @param {number} qualifyingProductId
 * @param {boolean} alternatePromotionalProduct
 * @returns {PromotionalParentProduct}
 * @memberof CartComponent
 */
  mapParentToPromotionalProduct(qualifyingProductId: number, alternatePromotionalProduct: boolean): PromotionalParentProduct {
    const promotionalParentProduct: PromotionalParentProduct = {
      parentProductId: qualifyingProductId ? qualifyingProductId : null,
      isAlternatePromotionalProduct: alternatePromotionalProduct
    };
    return promotionalParentProduct;

  }

  /**
   * @description retreive the quantity
   * @date 2019-01-27
   * @param {number} quantity
   * @param {boolean} isrestrictedProducts
   * @param {number} parentProductId
   * @returns {number}
   * @memberof CartComponent
   */
  getQuantity(parentProductIds: number): Item {
    const autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    let product: Item;
    if (parentProductIds) {
      const value = autoshipSessionInfo.items.filter(x => {
        if (x.promotions && x.promotions.length > 0) {
          const promotionalProduct = x.promotions.find(p => p.promotionTypeId === PromotionsTypes.Autoship);
          if (promotionalProduct && promotionalProduct.alternateComplementaryProductId === parentProductIds
            && !x.isPromotionalProduct) {
            product = x;
            return x;
          }
        }
      });
    }
    return product;
  }

  /**
* @description check is Promotional Product exists
* @date 2019-01-22
* @param {Cart} autoshipSessionInfo
* @param {Item} promotionalProduct
* @returns {boolean}
* @memberof CartComponent
*/
  checkIsPromotionalProductExist(autoshipSessionInfo: Cart, promotionalProduct: Item): boolean {
    let isPromotionalProductExists = false;
    if (autoshipSessionInfo && autoshipSessionInfo.items && autoshipSessionInfo.items.length > 0) {
      const isProductExists = autoshipSessionInfo.items.find(prod =>
        prod.productId === promotionalProduct.productId && prod.isPromotionalProduct);
      if (isProductExists) {
        autoshipSessionInfo.items.forEach(x => {
          if (x.productId === isProductExists.productId && x.isPromotionalProduct) {
            isPromotionalProductExists = true;
            const promotionalProd: PromotionalParentProduct = {
              parentProductId: promotionalProduct.promotionalParentProducts[0].parentProductId,
              isAlternatePromotionalProduct: promotionalProduct.promotionalParentProducts[0].isAlternatePromotionalProduct
            };
            x.promotionalParentProducts.push(promotionalProd);
            x.quantity = x.quantity + promotionalProduct.quantity;
          }
        });
        this.autoshipCart = new Cart(autoshipSessionInfo, this.store);
      }
    }
    return isPromotionalProductExists;
  }


  /**
* @description Autoship Shipping Address Details
* @date 2018-09-17
* @private
* @param {Autoship} autoship
* @memberof ShippingAddressNewComponent
*/
  private getAutoshipShippingAddressDetails(autoship: Autoship): void {
    if (autoship && autoship.autoshipShippingInformations &&
      autoship.autoshipShippingInformations.length > 0 &&
      autoship.autoshipShippingInformations[0].shippingAddressId) {
      this._addressService.getAddressDetailsById(autoship.autoshipShippingInformations[0].shippingAddressId)
        .subscribe(response => {
          if (response && response.length > 0) {
            const autoshipAddressDetails = response[0];
            autoshipAddressDetails.country =
              this.countries.find((x: Country) => x.countryId ===
                autoshipAddressDetails.countryId).isocodeThree;
            autoshipAddressDetails.name = autoshipAddressDetails.shipToName;
            autoshipAddressDetails.zip = autoshipAddressDetails.postalCode;
            autoshipAddressDetails.state = autoshipAddressDetails.stateCode;
            this.shippingAddress = autoshipAddressDetails;
          }
        });
    }
  }

  /**
   * @description this method will check the product restriction
   * @date 2019-01-17
   * @param {Item} promotionalProd
   * @memberof CartComponent
   */
  checkProductRestrictions(promotionalProd: Item): void {
    this.checkProductRestrictions(promotionalProd);
    this.getShippingRestrictionsForPromotionalProd(this.autoshipCart, promotionalProd);
  }

  /**
   * @description gets the shipping restricted products
   * @date 2019-01-17
   * @param {AutoshipPreferences} autoShipItem
   * @param {Item} promotionalProd
   * @memberof CartComponent
   */
  getShippingRestrictionsForPromotionalProd(autoshipCart: Cart, promotionalProd: Item): void {
    let itemNumbers: Item[] = null;
    const shippingOptionsRequest: ShippingOptionsRequest = this.prepareShippingOptions(autoshipCart, promotionalProd);
    this._shippingService
      .getShippingOptions(shippingOptionsRequest)
      .subscribe((response: ShippingOptionsResponse) => {
        if (response && response.productModels && response.productModels.length > 0) {
          itemNumbers = this.getRestrictedItemNumbers(response);
        }
        this.getRestrictedProducts(itemNumbers);
      });
  }

  /**
   * @description get the shipping Restricted Products
   * @param {Cart} autoshipCart
   * @memberof CartComponent
   */
  getShippingRestrictionsForAutoshipProducts(): void {
    const shippingOptionsRequest: ShippingOptionsRequest = this.prepareShippingOptions(this.autoshipCart);
    this._shippingService.getShippingOptions(shippingOptionsRequest)
      .subscribe((response: ShippingOptionsResponse) => {
        if (response && response.productModels && response.productModels.length > 0) {
          this.shippingRestrictedProduct(response);
        } else {
          this.navigateToCheckout();
        }
      }, (error: any) => {
        this.navigateToCheckout();
      });
  }

  /**
   * @description this method is used
   * validate this product is restricted or not
   * @param {*} restrictedProduct
   * @memberof CartComponent
   */
  private shippingRestrictedProduct(shippingOptionsResponse: ShippingOptionsResponse) {
    if (shippingOptionsResponse.success && shippingOptionsResponse.productModels) {
      this.productShippingRestriction = this.prepareProductShippingRestrictions(shippingOptionsResponse);
      if (this.productShippingRestriction) {
        this.getAutoshipRestrictedProducts();
        this.shippingRestrictionModal.show();
      }

    } else {
      this.productShippingRestriction = null;
    }
  }

  /**
   * @description close the popup
   * @date 2019-05-15
   * @memberof CartComponent
   */
  onHidden(): void {
    this.shippingRestrictionModal.hide();
  }

  /**
   * @description this method will get restrcited products
   * @private
   * @returns {RestrictedProduct[]}
   * @memberof CartComponent
   */
  private getAutoshipRestrictedProducts(): RestrictedProduct[] {
    const cartItems: Item[] = this.autoshipCart.items;
    this.restrictedProducts = [];
    const restrictedItems = [];
    // cartItems = _.uniqBy(cartItems, function (e: any) {
    //   return e.id;
    // });
    const restrictedProductItemNumbers: any[] = this.productShippingRestriction.itemNumbers;
    if (restrictedProductItemNumbers && restrictedProductItemNumbers.length > 0
      && cartItems && cartItems.length > 0) {
      cartItems.forEach(element => {
        restrictedProductItemNumbers.forEach(x => {
          if (element.itemNumber === x.itemNumber.substring(x.itemNumber.indexOf('#') + 1)) {
            const error: any = this._translateService.get('checkout.' + x.errorDescription);
            element['errorDescription'] = error.value;
            if (x.errorDescription) {
              restrictedItems.push(element);
            }
          }
        });
      });
    }
    this.restrictedProducts = restrictedItems;
    return this.restrictedProducts;
  }

  /**
   * @description  this method will prepare shipping restrictions
   * based on shipping address and shipping options response
   * @private
   * @memberof CartComponent
   */
  private prepareProductShippingRestrictions(shippingOptionsResponse: ShippingOptionsResponse): ProductShippingRestriction {
    const productShippingRestriction: ProductShippingRestriction = {
      productModelResponse: true,
      shippingResponse: shippingOptionsResponse.success ? shippingOptionsResponse.success : false,
      productError: this.getShippingRestrictionError(),
      itemNumbers: this.getRestrictedItemNumbers(shippingOptionsResponse),
      itemNo: this.getShippingRestrictionItemNo(shippingOptionsResponse)
    };
    return productShippingRestriction;
  }

  /**
   * @description this method will find the restricted products
   * @date 2019-01-17
   * @param {Item[]} itemNumbers
   * @memberof CartComponent
   */
  getRestrictedProducts(itemNumbers: Item[]): void {
    if (itemNumbers && itemNumbers.length > 0) {
      itemNumbers.forEach(x => {
        this.autoshipCart.items.forEach(element => {
          if (element.itemNumber === x.itemNumber.substring(x.itemNumber.indexOf('#') + 1)) {
            this.autoshipCart.items = _.remove(this.autoshipCart.items, function (n) {
              if (x.itemNumber === n.itemNumber && !n.isPromotionalProduct) {
                return true;
              } else {
                return x.itemNumber !== n.itemNumber;
              }
            });
          }
          if (!element.isAlternatePromotionalProduct && element.alternatePromotionalProductId) {
            const productId: number[] = [];
            const parentProdutId = this.autoshipCart.items.filter(y => {
              if (element.promotionalParentProducts && element.promotionalParentProducts.length > 0) {
                const isProductExists = element.promotionalParentProducts.find(prod => prod.parentProductId === y.productId);
                if (isProductExists) {
                  const promotionalProduct = y.promotions.find(p => p.promotionTypeId === PromotionsTypes.Autoship);
                  if (promotionalProduct) {
                    productId.push(promotionalProduct.alternateComplementaryProductId);
                  }
                }
              }
            });
            this._cacheService.set(CacheKey.AutoshipCart, this.autoshipCart);
            this.getPromotionalProductDetails(productId, element, true, true);
          }
        });
      });
    }
  }

  /**
   * @description this method will give the product error descriptions
   * @private
   * @param {*} restrictedProduct
   * @returns {string}
   * @memberof CartComponent
   */
  private getShippingRestrictionError(): string {
    let productError = '';
    if (this.shippingAddress && this.shippingAddress.stateCode && this.shippingAddress.countryId) {
      if (this.states) {
        const stateName: string = this.states.find(x => x.stateCode === this.shippingAddress.stateCode).stateName;
        const error: any =
          this._translateService.get(
            'checkout.The Address configured in Autoship profile the following products cannot be sold in');
        productError = error.value;
        productError = productError + ' ' + stateName;
      }
    } else {
      const error: any =
        this._translateService.get('checkout.The Address configured in Autoship profile the following products cannot be sold');
      productError = error.value;
    }
    return productError;
  }

  /**
   * @description this method will give restricted items numbers
   * @private
   * @param {*} restrictedProduct
   * @returns {string}
   * @memberof CartComponent
   */
  private getShippingRestrictionItemNo(restrictedProduct: ShippingOptionsResponse): string {
    let itemNumber = '';
    if (restrictedProduct && restrictedProduct.productModels
      && restrictedProduct.productModels.length > 1) {
      itemNumber = restrictedProduct.productModels[0].itemNumber;
    }
    return itemNumber;
  }

  /**
 * @description this method will prepare request
 * to get shipping options
 * @date 2018-07-21
 * @private
 * @returns {ShippingOptionsRequest}
 * @memberof CartComponent
 */
  private prepareShippingOptions(cartItems: Cart, promotionalProd?: Item): ShippingOptionsRequest {
    const shippingOptions: ShippingOptionsRequest = {
      productModels: this.getProductModels(cartItems.items, promotionalProd),
      orderSourceId: OrderSourceType.Web,
      languageCode: this.languageCode,
      orderTypeId: ShippingOrderType.Personal,
      fromAddress: this._configurationService.getWarehouseAddress(this.isoCountryCode),
      toAddress: this.shippingAddress,
      storeId: this.store.id,
      requestID: 2, // for now we are using two once config is done we will drive from enum
      memberTypeId: this.getShippingMemberType(),
      priceTypeId: this._activeSessionService.getPriceTypeId(),
      memberLevelId: this.getShippingMemberTitle(),
      orderSubTotal: this.autoshipCart.subTotal,
      orderCaseCredits: this.autoshipCart.totalPoints,
      purchaseFlowId: this._activeSessionService.getPurchaseFlowId(),
      shippingTypeId: ShippingType.DELIVERY,
      storeHomeCountryCode: this.isoCountryCode.toUpperCase()
    };
    return shippingOptions;
  }

  /**
 * @description Gets Member Title Required for Shipping Calculation
 * @private
 * @returns {number}
 * @memberof ShippingMethodsNewComponent
 */
  private getShippingMemberTitle(): number {
    return this._activeSessionService.getMemberTitleId() === MemberLevel.PREFERREDCUSTOMER
      ? ShippingMemberTitle.NOVUS : ShippingMemberTitle.ASSISTANTMANAGER;
  }

  /**
 * @description Gets Member Type Required for Shipping Calculation
 * @private
 * @returns {number}
 * @memberof CartComponent
 */
  private getShippingMemberType(): number {
    if (this._activeSessionService.getMemberTypeId() === MemberType.DISTRIBUTOR ||
      this._activeSessionService.getMemberTypeId() === MemberType.PREFERREDCUSTOMER) {
      return ShippingMemberType.DISTRIBUTOR;
    } else {
      return ShippingMemberType.RETAIL;
    }
  }

  /**
   * @description this method will map the products
   * @date 2019-01-17
   * @private
   * @param {Item[]} products
   * @param {Item} [promotionalProd]
   * @returns {ShippingProductModel[]}
   * @memberof CartComponent
   */
  private getProductModels(products: Item[], promotionalProd?: Item): ShippingProductModel[] {
    const productModels: ShippingProductModel[] = [];
    if (promotionalProd) {
      products = [];
      products.push(promotionalProd);
    }
    products.forEach((x: Item) => {
      const productModel: ShippingProductModel = {
        productID: x.id,
        productHeight: x.height,
        productWeight: x.weight,
        productQuantity: x.quantity,
        productLength: x.length,
        productWidth: x.width,
        wholesalePrice: x.wholesalePrice,
        sellingPrice: x.applicablePrice,
        isOrderLiteratureOnly: x.literature || false,
        retailPrice: x.retailPrice,
        weightMetricId: ProductWeightMetric.KGS,
        isShippable: x.shippingRequired,
        itemNumber: x.itemNumber
      };
      productModels.push(productModel);
    });
    return productModels;
  }

  /**
   * @description this method will get the restriced items nummbers list
   * @date 2019-01-17
   * @private
   * @param {ShippingOptionsResponse} restrictedProduct
   * @returns {Item[]}
   * @memberof CartComponent
   */
  private getRestrictedItemNumbers(restrictedProduct: ShippingOptionsResponse): Item[] {
    const itemNumbers: Item[] = [];
    restrictedProduct.productModels.forEach((x: any) => {
      itemNumbers.push(x);
    });
    return itemNumbers;
  }


  /**
   * @description prepare Autoship cart
   * @date 2018-09-07
   * @private
   * @param {Item} item
   * @param {CartTypes} cartType
   * @param {Cart} cart
   * @returns {Cart}
   * @memberof CartComponent
   */
  private prepareAutoshipCart(item: Item, cartType: CartTypes, cart: Cart, cartItemIndex: number): Cart {
    cart.cartTypeId = cartType;
    cart.purchaseFlowId = 1;
    if (item && cartItemIndex === -1) {
      cart.items.push(item);
    } else if (item && cartItemIndex >= 0) {
      cart.items.splice(cartItemIndex, 0, item);
    }
    return cart;
  }

  /**
  * setCurrentDate Method used to assign the current date
  * @param  {string} valueToSet
  * @returns void
  */
  setCurrentDate(): void {
    const date = new Date().toJSON().split('T')[0];
    this.autoshipDate = new Date(date);
  }
  //#endregion

  /**
   * To avoid MemoryLeaks need to unsubscribe.
   */
  ngOnDestroy() {
    if (this.cartSubscription) {
      this.cartSubscription.unsubscribe();
    }
    if (this.wishListSubscription) {
      this.wishListSubscription.unsubscribe();
    }
  }

  /**
   * Method to get store data
   */
  getStoreData() {
    const storeConfigResult: StoreConfig = this._configurationService.getStoreData();
    if (storeConfigResult) {
      this.store = storeConfigResult;
      this.storeId = storeConfigResult.id;
      if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
        && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()
        && !this.userInfo.wholesaleQualified) {
        const isHomeCountry = this._commonService.isHomeCountry();
        if (!this.isFPCOptInEligible && isHomeCountry) {
          this.getWholesaleQualified();
        }
      } else {
        this.getCartItems();
      }
      this.getCartItems();
    }
  }
  /**
    * set the minimun and maximun dates for Autoshop
    */
  getDates(): void {
    const currentDate = new Date();
    this.minDate = new Date();
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + (environment.autoShipMaxMonths);
    const day = environment.autoShipEndDay;
    this.maxDate = new Date(year, month, day);
  }
  /**
   * Enable the dates only in given Range
   */
  public myFilter = (d: any): boolean => {
    if (d) {
      const date = d._d.getDate();
      if (date >= environment.autoShipStartDay && date <= environment.autoShipEndDay) {
        return true;
      }
    }
  }
  /**
   * Validate AutoShip Profile Names
   */
  validateAutoShipProfileName(autoShipName: string): void {
    if (this.userInfo && this.userInfo.memberId) {
      this._cartService.validateAutoShipProfileName(this.userInfo.memberId).subscribe(response => {
        if (response && response[0].body && response[0].body.length > 0) {
          const autoShipProfiles: Autoship[] = response[0].body;
          if (autoShipProfiles && autoShipProfiles.length) {
            const existingAutoshipName = autoShipProfiles.find(x => x.name.toLowerCase() === autoShipName.toLowerCase());
            if (existingAutoshipName) {
              this.showAutoShipErrorMessage = true;
              this.errorAutoShipMessages = 'AutoShip Profile Name Already exists.';
            } else {
              this.removeAutoshipValidation();
            }
          } else {
            this.removeAutoshipValidation();
          }
        } else {
          this.removeAutoshipValidation();
        }
      }, error => {
        this.removeAutoshipValidation();
      });
    }
  }

  /**
   * to remove validation messages while clearing cart
   * @returns void
   */
  removeAutoshipValidation(): void {
    this.showAutoShipErrorMessage = false;
    this.errorAutoShipMessages = null;
  }

  /**
   *Clear Autoship Cart
   *
   * @memberof CartComponent
   */
  clearAutoshipCart() {
    const autoshipSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    if (autoshipSession && autoshipSession.items && autoshipSession.items.length > 0) {
      this._cartService.removeCart(autoshipSession.sessionGuid).subscribe(response => {
        this._cacheService.remove(CacheKey.AutoshipCart);
        window.location.href = environment.accountSiteURL + '/' + this.isoCountryCode + '/' + this.languageCode +
          '/account/my-profile';
      });
    }
  }

  /**
  * Confirmation poup to clear cart
  * @param  {any} event
  */
  clearCart(event: any) {
    this.removeItem = false;
    this.clearBag = true;
    this.showModalPopup(true);
  }

  /**
   * To remove all the items from cart
   * @param  {boolean} isConfirm
   */
  confirmToRemoveCart(isConfirm: boolean) {
    if (isConfirm) {
      let cartSessionInfo: Cart;
      if (this.userInfo && this.isAutoshipEnabled) {
        this.clearAutoshipCart();
        this._cacheService.removeCookieValue(CacheKey.CartSessionGuid);
      } else {
        cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
        const sessionGuid = cartSessionInfo.sessionGuid;
        this._cartService
          .removeCart(sessionGuid)
          .subscribe((response: boolean) => {
            if (response) {
              this._cacheService.remove(CacheKey.CartSessionInfo);
              this._cacheService.remove(CacheKey.hasCartItems);
              this._cacheService.setCookieValue(CacheKey.ClearCart, 'true');
              this._cacheService.removeCookieValue(CacheKey.CartSessionGuid);
              setTimeout(() => {
                this._cacheService.remove(CacheKey.CheckoutStep);
                const loadCartSession = {
                  sessionInfo: sessionGuid,
                  reloadMemberCart: false
                };
                this._appMessageService.setMiniCart(loadCartSession);
              }, 700);
              this.shoppingCart = new Cart(null, this.store);
              this.shoppingCart.itemsCount = 0;
              this.showModalPopup(false);
              this.navigateToProducts();
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      }
    }
    this.showModalPopup(false);
  }

  /**
   * @description this method will navigate to products page
   * @date 2019-03-05
   * @memberof CartComponent
   */
  navigateToProducts(): void {
    let selectedCategory: Categories;
    const categoriesTree: Categories[] = this._cacheService.get(CacheKey.CategoriesTree);
    if (categoriesTree && categoriesTree.length > 0) {
      selectedCategory = categoriesTree[0];
    }
    if (selectedCategory && selectedCategory.slug) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      this.router.navigate
        (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase()
          + '/' + selectedCategory.slug]);
    } else {
      this.router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/'
        + this.language.toLowerCase() + '/products');
    }
  }

  /**
   * @description Navigate to the Account portal
   * @date 2018-09-17
   * @memberof CartComponent
   */
  goToAccount(): void {
    const autoshipSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    this._cacheService.setCookieValue(CacheKey.AutoshipGuid, autoshipSessionInfo.sessionGuid);
    this._cacheService.remove(CacheKey.AutoshipCart);
    const accountUrl = environment.accountSiteURL + '/' + this.isoCountryCode.toLowerCase() + '/' +
      this.languageCode.toLowerCase() + '/account/autoship-preferences';
    window.location.href = accountUrl;
  }

  /**
     *Disable the datepicker year change selection
     *
     * @memberof AutoshipPreferenceComponent
     */
  datePickerOpen() {
    const yearSelectionButton = document.getElementsByClassName('owl-dt-control-period-button');
    if (yearSelectionButton) {
      yearSelectionButton[0].setAttribute('disabled', 'true');
    }
    if (this.isDateOffset) {
      this.datePickerConfig();
    }
  }

  /**
   * @description
   * @date 2019-02-21
   * @memberof CartComponent
   */
  datePickerConfig(): void {
    const datePickerElement = $('#datetimepicker6');
    const offset = datePickerElement.offset().top;
    const height = $(window).height();
    if (offset > (height / 2)) {
      $('.cdk-overlay-pane.owl-dt-popup').css({
        bottom: height - datePickerElement.offset().top,
        top: 'initial',
        left: datePickerElement.offset().left - 10
      });
    } else {
      $('.cdk-overlay-pane.owl-dt-popup').css({
        top: datePickerElement.offset().top - 52,
        bottom: 'initial',
        left: datePickerElement.offset().left - 10
      });
    }
  }

  /**
   *Enables the FPC To FBO Opt-in
   *
   * @memberof CartComponent
   */
  enableFPCToFBOOptIn() {
    if (this.userInfo && this.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER && this.userInfo.homeCountryCode
      && this.isoCountryCode && this.userInfo.homeCountryCode.toUpperCase() === this.isoCountryCode.toUpperCase()) {
      const IsFPCOptInEligibleCheck = this._cacheService.get(CacheKey.IsFPCOptInEligible);
      if (JSON.parse(IsFPCOptInEligibleCheck) || this.userInfo.wholesaleQualified) {
        this.isFPCOptInEligible = true;
      } else {
        this.isFPCOptInEligible = false;
      }
      const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
      if (cartSession && cartSession.items) {
        const isFBOEligibleAvailable = cartSession.items.filter(x => x.fboEligible);
        if ((isFBOEligibleAvailable && isFBOEligibleAvailable.length > 0) || this.userInfo.wholesaleQualified) {
          this.isFPCOptInEligible = true;
          this._cacheService.set(CacheKey.IsFPCOptInEligible, 'true');
        }
      }
      if (this.isFPCOptInEligible) {
        this.hideFpcOptinMessage = false;
        this.showOptInMessage = true;
        this.getCartItems();
      }
    }
  }

  /**
  *Navigates to Products page based on Configured Categories
  *
  * @memberof CartComponent
  */
  navigateToStarterPack(): void {
    this.router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/'
      + this.language.toLowerCase() + '/' + this.starterPackUrl);
  }
}
