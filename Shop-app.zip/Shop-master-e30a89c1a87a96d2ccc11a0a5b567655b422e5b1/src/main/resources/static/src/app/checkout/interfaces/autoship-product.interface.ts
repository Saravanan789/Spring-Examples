
export interface AutoshipProduct {
    id?: number;
    productId: number;
    quantity: number;
    createdBy: number;
    updatedBy?: number;
}
