export enum VideoSource {
    MediaCloud = 'MediaCloud',
    YouTube = 'YouTube',
    Vimeo = 'Vimeo',
}
