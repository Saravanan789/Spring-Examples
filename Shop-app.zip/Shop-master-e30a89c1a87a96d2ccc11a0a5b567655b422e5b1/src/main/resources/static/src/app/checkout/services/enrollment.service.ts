import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { VerifyAccountResponse, EnrollSession, EnrollInfo, PersonalInformation, CheckoutInformation, MemberContact } from '../interfaces';
import { Member } from '../../shared/interfaces';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Observable } from 'rxjs/Observable';
import { Address } from '../../common/interfaces';
import { EasterEggAddress } from '../constants';
import { CacheService } from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { environment } from '../../../environments/environment';
import { ContactTypeValue } from '../enums';

/**
 * @description this service used to
 * get account information and create user info
 * @date 2018-07-31
 * @export
 * @class EnrollService
 */
@Injectable()
export class EnrollService {

    constructor(
        private _http: Http,
        private _cacheService: CacheService
    ) { }

    /**
      * to get details by enroll guid
      * @param  {any} enrollGuid
      * @returns Observable
      */
    getEnrollSessionByGuid(enrollGuid: string): Observable<any[]> {
        return this._http
            .get(environment.apiUrl + '/order/enrollsession/' + enrollGuid)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * to validate new email
     * @param  {any} emailId
     * @returns Observable
     */
    verifyEmailAccountExists(emailId: string): Observable<any> {
        let encodedEmail = encodeURIComponent(emailId)
        let url = ApiUrlConstants.accountApiUrl + '/member-information?email=' + encodedEmail;
        if (environment.enableLongPoll) {
            url = url + '&isPoll=' + environment.enableLongPoll;
        }
        return this._http
            .get(url)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description to validate new GovernmentId
     * @date 2019-02-22
     * @param {string} governmentId
     * @param {string} countryCode
     * @param {number} storeId
     * @param {number} [memberId]
     * @returns {Observable<any>}
     * @memberof EnrollService
     */
    validateGovernmentId(governmentId: string, countryCode: string, storeId: number, memberId?: number)
        : Observable<any> {
        let _restUrl = ApiUrlConstants.accountApiUrl + '/members/check-unique-identification/?storeId=' + storeId
            + '&governmentId=' + governmentId + '&countryCode=' + countryCode;
        if (memberId) {
            _restUrl = _restUrl + '&memberId=' + memberId;
        }
        return this._http
            .get(_restUrl)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * This method used for verify phone number account exists or not
     * verifyPhoneNumberAccountExists
     * @param {string} phoneNumber
     * @returns {Observable<any>}
     * @memberof EnrollService
     */
    verifyPhoneNumberAccountExists(phoneNumber: string): Observable<any> {
        return this._http
            .get(ApiUrlConstants.accountApiUrl + '/member-exists?phone=' + phoneNumber)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
      * to validate new username
      * @param  {any} username
      * @returns Observable
      */
    validateRetailCustomerUsername(username: string): Observable<any> {
        return this._http
            .get(ApiUrlConstants.accountApiUrl + '/users/user-name-exists/' + username
                + '?userType=' + 6)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }


    /**
     * @description this method will update enrol user
     * session
     * @date 2018-07-31
     * @param {string} sessionGuid
     * @param {EnrollSession} sessionRequest
     * @returns {Observable<any[]>}
     * @memberof EnrollService
     */
    updateEnrollSession(sessionGuid: string, sessionRequest: EnrollSession): Observable<EnrollSession> {
        return this._http
            .put(ApiUrlConstants.orderApiUrl + '/enrollsession/' + sessionGuid, sessionRequest)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }


    /**
     * @description this method will save
     * user enroll session
     * @date 2018-07-31
     * @param {EnrollSession} sessionRequest
     * @returns {Observable<any>}
     * @memberof EnrollService
     */
    saveEnrollSession(sessionRequest: EnrollSession): Observable<EnrollSession> {
        return this._http
            .post(ApiUrlConstants.orderApiUrl + '/enrollsession', sessionRequest)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }


    /**
     * @description this method will use to enroll
     * memebr into system
     * @date 2018-07-31
     * @param {*} enrollRequest
     * @returns {Observable<any>}
     * @memberof EnrollService
     */
    createEnrollRequest(enrollRequest: EnrollInfo): Observable<EnrollInfo> {
        //const url = decodeURIComponent(encodeURIComponent(ApiUrlConstants.accountApiUrl + '/enrollment'));
        return this._http
            .post(decodeURIComponent(encodeURIComponent(ApiUrlConstants.accountApiUrl + '/enrollment')),
            decodeURIComponent(encodeURIComponent(JSON.stringify(enrollRequest))))
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this method will use to update
     * memebr into system
     * @date 2018-07-31
     * @param {*} enrollRequest
     * @param {number} memberId
     * @returns {Observable<any>}
     * @memberof EnrollService
     */
    updateEnrollment(enrollRequest: EnrollInfo, memberId: number): Observable<EnrollInfo> {
        return this._http
            .put(ApiUrlConstants.accountApiUrl + '/enrollment/members/' + memberId, JSON.stringify(enrollRequest))
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this method is used
     * to map the validated account response to user info  varible of
     * personalinfo settings
     * @date 2018-07-19
     * @private
     * @memberof PersonalInfoComponent
     */
    mapAccountResponseToUserInfo(verifyAccountResponse: VerifyAccountResponse): Member {
        const userInfo: Member = {
            distributorId: verifyAccountResponse.distributorId,
            email: verifyAccountResponse.email,
            firstName: verifyAccountResponse.firstName,
            fullName: verifyAccountResponse.fullName,
            homeCountryId: verifyAccountResponse.homeCountryId,
            lastName: verifyAccountResponse.lastName,
            memberAllowedCountries: verifyAccountResponse.memberAllowedCountries,
            memberId: verifyAccountResponse.memberId,
            memberTitle: verifyAccountResponse.memberTitle,
            memberTitleId: verifyAccountResponse.memberTitleId,
            memberType: verifyAccountResponse.memberType,
            memberTypeId: verifyAccountResponse.memberTypeId,
            middleName: verifyAccountResponse.middleName,
            phone: verifyAccountResponse.phone,
            profileImageURL: verifyAccountResponse.profileImageURL,
            sponsorId: verifyAccountResponse.sponsorId,
            userEntityId: verifyAccountResponse.userEntityId,
            userId: verifyAccountResponse.userId,
            userName: verifyAccountResponse.userName,
            userType: verifyAccountResponse.userType,
            wholesaleQualified: false,
            preferenceValue: verifyAccountResponse.preferenceValue,
            displayName: verifyAccountResponse.displayName
        };
        return userInfo;
    }

    /**
     * @description this method will provide autopopulate information
     * @date 2018-08-09
     * @param {string} isoCountryCode
     * @returns {PersonalInformation}
     * @memberof EnrollService
     */
    getAutoPopulateInformation(isoCountryCode: string): PersonalInformation {
        const emailGUID = this.createGUIDByDate();
        let populateAddress: Address;
        switch (isoCountryCode) {
            case 'usa': {
                populateAddress = EasterEggAddress.personalInfoUSAaddress;
                break;
            }
            case 'can': {
                populateAddress = EasterEggAddress.personalInfoCANaddress;
                break;
            }
            case 'gbr': {
                populateAddress = EasterEggAddress.personalInfoGBRaddress;
                break;
            }
            case 'bel': {
                populateAddress = EasterEggAddress.personalInfoBELaddress;
                break;
            }
            case 'nld': {
                populateAddress = EasterEggAddress.personalInfoNLDaddress;
                break;
            }
            case 'lux': {
                populateAddress = EasterEggAddress.personalInfoLUXaddress;
                break;
            }
            case 'bmu': {
                populateAddress = EasterEggAddress.personalInfoBMUaddress;
                break;
            }
            case 'bhs': {
                populateAddress = EasterEggAddress.personalInfoBHSaddress;
                break;
            }
            case 'bwi': {
                populateAddress = EasterEggAddress.personalInfoBWIaddress;
                break;
            }
            case 'cym': {
                populateAddress = EasterEggAddress.personalInfoCYMaddress;
                break;
            }
            case 'dom': {
                populateAddress = EasterEggAddress.personalInfoDOMaddress;
                break;
            }
            case 'hti': {
                populateAddress = EasterEggAddress.personalInfoHTIaddress;
                break;
            }
            case 'jam': {
                populateAddress = EasterEggAddress.personalInfoJAMaddress;
                break;
            }
            case 'tto': {
                populateAddress = EasterEggAddress.personalInfoTTOaddress;
                break;
            }
            case 'mhl': {
                populateAddress = EasterEggAddress.personalInfoMHLaddress;
                break;
            }
            case 'pyf': {
                populateAddress = EasterEggAddress.personalInfoPYFaddress;
                break;
            }
            case 'wsm': {
                populateAddress = EasterEggAddress.personalInfoWSMaddress;
                break;
            }
        }
        let currentTimeStamp = new Date().getTime() + '';
        if (currentTimeStamp && currentTimeStamp.length > 10) {
            currentTimeStamp = currentTimeStamp.substring(0, 10);
        }
        const personalInformation: PersonalInformation = {
            firstName: 'jhon' + emailGUID,
            middleName: 'Will',
            lastName: 'Kim' + emailGUID,
            email: 'jhon' + emailGUID + '@grr.la',
            sponserId: '',
            pass_word: 'Test@123',
            confirmPassword: 'Test@123',
            phoneNumber: currentTimeStamp,
            address: populateAddress,
            phoneType: ContactTypeValue.MOBILE
        };

        return personalInformation;
    }

    // Static member
    createGUIDByDate(): any {
        const date: any = new Date();
        const components: any = [
            date.getYear(),
            date.getMonth(),
            date.getDate(),
            date.getHours(),
            date.getMinutes(),
            date.getSeconds(),
        ];
        return components.join('');
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response) {
        return Observable.throw(error);
    }

    /**
     * this method used for rebind personal information from user information
     *
     * @memberof PersonalInfoComponent
     */
    getOptInPersonalInfo(memberContact?: MemberContact): PersonalInformation {
        const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const personalInformation: PersonalInformation = {
            firstName: userInfo.firstName,
            middleName: userInfo.middleName ? userInfo.middleName : '',
            lastName: userInfo.lastName,
            email: userInfo.email,
            sponserId: this.mapSponsorDetails(checkoutInformation, userInfo),
            phoneNumber: memberContact ? memberContact.value : userInfo.phone,
            pass_word: '',
            confirmPassword: '',
            address: this.mapAddressDetails(checkoutInformation),
            dateOfBirth: this.mapDateOfBirthDetails(checkoutInformation),
            governmentId: this.mapGovernmentIdDetails(checkoutInformation),
            phoneType: memberContact ? memberContact.contactTypeID : ContactTypeValue.MOBILE
        };
        return personalInformation;
    }

    /**
     * @description Map user Sponsor Details
     * @date 2019-02-26
     * @private
     * @param {CheckoutInformation} checkoutInformation
     * @param {Member} userInfo
     * @returns {string}
     * @memberof EnrollService
     */
    private mapSponsorDetails(checkoutInformation: CheckoutInformation, userInfo: Member): string {
        if (checkoutInformation && checkoutInformation.sponsorInformation
            && checkoutInformation.sponsorInformation.sponsorId) {
            return checkoutInformation.sponsorInformation.sponsorId;
        } else {
            return userInfo.sponsorId;
        }
    }

    /**
     * @description Map FPC Address Details
     * @date 2019-02-26
     * @private
     * @param {CheckoutInformation} checkoutInformation
     * @returns {Address}
     * @memberof EnrollService
     */
    private mapAddressDetails(checkoutInformation: CheckoutInformation): Address {
        if (checkoutInformation && checkoutInformation.personalInformation && checkoutInformation.personalInformation.address) {
            return checkoutInformation.personalInformation.address;
        } else {
            return null;
        }
    }

    /**
     * @description Map date of birth detials
     * @date 2019-02-26
     * @private
     * @param {CheckoutInformation} checkoutInformation
     * @returns {string}
     * @memberof EnrollService
     */
    private mapDateOfBirthDetails(checkoutInformation: CheckoutInformation): string {
        if (checkoutInformation && checkoutInformation.personalInformation && checkoutInformation.personalInformation.dateOfBirth) {
            return checkoutInformation.personalInformation.dateOfBirth;
        } else {
            return '';
        }
    }

    /**
     * @description map government Id Details
     * @date 2019-02-26
     * @private
     * @param {CheckoutInformation} checkoutInformation
     * @returns {string}
     * @memberof EnrollService
     */
    private mapGovernmentIdDetails(checkoutInformation: CheckoutInformation): string {
        if (checkoutInformation && checkoutInformation.personalInformation && checkoutInformation.personalInformation.governmentId) {
            return checkoutInformation.personalInformation.governmentId;
        } else {
            return '';
        }
    }
    /**
  * processPollRequest
  * @param  {Order} processPollRequest
  * @returns Observable
  */
    processPollRequest(requestUrl: string): Observable<any> {
        return (
            this._http
                .get(decodeURIComponent(encodeURIComponent(requestUrl)))
                .map((res: Response) => res.json())
                .catch(this.handleErrorObservable)
        );
    }
}
