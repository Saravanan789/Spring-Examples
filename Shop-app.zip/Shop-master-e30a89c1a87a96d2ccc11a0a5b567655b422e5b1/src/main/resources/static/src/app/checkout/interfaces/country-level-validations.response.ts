import { PersonalInfoFormFields } from './personal-info-form-fields.interface';

export interface CountryLevelValidations {
    countryCode: string;
    validations: PersonalInfoFormFields;
}
