import { TaxCart } from './tax-cart.interface';
import { ValidationDetail } from '../../payment/interfaces';

export interface TaxResponse {
    validations: ValidationDetail[];
    transactionID: number;
    cart: TaxCart;
    taxMetaData: any;
    success: any;
}
