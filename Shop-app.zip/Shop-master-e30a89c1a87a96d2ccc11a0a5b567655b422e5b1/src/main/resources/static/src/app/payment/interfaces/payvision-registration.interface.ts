import { PayvisionRegistrationRequest } from './payvision-registration-request.interface';
import { PaymentCallBackUrl } from './payment-callback-url.interface';

export interface PayvisionRegistration {
    countryCode: string;
    paymentMethodType: string;
    customerId: number;
    storeId: number;
    orderTypeId?: number;
    orderReferenceId?: number;
    paymentRequestModel: PayvisionRegistrationRequest;
    paymentCallBackUrlModel: PaymentCallBackUrl;
    currencyCode: string;
}
