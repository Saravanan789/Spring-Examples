import { Component, OnInit, Input, ElementRef, Renderer, ViewChild, HostListener, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CacheService } from '../../shared/services/cache.service';
import { SSO } from '../../sso/sso.constants';
import { CommonService } from '../../shared/services/common.service';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';

import { ProductDetailService } from '../services/product-detail.service';
import { Member } from '../../shared/interfaces/member.interface';
import { environment } from '../../../environments/environment';
import { ProductMessageService } from '../services/product-message.service';
import { AppMessageService } from '../../app-message.service';
import { Subscription } from 'rxjs/Subscription';
import { NotificationService } from '../../shared/services';
import { NotificationType } from '../../common/enums';
import { ProductReviewSuccessNotification } from '../enums';
import { TranslateService } from '@ngx-translate/core';
import { ProductReviewStatusCode } from '../enums/product-review-status.enum';
import { ReviewCount, ProductReview } from '../interfaces';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
@Component({
    selector: 'app-product-review',
    templateUrl:
        '../templates/template3/views/product-reviews.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/product-reviews.component.less'
    ]
})

export class ProductReviewComponent implements OnInit, OnDestroy {
    element: any;
    @Input() productItemNumber: number;
    @Input() overAllRating: number;
    @Output() productReviewCount = new EventEmitter<ReviewCount>();
    @ViewChild('fileInput') fileInput: ElementRef;
    showMore = false;
    reviewForm: FormGroup;
    showReviewForm = false;
    errorMessages: any = [];
    productReviews: ProductReview[] = [];
    reviewFormData: any;
    store: StoreConfig;
    storeId: number;
    reviewId: number = null;
    isSubmitted = false;
    userInfo: Member;
    fileData: any;
    memberTitleId: string;
    userTitle: string;
    purchaseFlow: any;
    reviewRequest: ProductReview;
    fileDetails: any = [];
    reviewCount = 2;
    isModalShown = false;
    selectedReview: any;
    s3BucketUrl = environment.cdnURL;
    isReviewReadonly = false;
    reviewSubscription: Subscription;
    enabledReviewbtn = false;
    @ViewChild('autoShownModal') autoShownModal: AppModalDirective;
    // @HostListener('document:keydown', ['$event'])
    // onKeydownEvent(event: KeyboardEvent): void {
    //     if (event.keyCode === 27) {
    //         this.isModalShown = false;
    //     }
    // }

    constructor(private _productDetailService: ProductDetailService,
        private _commonService: CommonService,
        private _cacheService: CacheService,
        private formBuilder: FormBuilder,
        public renderer: Renderer,
        private _configurationService: ConfigurationService,
        private _productMessageService: ProductMessageService,
        private _appMessageService: AppMessageService,
        private _notificationService: NotificationService,
        private _translateService: TranslateService,
        public elementRef: ElementRef) {
        this.getReviewFormSubject();
    }
    ngOnInit() {
        this.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.reviewForm = this.formBuilder.group({
            'description': ['', Validators.required],
            'title': ['', Validators.required],
            'rating': ['', Validators.required],
            // 'file': [{}]
        });
        this.getStoreData();
        this.getReviews();
        this.getUserInfo();
    }

    getStoreData() {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.store = result;
            this.storeId = this.store.id;
        }
    }

    /**
    * to get user information
    */
    getUserInfo() {
        if (this.userInfo) {
            this.memberTitleId = this._commonService.getMemberTitleByTiteId(this.userInfo);
            this.userTitle = this.userInfo.memberTitle;
            this.purchaseFlow = this._commonService.getPurchaseFlowType();
            this.getUserWriteReviewEligible();
        }
    }

    closeForm(): void {
        this.reviewId = 0;
        this.showReviewForm = false;
        this.reviewForm.reset();
        if (this.fileInput) {
            this.fileInput.nativeElement.value = '';
        }
    }

    /**
     * get review form subject subscription
     * @return void
     */
    getReviewFormSubject(): void {
        this.reviewSubscription = this._productMessageService.getWriteReviewSubject().subscribe((value) => {
            this.toggleReviewBlock(null, value);
        });
    }

    /**
     * to toggle write a review block
     * @param {Event} event
     * @param {boolean} forceShow
     */
    toggleReviewBlock(event?: Event, forceShow?: boolean) {
        this.isSubmitted = false;
        if (this.userInfo) {
            if (this.enabledReviewbtn) {
                this.showReviewForm = forceShow || !this.showReviewForm;
            }
            if (forceShow) {
                this._commonService.scrollTo('review', 1000);
            } else {
                setTimeout(() => {
                    this._commonService.scrollTo('review', 1000);
                    if (event) {
                        event.preventDefault();
                    }
                }, 500);
            }
        }
    }
    /**
     * review for anonymous
     */
    loginAnonymous() {
        this.isSubmitted = false;
        this.showReviewForm = !this.showReviewForm;
    }

    /**
     * to edit review block
     */
    editReviewBlock(review: any) {
        this.showReviewForm = true;
        this.reviewFormData = review;
        this.reviewId = review.id;
        if (review) {
            this.reviewForm.patchValue({
                description: this.reviewFormData.description,
                title: this.reviewFormData.title,
                rating: this.reviewFormData.rating,
                // file: this.reviewFormData.file
            });
        }
        setTimeout(function () {
            document.getElementById('form-name').focus();
        }, 500);
    }


    /**
     *to get all Reviews
     * @returns void
     */
    getReviews(): void {
        if (this.productItemNumber && this.store) {
            this._productDetailService
                .getReviews(this.productItemNumber, this.store.reviewRequiresApproval)
                .subscribe((response: ProductReview[]) => {
                    if (response && response.length > 0) {
                        this.productReviews = response;
                        this.emitProductReviewCount(response.length);
                        this.productReviews.forEach(item => {
                            item.ellipseValue = 85;
                        });
                        this.productReviews.length = response.length;
                    }
                });
        }
    }


    /**
     * @description thhis method will get the details of user is
     * eligible to write review or not
     * @date 2018-12-31
     * @memberof ProductReviewComponent
     */
    getUserWriteReviewEligible(): void {
        if (this.productItemNumber) {
            this._productDetailService
                .getUserWriteReviewEligible(this.userInfo.userId, this.productItemNumber)
                .subscribe((response: boolean) => {
                    this.enabledReviewbtn = false;
                    if (response) {
                        this.enabledReviewbtn = true;
                    }
                    if (this._cacheService.getCookieValue(CacheKey.WriteReview) === 'true') {
                        this._cacheService.removeCookieValue(CacheKey.WriteReview);
                        this.showReviewForm = false;
                        this.toggleReviewBlock();
                    }
                });
        }
    }

    /**
     * @description this method will emit product review info
     * of overall rating and reviewcount when user created new review
     * @date 2018-10-23
     * @private
     * @param {number} reviewCount
     * @memberof ProductReviewComponent
     */
    private emitProductReviewCount(reviewCount: number): void {
        const sumOfRatings = this.productReviews.map(x => x.rating)
            .reduce((sum, current) => sum + current, 0);
        let overAllRating = 0;
        if (sumOfRatings) {
            overAllRating = sumOfRatings / reviewCount;
        }
        this.productReviewCount.emit({ reviewCount: reviewCount, overAllRating: overAllRating });
    }

    /**
     * get file details of review
     * @returns void
     */
    getFileData(): void {
        if (this.fileInput && this.fileInput.nativeElement
            && this.fileInput.nativeElement.files && this.fileInput.nativeElement.files[0]) {
            const inputFiles: any = this.fileInput.nativeElement.files;
            this.convertImageFileToBase64AndUploadImage(inputFiles);
        } else {
            const reviewRequest = this.prepareReviewRequest(this.reviewFormData);
            this.saveProductReview(reviewRequest);
        }
    }

    /**
     * @returns void
     */
    login(): void {
        window.location.href = SSO.getSSOLoginUrl(false);
    }

    /**
     * convert images to Base 64
     * @param  {any} files
     */
    convertImageFileToBase64AndUploadImage(files: any): void {
        let counter = -1;
        let filesLenghtCount = files.length;
        const requestArray: any[] = [];
        let isReadyToSubmit = false;
        while (filesLenghtCount > 0) {
            const file = files[++counter];
            const reader: FileReader = new FileReader();
            reader.onloadend = (e) => {
                if (reader.result) {
                    const object = {};
                    object['content'] = reader.result;
                    object['fileName'] = file.name.split('.')[0];
                    object['extension'] = '.' + file.name.split('.')[1];
                    requestArray.push(object);
                    this.fileDetails = requestArray;
                    const reviewRequest = this.prepareReviewRequest(this.reviewFormData);
                    if (isReadyToSubmit) {
                        this.saveProductReview(reviewRequest);
                    }
                }
            };
            reader.readAsDataURL(file);
            filesLenghtCount = filesLenghtCount - 1;
            if (filesLenghtCount === 0) {
                isReadyToSubmit = true;
            }
        }
    }

    /**
     * save review of product
     * @param  {Productreview} reviewRequest
     * @returns void
     */
    private saveProductReview(reviewRequest: ProductReview): void {
        this._productDetailService.saveReview(reviewRequest).subscribe((response: any) => {
            if (response) {
                this.enabledReviewbtn = false;
                this.showSuccesNotification();
                this.closeForm();
                this.getReviews();
            }
        }, error => (this.errorMessages = <any>error));
    }


    /**
     * This method used for show success notification after posting review
     * showSuccesNotification
     * @memberof ProductReviewComponent
     */
    showSuccesNotification(): void {
        if (this.store && !this.store.reviewRequiresApproval) {
            this._notificationService.createNotification('',
                this._translateService.get('productreviews.' + ProductReviewSuccessNotification.ReviewAfterApproval)['value'],
                NotificationType.SUCCESS);
        } else if (this.store && this.store.reviewRequiresApproval) {
            this._notificationService.createNotification('',
                this._translateService.get('productreviews.' + ProductReviewSuccessNotification.ReviewBeforeApproval)['value'],
                NotificationType.SUCCESS);
        }
    }

    /**
     * @param  {any} reviewFormData
     */
    saveReview(reviewFormData: any, isValid: boolean) {
        this.isSubmitted = true;
        if (this.isSubmitted && isValid) {
            this.showReviewForm = false;
            this.reviewFormData = reviewFormData;
            this.getFileData();
        }
    }
    /**
     * @param  {any} reviewFormData
     */
    prepareReviewRequest(reviewFormData: any): ProductReview {
        const languageCode: string = this._cacheService.get(CacheKey.DefaultLanguage);
        this.reviewRequest = {
            storeId: this.storeId,
            id: this.reviewId,
            productID: this.productItemNumber,
            languageCode: languageCode,
            reviewBy: this.userInfo ? this.userInfo.userId : null,
            reviewUserName: this.userInfo ? this.userInfo.firstName : 'Anonymous',
            title: reviewFormData.title,
            description: reviewFormData.description,
            rating: reviewFormData.rating,
            statusCode: this.store.reviewRequiresApproval ?
                ProductReviewStatusCode.Submitted : ProductReviewStatusCode.Approved,
            images: this.fileDetails
            // content: this.fileDetails.content,
            // fileName: this.fileDetails.fileName,
            // extension: '.'+this.fileDetails.extension
        };
        return this.reviewRequest;
    }

    showMoreReviews() {
        this.showMore = !this.showMore;
    }

    /** resize the review block section height
     * {param} index
    */
    resizeReviewBlock(index: number) {
        const reviewBlckEl = <HTMLElement>document.getElementById('review-block' + index);
        if (reviewBlckEl) {
            const prodEllipsisVal = this.productReviews[index].ellipseValue;
            const descEl = <HTMLElement>reviewBlckEl.querySelector('#review-block-description' + index);
            if (prodEllipsisVal === 85) {
                reviewBlckEl.style.height = 'auto';
                descEl.style.height = 'auto';
                this.productReviews[index].ellipseValue = this.productReviews[index].description.length + 2;
                reviewBlckEl.style.paddingBottom = '2.3rem !important';
            } else {
                reviewBlckEl.style.height = '350px';
                descEl.style.height = '75px';
                this.productReviews[index].ellipseValue = 85;
                reviewBlckEl.style.paddingBottom = '1.5rem !important';
            }
        }
    }

    /** product review modal popup on large screen
     * {param} index
     */
    showReviewModal(index: number) {
        // this.isModalShown = true;
        this.autoShownModal.show();
        this.selectedReview = this.productReviews[index];
    }

    /**keydown event call
     * @param  {Event} event
     * @returns void
     */
    keyDownEvent(event: Event, index?: number): void {
        if (event.srcElement.id === 'averageRating') {
            document.getElementById('productreviewicon').focus();
            event.preventDefault();
        }
        if (event.srcElement.id === 'productreviewicon') {
            document.getElementById('averageRating').focus();
            event.preventDefault();
        }
        if (event.srcElement.id === 'customerRating' + index) {
            const userDetailId = 'userDetail' + index;
            document.getElementById(userDetailId).focus();
            event.preventDefault();
        }
        if (event.srcElement.id === 'userDetail' + index) {
            const customerRatingId = 'customerRating' + index;
            document.getElementById(customerRatingId).focus();
            event.preventDefault();
        }
    }

    /**To select review using keyboard
     * @param  {KeyboardEvent} event
     * @returns void
     */
    confirmSelection(event: KeyboardEvent): void {
        if (event.keyCode === 13) {
            this.isReviewReadonly = true;
        }
    }

    /**
     * redirect to sso login url
     * @param  {boolean} isLogin
     * @returns void
     */
    gotoLogin(isLogin: boolean): void {
        this._productMessageService.setWriteReviewSubject(true);
        this._appMessageService.setNotifyLoginStatus(isLogin);
        this._cacheService.setCookieValue(CacheKey.WriteReview, 'true');
    }

    ngOnDestroy(): void {
        if (this.reviewSubscription) {
            this.reviewSubscription.unsubscribe();
        }
    }
}
