export interface OrderShipping {
  id?: number;
  orderId?: number;
  deliveryPreferenceId: number;
  shipMethodId: number;
  shippingAddressId?: number;
  billingAddressId?: number;
  preferredTime?: string;
  notes?: string;
  shipmentDate?: string;
  shortCode: string;
  distributionCenter?: string;
}
