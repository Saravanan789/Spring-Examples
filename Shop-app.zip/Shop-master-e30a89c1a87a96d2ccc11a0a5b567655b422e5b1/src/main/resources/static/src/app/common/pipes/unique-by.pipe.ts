import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';
import 'intl';
import 'intl/locale-data/jsonp/en.js';

@Pipe({
  name: 'uniqueBy'
})

export class UniqueByPipe implements PipeTransform {
  transform(array: Array<any>, args?: any): any {
    return _.uniqBy(array, args);
  }
}
