export enum RowStatus {
    Active = 1,
    Inactive = 2
}
