import { AutoshipStatus } from '../enums/autoship-status.enum';
import { AutoshipProduct } from './autoship-product.interface';
import { AutoshipShippingInformation } from './autoship-shipping-information.interface';
import { AutoshipPayment } from './autoship-payment.interface';
import { AutoshipFrequency } from '../enums/autoship-frequency';

export interface Autoship {
    id?: number;
    autoshipStatusId: AutoshipStatus;
    name: string;
    emailId: string;
    memberId: number;
    countryId: number;
    storeId: number;
    frequencyTypeId: AutoshipFrequency;
    nextAutoshipRunDate?: Date;
    rowStateId?: number;
    startDate: string;
    createdBy: number;
    updatedBy?: number;
    autoshipProducts: AutoshipProduct[];
    autoshipShippingInformations?: AutoshipShippingInformation[];
    autoshipPayments?: AutoshipPayment[];
    autoShipDisplayDate?: string;

}
