export interface PayvisionRequestModel {
    webOrderId: string;
    tokenRegister: boolean;
    createRegistartion: boolean;
}
