import { OrderResponse } from './order-response.interface';

export interface OrderQueuedResponse {
    uuid: string;
    request: any;
    response: any;
    createdDate: string;
    status: string;
    location: string;
    responseModel: OrderResponse;
    validations: any;
}
