import { Directive, ElementRef, Renderer2, ViewContainerRef, ComponentFactoryResolver, OnDestroy } from '@angular/core';
import { ModalDirective, ComponentLoaderFactory } from 'ngx-bootstrap';
import { CommonService } from '../../shared/services';
@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[bsModal]',
    exportAs: 'app-modal'
})
export class AppModalDirective  extends ModalDirective implements OnDestroy {
    parentObject: any;
    constructor(_element: ElementRef,
        _viewContainerRef: ViewContainerRef,
        _renderer: Renderer2,
        _clf: ComponentLoaderFactory,
        private _commonService: CommonService) {
        super(_element, _viewContainerRef, _renderer, _clf);
        this.parentObject = new ModalDirective(_element, _viewContainerRef, _renderer, _clf);
    }
    /**
     * @override overrided the parentClass method
     * to manage the flickering while showing the popup
     * @memberof AppModalDirective
     */
    hideModal(): void {
        if (this.parentObject) {
            this.parentObject.hideModal();
        }
        this._commonService.jumpingScroll(false);
    }
    /**
     * @override overrided the parentClass method
     * @memberof AppModalDirective
     */
    show(): void {
        this._commonService.jumpingScroll(true);
        super.show();
    }
}
