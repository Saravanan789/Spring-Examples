import { AddressResponse } from './address-response.interface';
export interface Address {
    id?: number;
    memberId?: number;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    addressLine1: string;
    addressLine2: string;
    addressLine3?: string;
    addressLine4?: string;
    street?: string;
    shipMethodType?: string;
    houseNumber?: string;
    city: string;
    stateCode?: string;
    stateId?: number;
    state: string;
    country: string;
    countryCode?: string;
    county?: string;
    postalCode?: string;
    zip?: string;
    countryId?: number;
    phone?: string;
    addressVerified?: boolean;
    validAddress?: boolean;
    isSavedAddress?: boolean;
    addressType?: number;
    defaultAddress?: boolean;
    responseCodes?: AddressResponse[];
    memberAddressDetailId?: number;
    addressTypeId?: number;
    loggedInUserId?: number;
    name?: string;
    residential?: boolean;
    countryCodeTwo?: string;
    stateOrProvinceId?: number;
    zipCode?: string;
    shipToName?: string;
    contactTypeID?: number;
    latitude?: string;
    longitude?: string;
    value?: string;
    phoneNumber?: string;
    saveForFutureUse?: boolean;

    validations?: any[];
    sameAsSuggestedAddress?: boolean;
    company?: string;
    errorCodes?: VerifyAddressErrorCode[];
    formattedAddress?: string;
    organization?: string;
    countryFullName?: string;
    phoneType?: number;
    isInvalidAddress?: boolean;
}


export interface VerifyAddressErrorCode {
    errorCode: string;
    propertyName: string;
    validationMessage: string;
    messageType: string;
    messageRequired: boolean;
}
