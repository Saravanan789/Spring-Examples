import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {
    Router,
    RouterStateSnapshot,
    ActivatedRouteSnapshot
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { TaxResponse } from '../interfaces/tax-response.interface';
import { TaxRequest } from '../interfaces/tax-request.interface';

@Injectable()
export class OrderTaxService {
    constructor(
        private _http: Http
    ) { }

    /**
     * create order
     * @param  {Order} paymentRequest
     * @returns Observable
     */
    calculateOrderTax(taxRequest: TaxRequest): Observable<TaxResponse> {
        return this._http
       .post(ApiUrlConstants.taxApiUrl + '/api/calculate-tax', JSON.stringify(taxRequest))
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }


     /**
     * create order
     * @param  {Order} paymentRequest
     * @returns Observable
     */
    createOrderTaxTransaction(orderTaxTansactionRequest: any): Observable<any> {
        return this._http
            .post(ApiUrlConstants.taxApiUrl + '/api/tax/ordertransaction', JSON.stringify(orderTaxTansactionRequest))
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error.message || error);
    }
}
