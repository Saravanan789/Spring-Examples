export enum OrderStatus {
    Pending = 1,
    Canceled = 2,
    Accepted = 3,
    Shipped = 4
}
