export interface Card {
    cardContent: string;
    imageUrl: string;
    resolution: string;
    type: string;
    sortOrder: number;
 }
