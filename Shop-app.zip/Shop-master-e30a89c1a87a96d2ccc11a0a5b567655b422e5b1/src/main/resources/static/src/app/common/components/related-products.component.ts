import { TranslateService } from '@ngx-translate/core';
import { QuickviewComponent } from '../../products/components/quickview.component';
import { ProductService } from '../../products/services/product.service';
import { Product } from '../../products/interfaces/product.interface';
import { Item } from '../../shared/models/item.model';
import { Cart } from '../../shared/models/cart.model';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { UserTitleType } from '../../shared/enums/user-title-type.enum';
import { CommonService } from '../../shared/services/common.service';
import { CartService } from '../../shared/services/cart.service';
import { Component, Input, OnInit } from '@angular/core';
import { CacheService } from '../../shared/services/cache.service';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { StoreConfig, StorePurchaseFlow } from '../../shared/interfaces/StoreConfig.interface';
import { ImageType } from '../../products/enums/image-type.enum';
import * as _ from 'lodash';
import { AppMessageService } from '../../app-message.service';
import { Member } from '../../shared/interfaces/member.interface';
import { NotificationService } from '../../shared/services/notification.service';
import { NotificationType } from '../enums/notification-type.enum';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductType } from '../../products/enums/product-types.enum';
import { MemberLevel } from '../../shared/enums';
import { ActiveSessionService } from '../../shared/services';
import { CookieBannerType } from '../../shared/enums/cookie-banner-type';
import { CookieBannerResponse } from '../../shared/interfaces/cookie-banner-reponse';
import { TranslateParam } from '../interfaces';
@Component({
  selector: 'app-related-products',
  templateUrl: '../templates/template3/views/related-products.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/related-products.component.less'
  ]
})

export class RelatedProductsComponent implements OnInit {
  isPersonalPurchaseFlow = false;
  personalPurchaseFlow: string;
  purchaseFlows: StorePurchaseFlow[] = [];
  store: StoreConfig;
  relatedProducts: Product[] = [];
  errorMessages: any = [];
  selectedCurrency = 'USD';
  languageCode: string;
  storeId: number;
  imageTypes: any = ImageType;
  productType = ProductType;
  userLoggedIn: Member;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  isoCountryCode: string;
  disableDecrement: boolean;
  isAutoshipEnabled: boolean;
  bsModalRef: BsModalRef;
  isEnableWishList: boolean;
  public relatedSliderConfig: SwiperConfigInterface = {
    slidesPerView: 3,
    touchRatio: 0.2,
    navigation: true,
    breakpoints: {
      1200: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      930: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      640: {
        slidesPerView: 1,
        spaceBetween: 10
      }
    }
  };

  @Input() productId: number;
  @Input() hideQuantity = false;
  translateParams: TranslateParam;

  constructor(
    private _cacheService: CacheService,
    private productService: ProductService,
    private _cartService: CartService,
    private _router: Router,
    private _commonService: CommonService,
    private modalService: BsModalService,
    private _configurationService: ConfigurationService,
    private _translatePipe: TranslateService,
    private _appMessageService: AppMessageService,
    private _notificationService: NotificationService,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    this.personalPurchaseFlow = this.isAutoshipEnabled ? PurchaseFlow.AUTOSHIP : PurchaseFlow.PERSONAL;
    this.getStoreData();
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.getProductGroupConfig();
  }

  /**
   * @description to display releated products
   * @param  {number} productId
   * @param  {number} storeid
   */
  getRelatedProducts(storeId: number, productId: number, groupId: number) {
    if (storeId && productId) {
      this.productService
        .getRelatedProducts(storeId, productId, this.languageCode, groupId)
        .subscribe(response => {
          if (response) {
            this.relatedProducts = response;
            this.relatedProducts.forEach(x => {
              if (!(x.backOrderAllowed || (x.manageStock && x.stockQuantity > 0))) {
                x.productQuantity = 0;
              } else {
                x.productQuantity = 1;
              }
              x.disableDecrement = x.disableDecrement || true;
              x.commissionableVolume = !x.literature ? x.commissionableVolume : 0;
            });
            setTimeout(() => {
              this.loadWishListProducts();
            }, 1000);
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }


  // TO:DO For Demo We are Adding we need to integrate from store
  private getProductGroupConfig() {
    this._commonService.getProductGroupConfig().subscribe((response: any[]) => {
      if (response) {
        const groupConfig: any = response;
        if (groupConfig) {
          this.getRelatedProducts(this.storeId, this.productId, groupConfig.YouMayAlsoLike);
        }
      }
    });
  }

  /**
  * @description Show Modal popup
  * @param product
  */
  showModalPopup(product: Product) {
    const initialState = {
      productDetails: product
    };
    this.bsModalRef = this.modalService.show(QuickviewComponent, { class: 'modal-lg modal-dialog-centered', initialState });
    this.bsModalRef.content.product = product;
  }

  /**
  * @description To add an item
  * @param  {Product} product
  */
  addToWishList(product: Product): void {
    // TODO amruth - need to move text to s3 and translate
    if (!this.userLoggedIn) {
      // commenting code due to showing pop-over . No need for cookie banner
      // const cookieBannerData = {
      //   title: null,
      //   timeout: false,
      //   time: 2000,
      //   description: 'Please login or create an account in your first purchase to add products to your Favorites',
      //   notificationType: CookieBannerType.CartItemNotification
      // };
      // this._appMessageService.setCookieBannerData(cookieBannerData);
      return;
    }
    if (this.userLoggedIn && product.options && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('quickview.Item added to Favorites');
      const itemDeletedNotification: any = this._translatePipe.get('quickview.Item removed from Favorites');
      product.wishListItem = !product.wishListItem ? true : false;
      product.productQuantity = 1;
      const item: Item = this._cartService.convertProductToItemMappper(product);
      let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
      if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length >= 0 && wishListCart.sessionGuid) {
        const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .updateCart([item], CartTypes.WishlistCart, wishListCart)
          .subscribe((response: Cart) => {
            if (response) {
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      } else if (product.wishListItem) {
        this._cartService
          .saveCart([item], CartTypes.WishlistCart)
          .subscribe((response: Cart) => {
            if (response) {
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      } else if (!product.wishListItem) {
        const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .removeCartItem(wishListCart.sessionGuid, cartItem.id)
          .subscribe(response => {
            wishListCart = new Cart(wishListCart, this.store);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      }
    }
  }

  /**
   * @description navigate to product detail
   * @param  {Product} product
   * @returns void
   */
  navigateToProductDetail(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = this._commonService.getCategoryFromProduct(product);
    }
    if (product.customCatalogName && !selectedCategory.categoryName) {
      selectedCategory = {
        productCategoryId: product.customCatalogId,
        categoryName: product.customCatalogName,
      };
    }
    if (selectedCategory) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      if (selectedCategory.slug) {
        this._router.navigate([this.isoCountryCode.toLowerCase() +
          '/' + this.languageCode.toLowerCase() + '/products/' + selectedCategory.slug + '/' + product.slug]);
      } else {
        this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + product.slug]);
      }
    } else {
      this._router.navigate([this.isoCountryCode + '/' + this.languageCode + '/products/' + product.slug]);
    }
  }

  /**
   * @description set selected actegory
   * @param {*} selectedCategory
   * @memberof RelatedProductsComponent
   */
  setSelectedCategory(selectedCategory: any) {
    this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
  }

  /**
   * @description increment the product quantity
   * @param {*} prod
   * @memberof RelatedProductsComponent
   */
  incrementQuantity(prod): void {
    prod.productQuantity = ++prod.productQuantity;
    prod.disableDecrement = false;
    if (prod.productQuantity > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      this.outofStockNotification(prod);
    }
  }

  /**
   * @description decrement the product quantity
   * @param {*} prod
   * @memberof RelatedProductsComponent
   */
  decrementQuantity(prod): void {
    if (prod.productQuantity > 1) {
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
    }
    if (prod.productQuantity === 1) {
      prod.disableDecrement = true;
    }
  }

  /**
   * @description Update product quantity
   * @param {(Product | any)} prod
   * @memberof RelatedProductsComponent
   */
  updateQuantity(prod: Product | any) {
    const qty = parseInt(prod.productQuantity, 10);
    if (qty > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = prod.stockQuantity;
      this.outofStockNotification(prod);
    } else {
      prod.productQuantity = qty || null;
    }
    prod.disableDecrement = prod.productQuantity > 1 ? false : true;
  }

  /**
   * @description to how out of stock notification
   * @param {Product} product
   * @memberof RelatedProductsComponent
   */
  outofStockNotification(product: Product) {
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">'
      + product.stockQuantity + '</span>', NotificationType.ERROR);
  }

  /**
   * @description load wishlist items
   * @memberof RelatedProductsComponent
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      this.relatedProducts.forEach(x => {
        x.productQuantity = x.productQuantity ? x.productQuantity : 1;
        wishListCart.items.forEach(y => {
          if (y.productId === x.id) {
            x.wishListItem = true;
          }
        });
      });
    }
  }

  /**
   * @description get store data
   * @memberof RelatedProductsComponent
   */
  getStoreData(): void {
    const storeConfig: StoreConfig = this._configurationService.getStoreData();
    if (storeConfig) {
      this.store = storeConfig;
      this.storeId = this.store.id;
      this.purchaseFlows = storeConfig.purchaseFlows;
      this.isEnableWishList = this.store.enableWishlist;
      this.hasPurchaseFlow();
    }
  }

  /**
   * @memberof RelatedProductsComponent
   */
  hasPurchaseFlow(): void {
    if (this.purchaseFlows && this.purchaseFlows.length > 0 && (this.store.purchaseFlows !== null && this.store.purchaseFlows.length > 0)) {
      this.purchaseFlows.forEach(flow => {
        this.store.purchaseFlows.forEach((storeFlow: StorePurchaseFlow) => {
          if (flow.id === storeFlow.id && flow.name === this.personalPurchaseFlow) {
            this.isPersonalPurchaseFlow = true;
          }
        });
      });
    }
  }


  /**
   * @description show cart / Product detail based on variant.
   * @param {*} product
   * @param {number} cartType
   * @memberof RelatedProductsComponent
   */
  addToCart(product: Product, cartType: number): void {
    if (product && product.options.length === 0) {
      if (!product.addingToCart) {
        this.getShippingRestrictedProducts(product.itemNumber);
        this.manageShoppingCart(product, cartType);
      }
    } else if (product.productTypeMasterId === ProductType.Variable && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      this._router.navigate(['/', this.isoCountryCode.toLowerCase(), this.languageCode.toLowerCase(), 'products', product.slug]);
    }
  }

  /**
   * @description verifying whether the product is shippable to the selected shipping address or not
   * @param {string} itemNumber
   * @returns {*}
   * @memberof RelatedProductsComponent
   */
  getShippingRestrictedProducts(itemNumber: string): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (userDefaultAddressDetails) {
      const getShippingRestrictedProductsData = this._commonService.getShippingRestrictedProducts(itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            this._notificationService.createNotification('', response.productModels[0].errorDescription, NotificationType.ERROR);
          }
        });
    }
  }

  /**
* redirect to sso login url
* @param  {boolean} isLogin
* @returns void
*/
  gotoLogin(isLogin: boolean, product: Product): void {
    this._cacheService.set(CacheKey.WishListProduct, product);
    this._cacheService.set(CacheKey.RedirectToFavourites, true);
    this._appMessageService.setNotifyLoginStatus(isLogin);
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(product: Product, cartType: CartTypes) {
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      this._notificationService.createNotification('', 'Item added To Autoship bag', NotificationType.SUCCESS);
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('Item added to cart');
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    const item: Item = this._cartService.convertProductToItemMappper(product, cartSessionInfo);
    if (cartSessionInfo) {
      const cartItem = cartSessionInfo.items.filter(x => x.productId === item.productId)[0];
      if (cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > product.stockQuantity && product.manageStock && !product.backOrderAllowed) {
          product.errorMessage = true;
          setTimeout(() => {
            product.errorMessage = false;
          }, 2000);
          item.quantity = cartItem.quantity;
          const cartStockErrorForItem: any = this._translatePipe.get('stockError.No Stock Available for Item Number');
          this.outofStockNotification(product);
          return;
        }
      }
    }
    product.addingToCart = true;
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      product.addingToCart = false;
      this._appMessageService.setMiniCart(cartSession);
      this._appMessageService.showMiniCartView(product.id);
      this._commonService.focusTargetElement('minicart-shop-msg');
    } else if (cartSessionInfo) {
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }

  /**
 * @description Add Items to Autoship
 * @param product
 */
  addToAutoship(product) {
    this._notificationService.createNotification('', 'Item added To Autoship bag', NotificationType.SUCCESS);
    if (product.productQuantity > 0) {
      const item: Item = this._cartService.convertProductToItemMappper(product);
      let autoshipCart: Cart = this._cacheService.get(CacheKey.AutoshipCart);
      if (autoshipCart && autoshipCart.items && autoshipCart.items.length > 0) {
        const cartItem: Item = autoshipCart.items.find(x => x.productId === product.id);
        if (cartItem) {
          item.quantity = cartItem.quantity + item.quantity;
        }
        const mergeCartSession: Cart = JSON.parse(JSON.stringify(autoshipCart));
        autoshipCart.items = _.remove(autoshipCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .updateCart([item], CartTypes.AutoshipCart, autoshipCart)
          .subscribe((response: Cart) => {
            if (response) {
              autoshipCart = this._cartService.mergeCartSession(item, response, mergeCartSession);
              this._cacheService.set(CacheKey.AutoshipCart, autoshipCart);
            }
          });
      } else {
        this._cartService
          .saveCart([item], CartTypes.AutoshipCart)
          .subscribe((response: Cart) => {
            if (response) {
              autoshipCart = this._cartService.mergeCartSession(item, response, autoshipCart);
              this._cacheService.set(CacheKey.AutoshipCart, autoshipCart);
            }
          });
      }
    }
  }
}
