export enum SponsorWizardSearchType {
    SearchByFBOID = 'SearchByFBOID',
    SearchByFBOName = 'SearchByFBOName',
    SearchBySuggestSponsor = 'SearchBySuggestSponsor',
    SocialMedia = 'SocialMedia',
    WebSearch = 'WebSearch',
    Other = 'Other',
    SearchByWithoutSponsor = 'SearchByWithoutSponsor',
    SearchByWithSponsor = 'SearchByWithSponsor',
    SearchByIKnowSponsor = 'SearchByIKnowSponsor',
    SearchByIDontHaveSponsor = 'SearchByIDontHaveSponsor'
}
