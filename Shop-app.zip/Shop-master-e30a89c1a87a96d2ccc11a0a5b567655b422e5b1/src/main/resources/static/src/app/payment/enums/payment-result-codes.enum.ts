export enum PaymentResultCodes {
    SECURE = '^(800\.400\.2|100\.380\.4|100\.390)',
    RISKCHECK = '^(000\.400\.[1][0-9][1-9]|000\.400\.2)',
    EXTERNALBANK = '^(800\.[17]00|800\.800\.[123])',
    COMMUNICATION = '^(900\.[1234]00|000\.400\.030)'
}