import { SponsorSearchOption } from '../enums';

export interface SponsorSearchRequest {
    UserName: string;
    Email: string;
    FirstName: string;
    LastName: string;
    CountryId: string;
    PreferenceValue: string;
    PostalCode: string;
    Option: SponsorSearchOption;
    StateId: string;
    City: string;
    CountryCode?: string;
    AddressLine1?: string;
    EnableLongPoll: boolean;
}
