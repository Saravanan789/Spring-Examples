import { PayvisionBillingAddress, PayvisionMandatoryBillingAddressFields } from './payvision-billingaddress.interface';

export interface PayvisionBillingOptions {
    billingAddress: PayvisionBillingAddress;
    mandatoryBillingFields: PayvisionMandatoryBillingAddressFields;
}
