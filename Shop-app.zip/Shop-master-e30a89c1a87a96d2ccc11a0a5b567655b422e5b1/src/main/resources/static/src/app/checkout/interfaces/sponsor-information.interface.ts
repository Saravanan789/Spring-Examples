import { Address } from '../../common/interfaces';
import { MemberCommunicationPreference } from './member-communication-preference.interface';

export interface SponsorInformation {
    sponsorId: string;
    sponsorName: string;
    sponsorFirstName: string;
    sponsorLastName: string;
    sponsorMiddleName: string;
    sponsorEmail: string;
    sponsorLanguageId: number;
    sponsorLanguageCode: string;
    sponsorAddressLine1: string;
    sponsorAddressLine2: string;
    sponsorCity: string;
    sponsorStateCode: string;
    sponsorStateId: number;
    sponsorPostalCode: string;
    sponsorCountryId: number;
    sponsorCountryCode: string;
    wholesaleQualified: boolean;
    sponsorPhone: string;
    sponsorEnrolledDate: string;
    address: Address;
    memberMetadataModels: any[];
    responseMessage?: string;
    sponsorAssignedOptionId: number;
    memberCommunicationPreferences?: MemberCommunicationPreference;
    notifyMeAboutUpdates?: boolean;
}
