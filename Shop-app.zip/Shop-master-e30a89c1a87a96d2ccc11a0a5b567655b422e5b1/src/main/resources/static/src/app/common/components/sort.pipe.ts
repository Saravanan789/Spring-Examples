import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  /**
   * sort an list of elements based On given Sortby option
   * @param  {any} items
   * @param  {any} sortBy
   * @returns any
   */
  transform(items: any, sortBy: any): any {
    if (sortBy && items && Array.isArray(items) && items.length > 0) {
      return items.sort(function (ele1, elem2) { return ele1[sortBy] - elem2[sortBy]; });
    } else {
      return items;
    }
  }

}

