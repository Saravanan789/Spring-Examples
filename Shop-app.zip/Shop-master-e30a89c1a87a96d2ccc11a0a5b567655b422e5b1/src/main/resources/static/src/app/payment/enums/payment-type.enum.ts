export enum PaymentType {
    Credit_Card = 1,
    eCheck = 2,
    Money_order = 3,
    Cash = 4,
    PayPal = 5,
    Ideal = 6
}

export enum Portal {
    Account = 3,
    Join = 4,
    Corporate = 1
}
