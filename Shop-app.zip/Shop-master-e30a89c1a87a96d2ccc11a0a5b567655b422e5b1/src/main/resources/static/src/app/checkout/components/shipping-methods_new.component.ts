import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ShippingMethodsComponentSettings } from '../component-settings';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { CacheService, ConfigurationService, ActiveSessionService,
     CommonService, CartService, NotificationService } from '../../shared/services';
import { StoreConfig, State, CookieBannerResponse } from '../../shared/interfaces';
import {
    DeliveryOptionType, ShippingOrderType, OrderSourceType,
    ShippingType, ProductWeightMetric, BreadcrumbStep, ShippingMemberType, ShippingMemberTitle
} from '../enums';
import { Validators, FormBuilder } from '@angular/forms';
import {
    CheckoutInformation, PickupLoaction,
    ShippingOptionsRequest, ShippingOptionsResponse, ShippingProductModel,
    ShippingMethod, ShippingMethodInformation, ProductShippingRestriction, RestrictedProduct, Autoship
} from '../interfaces';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Cart, Item } from '../../shared/models';
import { ShippingMethodService, CheckoutMessageService } from '../services';
import { CurrencyPipe } from '../../common/pipes/currency-format.pipe';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AppMessageService } from '../../app-message.service';
import * as _ from 'lodash';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { Address } from '../../common/interfaces';
import { MemberType, MemberLevel, CartTypes, CookieBannerType } from '../../shared/enums';
import { AppSectionSpinnerService } from '../../common/services/section-spinner.service';
import { PromotionalParentProduct } from '../../shared/interfaces/product-promotions.interface';
import { PromotionsTypes } from '../enums/autoship-frequency.enum';
import { NotificationType } from '../../common/enums';

/**
 * @description this component will be used
 * to display the shipping methods and pickup locations
 * based on store and delivery option type
 * @date 2018-07-21
 * @export
 * @class ShippingMethodsNewComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-shipping-methods-new',
    templateUrl:
        '../templates/template3/views/shipping-methods_new.component.html',
    styleUrls: ['../templates/template3/themes/default/less/shipping-methods_new.component.less'
    ]
})

export class ShippingMethodsNewComponent implements OnInit, OnDestroy {
    sMethodsComponentSettings: ShippingMethodsComponentSettings = new ShippingMethodsComponentSettings();

    @ViewChild('shippingRestrictionModal') public shippingRestrictionModal: AppModalDirective;
    // Input variables
    // Setting Default Shipping method type
    // tslint:disable-next-line:no-input-rename
    @Input('deliveryOptionType') deliveryOptionType: DeliveryOptionType = DeliveryOptionType.Delivery;
    @Output() selectedDeliveryOption = new EventEmitter<any>();
    @ViewChild('shippingMethodBtn') public shippingMethodBtn: ElementRef;
    @Output() errorHandler = new EventEmitter<any>();

    constructor(
        private _formBuilder: FormBuilder,
        private _cacheService: CacheService,
        private _configurationService: ConfigurationService,
        private _shippingMethodService: ShippingMethodService,
        private _currencyPipe: CurrencyPipe,
        private _activeSessionService: ActiveSessionService,
        private _checkoutMessageService: CheckoutMessageService,
        private _appMessageService: AppMessageService,
        private _router: Router,
        private _translateService: TranslateService,
        private _commonService: CommonService,
        private _cartService: CartService,
        private _sectionSpinnerService: AppSectionSpinnerService,
        private _notificationService: NotificationService
    ) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
    * @description it used to load default configuration
    * of the current component based on user
    * @date 2018-07-19
    * @private
    * @memberof ShippingMethodsNewComponent
    */
    private loadDefaultSettings(): void {
        this.sMethodsComponentSettings.autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
        this.sMethodsComponentSettings.isoCountryCode = this._configurationService.getShippingCountryCode();
        this.sMethodsComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.getStoreData();
        this.loadCheckoutInformation();
        this.getCartSessionInfo();
        this.subscribePlaceOrderEvent();
        this.validateCurrentStep();
    }

    /**
     * @description Its an Subscription of breadcrumb navigation
     * for shipping Methods section
     * @memberof ShippingAddressComponent
     */
    validateCurrentStep(): void {
        this.sMethodsComponentSettings.breadcrumbSubscription =
            this._checkoutMessageService.getValidateCurrentStep$().subscribe((step: BreadcrumbStep) => {
                if (step === BreadcrumbStep.PAYMENT &&
                    this.deliveryOptionType === DeliveryOptionType.Delivery && this.shippingMethodBtn) {
                    this.shippingMethodBtn.nativeElement.click();
                }
            });
    }

    /**
    * @description this method will triggrer when loading of
    * cart items done from service
    * @date 2018-08-01
    * @private
    * @memberof ShippingMethodsNewComponent
    */
    private getCartSessionInfo(): void {
        this.sMethodsComponentSettings.cartSubscription = this._appMessageService
            .getCartItemsChanges()
            .subscribe((response) => {
                this.getCartItemsAndShippingMethods();
            });
    }

    /**
     * @description this method retives
     * store information from cache service
     * @date 2018-07-19
     * @memberof PersonalInfoComponent
     */
    private getStoreData(): void {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.sMethodsComponentSettings.store = result;
        }
    }

    /**
     * @description this method is used
     * load stored information while refreshing the page
     * @date 2018-07-21
     * @memberof ShippingAddressNewComponent
     */
    private loadCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.shippingInformation) {
            this.sMethodsComponentSettings.checkoutInformation = checkoutInformation;
            this.sMethodsComponentSettings.deliveryOptionType = this.deliveryOptionType ? this.deliveryOptionType
                : checkoutInformation.shippingInformation.deliveryOptionType;
            if (checkoutInformation.shippingInformation.shippingAddress) {
                this.sMethodsComponentSettings.shippingAddress = checkoutInformation.shippingInformation.shippingAddress;
            }
        }
        this.getCartItemsAndShippingMethods();
    }


    /**
     * @description this method used to load
     * cart information and based on cart details
     * will traverse the request to shipping methods
     * @date 2018-07-21
     * @param {Address} shippingAddress
     * @memberof ShippingMethodsNewComponent
     */
    private getCartItemsAndShippingMethods(): void {
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        const autoshipSession = this._cacheService.get(CacheKey.AutoshipCart);
        const autoshipDetails = this._cacheService.get(CacheKey.AutoshipDetails);
        const isAutoshipEnabled: boolean = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (isAutoshipEnabled &&
            autoshipSession && autoshipSession.items && autoshipSession.items.length > 0) {
            this.sMethodsComponentSettings.shoppingCart
                = new Cart(autoshipSession, this.sMethodsComponentSettings.store);
            this.getShippingMethods();
        } else if (cartSession && cartSession.items && cartSession.items.length > 0) {
            this.sMethodsComponentSettings.shoppingCart
                = new Cart(cartSession, this.sMethodsComponentSettings.store);
            this.getShippingMethods();
            if (this.sMethodsComponentSettings.autoshipCart && !isAutoshipEnabled && !autoshipDetails) {
                this.getAutoshipShippingMethods();
            }
        }
    }

    /**
     * @description creating a form for
     * shipping method information
     * @date 2018-07-19
     * @memberof PersonalInfoComponent
     */
    private createShippingMethodForm(shippingMethodId: number): void {
        this.sMethodsComponentSettings.shippingMethodForm = this._formBuilder.group({
            shippingMethod: [shippingMethodId, Validators.required]
        });
    }

    /**
    * @description this method will
    * process and validate Shipping Method,
    * @date 2018-07-20
    * @param {Event} $event
    * @memberof ShippingMethodsNewComponent
    */
    submitShippingMethod($event: Event): void {
        // submiting personal information
        if (this.sMethodsComponentSettings.shippingMehtod) {
            const memberCCLimitExceeded = this.getMemberCCLimit();
            if (memberCCLimitExceeded) {
                const exceedMonthlyCCPopup: any = this._translateService
                    .get('common.Your cart contains a case credit value that brings your total monthly case credits above the limit');
                const monthlyCCContent = exceedMonthlyCCPopup.value
                 + ' <b class="helvetica-bold">' + this.sMethodsComponentSettings.monthlyCCValue + '</b>';
                this._notificationService.createNotification('', monthlyCCContent, NotificationType.ERROR);
            } else {
                this.placeOrder();
            }

        }
    }

    /**
     * @description Calculate the member CC limit
     * @date 2019-05-04
     * @memberof ShippingAddressNewComponent
     */
    getMemberCCLimit(): boolean {
        this.sMethodsComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        if (this.sMethodsComponentSettings.userInfo
            && (this.sMethodsComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
                || this.sMethodsComponentSettings.userInfo.memberTypeId === MemberType.DISTRIBUTOR)) {
            const validateOrderRule = this._commonService.verifyOrderRules();
            this.sMethodsComponentSettings.thresholdCrossed = validateOrderRule.thresholdCrossed;
            this.sMethodsComponentSettings.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
            this.sMethodsComponentSettings.monthlyCCValue = validateOrderRule.monthlyCCValue;
        }
        return this.sMethodsComponentSettings.memberCCLimitExceeded;
    }


    /**
     * @description this method subscribe the place order
     * request status
     * @date 2018-08-17
     * @memberof ShippingMethodsNewComponent
     */
    subscribePlaceOrderEvent(): void {
        this.sMethodsComponentSettings.placeOrderSubscription = this._checkoutMessageService
            .getDisablePlaceOrderBtn()
            .subscribe(response => {
                if (this.sMethodsComponentSettings.store && this.sMethodsComponentSettings.store.createOrderOnTaxFailure) {
                    this.sMethodsComponentSettings.disableNextButton = response.isDisablePlaceOrderBtn;
                    if (response.isDisablePlaceOrderBtn && response.validations) {
                        const cookieBannerData: CookieBannerResponse = {
                            title: 'Tax Error notification',
                            description: response.validations,
                            notificationType: CookieBannerType.TaxNotification,
                            showBanner: true,
                            errorId: response.errorId
                        };
                        this._appMessageService.setCookieBannerData(cookieBannerData);
                    }
                }
            });
    }

    /**
     * @description Place Order
     * @date 2018-08-02
     * @memberof ShippingMethodsNewComponent
     */
    placeOrder(): void {
        this.sMethodsComponentSettings.disableNextButton = true;
        this._appMessageService.setProcessOrder();
    }

    /**
     * @description Method to get shipping methods
     * @private
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingMethods(): void {
        const shippingOptionsRequest: ShippingOptionsRequest = this.prepareShippingOptions(this.sMethodsComponentSettings.shoppingCart);
        this.sMethodsComponentSettings.shippingMethods = null;
        setTimeout(() => {
            this._sectionSpinnerService.start('deliveryMethod');
        }, 0);
        this._shippingMethodService
            .getShippingOptions(shippingOptionsRequest)
            .subscribe((shippingOptionsResponse: ShippingOptionsResponse) => {
                this.processShippingOptionsResponse(shippingOptionsResponse);
            }, (error: any) => {
                this.sMethodsComponentSettings.translateParams = this._commonService.handleError(error);
                this.errorHandler.emit(this.sMethodsComponentSettings.translateParams);
                this._sectionSpinnerService.stop('deliveryMethod');
            });
    }

    /**
     * @description get Shipping Methods for the Autoship
     * @date 2018-10-14
     * @private
     * @memberof ShippingMethodsNewComponent
     */
    private getAutoshipShippingMethods(): void {
        const shippingOptionsRequest: ShippingOptionsRequest = this.prepareShippingOptions(this.sMethodsComponentSettings.autoshipCart);
        this._shippingMethodService
            .getShippingOptions(shippingOptionsRequest)
            .subscribe((shippingOptionsResponse: ShippingOptionsResponse) => {
                if (shippingOptionsResponse && shippingOptionsResponse.shippingMethods
                    && shippingOptionsResponse.shippingMethods.length > 0) {
                    this.sMethodsComponentSettings.autoshipShippingMethods = shippingOptionsResponse.shippingMethods.map(x => {
                        x.importFeeEnabled = shippingOptionsResponse.importFeeEnabled;
                        x.distributionCenterName = shippingOptionsResponse.distributionCenterName;
                        if (x.shippingCharge) {
                            x.shippingCharge = this._currencyPipe.getFormatedCurrency(x.shippingCharge);
                        }
                        if (x.importFeeValue) {
                            x.importFeeValue = this._currencyPipe.getFormatedCurrency(x.importFeeValue);
                        }
                        return x;
                    });
                    if (this.sMethodsComponentSettings.autoshipShippingMethods) {
                        this.sMethodsComponentSettings.autoshipShippingMethod =
                            this.sMethodsComponentSettings.autoshipShippingMethods.find(x => x.default);
                        if (!this.sMethodsComponentSettings.autoshipShippingMethod) {
                            this.sMethodsComponentSettings.autoshipShippingMethod =
                                this.sMethodsComponentSettings.autoshipShippingMethods[0];
                        }
                        const initialAutoshipDetails = {
                            shippingMethodInfo: this.sMethodsComponentSettings.autoshipShippingMethod,
                            shippingAddress: this.sMethodsComponentSettings.shippingAddress
                        };
                        this._cacheService.set(CacheKey.InitialAutoshipDetails, initialAutoshipDetails);
                    }
                } else if (shippingOptionsResponse && shippingOptionsResponse.productModels
                    && shippingOptionsResponse.productModels.length > 0) {
                    let itemNumbers: Item[] = null;
                    itemNumbers = this.getRestrictedItemNumbers(shippingOptionsResponse);
                    this.getAutoshipShippingRestrictedProducts(itemNumbers);
                }
            });
    }

    /**
 * @description this method will find the restricted products
 * @date 2019-01-17
 * @param {Item[]} itemNumbers
 * @memberof ShippingMethodsNewComponent
 */
    getAutoshipShippingRestrictedProducts(itemNumbers: Item[]): void {
        const promotionalProducts: Item[] = [];
        const productIds: number[] = [];
        if (itemNumbers && itemNumbers.length > 0) {
            itemNumbers.forEach(x => {
                this.sMethodsComponentSettings.autoshipCart.items.forEach(element => {
                    if (element.itemNumber === x.itemNumber.substring(x.itemNumber.indexOf('#') + 1)) {
                        this.sMethodsComponentSettings.autoshipCart.items =
                            _.remove(this.sMethodsComponentSettings.autoshipCart.items, function (n) {
                                if (x.itemNumber === n.itemNumber && !n.isPromotionalProduct) {
                                    return true;
                                } else {
                                    return x.itemNumber !== n.itemNumber;
                                }
                            });
                    }
                    if (!element.isAlternatePromotionalProduct && element.alternatePromotionalProductId) {
                        const parentProdutId = this.sMethodsComponentSettings.autoshipCart.items.filter(y => {
                            if (element.promotionalParentProducts && element.promotionalParentProducts.length > 0) {
                                const isProductExists =
                                    element.promotionalParentProducts.find(prod => prod.parentProductId === y.productId);
                                if (isProductExists) {
                                    const promotionalProduct = y.promotions.find(p => p.promotionTypeId === PromotionsTypes.Autoship);
                                    if (promotionalProduct) {
                                        productIds.push(promotionalProduct.alternateComplementaryProductId);
                                    }
                                }
                            }
                        });
                    }
                });
            });
        }
        this._cacheService.set(CacheKey.AutoshipCart, this.sMethodsComponentSettings.autoshipCart);
        if (productIds && productIds.length > 0) {
            this.getPromotionalProductDetails(productIds);
        }
    }

    /**
   * @description get promotional product details
   * @date 2019-01-15
   * @param {number[]} productId
   * @memberof ShippingMethodsNewComponent
   */
    getPromotionalProductDetails(productIds: number[]): void {
        this._commonService.getProductsByIds(productIds, this.sMethodsComponentSettings.languageCode,
            this.sMethodsComponentSettings.store.id, true).subscribe((response) => {
                if (response && response.length > 0) {
                    let autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
                    response.forEach((prod) => {
                        let promotionalProd: Item = null;
                        promotionalProd = this._cartService.convertProductToItemMappper(prod);
                        promotionalProd.CV = 0;
                        promotionalProd.totalPrice = 0;
                        promotionalProd.isPromotionalProduct = true;
                        promotionalProd.applicablePrice = 0;
                        promotionalProd.totalPoints = 0;
                        promotionalProd.disableDecrement = true;
                        promotionalProd.disableIncrement = true;
                        let promotionalParentProduct: PromotionalParentProduct = null;
                        const prodPromotions = this.getQuantity(promotionalProd.productId);
                        if (prodPromotions) {
                            promotionalParentProduct = this.mapParentToPromotionalProduct(prodPromotions.productId, true);
                            promotionalProd.quantity = prodPromotions.quantity;
                        }
                        promotionalProd.promotionalParentProducts.push(promotionalParentProduct);
                        promotionalProd.isAlternatePromotionalProduct = true;
                        const isPromotionalProductExists = this.checkIsPromotionalProductExist(autoshipSessionInfo, promotionalProd);
                        if (!isPromotionalProductExists) {
                            autoshipSessionInfo = this.prepareAutoshipCart(promotionalProd, CartTypes.AutoshipCart, autoshipSessionInfo
                                ? autoshipSessionInfo : new Cart(null, this.sMethodsComponentSettings.store), null);
                        }
                        this.sMethodsComponentSettings.autoshipCart = new Cart(autoshipSessionInfo, this.sMethodsComponentSettings.store);
                    });
                    this.getShippingDetails();
                } else {
                    this.getShippingDetails();
                }
            });
    }

    /**
* @description map parent id to promotional product
* @date 2019-01-27
* @param {number} qualifyingProductId
* @param {boolean} alternatePromotionalProduct
* @returns {PromotionalParentProduct}
* @memberof ShippingMethodsNewComponent
*/
    mapParentToPromotionalProduct(qualifyingProductId: number, alternatePromotionalProduct: boolean): PromotionalParentProduct {
        const promotionalParentProduct: PromotionalParentProduct = {
            parentProductId: qualifyingProductId ? qualifyingProductId : null,
            isAlternatePromotionalProduct: alternatePromotionalProduct
        };
        return promotionalParentProduct;

    }

    /**
     * @description retreive the quantity
     * @date 2019-01-27
     * @param {number} quantity
     * @param {boolean} isrestrictedProducts
     * @param {number} parentProductId
     * @returns {number}
     * @memberof ShippingMethodsNewComponent
     */
    getQuantity(parentProductIds: number): Item {
        const autoshipSessionInfo: Cart = this._cacheService.get(CacheKey.AutoshipCart);
        let product: Item;
        if (parentProductIds) {
            const value = autoshipSessionInfo.items.filter(x => {
                if (x.promotions && x.promotions.length > 0) {
                    const promotionalProduct = x.promotions.find(p => p.promotionTypeId === PromotionsTypes.Autoship);
                    if (promotionalProduct && promotionalProduct.alternateComplementaryProductId === parentProductIds
                        && !x.isPromotionalProduct) {
                        product = x;
                        return x;
                    }
                }
            });
        }
        return product;
    }

    /**
     * @description get shipping details for promotional products
     * @date 2019-01-22
     * @memberof ShippingMethodsNewComponent
     */
    getShippingDetails(): void {
        this.sMethodsComponentSettings.isReloadCart = true;
        this._cacheService.set(CacheKey.AutoshipCart, this.sMethodsComponentSettings.autoshipCart);
        this.getAutoshipShippingMethods();
    }

    /**
    * @description check is Promotional Product exists
    * @date 2019-01-22
    * @param {Cart} autoshipSessionInfo
    * @param {Item} promotionalProduct
    * @returns {boolean}
    * @memberof ShippingMethodsNewComponent
    */
    checkIsPromotionalProductExist(autoshipSessionInfo: Cart, promotionalProduct: Item): boolean {
        let isPromotionalProductExists = false;
        if (autoshipSessionInfo && autoshipSessionInfo.items && autoshipSessionInfo.items.length > 0) {
            const isProductExists = autoshipSessionInfo.items.find(prod =>
                prod.productId === promotionalProduct.productId && prod.isPromotionalProduct);
            if (isProductExists) {
                autoshipSessionInfo.items.forEach(x => {
                    if (x.productId === isProductExists.productId && x.isPromotionalProduct) {
                        isPromotionalProductExists = true;
                        const promotionalProd: PromotionalParentProduct = {
                            parentProductId: promotionalProduct.promotionalParentProducts[0].parentProductId,
                            isAlternatePromotionalProduct: promotionalProduct.promotionalParentProducts[0].isAlternatePromotionalProduct
                        };
                        x.promotionalParentProducts.push(promotionalProd);
                        x.quantity = x.quantity + promotionalProduct.quantity;
                    }
                });
                this.sMethodsComponentSettings.autoshipCart = new Cart(autoshipSessionInfo, this.sMethodsComponentSettings.store);
            }
        }
        return isPromotionalProductExists;
    }

    /**
     * @description prepare Autoship cart
     * @date 2018-09-07
     * @private
     * @param {Item} item
     * @param {CartTypes} cartType
     * @param {Cart} cart
     * @returns {Cart}
     * @memberof CartComponent
     */
    private prepareAutoshipCart(item: Item, cartType: CartTypes, cart: Cart, cartItemIndex: number): Cart {
        cart.cartTypeId = cartType;
        cart.purchaseFlowId = 1;
        if (item && cartItemIndex === -1) {
            cart.items.push(item);
        } else if (item && cartItemIndex >= 0) {
            cart.items.splice(cartItemIndex, 0, item);
        }
        return cart;
    }



    /**
     * @description this method will process response
     * of shipping methods
     * @date 2018-07-21
     * @private
     * @param {ShippingOptionsResponse} shippingOptionsResponse
     * @memberof ShippingMethodsNewComponent
     */
    private processShippingOptionsResponse(shippingOptionsResponse: ShippingOptionsResponse): void {
        const autoshipDetails = this._cacheService.get(CacheKey.AutoshipDetails);
        if (shippingOptionsResponse && shippingOptionsResponse.shippingMethods && shippingOptionsResponse.shippingMethods.length > 0) {
            this.sMethodsComponentSettings.shippingValidations = null;
            this.formatShippingMethodsPrice(shippingOptionsResponse);
            this.shippingRestrictedProduct(shippingOptionsResponse);
            if (this.sMethodsComponentSettings.checkoutInformation &&
                this.sMethodsComponentSettings.checkoutInformation.shippingMethodInformation
                && this.sMethodsComponentSettings.checkoutInformation
                    .shippingMethodInformation.shippingMethod) {
                const shippingMehtod = this.sMethodsComponentSettings.checkoutInformation.shippingMethodInformation.shippingMethod;
                this.sMethodsComponentSettings.shippingMehtod = this.sMethodsComponentSettings.shippingMethods
                    .find(x => x.shippingMethodId === shippingMehtod.shippingMethodId);
            }
            if (!this.sMethodsComponentSettings.shippingMehtod
                && this.sMethodsComponentSettings.shippingMethods.find(x => x.default)) {
                this.sMethodsComponentSettings.shippingMehtod = this.sMethodsComponentSettings.shippingMethods.find(x => x.default);
            } else if (!this.sMethodsComponentSettings.shippingMehtod) {
                this.sMethodsComponentSettings.shippingMehtod = this.sMethodsComponentSettings.shippingMethods[0];
            }
            if (this.sMethodsComponentSettings.autoshipCart && !autoshipDetails) {
                this.validateAutoshipShippingInformation();
            } else {
                this.saveCheckoutInformation();
            }
            this.createShippingMethodForm(this.sMethodsComponentSettings.shippingMehtod.shippingMethodId);
        } else if (shippingOptionsResponse && shippingOptionsResponse.validations && shippingOptionsResponse.validations.length > 0) {
            this.sMethodsComponentSettings.shippingMethods = null;
            this.sMethodsComponentSettings.shippingValidations = shippingOptionsResponse.validations;
        } else if (shippingOptionsResponse && shippingOptionsResponse.productModels && shippingOptionsResponse.productModels.length > 0) {
            this.shippingRestrictedProduct(shippingOptionsResponse);
        }
        this._sectionSpinnerService.stop('deliveryMethod');
    }

    /**
     * @description to get the autoship shipping Methods
     * @date 2018-10-24
     * @memberof ShippingMethodsNewComponent
     */
    validateAutoshipShippingInformation(): void {
        //  to get the autoship shipping Methods.
        if (!this.sMethodsComponentSettings.autoshipMethodInterval &&
            this.sMethodsComponentSettings.autoshipCart && !this.sMethodsComponentSettings.autoshipShippingMethod) {
            const shippingMethods = this;
            this.sMethodsComponentSettings.autoshipMethodInterval = setInterval(function () {
                shippingMethods.validateAutoshipShippingInformation();
            }, 300);
        } else if (!this.sMethodsComponentSettings.autoshipCart ||
            (this.sMethodsComponentSettings.autoshipCart && this.sMethodsComponentSettings.autoshipShippingMethod)) {
            clearInterval(this.sMethodsComponentSettings.autoshipMethodInterval);
            this.saveCheckoutInformation();
        }
    }

    /**
     * @description this method used to format
     * shipping charge and import fee value of shipping methods
     * @date 2018-07-21
     * @private
     * @param {ShippingOptionsResponse} shippingOptionsResponse
     * @memberof ShippingMethodsNewComponent
     */
    private formatShippingMethodsPrice(shippingOptionsResponse: ShippingOptionsResponse): void {
        this.sMethodsComponentSettings.shippingMethods = shippingOptionsResponse.shippingMethods.map(x => {
            x.importFeeEnabled = shippingOptionsResponse.importFeeEnabled;
            x.distributionCenterName = shippingOptionsResponse.distributionCenterName;
            if (x.shippingCharge) {
                x.shippingCharge = this._currencyPipe.getFormatedCurrency(x.shippingCharge);
            }
            if (x.importFeeValue) {
                x.importFeeValue = this._currencyPipe.getFormatedCurrency(x.importFeeValue);
            }
            return x;
        });
    }

    /**
     * @description this method will make country code
     * to upper case
     * @private
     * @returns {Address}
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingAddress(): Address {
        if (this.sMethodsComponentSettings.shippingAddress) {
            this.sMethodsComponentSettings.shippingAddress.countryCode =
                this.sMethodsComponentSettings.shippingAddress.countryCode.toUpperCase();
            return this.sMethodsComponentSettings.shippingAddress;
        } else {
            return this.sMethodsComponentSettings.shippingAddress;
        }
    }


    /**
     * @description this method is used
     * validate this product is restricted or not
     * @date 2018-07-21
     * @param {*} restrictedProduct
     * @memberof ShippingMethodsNewComponent
     */
    private shippingRestrictedProduct(shippingOptionsResponse: ShippingOptionsResponse) {
        if (shippingOptionsResponse.success && shippingOptionsResponse.productModels) {
            this.sMethodsComponentSettings.productShippingRestriction = this.prepareProductShippingRestrictions(shippingOptionsResponse);
            if (this.sMethodsComponentSettings.productShippingRestriction) {
                this.getRestrictedProducts();
                this.shippingRestrictionModal.show();
            }

        } else {
            this.sMethodsComponentSettings.productShippingRestriction = null;
        }
    }

    /**
     * @description this method will get restrcited products
     * @private
     * @returns {RestrictedProduct[]}
     * @memberof ShippingMethodsNewComponent
     */
    private getRestrictedProducts(): RestrictedProduct[] {
        let cartItems: Item[] = this.sMethodsComponentSettings.shoppingCart.items;
        this.sMethodsComponentSettings.restrictedProducts = [];
        const restrictedItems = [];
        cartItems = _.uniqBy(cartItems, function (e: any) {
            return e.id;
        });
        const restrictedProductItemNumbers: any[] = this.sMethodsComponentSettings.productShippingRestriction.itemNumbers;
        if (restrictedProductItemNumbers && restrictedProductItemNumbers.length > 0
            && cartItems && cartItems.length > 0) {
            cartItems.forEach(element => {
                restrictedProductItemNumbers.forEach(x => {
                    if (element.itemNumber === x.itemNumber.substring(x.itemNumber.indexOf('#') + 1)) {
                        const error: any = this._translateService.get('checkout.' + x.errorDescription);
                        element['errorDescription'] = error.value;
                        if (x.errorDescription) {
                            restrictedItems.push(element);
                        }
                    }
                });
            });
        }
        this.sMethodsComponentSettings.restrictedProducts = restrictedItems;
        return this.sMethodsComponentSettings.restrictedProducts;
    }

    /**
     * @description  this method will prepare shipping restrictions
     * based on shipping address and shipping options response
     * @private
     * @memberof ShippingMethodsNewComponent
     */
    private prepareProductShippingRestrictions(shippingOptionsResponse: ShippingOptionsResponse): ProductShippingRestriction {
        const productShippingRestriction: ProductShippingRestriction = {
            productModelResponse: true,
            shippingResponse: shippingOptionsResponse.success ? shippingOptionsResponse.success : false,
            productError: this.getShippingRestrictionError(shippingOptionsResponse),
            itemNumbers: this.getRestrictedItemNumbers(shippingOptionsResponse),
            itemNo: this.getShippingRestrictionItemNo(shippingOptionsResponse)
        };
        return productShippingRestriction;
    }

    /**
     * @description this method will give the product error descriptions
     * @private
     * @param {*} restrictedProduct
     * @returns {string}
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingRestrictionError(restrictedProduct: ShippingOptionsResponse): string {
        let productError = '';
        if (restrictedProduct && restrictedProduct.productModels
            && restrictedProduct.productModels.length === 1) {
            productError = restrictedProduct.productModels[0].errorDescription;
        } else {
            if (this.sMethodsComponentSettings && this.sMethodsComponentSettings.shippingAddress
                && this.sMethodsComponentSettings.shippingAddress.stateCode && this.sMethodsComponentSettings.shippingAddress.countryId) {
                productError = this.getStatesLookup(this.sMethodsComponentSettings.shippingAddress.countryId
                    , this.sMethodsComponentSettings.shippingAddress.stateCode);
            } else {
                const error: any = this._translateService.get('checkout.Following products are not allowed for selected shipping address.');
                productError = error.value;
            }

        }
        return productError;
    }


    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof ShippingMethodsNewComponent
     */
    private getStatesLookup(countryId: number, stateCode: string): string {
        let productError = '';
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            const stateName: string = storedStates.find(x => x.stateCode === stateCode).stateName;
            const error: any =
                this._translateService.get('checkout.' + stateName + ' ' + 'does not allow for the following items to be shipped:');
            productError = error.value;
        } else if (countryId) {
            this._commonService.getStatesByCountry(countryId).subscribe((res: State[]) => {
                const stateName: string = res.find(x => x.stateCode === stateCode).stateName;
                const error: any =
                    this._translateService.get(decodeURIComponent(encodeURIComponent('checkout.' + stateName))
                         + ' ' + 'does not allow for the following items to be shipped:');
                this.sMethodsComponentSettings.productErrorMsg = error.value;
            }, (err: any) => {
            });
        }
        return productError;
    }

    /**
     * @description this method will give restricted items numbers
     * @private
     * @param {*} restrictedProduct
     * @returns {string}
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingRestrictionItemNo(restrictedProduct: ShippingOptionsResponse): string {
        let itemNumber = '';
        if (restrictedProduct && restrictedProduct.productModels
            && restrictedProduct.productModels.length > 1) {
            itemNumber = restrictedProduct.productModels[0].itemNumber;
        }
        return itemNumber;
    }

    /**
     * @description this method will get the restriced items nummbers list
     * @param {*} restrictedProduct
     * @memberof ShippingMethodsNewComponent
     */
    private getRestrictedItemNumbers(restrictedProduct: ShippingOptionsResponse): Item[] {
        const itemNumbers: Item[] = [];
        restrictedProduct.productModels.forEach((x: any) => {
            itemNumbers.push(x);
        });
        return itemNumbers;
    }

    /**
     * @description this method redirects user to shopping bag page
     * @memberof ShippingMethodsNewComponent
     */
    removeNonShippableProducts(): void {
        this._router.navigateByUrl('/' + this.sMethodsComponentSettings.isoCountryCode.toLowerCase()
            + '/' + this.sMethodsComponentSettings.languageCode.toLowerCase() + '/cart');
    }

    /**
     * @description this method redirects the user to shipping address section page
     * @memberof ShippingMethodsNewComponent
     */
    changeShippingAddress(): void {
        this._router.navigateByUrl('/' + this.sMethodsComponentSettings.isoCountryCode.toLowerCase()
            + '/' + this.sMethodsComponentSettings.languageCode.toLowerCase() + '/checkout/shipping');
    }

    /**
     * @description this method will prepare request
     * to get shipping options
     * @date 2018-07-21
     * @private
     * @returns {ShippingOptionsRequest}
     * @memberof ShippingMethodsNewComponent
     */
    private prepareShippingOptions(cartItems: Cart): ShippingOptionsRequest {
        const shippingOptions: ShippingOptionsRequest = {
            productModels: this.getProductModels(cartItems),
            orderSourceId: OrderSourceType.Web,
            languageCode: this.sMethodsComponentSettings.languageCode,
            orderTypeId: ShippingOrderType.Personal,
            fromAddress: this._configurationService
                .getWarehouseAddress(this.sMethodsComponentSettings.isoCountryCode),
            toAddress: this.getShippingAddress(),
            storeId: this.sMethodsComponentSettings.store.id,
            requestID: 2, // for now we are using two once config is done we will drive from enum
            memberTypeId: this.getShippingMemberType(),
            priceTypeId: this._activeSessionService.getPriceTypeId(),
            memberLevelId: this.getShippingMemberTitle(),
            orderSubTotal: this.sMethodsComponentSettings.shoppingCart.subTotal,
            orderCaseCredits: this.sMethodsComponentSettings.shoppingCart.totalPoints,
            purchaseFlowId: this._activeSessionService.getPurchaseFlowId(),
            shippingTypeId: this.sMethodsComponentSettings.deliveryOptionType === DeliveryOptionType.Delivery
                ? ShippingType.DELIVERY : ShippingType.PICKUP,
            storeHomeCountryCode: this.sMethodsComponentSettings.isoCountryCode.toUpperCase()
        };
        return shippingOptions;
    }

    /**
     * @description Get product models
     * @private
     * @param {Cart} cartItems
     * @returns {ShippingProductModel[]}
     * @memberof ShippingMethodsNewComponent
     */
    private getProductModels(cartItems: Cart): ShippingProductModel[] {
        const productModels: ShippingProductModel[] = [];
        cartItems.items.forEach((x: Item) => {
            const productModel: ShippingProductModel = {
                productID: x.id,
                productHeight: x.height,
                productWeight: x.weight,
                productQuantity: x.quantity,
                productLength: x.length,
                productWidth: x.width,
                wholesalePrice: x.wholesalePrice,
                sellingPrice: x.applicablePrice,
                isOrderLiteratureOnly: x.literature,
                retailPrice: x.retailPrice,
                weightMetricId: ProductWeightMetric.KGS,
                isShippable: x.shippingRequired,
                itemNumber: x.itemNumber
            };
            productModels.push(productModel);
        });
        return productModels;
    }

    /**
     * @description loaction  of langitude url
     * for selected pickup location
     * @date 2018-07-21
     * @param {*} pickUplocation
     * @returns {string}
     * @memberof ShippingMethodsNewComponent
     */
    getLocationMap(pickUplocation: PickupLoaction): string {
        if (pickUplocation && pickUplocation.latitude && pickUplocation.longitude) {
            return ApiUrlConstants.googleMapsUrl + pickUplocation.latitude + ',' + pickUplocation.longitude;
        } else {
            return null;
        }
    }

    /**
     * @description ADA Complience
     * function used when we are accessing through keyboard
     * @date 2018-07-21
     * @param {number} index
     * @memberof ShippingMethodsNewComponent
     */
    triggerClick(index: number): void {
        $('#shippingMethod' + index).prop('checked', true).trigger('click');
    }

    /**
     * @description this method will
     * excecute on changing of shipping option
     * @date 2018-07-23
     * @param {ShippingMethod} shippingMehtod
     * @memberof ShippingMethodsNewComponent
     */
    selectShippingMethod(shippingMehtod: ShippingMethod): void {
        this.sMethodsComponentSettings.shippingMehtod = shippingMehtod;
        this.saveCheckoutInformation();
    }

    /**
     * @description this method is used
     * to emit shipping mthod info from parent to child
     * when we chose delivery type pickup
     * @date 2018-07-24
     * @private
     * @param {ShippingMethod} shippingMehtod
     * @memberof ShippingMethodsNewComponent
     */
    private emitShippingMethod(): void {
        if (this.deliveryOptionType === this.sMethodsComponentSettings.deliveryOptions.Pickup) {
            this.selectedDeliveryOption.emit(this.sMethodsComponentSettings.shippingMehtod);
        }
    }

    /**
     * @description Saving Checkout Information
     * @date 2018-07-20
     * @memberof ShippingMethodsNewComponent
     */
    private saveCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        checkoutInformation.shippingMethodInformation =
            this.prepareShippingMethodInformation(this.sMethodsComponentSettings.shippingMehtod);
        if (this.sMethodsComponentSettings.autoshipCart) {
            checkoutInformation.autoshipShippingMethodInformation =
                this.prepareShippingMethodInformation(this.sMethodsComponentSettings.autoshipShippingMethod);
        }
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
        this._checkoutMessageService.setTaxCalc(this.sMethodsComponentSettings.isReloadCart);
        this.emitShippingMethod();
    }

    /**
     * @description this method will
     * prepare shipping information related to
     * delivery type
     * @date 2018-07-23
     * @returns {ShippingMethodInformation}
     * @memberof ShippingMethodsNewComponent
     */
    private prepareShippingMethodInformation(shippingMethod: ShippingMethod): ShippingMethodInformation {
        const shippingMethodInformation: ShippingMethodInformation = {
            shippingMethod: shippingMethod
        };
        return shippingMethodInformation;
    }

    /**
     * @description Gets Member Type Required for Shipping Calculation
     * @private
     * @returns {number}
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingMemberType(): number {
        if (this._activeSessionService.getMemberTypeId() === MemberType.DISTRIBUTOR ||
            this._activeSessionService.getMemberTypeId() === MemberType.PREFERREDCUSTOMER) {
            return ShippingMemberType.DISTRIBUTOR;
        } else {
            return ShippingMemberType.RETAIL;
        }
    }

    /**
     * @description Gets Member Title Required for Shipping Calculation
     * @private
     * @returns {number}
     * @memberof ShippingMethodsNewComponent
     */
    private getShippingMemberTitle(): number {
        return this._activeSessionService.getMemberTitleId() === MemberLevel.PREFERREDCUSTOMER
            ? ShippingMemberTitle.NOVUS : ShippingMemberTitle.ASSISTANTMANAGER;
    }

    ngOnDestroy(): void {
        if (this.sMethodsComponentSettings.cartSubscription) {
            this.sMethodsComponentSettings.cartSubscription.unsubscribe();
        }
        if (this.sMethodsComponentSettings.placeOrderSubscription) {
            this.sMethodsComponentSettings.placeOrderSubscription.unsubscribe();
        }
        if (this.sMethodsComponentSettings.breadcrumbSubscription) {
            this.sMethodsComponentSettings.breadcrumbSubscription.unsubscribe();
        }
    }

    /**
    * @returns void
    */
    onHidden(): void {
        this.shippingRestrictionModal.hide();
    }
}
