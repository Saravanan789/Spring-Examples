import { CartComponent } from './components/cart.component';

export class CartModuleConstants {
  static MODULE_COMPONENTS = [
    CartComponent
  ];
}
