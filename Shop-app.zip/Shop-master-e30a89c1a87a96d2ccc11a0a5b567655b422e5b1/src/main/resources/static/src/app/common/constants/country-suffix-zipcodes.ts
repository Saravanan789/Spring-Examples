export class CountrySuffixZipCodes {
    public static USACountrySuffixZipCode: CountrySuffixZipCode =
        { countryId: 1, defaultSuffixZipCode: '0000' , zipCodeLength : 5 };
}

interface CountrySuffixZipCode {
    countryId: number;
    defaultSuffixZipCode: string;
    zipCodeLength: number;
}
