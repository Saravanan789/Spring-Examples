import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/pairwise';
import { CommonService } from './shared/services/common.service';
import { Router, NavigationEnd, NavigationStart } from '@angular/router';
import { Component, ViewEncapsulation, HostListener } from '@angular/core';
import { SSO } from './sso/sso.constants';
import { AppService } from './app.service';
import { CacheService } from './shared/services/cache.service';
import { CacheKey } from './shared/constants/cachekey.constants';
import { OnInit, OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import * as _ from 'lodash';
import { environment } from '../environments/environment';
import { ConfigurationService } from './shared/services/configuration.service';
import { Member } from './shared/interfaces/member.interface';
import { Location } from '@angular/common';
import { Meta, Title } from '@angular/platform-browser';
import { MetaTagConstants } from './shared/constants/meta-tag.constants';

declare var canShowSplashInitally: any;

@Component({
  selector: 'app-shop',
  templateUrl: './app.component.html',
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit, OnDestroy {
  userInfo: any;
  routerSubscription: Subscription;
  isoCountryCode: string;
  documentStatus: any;
  impersonatedUser = false;
  portalId = 3;
  ackRequired: any;
  languageCode: string;
  canLoadSplashScreenInitally: any;
  private _routeScrollPositions: { [url: string]: number }[] = [];
  constructor(
    private _appService: AppService,
    private _router: Router,
    private _cacheService: CacheService,
    private _commonService: CommonService,
    private _location: Location,
    private _configurationService: ConfigurationService,
    private _meta: Meta,
    private title: Title
  ) {
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.validateSSO();
    this.appendCmsScripts();
  }
  ngOnInit() {
    const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
    if (!userInfo) {
      this._cacheService.remove(CacheKey.IgnoreOptInSkipCount);
      this.validateSSOFromLegacy();
    } else {
      this._cacheService.remove(CacheKey.WishListSession);
    }
    this.canLoadSplashScreenInitally = canShowSplashInitally;
    this.routerSubscription = this._router.events
      .filter(event => event instanceof NavigationEnd)
      .subscribe(x => {
        window.scrollTo(0, 0);
        this.defaultSEOSettings();
      });
    this.userInfo = this._cacheService.get(CacheKey.UserInfo);
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.changeRouteBasedOnLanguage();
    const accessToken = SSO.isRemoveObsoleteCookie()
      ? localStorage.getItem(SSO.ACCESS_TOKEN) : this._cacheService.getCookieValue(SSO.ACCESS_TOKEN);
    if (accessToken && this.userInfo && this.userInfo.hasActionItems) {
      this.documentStatus = this._cacheService.get(CacheKey.DocumentStatus);
      this.impersonatedUser = this._cacheService.get(CacheKey.ImpersonatedUser);
    }
    // Remove localstorage information, when user logout
    if (this._cacheService.get(CacheKey.loggedIn) && !this._cacheService.get(CacheKey.UserInfo)) {
      this.clearUserStoredInfo();
    }
    // when navigated from other portals loading category
    if (this._cacheService.getCookieValue(CacheKey.SelectedCategoryId)) {
      const categoryId = parseInt(this._cacheService.getCookieValue(CacheKey.SelectedCategoryId), 10);
      if (categoryId) {
        this._cacheService.set(CacheKey.SelectedCategoryState, { productCategoryId: categoryId, isFirstLoad: true });
        this._cacheService.removeCookieValue(CacheKey.SelectedCategoryId);
      }
    }
    this.getStoreConfig();
  }

  /**
   * Clear the user information, when they loggedout
   * @memberof AppComponent
   */
  clearUserStoredInfo(): void {
    this._cacheService.remove(CacheKey.CheckoutInformation);
    this._cacheService.remove(CacheKey.loggedIn);
  }

  retainScrollPosition() {
    if ('scrollRestoration' in history) {
      history.scrollRestoration = 'manual';
    }
    // save or restore scroll position on route change
    this._router.events.pairwise().subscribe(([prevRouteEvent, currRouteEvent]) => {
      if (prevRouteEvent instanceof NavigationEnd && currRouteEvent instanceof NavigationStart) {
        this._routeScrollPositions[prevRouteEvent.url] = window.pageYOffset;
      }
      if (currRouteEvent instanceof NavigationEnd) {
        setTimeout(() => {
          const scrollPos = this._routeScrollPositions[currRouteEvent.url] || 0;
          this._commonService.scrollByValue(0, scrollPos, 300);
        }, 1000);
      }
    });
  }

  /**
      * Adding CMS Scripts
      * @memberof AppComponent
      */
  appendCmsScripts(): void {
    const script = document.createElement('script');
    const url = environment.cdnURL + environment.cmsTemplateScriptPath;
    if (script) {
      script.type = 'text/javascript';
      script.setAttribute('src', url);
      script.crossOrigin = 'anonymous';
      environment.cmsTemplateScriptIntegrity = environment.cmsTemplateScriptIntegrity ? environment.cmsTemplateScriptIntegrity : '';
      script.setAttribute('integrity', environment.cmsTemplateScriptIntegrity);
      document.head.appendChild(script);
    }
  }
  /**
   * @returns void
   */
  private getStoreConfig(): void {
    this._configurationService.getStoreByCountry(this.isoCountryCode)
      .subscribe(storeConfig => {
        if (storeConfig) {
          storeConfig.storeCountryCode = this.isoCountryCode;
          this._cacheService.set(CacheKey.StoreConfiguration, storeConfig);
          this._cacheService.setCookieValue(CacheKey.StoreHomeCountry, storeConfig.homeIsocodeThree);
        }
      });
  }


  /**
   * @description this method will change route
   * @date 2018-12-20
   * @private
   * @memberof AppComponent
   */
  private changeRouteBasedOnLanguage(): void {
    const urlLocation = window.location.pathname;
    const urlPath = window.location.pathname.split('/');
    const lang = urlPath[2];
    if (lang && lang.toLowerCase() !== this.languageCode.toLowerCase()) {
      this._location.replaceState(urlLocation.split(lang).join(this.languageCode.toLowerCase()));
    }
  }


  /**
   * @returns void
   */
  validateSSO(): void {
    if (window.location.pathname === '' || window.location.pathname === '/') {
      const isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode) || 'usa';
      try {
        let languageCode;
        try {
          languageCode = JSON.parse(this._cacheService.getCookieValue(CacheKey.languageCode));
        } catch (error) {
          languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        }
        this._router.navigate([isoCountryCode + '/' + languageCode.toLowerCase() + '/products'], { replaceUrl: true });
      } catch (error) {
        this._router.navigate([isoCountryCode + '/en-us/products'], { replaceUrl: true });
      }
    }
  }

  /**
   * Navigate to Keycloak and Show user as logged-in User while coming from Legacy
   */
  validateSSOFromLegacy() {
    if (window.location.href.indexOf('legacy=true') > -1) {
      window.location.href = SSO.getSSOLoginUrl(false);
    }
  }

  /**
     * User Action Center documents
     */
  getActionCenterDocuments() {
    this._appService.getUserSpecificDocuments(this.userInfo.memberTypeId, this.userInfo.memberId, this.portalId).then(response => {
      if (response && response.length > 0 && response[0].statusCodeValue === 200) {
        this.ackRequired = response[0].body.filter(x => x.acceptedStatus === false);
        if (this.ackRequired && this.ackRequired.length > 0) {
          if (this.documentStatus && this.documentStatus.length > 0) {
            this.documentStatus = _.uniqBy(this.documentStatus, function (e: any) {
              return e.id;
            });
            const testItems = this.ackRequired;
            const objDocs = this.documentStatus;
            const documentsList = [];
            this.ackRequired.forEach(element => {
              if (!this.documentStatus.find(x => x.id === element.documentLibraryVersionId)) {
                documentsList.push(element);
              }

            });
            if (documentsList && documentsList.length > 0) {
              window.location.href = environment.accountSiteURL + '?redirectUrl=' + window.location.href;
            }
          } else {
            window.location.href = environment.accountSiteURL + 'redirectUrl=' + window.location.href;
          }
        }
      }
    });
  }

  /**
   * To update a default meta tags
   * @memberof AppComponent
   */
  defaultSEOSettings(): void {
    this.title.setTitle(MetaTagConstants.metaTitle);
    this._meta.updateTag({ name: 'description', content: MetaTagConstants.metaDescription });
  }

/**
 * @description
 * To prevent back navigation on pressing backspace key
 * @date 2018-11-21
 * @param {KeyboardEvent} evt
 * @memberof AppComponent
 */
@HostListener('document:keydown', ['$event'])
onKeyDown(evt: KeyboardEvent) {
  const nodes = ['INPUT', 'SELECT', 'TEXTAREA'];
  if (evt.which === 8 &&
    (nodes.indexOf((<HTMLInputElement>evt.target).nodeName) < 0)) {
    evt.preventDefault();
  }
}

ngOnDestroy() {
  this.routerSubscription.unsubscribe();
}
}
