export interface PaymentLineItem {
    itemId: number;
    itemDescription: string;
    itemUnitPrice: number;
    itemQuantity: number;
    itemTax: number;
}
