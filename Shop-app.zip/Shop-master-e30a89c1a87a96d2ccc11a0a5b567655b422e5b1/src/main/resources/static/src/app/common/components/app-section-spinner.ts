import { Component, OnInit, Input, AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { AppSectionSpinnerService } from '../services/section-spinner.service';
@Component({
    selector: 'app-section-spinner',
    templateUrl: '../templates/template3/views/app-section-spinner.html',
    styleUrls: ['../templates/template3/themes/default/less/app-section-spinner.less']
})
export class AppSectionSpinnerComponent implements OnInit, OnDestroy {
    @Input() sectionName: string;
    showSpinner = false;
    constructor(private sectionSpinnerService: AppSectionSpinnerService, private elementRef: ElementRef) { }

    ngOnInit(): void {
        this.registerSectionSpinner(this.sectionName);
    }
    /**
     * @description Register a Section Spinners to Listen
     * @param {string} sectionName
     * @memberof AppSectionSpinnerComponent
     */
    registerSectionSpinner(sectionName: string): void {
        if (sectionName) {
            this.sectionSpinnerService.listenLoader(sectionName).subscribe((show: boolean) => {
                // const elParentRef = this.elementRef.nativeElement.parentElement;
                // if (show) {
                //     elParentRef.classList.add('container--show');
                // } else {
                //     elParentRef.classList.remove('container--show');
                // }
                this.showSpinner = show;
            });
        }
    }

    ngOnDestroy(): void {
        this.sectionSpinnerService.unsubscribeListener(this.sectionName);
    }

}
