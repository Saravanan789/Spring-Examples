export enum CountryName {
    USA = 'usa',
    CAN = 'can',
    BEL = 'bel',
    NLD = 'nld',
    GBR = 'gbr',
    LUX = 'lux',
    ITA = 'ita'
}
