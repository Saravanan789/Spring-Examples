export interface PickupLoaction {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    addressLine4: string;
    city: string;
    state: string;
    stateCode: string;
    stateId: number;
    countryCode: string;
    country: string;
    county: string;
    countryId: number;
    zip: string;
    postalCode?: string;
    company: string;
    name: string;
    pickupCenterName: string;
    instruction: string;
    optionName: string;
    pickUpCenterId: number;
    latitude: string;
    longitude: string;
    residential: boolean;
    validAddress: boolean;
    addressType?: number;
}
