export interface AddressResponse {
    responseCode: string;
    responseDescription: string;
}

export interface JsonSchemaFormOptions {
    addSubmit: boolean;
    loadExternalAssets: boolean;
    debug: boolean;
    setSchemaDefaults: boolean;
    returnEmptyFields: boolean;
}
