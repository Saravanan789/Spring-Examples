import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Order } from '../interfaces/order.interface';
import { OrderLineItemType } from '../interfaces/order-lineItem-type.interface';
import {
  OrderShipping, CheckoutInformation,
  OrderLineItem, TaxItems
} from '../interfaces';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { CacheService, ActiveSessionService, ConfigurationService, CommonService } from '../../shared/services';
import { DeliveryOptionType, ShippingType, OrderStatus } from '../enums';
import { Item } from '../../shared/models';
import { CartSummaryComponentSettings, CheckoutComponentSettings } from '../component-settings';
import { State, Country } from '../../shared/interfaces';
import { CurrencyPipe } from '../../common/pipes/currency-format.pipe';
import { ShippingMethodService } from './shipping-method.service';
import { AutoshipService } from './autoship.service';
import { OrderSource } from '../constants';
import { Address } from '../../common/interfaces';
import { AddressType } from '../../common/enums';

@Injectable()
export class OrderService {

  constructor(
    private _http: Http,
    private _cacheService: CacheService,
    private _currencyPipe: CurrencyPipe,
    private _shippingMethodService: ShippingMethodService,
    private _autoshipService: AutoshipService,
    private _activeSessionService: ActiveSessionService,
    private _configurationService: ConfigurationService,
    private _commonService: CommonService
  ) { }

  /**
   * create order
   * @param  {Order} paymentRequest
   * @returns Observable
   */
  createOrder(orderRequest: Order): Observable<any> {
    return this._http
      .post(ApiUrlConstants.orderApiUrl + '/orders', JSON.stringify(orderRequest))
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description
   * @date 2018-07-31
   * @param {Order} orderRequest
   * @param {string} url
   * @returns {Observable<any>}
   * @memberof OrderService
   */
  createNewOrder(orderRequest: Order, url: string): Observable<any> {
    return this._http
      // .post(url, JSON.stringify(orderRequest))
      .post(decodeURIComponent(encodeURIComponent(url)), JSON.stringify(orderRequest))
      .map((res: Response) => res)
      .catch(this.handleErrorObservable);
  }

  /**
   * to change order status
   * @param  {any} orderId
   * @returns Observable
   */
  changeOrderStatus(orderId: string, orderStatus: number): Observable<any> {
    return this._http
      .patch(ApiUrlConstants.orderApiUrl + '/order/' + orderId + '/orderStatus/' + orderStatus, '')
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * to change order status
   * @param  {any} orderId
   * @returns Observable
   */
  changeOrderPaymentStatus(orderPaymentRequest: any, orderPaymentId: number, webOrderId: number): Observable<any> {
    return this._http
      .put(ApiUrlConstants.orderApiUrl + '/order/' + webOrderId + '/orderPayment/' + orderPaymentId, JSON.stringify(orderPaymentRequest))
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * get order details by order id
   * @param  {any} orderId
   * @returns Observable
   */
  getOrderDetailsById(webOrderId: string): Observable<Order> {
    return this._http
      .get(ApiUrlConstants.orderApiUrl + '/orders/' + webOrderId)
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
  * to get order line item types
  * @param  {any} enrollGuid
  * @returns Observable
  */
  getOrderLineItemTypes(): Observable<OrderLineItemType[]> {
    return this._http
      .get(ApiUrlConstants.orderApiUrl + '/lineitem-types')
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description
   * @date 2018-07-31
   * @param {*} scrollDuration
   * @memberof OrderService
   */
  scrollToTop(scrollDuration: any): void {
    const scrollStep = -window.scrollY / (scrollDuration / 15),
      scrollInterval = setInterval(function () {
        if (window.scrollY !== 0) {
          window.scrollBy(0, scrollStep);
        } else {
          clearInterval(scrollInterval);
        }
      }, 15);
  }

  /**
   * @description this method will return order shipping details
   * bbassed on user sele
   * @date 2018-07-31
   * @returns {OrderShipping[]}
   * @memberof OrderService
   */
  getOrderShippings(): OrderShipping[] {
    const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    const orderShippings: OrderShipping[] = [];
    if (checkoutInformation.shippingInformation && checkoutInformation.shippingMethodInformation
      && checkoutInformation.shippingMethodInformation.shippingMethod) {
      const orderShipping: OrderShipping = {
        deliveryPreferenceId: checkoutInformation.shippingInformation.deliveryOptionType
          === DeliveryOptionType.Delivery ? ShippingType.DELIVERY : ShippingType.PICKUP,
        shipMethodId: checkoutInformation.shippingMethodInformation.shippingMethod.shippingMethodId,
        shippingAddressId: this.getShippingAddressId(checkoutInformation),
        billingAddressId: null,
        shortCode: checkoutInformation.shippingMethodInformation.shippingMethod.shortCode,
        preferredTime: null,
        notes: null,
        shipmentDate: null,
        distributionCenter: checkoutInformation.shippingMethodInformation.shippingMethod.distributionCenterName ?
          checkoutInformation.shippingMethodInformation.shippingMethod.distributionCenterName : ''
      };
      orderShippings.push(orderShipping);
    }
    return orderShippings;
  }

  /**
   * @description this method will return saved shipping
   * address id
   * @date 2018-07-31
   * @private
   * @param {CheckoutInformation} checkoutInformation
   * @memberof OrderService
   */
  private getShippingAddressId(checkoutInformation: CheckoutInformation): number {
    return (checkoutInformation.shippingInformation && checkoutInformation.shippingInformation.deliveryOptionType
      === DeliveryOptionType.Delivery && checkoutInformation.shippingInformation.shippingAddress)
      ? checkoutInformation.shippingInformation.shippingAddress.id : 0;
  }


  /**
   * @description this method used prepare
   * order request
   * @date 2018-07-31
   * @returns {Order}
   * @memberof OrderService
   */

  prepareOrderRequest(checkoutComponentSettings: CheckoutComponentSettings): Order {
    const cartSummaryInformation: CartSummaryComponentSettings = checkoutComponentSettings.cartSummaryComponentSettings;
    const memberTitleId = this._activeSessionService.getMemberTitleId();
    const wholesaleQualified = this._activeSessionService.getWholesaleQualified();
    const personalDiscountPercentage = this._commonService.getDiscountPerc(memberTitleId, wholesaleQualified);
    const orderRequest: Order = {
      countryCode: this._configurationService.getShippingCountryCode(),
      memberTypeId: checkoutComponentSettings.registerMemberType,
      orderStatusId: OrderStatus.Pending,
      memberId: this.getMemberId(checkoutComponentSettings),
      email: this.getMemberEmail(checkoutComponentSettings),
      languageCode: this.getLanguageCode(checkoutComponentSettings),
      storeId: checkoutComponentSettings.store.id,
      orderTypeId: this._activeSessionService.getOrderTypeId(),
      memberLevelId: this.getMemberTitleId(checkoutComponentSettings),
      shippingCost: cartSummaryInformation.shippingTotal,
      importFeeValue: this._currencyPipe.getFormatedCurrency(cartSummaryInformation.importFeeValue),
      shippingTax: 0,
      distrubutorId: this.getDistributorId(checkoutComponentSettings),
      orderSubTotal: cartSummaryInformation.shoppingCart.subTotal,
      orderTotalAfterDiscount: null,
      orderTotal: cartSummaryInformation.shoppingCart.total,
      orderTax: cartSummaryInformation.taxableAmount,
      currencyId: checkoutComponentSettings.store.currencyId,
      source: OrderSource.WEB,
      orderNotes: null,
      orderLineItems: this.getOrderLineItems(cartSummaryInformation),
      orderShippings: this.getOrderShippings(),
      orderDiscounts: null,
      orderPayments: null,
      shippingAddressModel: this.getShippingAddress(),
      billingAddressModel: this.getBillingAddress(),
      addresses: this.getAddresses(checkoutComponentSettings.countries, checkoutComponentSettings.states),
      currencyCode: checkoutComponentSettings.store.currencyCode,
      createdBy: this.getUserId(checkoutComponentSettings),
      additionalOrderInfo: [],
      taxMetaData: cartSummaryInformation.orderTaxResponse ? cartSummaryInformation.orderTaxResponse.taxMetaData : null,
      priceTierName: this.getPriceTier(cartSummaryInformation),
      wholesaleQualified: this._activeSessionService.getWholesaleQualified(),
      autoship: this._autoshipService.createAutoshipRequest(checkoutComponentSettings),
      sponsorId: this.getSponsorId(checkoutComponentSettings),
      personalDiscountPercentage: personalDiscountPercentage
    };
    return orderRequest;
  }


  /**
   * @description this method will return the member id
   * based on userinfo or returning guest user
   * @date 2018-11-08
   * @private
   * @returns {number}
   * @memberof OrderService
   */
  private getMemberTitleId(checkoutComponentSettings: CheckoutComponentSettings): number {
    if (checkoutComponentSettings &&
      checkoutComponentSettings.userInfo) {
      return this._activeSessionService.getMemberTitleId();
    } else if (checkoutComponentSettings.checkoutInformation
      && checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
      return checkoutComponentSettings.checkoutInformation.retuningGuestUser.memberTitleId;
    }
  }

  /**
   * @description this method will return the member id
   * based on userinfo or returning guest user
   * @date 2018-11-08
   * @private
   * @returns {number}
   * @memberof OrderService
   */
  private getMemberId(checkoutComponentSettings: CheckoutComponentSettings): number {
    if (checkoutComponentSettings &&
      checkoutComponentSettings.userInfo) {
      return this._activeSessionService.getMemberId();
    } else if (checkoutComponentSettings.checkoutInformation
      && checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
      return checkoutComponentSettings.checkoutInformation.retuningGuestUser.memberId;
    }
  }

  /**
   * @description this method will return the member id
   * based on userinfo or returning guest user
   * @date 2018-11-08
   * @private
   * @returns {string}
   * @memberof OrderService
   */
  private getDistributorId(checkoutComponentSettings: CheckoutComponentSettings): string {
    if (checkoutComponentSettings &&
      checkoutComponentSettings.userInfo) {
      return this._activeSessionService.getDistributorId();
    } else if (checkoutComponentSettings.checkoutInformation
      && checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
      return checkoutComponentSettings.checkoutInformation.retuningGuestUser.distributorId;
    }
  }

  /**
   * @description this method will return the member id
   * based on userinfo or returning guest user
   * @date 2018-11-08
   * @private
   * @returns {string}
   * @memberof OrderService
   */
  private getUserId(checkoutComponentSettings: CheckoutComponentSettings): number {
    if (checkoutComponentSettings &&
      checkoutComponentSettings.userInfo) {
      return this._activeSessionService.getUserId();
    } else if (checkoutComponentSettings.checkoutInformation
      && checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
      return checkoutComponentSettings.checkoutInformation.retuningGuestUser.userId;
    }
  }

  /**
  * @description this method will return the member id
  * based on userinfo or returning guest user
  * @date 2018-11-08
  * @private
  * @returns {string}
  * @memberof OrderService
  */
  private getSponsorId(checkoutComponentSettings: CheckoutComponentSettings): string {
    if (checkoutComponentSettings &&
      checkoutComponentSettings.userInfo) {
      return this._activeSessionService.getSponsorId();
    } else if (checkoutComponentSettings.checkoutInformation
      && checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
      return checkoutComponentSettings.checkoutInformation.retuningGuestUser.sponsorId;
    }
  }

  /**
   * @description this method will be used to
   * load language code
   * @date 2018-08-21
   * @param {string} languageCode
   * @returns {string}
   * @memberof OrderService
   */
  getLanguageCode(checkoutComponentSettings: CheckoutComponentSettings): string {
    let languageShortCode = '';
    if (checkoutComponentSettings && checkoutComponentSettings.store
      && checkoutComponentSettings.store.languages && checkoutComponentSettings.store.languages.length > 0) {
      const storeLanguages = checkoutComponentSettings.store.languages;
      const language = storeLanguages.find(lang => lang.cultureName.toLowerCase()
        === checkoutComponentSettings.languageCode.toLowerCase());
      if (language) {
        languageShortCode = language.languageCode;
      }
    }
    return languageShortCode;
  }

  /**
   * @description this method will get order line items
   * @date 2018-07-31
   * @private
   * @param {CartSummaryComponentSettings} cartSummaryInformation
   * @returns {OrderLineItem[]}
   * @memberof OrderService
   */
  getOrderLineItems(cartSummaryInformation: CartSummaryComponentSettings): OrderLineItem[] {
    const lineItems: OrderLineItem[] = [];
    if (cartSummaryInformation.shoppingCart
      && cartSummaryInformation.shoppingCart.items
      && cartSummaryInformation.shoppingCart.items.length > 0) {
      let itemLineNumber = 0;
      cartSummaryInformation.shoppingCart.items.forEach((x: Item) => {
        let lineItemTax: TaxItems;
        if (cartSummaryInformation.orderTaxResponse
          && cartSummaryInformation.orderTaxResponse.cart
          && cartSummaryInformation.orderTaxResponse.cart.orderLineItems
          && cartSummaryInformation.orderTaxResponse.cart.orderLineItems.length > 0) {
          lineItemTax = cartSummaryInformation.orderTaxResponse
            .cart.orderLineItems.find(y => y.itemNumber === x.itemNumber);
        }
        const lineItem: OrderLineItem = {
          discountPercentage: x.discountPercentage,
          literature: x.literature,
          orderLineNumber: ++itemLineNumber,
          productId: x.productId,
          itemNumber: x.itemNumber,
          productName: x.displayName,
          unitRetailPrice: x.retailPrice,
          unitWholeSalePrice: x.wholesalePrice,
          unitPaidPrice: x.applicablePrice,
          unitCommissionablePrice: 0,
          importedMeasurementUnit: x.importedMeasurementUnit,
          revisionNumber: x.revisionNumber,
          taxRate: 0,
          unitTax: lineItemTax ? lineItemTax.salesTax : 0,
          unitTaxablePrice: lineItemTax ? lineItemTax.taxablePrice : 0,
          unitQualificationValue: x.CV ? x.CV : 0,
          quantity: x.quantity,
          freeshipping: false,
          fboEligible: x.fboEligible,
          downloadActivated: x.downloadableProduct,
          weight: x.weight,
          height: x.height,
          length: x.length,
          width: x.width,
          totalAmount: this._currencyPipe.getFormatedCurrency(x.applicablePrice * x.quantity),
          discountAmount: this._currencyPipe.getFormatedCurrency((parseFloat(x.retailPrice.toFixed(2)) * x.quantity) -
            (parseFloat(x.applicablePrice.toFixed(2)) * x.quantity)),
        };
        lineItems.push(lineItem);
      });
    }
    return lineItems;
  }


  /**
   * @description get shipping address
   * @date 2018-07-31
   * @private
   * @returns {Address}
   * @memberof OrderService
   */
  getShippingAddress(): Address {
    const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    if (checkoutInformation && checkoutInformation.shippingInformation &&
      checkoutInformation.shippingInformation.shippingAddress) {
      checkoutInformation.shippingInformation.shippingAddress.addressType = AddressType.SHIPPING;
      return checkoutInformation.shippingInformation.shippingAddress;
    }
  }

  /**
   * @description get billing address
   * @date 2018-07-31
   * @private
   * @returns {Address}
   * @memberof OrderService
   */
  private getBillingAddress(): Address {
    const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    if (checkoutInformation && checkoutInformation.paymentInformation &&
      checkoutInformation.paymentInformation.billingAddress) {
      checkoutInformation.paymentInformation.billingAddress.addressType = AddressType.BILLING;
      return checkoutInformation.paymentInformation.billingAddress;
    }
  }

  /**
   * @description thhis method will be used
   * to get all list of address
   * @date 2018-07-31
   * @private
   * @returns {Address[]}
   * @memberof OrderService
   */
  getAddresses(countries: Country[], states: State[]): Address[] {
    const addresses: Address[] = [];
    const shippingAddress = this.getShippingAddress();
    if (shippingAddress) {
      addresses.push(this.getShippingAddress());
    }
    const billingAddress = this.getBillingAddress();
    if (billingAddress) {
      addresses.push(billingAddress);
    }
    const pickupAddress = this.getPickupAddress(countries, states);
    if (pickupAddress) {
      addresses.push(pickupAddress);
    }
    return addresses;
  }

  /**
   * @description this method will
   * retrive shipping emthod pickup location address
   * @date 2018-07-31
   * @private
   * @returns {Address}
   * @memberof OrderService
   */
  getPickupAddress(countries: Country[], states: State[]): Address {
    const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    if (checkoutInformation.shippingInformation
      && checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup
      && checkoutInformation.shippingMethodInformation && checkoutInformation.shippingMethodInformation.shippingMethod) {
      return this._shippingMethodService.getPickupAddress(checkoutInformation.shippingMethodInformation.shippingMethod,
        states, countries);
    }
  }

  /**
   * @description this method will return price tier
   * @date 2018-07-31
   * @private
   * @param {CartSummaryComponentSettings} cartSummaryComponentSettings
   * @returns {string}
   * @memberof OrderService
   */
  getPriceTier(cartSummaryComponentSettings: CartSummaryComponentSettings): string {
    let priceTierName = '';
    if (cartSummaryComponentSettings &&
      cartSummaryComponentSettings.shoppingCart
      && cartSummaryComponentSettings.shoppingCart.items && cartSummaryComponentSettings.shoppingCart.items.length > 0) {
      priceTierName = cartSummaryComponentSettings.shoppingCart.items[0].priceTierName;
    }
    return priceTierName;
  }

  /**
   * @description
   * @date 2018-07-31
   * @private
   * @returns {string}
   * @memberof OrderService
   */
  getMemberEmail(checkoutComponentSettings: CheckoutComponentSettings): string {
    const checkoutInformation: CheckoutInformation = checkoutComponentSettings.checkoutInformation;
    return checkoutComponentSettings.userInfo ? checkoutComponentSettings.userInfo.email :
      checkoutInformation && checkoutInformation.personalInformation ? checkoutInformation.personalInformation.email :
        checkoutInformation && checkoutInformation.retuningGuestUser ? checkoutInformation.retuningGuestUser.email : '';
  }

  /**
   * To handle the obervable error response
   * @param  {Response|any} error
   */
  private handleErrorObservable(error: Response | any) {
    return Observable.throw(error);
  }
}
