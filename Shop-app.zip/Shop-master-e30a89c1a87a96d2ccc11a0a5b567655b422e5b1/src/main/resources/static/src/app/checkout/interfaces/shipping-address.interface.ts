import { AddressResponse } from '../../common/interfaces';

export interface ShippingAddress {
  memberId: number;
  id?: number;
  shipToName: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3?: string;
  addressLine4?: string;
  street?: string;
  houseNumber?: string;
  stateId?: string;
  countryId?: number;
  city: string;
  contactTypeID: number;
  defaultAddress?: boolean;
  county?: string;
  postalCode: string;
  name?: string;
  residential?: boolean;
  addressTypeId: number;
  phone?: string;
  addressVerified: boolean;
  loggedInUserId: number;
  responseCodes: AddressResponse[];
}
