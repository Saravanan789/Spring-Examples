import { QuickviewComponent } from '../../products/components/quickview.component';
import { ProductService } from '../../products/services/product.service';
import { Product } from '../../products/interfaces/product.interface';
import { Item } from '../../shared/models/item.model';
import { Cart } from '../../shared/models/cart.model';
import { CommonService } from '../../shared/services/common.service';
import { CartService } from '../../shared/services/cart.service';
import { Component, Input, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CacheService } from '../../shared/services/cache.service';
import { SwiperConfigInterface, SwiperComponent } from 'ngx-swiper-wrapper';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ImageType } from '../../products/enums/image-type.enum';
import * as _ from 'lodash';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { StoreConfig, StorePurchaseFlow } from '../../shared/interfaces/StoreConfig.interface';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { OnInit } from '@angular/core/src/core';
import { AppMessageService } from '../../app-message.service';
import { Country } from '../../shared/interfaces';
import { MemberLevel } from '../../shared/enums';
import { ActiveSessionService } from '../../shared/services';

@Component({
  selector: 'app-featured-products',
  templateUrl:
    '../templates/template3/views/featured-products.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/featured-products.component.less'
  ]
})
export class FeaturedProductsComponent implements OnDestroy, OnInit {
  isPersonalPurchaseFlow = false;
  personalPurchaseFlow: string = PurchaseFlow.PERSONAL;
  purchaseFlows: StorePurchaseFlow[] = [];
  store: StoreConfig;
  country: any;
  userLoggedIn: boolean;
  featuredProducts: Product[];
  errorMessages: any = [];
  productId = 1;
  selectedCurrency = 'USD';
  languageCode: string;
  storeId: number;
  groupId = 1;
  imageTypes: any = ImageType;
  @Input() hideWishList: boolean;
  @Input() isRecommended = false;
  hideWishListItems: boolean;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  config: any;
  isoCountryCode: string;
  hideItemsSubscription: any;
  productCount = 6;
  public featuredSliderConfig: SwiperConfigInterface = {
    slidesPerView: 3,
    touchRatio: 0.2,
    autoplay: true,
    navigation: true,
    breakpoints: {
      1200: {
        slidesPerView: 4,
        spaceBetween: 10
      },
      1024: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      640: {
        slidesPerView: 1,
        spaceBetween: 10
      }
    }
  };

  constructor(
    private _cacheService: CacheService,
    private _productService: ProductService,
    private _cartService: CartService,
    private _commonService: CommonService,
    private _router: Router,
    private _configurationService: ConfigurationService,
    private _appMessageService: AppMessageService,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.getStoreData();
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.country = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.isoCountryCode = this.country;
    this.getOptionsConfig();
    this.featuredSliderConfig.slidesPerView = this.config.options.slides;
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    if (this.isRecommended) {
      const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
      if (cartSession && cartSession.items && cartSession.items.length > 0) {
        const product: Item = cartSession.items[0];
        this.getProductGroupConfig(product);
      }
    } else {
      this.getFeaturedProducts(this.storeId);
    }
    this.wishListItemsBlock();
  }

  // TO:DO For Demo We are Adding we need to integrate from store
  private getProductGroupConfig(product: any) {
    this._commonService.getProductGroupConfig().subscribe((response: any[]) => {
      if (response) {
        const groupConfig: any = response;
        if (groupConfig) {
          this.getRecommendedProducts(this.storeId, product.productId, groupConfig.Recommended);
        }
      }
    });
  }

  // for Group Name we configured later will drive from Store Config
  private getOptionsConfig(): void {
    const featuredProductsConfig: any = [
      {
        countryCode: 'usa',
        options: {
          name: this.isRecommended ? 'featuredProducts.Recommended Products' : 'featuredProducts.Featured Products',
          slides: 3,
          quickviewEnabled: true
        }
      },
      {
        countryCode: 'can',
        options: {
          name: 'featuredProducts.OTHER GREAT BUSINESS BUILDING PRODUCTS',
          slides: 4,
          quickviewEnabled: true
        }
      }
    ];
    this.config = _.find(featuredProductsConfig, {
      countryCode: (this.country || 'usa')
    });
  }

  /**
   * @param  {Product} product
   * @returns void
   */
  navigateToProductDetail(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = product.categories[0];
    }
    if (product.customCatalogName && product.categories.length > 0) {
      selectedCategory = {
        productCategoryId: product.customCatalogId,
        categories: product.customCatalogName,
      };
    }
    if (selectedCategory) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
    }
    if (selectedCategory && selectedCategory.slug) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase()
        + '/products/' + selectedCategory.slug + '/' + product.slug]);
    } else {
      this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + product.slug]);
    }
  }

  /**
   * to display releated products
   * @param  {number} productId
   * @param  {number} storeid
   */
  getFeaturedProducts(storeId: number) {
    if (storeId) {
      this._productService
        .getFeaturedProducts(storeId, this.languageCode, this.productCount, 1, '')
        .subscribe(response => {
          if (response && response.length > 0) {
            this.featuredProducts = response;
            this.loadWishListProducts();
          }
        }, error => (this.errorMessages = <any>error));
    }

  }

  /**
   * Get Recommended Products
   * @param  {number} storeId
   * @param  {number} productId
   * @param  {number} groupId
   * @returns void
   */
  getRecommendedProducts(storeId: number, productId: number, groupId: number): void {
    if (storeId && productId) {
      this._productService
        .getRecommendedProducts(storeId, productId, groupId, this.languageCode, 10, 1, '')
        .subscribe(response => {
          if (response && response.length > 0) {
            this.featuredProducts = response;
            this.loadWishListProducts();
          }
        }, error => (this.errorMessages = <any>error));
    }
  }

  /**
  * To add an item
  * @param  {Product} product
  */
  addToWishList(product: Product): void {
    product.wishListItem = !product.wishListItem ? true : false;
    product.productQuantity = 1;
    const item: Item = this._cartService.convertProductToItemMappper(product);
    let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length >= 0 && wishListCart.sessionGuid) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .updateCart([item], CartTypes.WishlistCart, wishListCart)
        .subscribe((response: Cart) => {
          if (response) {
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }
        });
    } else if (product.wishListItem) {
      this._cartService
        .saveCart([item], CartTypes.WishlistCart)
        .subscribe((response: Cart) => {
          if (response) {
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }
        });
    } else if (!product.wishListItem) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .removeCartItem(wishListCart.sessionGuid, cartItem.id)
        .subscribe(response => {
          wishListCart = new Cart(wishListCart, this.store);
          this._cacheService.set(CacheKey.WishListSession, wishListCart);
          this._appMessageService.setWishListItems();
        });
    }
  }

  /**
   * @description load wishlist products
   * @memberof FeaturedProductsComponent
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      this.featuredProducts.forEach(x => {
        wishListCart.items.forEach(y => {
          if (y.productId === x.id) {
            x.wishListItem = true;
          }
        });
      });
    }
  }

  /**
   * @description
   * @memberof FeaturedProductsComponent
   */
  wishListItemsBlock(): void {
    if (this.hideWishList) {
      this.featuredSliderConfig.slidesPerView = 5;
    }
  }

  /**
   * @description method to get store data
   * @memberof FeaturedProductsComponent
   */
  getStoreData(): void {
    const storeConfig: StoreConfig = this._configurationService.getStoreData();
    if (storeConfig) {
      this.store = storeConfig;
      this.storeId = this.store.id;
      this.purchaseFlows = storeConfig.purchaseFlows;
      this.hasPurchaseFlow();
    }
  }

  /**
   * @description
   * @memberof FeaturedProductsComponent
   */
  hasPurchaseFlow(): void {
    if (this.purchaseFlows.length > 0 && (this.store.purchaseFlows !== null && this.store.purchaseFlows.length > 0)) {
      this.purchaseFlows.forEach(flow => {
        this.store.purchaseFlows.forEach((storeFlow: any) => {
          if (flow.id === storeFlow.id && flow.name === this.personalPurchaseFlow) {
            this.isPersonalPurchaseFlow = true;
          }
        });
      });
    }
  }

  ngOnDestroy(): void {
    // unsubscribe to avoid memory leaks
    if (this.hideItemsSubscription) {
      this.hideItemsSubscription.unsubscribe();
    }
  }

}
