export enum SponsorSearchType {
    SearchById = 1,
    SmartSearch = 2,
    SuggestSponsor = 3
}
