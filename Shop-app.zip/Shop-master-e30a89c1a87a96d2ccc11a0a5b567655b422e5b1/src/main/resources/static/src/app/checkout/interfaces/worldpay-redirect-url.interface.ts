export interface WorldPayRedirectUrl {
    successURL: string;
    failureURL: string;
    cancelURL: string;
}
