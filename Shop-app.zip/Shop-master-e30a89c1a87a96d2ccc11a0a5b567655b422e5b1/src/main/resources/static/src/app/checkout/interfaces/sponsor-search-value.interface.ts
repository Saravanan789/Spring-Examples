export interface SponsorSearchValue {
    id: number;
    criteria: string;
    property: string;
}
