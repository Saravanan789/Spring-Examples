export enum OrderType {
    ENROLLMENT = 1,
    PERSONAL = 2,
    AUTOSHIP = 3,
    OFFICEPOS = 4,
    EVENTPOS = 5,
    RETAIL = 6
}
