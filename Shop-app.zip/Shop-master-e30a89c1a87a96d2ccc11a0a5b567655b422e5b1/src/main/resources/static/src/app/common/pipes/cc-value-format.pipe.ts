import { Pipe, PipeTransform } from '@angular/core';
import { ConfigurationService } from '../../shared/services/configuration.service';
import 'intl';
import 'intl/locale-data/jsonp/en.js';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';

@Pipe({
    name: 'ccFormat'
})
export class CCPipe implements PipeTransform {
    store: StoreConfig;

    constructor(private _configurationService: ConfigurationService) {
        this.getStoreData();
    }

    getCCFormat(value: number, displayCC: boolean = true): string {
        const ccformat: string = this.store.ccNumberFormat;
        const commissionSymbol = this.store.ccSymbol;
        const decimalLength: number = this.store.ccNumberDecimals;
        const chunkDelimiter: string = this.store.thousandSeperator;
        const decimalDelimiter: string = this.store.decimalSeparator;
        const chunkLength = 3;
        if (value !== undefined && value !== null) {
            const result = '\\d(?=(\\d{' + chunkLength + '})+' + (decimalLength > 0 ? '\\D' : '$') + ')';
            // tslint:disable-next-line:no-bitwise
            const num = value.toFixed(Math.max(0, ~~decimalLength));
            const totalCommission = (decimalDelimiter ? num.replace('.', decimalDelimiter) : num).
            replace(new RegExp(result, 'g'), '$&' + chunkDelimiter);
            // return commisionValue+" "+units;
            let commissionableValue;
            switch (ccformat) {
                case 'CL':
                    commissionableValue = displayCC ? commissionSymbol + ' ' + totalCommission : totalCommission;
                    break;
                case 'CR':
                    commissionableValue = displayCC ? totalCommission + ' ' + commissionSymbol : totalCommission;
                    break;
                default:
                    commissionableValue = displayCC ? totalCommission + ' ' + commissionSymbol : totalCommission;
                    break;
            }
            return commissionableValue;
        }
    }
    transform(value: number, displayCC: boolean = true): string {
        return this.getCCFormat(value, displayCC);
    }

    getStoreData() {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result != null) {
            this.store = result;
        }
    }
}
