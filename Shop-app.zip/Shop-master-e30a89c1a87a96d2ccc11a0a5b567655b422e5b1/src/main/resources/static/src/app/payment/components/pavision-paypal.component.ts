import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { PaymentComponentSettings, PayvisionPaypalComponentSettings } from '../component-settings';
import { PayvisionService, PaymentService } from '../services';
import { ActiveSessionService } from '../../shared/services';
import { FormBuilder } from '@angular/forms';
import { PaymentRegistrationResponse, PayvisionRegistration } from '../interfaces';
import { PaymentStatus, PaymentProcessorAlias } from '../enums';
import { PaymentConstants } from '../constants';
import { LoaderService } from '../../shared/services/loader.service';
import { AppSectionSpinnerService } from '../../common/services/section-spinner.service';

/**
 * @description this component will provide payment functionality
 * for payvision paypal payment processor
 * @date 2018-08-22
 * @export
 * @class PayvisionPaypalComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-payvision-paypal',
    templateUrl: '../templates/template3/views/payvision-paypal.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/payvision-paypal.component.less'
    ]
})

export class PayvisionPaypalComponent implements OnInit {
    ppComponentSettings: PayvisionPaypalComponentSettings = new PayvisionPaypalComponentSettings();

    // Input variables
    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;
    // tslint:disable-next-line:no-input-rename
    @Input('enablePlaceOrder') enablePlaceOrder: boolean;
    // Output variables
    @Output() submitPayment = new EventEmitter<any>();

    constructor(
        private _payvisionService: PayvisionService,
        private _activeSessionService: ActiveSessionService,
        private _sectionSpinnerService: AppSectionSpinnerService,
        private _paymentService: PaymentService,
        private _formBuilder: FormBuilder) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof PayvisionPaypalComponent
     */
    loadDefaultSettings() {
        this.ppComponentSettings = Object.assign(this.ppComponentSettings, this.paymentComponentSettings);
        this.getPavisionPaypalPaymentForm();
    }

    /**
    * @description to get the Payment form
    * @date 2018-07-27
    * @memberof PayvisionPaypalComponent
    */
    getPavisionPaypalPaymentForm(): void {
        setTimeout(() => {
            this._sectionSpinnerService.start('paypal');
        }, 0);
        if (this.ppComponentSettings.store && this.ppComponentSettings.store.id) {
            this._payvisionService
                .getPayvisionForm(this.ppComponentSettings.store.id, this.payvisionPaypalRegistration())
                .subscribe((response: PaymentRegistrationResponse) => {
                    this.loadPayvisionPaypalForm(response);
                });
        }
    }

    /**
     * @description to load the Payvision Merchant Determined
     * Registration Checkout form
     * @date 2018-07-27
     * @param {string} checkoutId
     * @memberof PayvisionPaypalComponent
     */
    loadPayvisionPaypalForm(registrationResponse: PaymentRegistrationResponse): void {
        if (this.ppComponentSettings.checkoutInformation) {
            if (registrationResponse && registrationResponse.id) {
                const scriptSrc = registrationResponse.formUrl;
                window['wpwlOptions'] = this.getPayvisionPaypalOptions();
                $('#' + PaymentConstants.PayVisionScriptID).remove();
                const wpwl = window['wpwl'];
                if (wpwl && wpwl.checkout && wpwl.checkout.config
                    && wpwl.checkout.config.environmentConfig) {
                    const envConfig = wpwl.checkout.config.environmentConfig;
                    // tslint:disable-next-line:quotemark
                    if (document.querySelector("script[src*='" + envConfig.cacheVersion + "']")) {
                        // tslint:disable-next-line:quotemark
                        document.querySelector("script[src*='" + envConfig.cacheVersion + "']").remove();
                    }
                }
                const payvisionScript = document.createElement('script');
                payvisionScript.id = PaymentConstants.PayVisionScriptID;
                payvisionScript.src = scriptSrc + '?checkoutId=' + registrationResponse.id;
                payvisionScript.type = 'text/javascript';
                document.head.appendChild(payvisionScript);
                const payvisionForm = document.createElement('form');
                payvisionForm.setAttribute('action', registrationResponse.paymentUrl);
                payvisionForm.setAttribute('class', 'paymentWidgets');
                payvisionForm.setAttribute('data-brands', 'PAYPAL');
                payvisionForm.setAttribute('data-brands-e', 'VISA MASTER AMEX PAYPAL IDEAL');
                document.body.appendChild(payvisionForm);
                window['wpwlOptions'] = window['wpwlOptions'] || {};
                jQuery('form.paymentWidgets').appendTo('#payPalScript');
            }
        }
        setTimeout(() => {
            this.paymentComponentSettings.paymentMethodTypeForm.enable();
            this._sectionSpinnerService.stop('paypal');
        }, 6000);
    }

    /**
     * @description mapping payvision paypal options
     * here we used any type
     * @date 2018-07-27
     * @memberof PayvisionPaypalComponent
     */
    private getPayvisionPaypalOptions(): any {
        if (this.ppComponentSettings.checkoutInformation.shippingInformation) {

            // Reason we any Type here is we dont have chance
            // to write to interface for payvison object
            const payvisionPaypalOptions: any = {
                style: 'plain',
                onReady: function () {
                    // $('form').attr('target', 'iframeRes');
                }
            };
            return payvisionPaypalOptions;
        }
    }

    /**
    * @description preparing the Payvision Registration
    * checkout form request
    * @date 2018-07-27
    * @returns {PayvisionRegistration}
    * @memberof PayvisionPaypalComponent
    */
    payvisionPaypalRegistration(): PayvisionRegistration {
        const checkoutInformation = this.ppComponentSettings.checkoutInformation;
        if (checkoutInformation && checkoutInformation.orderDetails) {
            const payvisionRegistration: PayvisionRegistration = {
                countryCode: this.ppComponentSettings.isoCountryCode.toUpperCase(),
                customerId: this._paymentService.getCustomerId(),
                storeId: this.ppComponentSettings.store.id,
                orderTypeId: this._activeSessionService.getOrderTypeId(),
                paymentMethodType: this.ppComponentSettings.paymentMethodTypes.PayPal,
                currencyCode: this.ppComponentSettings.store.currencyCode,
                orderReferenceId: checkoutInformation.orderDetails.id,
                paymentRequestModel: {
                    createRegistartion: false,
                    webOrderId: checkoutInformation.orderDetails.webOrderId
                },
                paymentCallBackUrlModel: {
                    webOrderId: checkoutInformation.orderDetails.webOrderId,
                    cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
                    failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
                    successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
                }
            };
            return payvisionRegistration;
        }
    }

    /**
    * @description this method will return current window url
    * @date 2018-08-13
    * @private
    * @returns {string}
    * @memberof PayvisionPaypalComponent
    */
    private getCurrentWindowUrl(): string {
        const currentWindowURL: string = window.location.origin + '/' + this.ppComponentSettings.isoCountryCode +
            '/' + this.ppComponentSettings.languageCode + '/checkout/payment/'
            + PaymentProcessorAlias.PAYVISIONPAYPAL.toLowerCase() + '/';

        return currentWindowURL;
    }
}
