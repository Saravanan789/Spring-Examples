export interface PayvisionRegistrationRequest {
    createRegistartion: boolean;
    webOrderId?: string;
}
