import { PersonalInfo } from './personal-info.interface';
import { Order } from './order.interface';
import { Cart } from '../../shared/models';
import { SponsorInformation } from './sponsor-information.interface';

export interface EnrollInfo {
    personalInfo: PersonalInfo;
    orderInfo: Order;
    shoppingCartInfo: Cart;
    documents?: Document;
    sponsorInfo?: SponsorInformation;
    sponsorId?: string;
    isSuccess?: boolean;
    error?: any;
    ipAddress?: string;
    statusCode?: string;
    validations?: any[];
}
