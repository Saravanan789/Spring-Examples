import { OnInit, Component, Input, Output, EventEmitter } from '@angular/core';
import { PaymentComponentSettings, MoneyOrderComponentSettings } from '../component-settings';
import { AppMessageService } from '../../app-message.service';
import { Address } from '../../common/interfaces';
import { AddressComponentSettings } from '../../common/component-settings';
import { environment } from '../../../environments/environment';
import { PaymentInformation } from '../../checkout/interfaces';

/**
 *
 *
 * @export
 * @class MoneyOrderComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-moneyorder',
    templateUrl: '../templates/template3/views/money-order.component.html',
    styleUrls: ['../templates/template3/themes/default/less/money-order.component.less']
})

export class MoneyOrderComponent implements OnInit {

    moneyOrderSettings: MoneyOrderComponentSettings = new MoneyOrderComponentSettings();

    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;
    // tslint:disable-next-line:no-input-rename
    @Input('enablePlaceOrder') enablePlaceOrder: boolean;

    // Output variables
    @Output() submitPayment = new EventEmitter<any>();

    constructor(
        private _appMessageService: AppMessageService,
    ) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
       * @description Load Default shipping Settings
       * for the current user
       * @date 2018-08-14
       * @memberof MoneyOrderComponent
       */
    loadDefaultSettings(): void {
        this.moneyOrderSettings = Object.assign(this.moneyOrderSettings, this.paymentComponentSettings);
        const checkoutInformation = this.moneyOrderSettings.checkoutInformation;
        this.moneyOrderSettings.shippingAddress = checkoutInformation && checkoutInformation.shippingInformation &&
            checkoutInformation.shippingInformation.shippingAddress ? checkoutInformation.shippingInformation.shippingAddress : null;
        this.moneyOrderSettings.viewBillingAddress = true;
        if (this.moneyOrderSettings.selectedPaymentMethod.billingAddressRequired) {
            this.moneyOrderSettings.moneyOrderBillingSchemaUrl = this.moneyOrderSettings.isoCountryCode
                + '-billing-schema-form.json';
        }
    }

    /**
    * on click of checkbox (same as shipping address) this method triggers
    * @date 2018-08-14
    * @param {*} event
    * @memberof MoneyOrderComponent
    */
    showBillingAddress(event: any): void {
        const target = event.target;
        if (target.checked) {
            this.useShippingAsBilling(true);
            this.moneyOrderSettings.viewBillingAddress = false;
            this.moneyOrderSettings.shippingAsBilling = true;
            this.moneyOrderSettings.billingAddress = null;
        } else {
            this.useShippingAsBilling(false);
            this.moneyOrderSettings.viewBillingAddress = true;
            this.moneyOrderSettings.shippingAsBilling = false;
        }
    }

    /**
     * sets shippingAsBilling value
     * @date 2018-08-14
     * @private
     * @param {Address} shippingAddress
     * @param {boolean} useShipping
     * @memberof MoneyOrderComponent
     */
    private useShippingAsBilling(useShipping: boolean): void {
        if (this.moneyOrderSettings.selectedPaymentMethod.billingAddressRequired) {
            if (useShipping) {
                this.moneyOrderSettings.viewBillingAddress = false;
                this.moneyOrderSettings.shippingAsBilling = true;
                this.moneyOrderSettings.billingAddress = this.constructBillingAddress();
            } else {
                this.moneyOrderSettings.shippingAsBilling = false;
            }
        } else {
            this.moneyOrderSettings.viewBillingAddress = false;
        }
    }

    /**
    * gets billing address by condition
    * @date 2018-08-14
    * @returns {Address}
    * @memberof MoneyOrderComponent
    */
    getBillingAddressByCondition(): Address {
        if (this.moneyOrderSettings.shippingAsBilling) {
            return this.moneyOrderSettings.shippingAddress;
        }
        return this.moneyOrderSettings.billingAddress;

    }
    /**
         * @description constructing billing address
         * @date 2018-08-14
         * @returns {Address}
         * @memberof MoneyOrderComponent
         */
    constructBillingAddress(): Address {
        if (this.moneyOrderSettings.selectedPaymentMethod.billingAddressRequired) {
            const shippingAddress = this.getBillingAddressByCondition();
            const country = shippingAddress ? this.moneyOrderSettings.countries
                .find(z => z.isocodeThree.toUpperCase() === shippingAddress.country.toUpperCase()) : null;
            if (shippingAddress) {
                const billingAddress = {
                    firstName: shippingAddress.firstName || shippingAddress.name,
                    lastName: shippingAddress.lastName,
                    addressLine1: shippingAddress.addressLine1,
                    addressLine2: shippingAddress.addressLine2,
                    city: shippingAddress.city,
                    country: shippingAddress.country,
                    countryCode: shippingAddress.country,
                    countryCodeTwo: country ? country.isocodeTwo : '',
                    state: shippingAddress.state,
                    zip: shippingAddress.zip,
                    phone: shippingAddress.phone,
                    name: shippingAddress.firstName || shippingAddress.name,
                    postalCode: shippingAddress.zip || shippingAddress.postalCode
                };
                return billingAddress;
            }
        }
        return null;
    }

    /**
     * Process payment on click of continue (from billing schema form)
     * @date 2018-08-14
     * @param {AddressComponentSettings} address
     * @memberof MoneyOrderComponent
     */
    getBillingAddressInfo(addressComponentSettings: AddressComponentSettings): void {
        if (addressComponentSettings) {
            this.moneyOrderSettings.billingAddress = addressComponentSettings.address;
        }
    }

    /**
    * submit Money order - saving Money order
    * @date 2018-08-14
    * @memberof MoneyOrderComponent
    */
    submitMoneyOrder(): void {
        if (this.moneyOrderSettings.selectedPaymentMethod.billingAddressRequired) {
            // onclick of continue address will get submitted.
            this._appMessageService.setSubmitAddress(true);
        }
        this.submitPaymentInformation();
    }

    /**
   * @description
   * @private
   * @date 2018-08-14
   * @param {PayvisionRegistrationResponse} payvisionRegistrationResponse
   * @returns {PaymentInformation}
   * @memberof MoneyOrderComponent
   */
    private getPaymentInformation(): PaymentInformation {
        const paymentInformation: PaymentInformation = {
            paymentToken: null,
            billingAddress: this.constructBillingAddress(),
            isEnrollment: false,
            selectedPaymentMethod: this.moneyOrderSettings.selectedPaymentMethod,
            isCompleteRedirection: false,
        };
        return paymentInformation;
    }


    /**
     * Save payment information to checkout information
     * @date 2018-08-14
     * @memberof MoneyOrderComponent
     */
    submitPaymentInformation() {
        this.moneyOrderSettings.paymentInformation = this.getPaymentInformation();
        this.submitPayment.emit(this.moneyOrderSettings.paymentInformation);
    }

}
