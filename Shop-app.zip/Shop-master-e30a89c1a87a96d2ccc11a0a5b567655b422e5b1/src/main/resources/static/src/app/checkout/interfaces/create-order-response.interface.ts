import { OrderResponse } from './order-response.interface';

export interface CreateOrderResponse {
    uuid: string;
    request: string;
    response: string;
    createdDate: string;
    status: string;
    location: string;
    responseModel: OrderResponse;
}
