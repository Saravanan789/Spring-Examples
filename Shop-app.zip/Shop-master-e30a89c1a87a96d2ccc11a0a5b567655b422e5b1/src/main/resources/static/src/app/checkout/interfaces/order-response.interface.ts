export interface OrderResponse {
    validations: any;
    fieldErrors: any[];
    orderNumber: string;
    paymentId: number;
    orderStatusId: number;
    orderPaymentStatus: string;
    paymentToken: string;
    webOrderId: string;
    redirectUrl: string;
    paymentTransactionNo: string;
    redirect: boolean;
    autoshipResponse: any;
    transactionId: string;
    id: number;
    success: boolean;
}
