import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { Cart } from '../../shared/models';
import { environment } from '../../../environments/environment';
import { DeliveryOptionType } from '../enums';
import { PurchaseFlow, MemberLevel } from '../../shared/enums';
import {
    CheckoutInformation, PaymentInformation,
    ShippingMethod, ShippingInformation, ShippingMethodInformation, Order, SponsorInformation, PersonalInformation, Autoship
} from '../interfaces';
import { Address } from '../../common/interfaces';
import { Subscription } from 'rxjs/Subscription';
import { CookieService } from 'ngx-cookie-service';

export class OrderSummaryComponentSettings extends BaseSettings {
    orderDetails: Order;
    webOrderId: string;
    memberId: number;
    deliveryOptions = DeliveryOptionType;
    checkoutInformation: CheckoutInformation;
    paymentInformation: PaymentInformation;
    shippingInformation: ShippingInformation;
    shippingMethodInformation: ShippingMethodInformation;
    shippingMethod: ShippingMethod;
    totalSavings: number;
    memberTitle = MemberLevel;
    memberTitleId: number = MemberLevel.RETAIL;
    cardType: string;
    purchaseFlow: PurchaseFlow;
    billingAddress: Address;
    shippingAddress: Address;
    deliveryOptionType: DeliveryOptionType;
    customerName: string = environment.customerName;
    shoppingCart: Cart;
    translationValues: any;
    s3BucketUrl = environment.cdnURL;
    autoshipCart: Cart;
    autoshipDetails: Autoship;
    autoshipShippingMethodDetails: ShippingMethod;
    autoshipShippingAddressDetails: Address;
    isAutoshipEnabled: boolean;
    productId: number;
    failedStatus: boolean;
    status: boolean;
    cartSubscription: Subscription;
    sponsorInformation: SponsorInformation;
    currentDate: Date = new Date();
    personalInformation: PersonalInformation;
    clearCartInProgress = false;
    autoshipDate: Date;
    phoneNumberFormat: string;
    gstTax = 0;
    pstTax = 0;
    cookieService: CookieService = new CookieService(document);
    cartStatus = {
        clearCart: false,
        clearAutoshipCart: false
    };
}
