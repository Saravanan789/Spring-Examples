import {Pipe, PipeTransform} from '@angular/core';
import * as moment from 'moment';
import { ConfigurationService } from '../../shared/services/configuration.service';
import 'intl';
import 'intl/locale-data/jsonp/en.js';

// under systemjs, moment is actually exported as the default export, so we account for that
const momentConstructor: (value?: any) => moment.Moment = (<any>moment).default || moment;

@Pipe({ name: 'dateFormat' })
export class DateFormatPipe implements PipeTransform {
    store: any;

    constructor(private _configurationService: ConfigurationService) {
        this.getStoreData();
    }

  transform(value: Date | moment.Moment | string | number, format: string): string {
    if (!value) {
        return '';
    }
    return momentConstructor(value).format(this.store.dateFormat);
  }

  getStoreData() {
       const result = this._configurationService.getStoreData();
        if (result != null) {
            this.store = result;
        }
    }
}
