import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { ApiUrlConstants } from './common/constants/api.constants';

@Injectable()
export class AppService {
    token: any;
    constructor(
        private _http: Http
    ) { }

    /**
     * get user Specific Action Center Documents
     */
    getUserSpecificDocuments(memberTypeId: number, memberId: number, portal: number): Promise<any> {
        return this._http.get(ApiUrlConstants.accountApiUrl + '/documents?memberId=' + memberId + '&portal=' + portal)
            .toPromise()
            .then((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
       * To handle the obervable error response
       * @param  {Response|any} error
       */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error.message || error);
    }
}
