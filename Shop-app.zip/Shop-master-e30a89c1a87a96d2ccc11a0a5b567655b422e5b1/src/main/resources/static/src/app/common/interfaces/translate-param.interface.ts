export interface TranslateParam {
    errorGuid: string;
}
