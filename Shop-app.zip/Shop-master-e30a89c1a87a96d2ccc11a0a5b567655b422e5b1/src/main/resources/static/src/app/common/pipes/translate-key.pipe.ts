import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'translateKey'
})
export class TranslateKey implements PipeTransform {

    /**
     * @param  {Array<any>} items
     * @param  {predicate} filterOptions
     * @returns Array<any>
     */
    transform(translateText: string, param: any): string {
        if (translateText && translateText.length > 0) {
            if (param) {
                if (translateText.match(/(\|\|{1}\w+\|\|{1})/g)) {
                    translateText.match(/(\|\|{1}\w+\|\|{1})/g)
                        .map((x, y) => {
                            translateText = translateText.replace(x, param[x.substr(2, x.length - 4)]);
                        });
                }
            }
            if (translateText.match(/(\.)(?=\w)/)) {
                return translateText.split(/(\.)(?=\w)/).slice(2).join('');
            } else {
                return translateText;
            }
        } else {
            return translateText;
        }
    }
}
