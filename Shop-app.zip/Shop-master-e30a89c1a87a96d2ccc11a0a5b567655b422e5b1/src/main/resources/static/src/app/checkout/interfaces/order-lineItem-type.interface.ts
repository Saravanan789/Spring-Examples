export interface OrderLineItemType {
    id: number;
    name: string;
    description: string;
}

