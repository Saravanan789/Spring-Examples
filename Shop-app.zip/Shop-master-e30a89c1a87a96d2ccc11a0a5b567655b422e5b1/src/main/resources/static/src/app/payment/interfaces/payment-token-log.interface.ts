import { PaymentMethod } from './payment-method.interface';
import { Address } from '../../common/interfaces';

export interface PaymentTokenResponseLog {
    token: string;
    customerId: any;
    customerProfileID: any;
    paymentMethod: PaymentMethod;
    reusable: boolean;
    billingAddress: Address;
    billingAddressId: string;
    countryCode: string;
    storeId: number;
    memberId: any;
    addressVerified?: boolean;
}
