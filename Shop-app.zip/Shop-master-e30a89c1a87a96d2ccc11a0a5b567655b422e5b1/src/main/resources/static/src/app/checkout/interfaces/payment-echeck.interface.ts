/**
 * Used at Checkout information
 *
 * @export
 * @interface PaymentEcheck
 */
export interface PaymentEcheck {
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    accountType: string;
    mecTransactionID: string;
    nameOnBankAccount: string;
    customMessage: string;
    reusable: boolean;
    eCheckID: number;
    email: string;
    phone: string;
}
