import { AbstractControl } from '@angular/forms';


export class CustomValidator {


    /**
     * @description
     * @date 2018-11-16
     * @static
     * @returns
     * @memberof CustomValidator
     */
    static checkIfAccountSelected() {
        return (control: AbstractControl) => {
            if (+control.value === -1) {
                return { 'required': true };
            } else {
                return null;
            }
        };
    }

}
