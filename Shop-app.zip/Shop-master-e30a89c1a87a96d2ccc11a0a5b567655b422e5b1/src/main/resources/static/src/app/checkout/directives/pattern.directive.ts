import { Directive, Input, OnChanges, SimpleChanges } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator, ValidatorFn, Validators } from '@angular/forms';

/** A hero's name can't match the given regular expression */
export function regExpPatternValidator(regExp: RegExp): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const txtvalue: string = control.value;
    const no = txtvalue ? regExp.test(txtvalue) : true;
    return no ? null : { 'patternValidator': { txtvalue } };
  };
}

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[patternValidator]',
  providers: [{ provide: NG_VALIDATORS, useExisting: PatternValidatorDirective, multi: true }]
})
export class PatternValidatorDirective implements Validator, OnChanges {

  @Input() patternValidator: string;
  private valFn = Validators.nullValidator;

  ngOnChanges(changes: SimpleChanges): void {
    const change = changes['patternValidator'];
    if (change) {
      const val: string | RegExp = change.currentValue;
      const re = val instanceof RegExp ? val : new RegExp(val);
      this.valFn = regExpPatternValidator(re);
    } else {
      this.valFn = Validators.nullValidator;
    }
  }

  validate(control: AbstractControl): { [key: string]: any } {
    return this.valFn(control);
  }
}
