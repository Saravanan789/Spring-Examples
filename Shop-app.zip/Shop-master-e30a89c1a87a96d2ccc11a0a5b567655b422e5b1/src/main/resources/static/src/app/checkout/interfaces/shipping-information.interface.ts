import { Address } from '../../common/interfaces';
import { DeliveryOptionType } from '../enums';

export interface ShippingInformation {
    shippingAddress: Address;
    deliveryOptionType: DeliveryOptionType;
}
