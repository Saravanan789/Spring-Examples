import { PaymentComponentSettings } from './payment.model';
import { PaymentEcheckRequest, PersonalCheck } from '../interfaces/payment-echeckrequest.interface';
import { FormGroup } from '@angular/forms';
import { AccountType } from '../enums/echeck-accounttypes.enum';
import { Address } from '../../common/interfaces';
import { ValidateEcheckRequest } from '../interfaces/validate-echeck-request.interface';
import { PaymentEcheck } from '../interfaces';
import { PaymentInformation } from '../../checkout/interfaces';


export class EcheckComponentSettings extends PaymentComponentSettings {
    accountTypes: AccountType[];
    paymentCheck: PaymentEcheck;
    echeckSchemaUrl: string;
    echeckForm: FormGroup;
    echeckRequest: PaymentEcheckRequest;
    isSaveEcheckForFuture: boolean;
    isPaymentWithSavedEcheck: boolean;
    isEcheckSubmitted: boolean;
    echeckErrorMessage: string;
    selectedEcheck: PersonalCheck;
    savedEchecks: PersonalCheck[];
    validatePersonalCheckRequest: ValidateEcheckRequest;
    savePersonalCheckRequest: PersonalCheck;
    billingAddress: Address;
    viewBillingAddress: boolean;
    shippingAsBilling: boolean;
    shippingAddress: Address;
    paymentInformation: PaymentInformation;
    phoneNumberFormat: string;
}

