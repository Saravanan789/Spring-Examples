
export interface AutoshipPayment {
    id?: number;
    paymentInstrumentId: string;
    sortOrder: number;
    shippingAddressId: number;
    createdBy?: number;
    updatedBy?: number;

}
