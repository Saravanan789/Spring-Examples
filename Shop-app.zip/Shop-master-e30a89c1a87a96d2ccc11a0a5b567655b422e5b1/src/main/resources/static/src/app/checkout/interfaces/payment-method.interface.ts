export interface PaymentMethod {
  prepaid: string;
  expiryYear: string;
  cardProductTypeDescContactless: string;
  countryCode: string;
  type: string;
  cardSchemeType: string;
  cardSchemeName: string;
  cardType: string;
  cardProductTypeDescNonContactless: string;
  maskedCardNumber: string;
  cardClass: string;
  name: string;
  expiryMonth: string;
  cardIssuer: string;
  billingAddressRequired: boolean;
}
