import { RelatedProductsComponent } from './components/related-products.component';
import { FieldFilterPipe } from './pipes/field-filter.pipe';

import { OrderByPipe } from './pipes/order-by.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { FilterPipe } from './pipes/filter.pipe';
import { HighlightSearch } from './pipes/highlight.pipe';
import { SafeHtmlPipe } from './pipes/safe-html.pipe';
import { SingleImageFilterPipe } from './pipes/single-image.filter.pipe';
import { ImageTypeFilterPipe } from './pipes/image-type-filter.pipe';
import { UniqueByPipe } from './pipes/unique-by.pipe';
import { SafeUrlPipe } from './pipes/safe-url.pipe';
import { CurrencyPipe } from './pipes/currency-format.pipe';
import { DateFormatPipe } from './pipes/date-format.pipe';
import { CCPipe } from './pipes/cc-value-format.pipe';
import { OnlyNumberDirective } from './directives/only-number.directive';
import { SlimScrollDirective } from './directives/slimscroll.directive';
import { PricePopoverComponent } from './components/price-popover.component';
import { TranslateKey } from './pipes/translate-key.pipe';
import { ChildImageFilterPipe } from './pipes/child-image-filter.pipe';
import { WishlistProductsComponent } from './components/wishlist-products.component';
import { FeaturedProductsComponent } from './components/featured.component';
import { RecentProductsComponent } from './components/recent-products.component';
import { HasPrivilegeDirective } from './directives/authorize.directive';
import { SortPipe } from './components/sort.pipe';
import { EllipsisPipe } from './pipes/ellipsis.pipe';
import { ImgSrcDirective } from './directives/img-src.directive';
import { FocusDirective } from './directives/focus.directive';
import { NoImageDirective } from './directives/no-image.directive';
import { ClickOutsideDirective } from './directives/click-outside.directive';
import { AccordianDirective } from './directives/accordian.directive';
import { AddressNewComponent } from './components';
import { DistributorIdFormat } from './pipes/distributor-id-format.pipe';
import { StaggerDirective } from './directives/stagger.component';
import { CardNavigationDirective } from './directives/card-navigation.directive';
import { FooterLearnMoreDirective } from './directives/footer-learn-more.directive';
import { AppSectionSpinnerComponent } from './components/app-section-spinner';
import { AppModalDirective } from './directives/app-modal.directive';
import { CustomMaskTextboxComponent, CustomSelectWidgetComponent } from './widgets';
import { DateFormatDirective } from './directives/validate-date-format';
import { ErrorGuidComponent } from './components/error-guid.component';
export class AppCommonModuleConstants {
    static MODULE_COMPONENTS = [
        OrderByPipe,
        SearchPipe,
        FilterPipe,
        HighlightSearch,
        SafeHtmlPipe,
        ImageTypeFilterPipe,
        SingleImageFilterPipe,
        UniqueByPipe,
        OnlyNumberDirective,
        SafeUrlPipe,
        SlimScrollDirective, FieldFilterPipe, TranslateKey,
        CurrencyPipe,
        DateFormatPipe,
        CCPipe, ChildImageFilterPipe, FocusDirective,
        TranslateKey, PricePopoverComponent,
        WishlistProductsComponent, FeaturedProductsComponent, ImgSrcDirective,
        RecentProductsComponent, RelatedProductsComponent, HasPrivilegeDirective,
        SortPipe, EllipsisPipe, NoImageDirective, ClickOutsideDirective,
        AccordianDirective,
        AddressNewComponent,
        CustomSelectWidgetComponent,
        DistributorIdFormat,
        StaggerDirective ,
        CardNavigationDirective,
        FooterLearnMoreDirective, AppSectionSpinnerComponent,AppModalDirective,
        CustomMaskTextboxComponent,
        DateFormatDirective,
        ErrorGuidComponent
    ];
}
