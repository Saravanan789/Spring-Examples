import { Component, OnInit, Input} from '@angular/core';
import { CacheService, ActiveSessionService } from '../../shared/services';
import { PaymentService, WorldpayXMLService } from '../services';
import { PaymentComponentSettings, WorldpayXMLPaypalComponentSettings } from '../component-settings';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Country } from '../../shared/interfaces';
import { PaymentStatus, PaymentProcessorAlias } from '../enums';
import { Address } from '../../common/interfaces';
import {
    WorldpayXMLRegistration, PaymentRegistrationResponse,
    WorldpayXMLPaymentService, PaymentCallBackUrl
} from '../interfaces';
import { CheckoutInformation } from '../../checkout/interfaces';
import { PaymentConstants } from '../constants';
import { Cart } from '../../shared/models';
declare let WPCL: any;

/**
 * @description this component provides payment functionality
 * with worldpay provider and will load base settings from parent
 * payment component like store and countries
 * @date 2018-07-26
 * @export
 * @class WorldpayComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-worldpay-xml-paypal',
    templateUrl: '../templates/template3/views/worldpay-xml-paypal.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/worldpay-xml-paypal.component.less'
    ]
})

export class WorldPayXMLPaypalComponent implements OnInit {
    wxmlpplComponentSettings: WorldpayXMLPaypalComponentSettings = new WorldpayXMLPaypalComponentSettings();

    // Input variables
    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;

    constructor(
        private _activeSessionService: ActiveSessionService,
        private _cacheService: CacheService,
        private _paymentService: PaymentService,
        private _worldpayXMLService: WorldpayXMLService) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
    * @description Load Default shipping Settings
    * for the current user
    * @date 2018-07-20
    * @memberof WorldPayComponent
    */
    loadDefaultSettings() {
        this.wxmlpplComponentSettings = Object.assign(this.wxmlpplComponentSettings, this.paymentComponentSettings);
        this.wxmlpplComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        if (cartSession && cartSession.items && cartSession.items.length > 0) {
            this.wxmlpplComponentSettings.shoppingCart = new Cart(cartSession, this.wxmlpplComponentSettings.store);
        }
        this.paymentComponentSettings.paymentMethodTypeForm.enable();
    }


    /**
    * @description to get the Payment form
    * @date 2018-07-27
    * @memberof WorldPayComponent
    */
    getWorldplayXMLPaymentForm(): void {
        this.paymentComponentSettings.paymentMethodTypeForm.disable();
        this._worldpayXMLService
            .getWorldpayXMLForm(this.wxmlpplComponentSettings.store.id, this.getWorldpayXMLRegistrationRequest())
            .subscribe((response: PaymentRegistrationResponse) => {
                this.paymentComponentSettings.paymentMethodTypeForm.enable();
                if (response && response.paymentUrl) {
                    window.location.href = decodeURIComponent(encodeURIComponent(response.paymentUrl));
                }
            }, (error: any) => {
                this.paymentComponentSettings.paymentMethodTypeForm.enable();
            });
    }

    /**
    * @description to load the Worldplay XML
    * Registration Checkout form
    * @date 2018-07-27
    * @memberof WorldPayComponent
    */
    loadWorldplayXMLForm(registrationResponse: PaymentRegistrationResponse): void {
        if (this.wxmlpplComponentSettings.checkoutInformation && WPCL
            && registrationResponse && registrationResponse.paymentUrl) {
            const customOptions = {
                iframeHelperURL: window.location.href,
                iframeBaseURL: window.location.origin,
                iframeIntegrationID: 'ifr',
                url: registrationResponse.paymentUrl,
                target: 'iframeRes',
                type: 'iframe',
                inject: 'immediate',
            };
            const libraryObject = new WPCL.Library();
            if (libraryObject) {
                libraryObject.setup(customOptions);
            }
        }
        setTimeout(() => {
            this.paymentComponentSettings.paymentMethodTypeForm.enable();
        }, 2000);
    }

    /**
     * @description preparing the WorldPay XML Registration
     * checkout form request
     * @date 2018-07-27
     * @returns {WorldpayXMLRegistration}
     * @memberof WorldPayComponent
     */
    getWorldpayXMLRegistrationRequest(): WorldpayXMLRegistration {
        const checkoutInformation: CheckoutInformation = this.wxmlpplComponentSettings.checkoutInformation;
        if (checkoutInformation && checkoutInformation.orderDetails) {
            const worldpayXMLRegistration: WorldpayXMLRegistration = {
                countryCode: this.wxmlpplComponentSettings.isoCountryCode.toUpperCase(),
                customerId: this._paymentService.getCustomerId(),
                storeId: this.wxmlpplComponentSettings.store.id,
                orderTypeId: this._activeSessionService.getOrderTypeId(),
                paymentMethodType: this.wxmlpplComponentSettings.paymentMethodTypes.PayPal,
                currencyCode: this.wxmlpplComponentSettings.store.currencyCode,
                orderReferenceId: checkoutInformation.orderDetails.id,
                paymentRequestModel: {
                    createRegistartion: true,
                    webOrderId: checkoutInformation.orderDetails.webOrderId
                },
                paymentCallBackUrlModel: this.getPaymentCallBackURLModel(checkoutInformation),
                billingAddress: this.getBillingAddress(),
                paymentServiceModel: this.getPaymentServiceModel(checkoutInformation)
            };
            return worldpayXMLRegistration;
        }
    }

    /**
     * @description this method will return payment call urls
     * @date 2018-08-22
     * @private
     * @returns {PaymentCallBackUrl}
     * @memberof WorldPayXMLComponent
     */
    private getPaymentCallBackURLModel(checkoutInformation: CheckoutInformation): PaymentCallBackUrl {
        const paymentCallBackUrlModel: PaymentCallBackUrl = {
            webOrderId: checkoutInformation.orderDetails.webOrderId,
            cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
            failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
            successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
        };
        return paymentCallBackUrlModel;
    }

    /**
     * @description this method will return world pay xml
     * request model
     * @date 2018-08-21
     * @private
     * @returns {WorldpayXMLPaymentService}
     * @memberof WorldPayXMLComponent
     */
    private getPaymentServiceModel(checkoutInformation: CheckoutInformation): WorldpayXMLPaymentService {
        const userEmail: string = this.wxmlpplComponentSettings.userInfo ? this.wxmlpplComponentSettings.userInfo.email :
            checkoutInformation && checkoutInformation.personalInformation
                ? checkoutInformation.personalInformation.email : '';
        let description = '';
        if (this.wxmlpplComponentSettings.shoppingCart && this.wxmlpplComponentSettings.shoppingCart.items
            && this.wxmlpplComponentSettings.shoppingCart.items.length > 0) {
            description = this.wxmlpplComponentSettings.shoppingCart.items[0].name;
        }

        const paymentServiceModel: WorldpayXMLPaymentService = {
            submit: {
                order: {
                    orderCode: checkoutInformation.orderDetails.webOrderId,
                    description: description,
                    amount: {
                        currencyCode: this.wxmlpplComponentSettings.store.currencyCode,
                        exponent: this.wxmlpplComponentSettings.store.numberDecimals
                    },
                    paymentMethodMask: {
                        include: {
                            code: PaymentConstants.paymentMethodMaskCode
                        }
                    },
                    shopper: {
                        shopperEmailAddress: userEmail
                    }
                }
            }
        };
        return paymentServiceModel;
    }

    /**
     * @description this method will return current window url
     * @date 2018-08-13
     * @private
     * @returns {string}
     * @memberof WorldPayComponent
     */
    private getCurrentWindowUrl(): string {
        const currentWindowURL: string = window.location.origin + '/' + this.wxmlpplComponentSettings.isoCountryCode +
            '/' + this.wxmlpplComponentSettings.languageCode + '/checkout/payment/'
            + PaymentProcessorAlias.WORLDPAYXML.toLowerCase() + '/';

        return currentWindowURL;
    }

    /**
    * @description mapping the billing address in the
    * WorldPay XML payment form
    * @date 2018-07-27
    * @private
    * @returns {WorldPay XMLBillingAddress}
    * @memberof WorldPayComponent
    */
    private getBillingAddress(): Address {
        const shippingAddress = this.wxmlpplComponentSettings.checkoutInformation.shippingInformation.shippingAddress;
        let country: Country;
        if (this.wxmlpplComponentSettings.countries && this.wxmlpplComponentSettings.countries.length > 0) {
            country = this.wxmlpplComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                === this.wxmlpplComponentSettings.isoCountryCode.toLowerCase());
        }
        const billingAddress: Address = {
            country: country ? country.isocodeTwo : '',
            countryCodeTwo: country ? country.isocodeTwo : '',
            countryCode: country ? country.isocodeTwo : '',
            state: shippingAddress ? shippingAddress.state : '',
            city: shippingAddress ? shippingAddress.city : '',
            postalCode: shippingAddress ? shippingAddress.postalCode : '',
            addressLine1: shippingAddress ? shippingAddress.addressLine1 : '',
            addressLine2: shippingAddress ? shippingAddress.addressLine2 : ''
        };
        return billingAddress;
    }

}
