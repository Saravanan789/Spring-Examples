import { OnInit, OnDestroy, Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {
    CommonService, CacheService, ActiveSessionService,
    ConfigurationService, NotificationService
} from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { environment } from '../../../environments/environment';
import {
    CheckoutInformation, ShippingMethod, ShippingInformation, Autoship, TaxValidationMessage
    , ShippingOptionsResponse, ProductShippingRestriction, PickupLoaction
} from '../interfaces';
import { DeliveryOptionType, BreadcrumbStep, WizardStep } from '../enums';
import {
    ShippingAddressComponentSettings, GuestPersonalInfoComponentSettings
} from '../component-settings';
import { CheckoutMessageService, ShippingMethodService } from '../services';
import { Router } from '@angular/router';
import { MemberType, MemberLevel } from '../../shared/enums';
import { Location } from '@angular/common';
import { Country, State, Member } from '../../shared/interfaces';
import { AppMessageService } from '../../app-message.service';
import { AddressService } from '../../common/services/address.service';
import { Address, TranslateParam } from '../../common/interfaces';
import { AddressComponentSettings } from '../../common/component-settings';
import { AddressType, DocumentCategoryId, DisplaySectionId, NotificationType } from '../../common/enums';
import { DeliveryOptionTypeResponse } from '../interfaces/delivery-option-type-response.interface';
import { MaskPipe } from 'ngx-mask';
import { Portal } from '../../payment/enums/payment-type.enum';
import { ProductRestrictionModel, ProductModel } from '../../products/interfaces/product-restriction.interface';
import { Cart, Item } from '../../shared/models';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { TranslateService } from '@ngx-translate/core';

/**
 * @description Shipping Address Information
 * @author NextSphere Technologies
 * @date 2018-07-20
 * @export
 * @class ShippingAddressComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-shipping-address-new',
    templateUrl:
        '../templates/template3/views/shipping-address_new.component.html',
    styleUrls: ['../templates/template3/themes/default/less/shipping-address_new.component.less'
    ]
})


export class ShippingAddressNewComponent implements OnInit, OnDestroy {
    sAddressComponentSettings: ShippingAddressComponentSettings = new ShippingAddressComponentSettings();
    @ViewChild('shippingAddressBtn') public shippingAddressBtn: ElementRef;
    @ViewChild('shippingRestrictionModal') public shippingRestrictionModal: AppModalDirective;
    constructor(
        private _formBuilder: FormBuilder,
        private _commonService: CommonService,
        private _cacheService: CacheService,
        private _checkoutMessageService: CheckoutMessageService,
        private _appMessageService: AppMessageService,
        private _router: Router,
        private _location: Location,
        private _addressService: AddressService,
        private _shippingMethodService: ShippingMethodService,
        private _configurationService: ConfigurationService,
        private _activeSessionService: ActiveSessionService,
        private _maskPipe: MaskPipe,
        private _translateService: TranslateService,
        private _notificationService: NotificationService
    ) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof ShippingAddressComponent
     */
    loadDefaultSettings() {
        const autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
        this.sAddressComponentSettings.autoshipDetails = this._cacheService.get(CacheKey.AutoshipDetails);
        if (autoshipCart && autoshipCart.items && autoshipCart.items.length > 0) {
            this.sAddressComponentSettings.isAutoshipItems = false;
            this.sAddressComponentSettings.saveForFutureUse.setValue(true);
        }
        this.sAddressComponentSettings.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        this.sAddressComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.sAddressComponentSettings.shippingSchemaUrl =
            this.sAddressComponentSettings.isoCountryCode.toLowerCase() + '-schema-form.json';
        this.sAddressComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.storeConfiguration();
        this.loadMemberType();
        this.removeQueryParamFromCurrentUrl();
        this.getDeliveryOptionTypes();
        this.getCountriesLookup();
        this.subscribePlaceOrderEvent();
        this.validateCurrentStep();
        this.fetchTermsConditionDocument();
    }

    /**
     * @description Calculate the member CC limit
     * @date 2019-05-04
     * @memberof ShippingAddressNewComponent
     */
    getMemberCCLimit(): boolean {
        if (this.sAddressComponentSettings.userInfo
            && (this.sAddressComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
                || this.sAddressComponentSettings.userInfo.memberTypeId === MemberType.DISTRIBUTOR)) {
            const validateOrderRule = this._commonService.verifyOrderRules();
            this.sAddressComponentSettings.thresholdCrossed = validateOrderRule.thresholdCrossed;
            this.sAddressComponentSettings.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
            this.sAddressComponentSettings.monthlyCCValue = validateOrderRule.monthlyCCValue;
        }
        return this.sAddressComponentSettings.memberCCLimitExceeded;
    }

    /**
     * @description Its an Subscription for breadcrumb navigation
     * for shipping address section
     * @memberof ShippingAddressComponent
     */
    validateCurrentStep(): void {
        this.sAddressComponentSettings.breadcrumbSubscription =
            this._checkoutMessageService.getValidateCurrentStep$()
                .subscribe((step: BreadcrumbStep) => {
                    if (step === BreadcrumbStep.DELIVERY && this.shippingAddressBtn) {
                        this.shippingAddressBtn.nativeElement.click();
                    }
                });
    }

    /**
     * @description
     * Check for Participating Country
     * @date 2018-08-27
     * @memberof ShippingAddressNewComponent
     */
    storeConfiguration(): void {
        this.sAddressComponentSettings.store = this._configurationService.getStoreData();
        if (this.sAddressComponentSettings.store && this.sAddressComponentSettings.store
            .homeCountryId === this.sAddressComponentSettings.store.countryId) {
            this.sAddressComponentSettings.isParticipatingCountry = false;
        } else {
            this.sAddressComponentSettings.isParticipatingCountry = true;
        }
    }

    /**
     * @description this method will load member type
     * or logeed in member information
     * @date 2018-07-25
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private loadMemberType(): void {
        this.sAddressComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        if (this._cacheService.get(CacheKey.FPCOptIn)) {
            this.sAddressComponentSettings.fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        }
        this.sAddressComponentSettings.registerMemberType = this.sAddressComponentSettings.userInfo
            && this.sAddressComponentSettings.userInfo.memberTypeId
            ? this.sAddressComponentSettings.userInfo.memberTypeId : this._cacheService.get(CacheKey.RegisterMemberType);
        if (this.sAddressComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER) {
            this.sAddressComponentSettings.displayAddressForm = true;
        }
        this.sAddressComponentSettings.registerMemberTypeValue = this._commonService
            .getMemberTypeValue(this.sAddressComponentSettings.registerMemberType);
    }


    /**
     * @description this method will load delivery options based on
     * register member type and purchase flow
     * @date 2018-09-14
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private getDeliveryOptionTypes(): void {
        this._shippingMethodService.getDeliveryOptionTypes(this.sAddressComponentSettings)
            .subscribe((deliveryOptionTypes: DeliveryOptionTypeResponse[]) => {
                if (deliveryOptionTypes && deliveryOptionTypes.length > 1) {
                    this.sAddressComponentSettings.displayDeliveryOptions = true;
                    this.createDeliveryOptionsTypeForm();
                } else {
                    this.sAddressComponentSettings.displayDeliveryOptions = false;
                    if (deliveryOptionTypes[0].optionValue.toLowerCase()
                        === DeliveryOptionType.Delivery.toLowerCase()) {
                        this.sAddressComponentSettings.deliveryOptionType = DeliveryOptionType.Delivery;
                        this.changeDeliveryOptionType(DeliveryOptionType.Delivery);
                    }
                }
            }, (error: any) => {
                this.sAddressComponentSettings.translateParams = this._commonService.handleError(error);
            });
    }

    /**
     * @description this method is used
     * load stored information while refreshing the page
     * @date 2018-07-21
     * @memberof ShippingAddressNewComponent
     */
    private loadCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (!this.sAddressComponentSettings.isAutoshipEnabled) {
            this.loadCheckoutShippingInformation(checkoutInformation);
        } else if (this.sAddressComponentSettings.isAutoshipEnabled) {
            this.loadCheckoutShippingInfoForAutoship(checkoutInformation);
        }
    }

    /**
     * @description load checkout shipping information
     * @date 2018-10-16
     * @param {CheckoutInformation} checkoutInformation
     * @memberof ShippingAddressNewComponent
     */
    private loadCheckoutShippingInformation(checkoutInformation: CheckoutInformation): void {
        if (checkoutInformation && checkoutInformation.personalInformation
            && checkoutInformation.personalInformation.address
            && !checkoutInformation.shippingInformation
            && !this.sAddressComponentSettings.isParticipatingCountry) {
            if (!checkoutInformation.personalInformation.address.name) {
                const shipToName = checkoutInformation.personalInformation.firstName
                    + ' ' + checkoutInformation.personalInformation.lastName;
                const phoneNumber = checkoutInformation.personalInformation.phoneNumber;
                checkoutInformation.personalInformation.address.phoneNumber = phoneNumber ? phoneNumber : '';
                checkoutInformation.personalInformation.address.name = shipToName ? shipToName.substring(0, 51) : '';
                checkoutInformation.personalInformation.address.firstName = checkoutInformation.personalInformation.firstName;
                checkoutInformation.personalInformation.address.lastName = checkoutInformation.personalInformation.lastName;
                checkoutInformation.personalInformation.address.middleName = checkoutInformation.personalInformation.middleName;
                checkoutInformation.personalInformation.address.phoneType = checkoutInformation.personalInformation.phoneType;
            }
            if (!this.sAddressComponentSettings.address && !(this.sAddressComponentSettings.userInfo
                && this.sAddressComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
                && this.sAddressComponentSettings.fpcOptIn)) {
                this.populateShippingAddress(checkoutInformation.personalInformation.address, true);
            }
        } else if (checkoutInformation && checkoutInformation.shippingInformation
            && checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery
            && checkoutInformation.shippingInformation.shippingAddress) {
            if (checkoutInformation.shippingInformation.shippingAddress.saveForFutureUse) {
                this.sAddressComponentSettings.displaySaveFutrueUse = true;
            }
            this.populateShippingAddress(checkoutInformation.shippingInformation.shippingAddress, false);
        } else if (this.sAddressComponentSettings.address && this.sAddressComponentSettings.store
            && this.sAddressComponentSettings.store.homeIsocodeThree) {
            if (this.sAddressComponentSettings.address.middleName) {
                this.sAddressComponentSettings.address.middleName = this.sAddressComponentSettings.address.middleName.substring(0, 5);
            }
            this.sAddressComponentSettings.address.country = this.sAddressComponentSettings.store.homeIsocodeThree;
            this.addressFieldsValidation();
            this.sAddressComponentSettings.displayAddressForm = true;
        } else if (!this.sAddressComponentSettings.userInfo) {
            this.sAddressComponentSettings.displayAddressForm = true;
        }
    }

    /** Address Comparsion
     * @description
     * @date 2019-06-14
     * @memberof ShippingAddressNewComponent
     */
    private addressFieldsValidation(): void {
        if (this.sAddressComponentSettings.address && this.sAddressComponentSettings.address.firstName
            && this.sAddressComponentSettings.address.lastName && this.sAddressComponentSettings.address.addressLine1
            && this.sAddressComponentSettings.address.city && this.sAddressComponentSettings.address.stateId) {
            this.sAddressComponentSettings.addressSubmitted = true;
        } else {
            this.sAddressComponentSettings.address.isInvalidAddress = true;
            this.sAddressComponentSettings.addressSubmitted = false;
        }
    }

    /**
     * @description load shipping details in autoship flow
     * @date 2018-10-16
     * @param {CheckoutInformation} checkoutInformation
     * @memberof ShippingAddressNewComponent
     */
    private loadCheckoutShippingInfoForAutoship(checkoutInformation: CheckoutInformation): void {
        if (checkoutInformation && checkoutInformation.shippingInformation
            && checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery
            && checkoutInformation.shippingInformation.shippingAddress) {
            this.shipToDifferentAddress();
        } else {
            const autoshipPreference: Autoship = this._cacheService.get(CacheKey.AutoshipDetails);
            if (autoshipPreference && autoshipPreference.autoshipShippingInformations &&
                autoshipPreference.autoshipShippingInformations.length > 0 &&
                autoshipPreference.autoshipShippingInformations[0].shippingAddressId) {
                this.getAutoshipShippingAddressDetails(autoshipPreference);
            } else {
                this.shipToDifferentAddress();
            }
        }
    }

    /**
 * @description Autoship Shipping Address Details
 * @date 2018-09-17
 * @private
 * @param {Autoship} autoship
 * @memberof ShippingAddressNewComponent
 */
    private getAutoshipShippingAddressDetails(autoship: Autoship): void {
        if (autoship && autoship.autoshipShippingInformations &&
            autoship.autoshipShippingInformations.length > 0 &&
            autoship.autoshipShippingInformations[0].shippingAddressId) {
            this._addressService
                .getAddressDetailsById(autoship.autoshipShippingInformations[0].shippingAddressId)
                .subscribe(response => {
                    if (response && response.length > 0) {
                        const autoshipAddressDetails = response[0];
                        autoshipAddressDetails.country =
                            this.sAddressComponentSettings.countries.find((x: Country) => x.countryId ===
                                autoshipAddressDetails.countryId).isocodeThree;
                        autoshipAddressDetails.name = autoshipAddressDetails.shipToName;
                        autoshipAddressDetails.zip = autoshipAddressDetails.postalCode;
                        autoshipAddressDetails.state = autoshipAddressDetails.stateCode;
                        this.sAddressComponentSettings.selectedSavedAddress = autoshipAddressDetails;
                        this.shipToDifferentAddress();
                    }
                });
        }
    }

    /**
     * @description this method will assign entered
     * addres into address form
     * @date 2018-08-01
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private populateShippingAddress(address: Address, mailingAddress: boolean): void {
        this.sAddressComponentSettings.address = address;
        if (mailingAddress) {
            this.sAddressComponentSettings.address.id = null;
            this.sAddressComponentSettings.address.defaultAddress = false;
        }
        if (this.sAddressComponentSettings.saveForFutureUse) {
            this.sAddressComponentSettings.saveForFutureUse.setValue(address.saveForFutureUse);
        }
        this.addressFieldsValidation();
        this.sAddressComponentSettings.displayAddressForm = true;
    }

    /**
     * @description Creating the delivery options form
     * @date 2018-07-20
     * @memberof ShippingAddressComponent
     */
    private createDeliveryOptionsTypeForm(): void {
        const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        this.sAddressComponentSettings.deliveryOptionType =
            this.sAddressComponentSettings.deliveryOptionType ? this.sAddressComponentSettings.deliveryOptionType :
                checkoutInfo && checkoutInfo.shippingInformation && checkoutInfo.shippingInformation.deliveryOptionType
                    ? checkoutInfo.shippingInformation.deliveryOptionType : DeliveryOptionType.Delivery;
        this.sAddressComponentSettings.deliveryOptionsForm = this._formBuilder.group({
            deliveryOptionType: [this.sAddressComponentSettings.deliveryOptionType, Validators.required]
        });
    }

    /**
     * @description Bind new address Schema Form
     * @date 2018-07-20
     * @memberof ShippingAddressNewComponent
     */
    shipToDifferentAddress(isSavedAddress?: boolean) {
        this.sAddressComponentSettings.displayMemberSavedAddress = true;
        this.sAddressComponentSettings.displayAddressForm = false;
        if (this.sAddressComponentSettings.isAutoshipEnabled && isSavedAddress) {
            let defaultAddress: Address = this.sAddressComponentSettings.memberSavedAddresses.find(x => x.defaultAddress);
            if (this.sAddressComponentSettings.isAutoshipEnabled && !defaultAddress) {
                defaultAddress = this.sAddressComponentSettings.memberSavedAddresses[0];
            }
            this.sAddressComponentSettings.address = defaultAddress;
            this.sAddressComponentSettings.addressSubmitted = true;
            this.sAddressComponentSettings.selectedSavedAddress = defaultAddress;
        }
        this._commonService.scrollByValue(0, 0, 0);
    }


    /**
     * @description Get Countries
     * @date 2018-07-19
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.sAddressComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            const selectedCountry =
                this.sAddressComponentSettings.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
                    this.sAddressComponentSettings.isoCountryCode.toLowerCase());
            if (selectedCountry && selectedCountry.countryId) {
                this.getStatesLookup(selectedCountry.countryId);
            }
            this.getMemberAddress();
        } else {
            this._commonService.getCountries().subscribe((countries: Country[]) => {
                if (countries && countries.length > 0) {
                    this.sAddressComponentSettings.countries = countries;
                    this.getMemberAddress();
                    this._cacheService.set(CacheKey.Countries, this.sAddressComponentSettings.countries);
                    const selectedCountry = this.sAddressComponentSettings.countries.
                        find((x: Country) => x.isocodeThree.toLowerCase() === this.sAddressComponentSettings.isoCountryCode.toLowerCase());
                    if (selectedCountry && selectedCountry.countryId) {
                        this.getStatesLookup(selectedCountry.countryId);
                    }
                }
            });
        }
    }

    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof ShippingAddressNewComponent
     */
    private getStatesLookup(countryId: number) {
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            this.sAddressComponentSettings.states = storedStates;
            this.getMemberSavedAddresses();
        } else if(countryId){
            this._commonService.getStatesByCountry(countryId).subscribe((states: State[]) => {
                this.sAddressComponentSettings.states = states;
                this.getMemberSavedAddresses();
            }, (err: any) => {
            });
        }
    }


    /**
     * @description this method will load
     * member saved address based on country id
     * @date 2018-07-24
     * @memberof ShippingAddressNewComponent
     */
    getMemberSavedAddresses(): void {
        if (this.sAddressComponentSettings.userInfo && this.sAddressComponentSettings.countries) {
            const countryId: number = this.sAddressComponentSettings.countries.find((z: Country) => z.isocodeThree.toUpperCase()
                === this.sAddressComponentSettings.isoCountryCode.toUpperCase()).countryId;
            this._addressService
                .getSavedAddress(this.sAddressComponentSettings.userInfo.memberId, countryId, AddressType.SHIPPING)
                .subscribe((memberAddresses: Address[]) => {
                    this.processMemberSavedAddressResponse(memberAddresses);
                });
        } else {
            this.loadCheckoutInformation();
        }
    }

    /**
     * @description this method used to process memeber saved
     * address response and set countyid and state codes
     * @date 2018-07-24
     * @param {Address[]} memberAddresses
     * @memberof ShippingAddressNewComponent
     */
    private processMemberSavedAddressResponse(memberAddresses: Address[]): void {
        if (memberAddresses && memberAddresses.length > 0) {
            this.sAddressComponentSettings.memberSavedAddresses = [];
            memberAddresses.forEach((x: Address) => {
                x.name = x.shipToName;
                x.zip = x.postalCode;
                const country: Country = this.sAddressComponentSettings.countries.find((z: Country) => z.countryId === x.countryId);
                x.country = country ? country.isocodeThree : '';
                x.countryCode = country ? country.isocodeThree : '';
                const state: State = this.sAddressComponentSettings.states.find((z: State) => z.id === x.stateId);
                x.state = state ? state.stateCode : '';
                x.stateCode = state ? state.stateCode : '';
                x.saveForFutureUse = true;
                this.sAddressComponentSettings.memberSavedAddresses.push(x);
            });
            this.prepopulateDefaultAddress();
        } else {
            this.loadCheckoutInformation();
            if (this.sAddressComponentSettings.userInfo) {
                this.sAddressComponentSettings.displayAddressForm = true;
            }
        }
    }

    /**
     * @description it used to prepopulate the
     * default address when user logged in tio system
     * @date 2018-07-25
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private prepopulateDefaultAddress(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        this.sAddressComponentSettings.displayAddressForm = false;
        let defaultAddress: Address = null;
        if (checkoutInformation && checkoutInformation.shippingInformation
            && checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery
            && checkoutInformation.shippingInformation.shippingAddress
            && this.sAddressComponentSettings.userInfo) {
            defaultAddress = checkoutInformation.shippingInformation.shippingAddress;
            this.sAddressComponentSettings.displaySaveFutrueUse = (defaultAddress.id || defaultAddress.memberAddressDetailId) ?
                false : true;
        } else {
            defaultAddress = this.sAddressComponentSettings.memberSavedAddresses.find(x => x.defaultAddress);
            this.sAddressComponentSettings.displaySaveFutrueUse = false;
        }
        if (defaultAddress) {
            this.sAddressComponentSettings.address = defaultAddress;
            if (this.sAddressComponentSettings.address) {
                this.sAddressComponentSettings.address.phone = this.sAddressComponentSettings.address.phoneNumber
                    ? this.sAddressComponentSettings.address.phoneNumber : null;
                this.maskPhoneNumber();
            }
            if (this.sAddressComponentSettings.saveForFutureUse) {
                this.sAddressComponentSettings.saveForFutureUse.setValue(defaultAddress.saveForFutureUse);
            }
            this.sAddressComponentSettings.selectedSavedAddress = this.sAddressComponentSettings.address;
            this.addressFieldsValidation();
        }
        this.loadCheckoutInformation();
        if (!this.sAddressComponentSettings.isAutoshipEnabled) {
            setTimeout(() => {
                this.sAddressComponentSettings.displayAddressForm = true;
            }, 100);
        }
    }

    /**
     * @description this method will mask phone number based on country format
     * @date 2018-11-13
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private maskPhoneNumber(): void {
        if (this.sAddressComponentSettings.address.phone) {
            this.sAddressComponentSettings.address.phone = this._maskPipe
                .transform(this.sAddressComponentSettings.address.phone, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.sAddressComponentSettings.isoCountryCode));
        }
    }

    /**
     * @description Member MAiling address
     *
     * @memberof ShippingAddressNewComponent
     */
    getMemberMailingAddress(): Address {
        let mailingAddress: Address;
        if (this.sAddressComponentSettings.userInfo) {
            mailingAddress = this.sAddressComponentSettings.mailingAddress;
        } else {
            const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation) || {};
            if (checkoutInformation && checkoutInformation.personalInformation &&
                checkoutInformation.personalInformation.address) {
                mailingAddress = checkoutInformation.personalInformation.address;
            }
        }
        return mailingAddress;
    }

    getMemberAddress(): void {
        if (this.sAddressComponentSettings.userInfo && this.sAddressComponentSettings.countries) {
            this._addressService
                .getSavedAddress(this.sAddressComponentSettings.userInfo.memberId, null, AddressType.MAILING)
                .subscribe((memberAddresses: Address[]) => {
                    if (memberAddresses && memberAddresses.length > 0) {
                        this.sAddressComponentSettings.mailingAddress = memberAddresses[0];
                    }
                }, error => {
                });
        }
    }

    /**
     * @description Map default address to Autoship
     * @date 2018-10-30
     * @param {Address} defaultAddress
     * @memberof ShippingAddressNewComponent
     */
    mapDefaultAddress(defaultAddress: Address): void {
        if (this.sAddressComponentSettings.isAutoshipEnabled && !defaultAddress) {
            defaultAddress = this.sAddressComponentSettings.memberSavedAddresses[0];
            if (defaultAddress) {
                this.sAddressComponentSettings.address = defaultAddress;
                if (this.sAddressComponentSettings.address) {
                    this.sAddressComponentSettings.address.phone = this.sAddressComponentSettings.address.phoneNumber
                        ? this.sAddressComponentSettings.address.phoneNumber : null;
                    this.maskPhoneNumber();
                }
                this.sAddressComponentSettings.selectedSavedAddress = defaultAddress;
                this.sAddressComponentSettings.addressSubmitted = true;
            }
        }
    }

    /**
     * @description this method is
     * used to change the delivery option from
     * shipping to pickup
     * @date 2018-07-21
     * @private
     * @memberof ShippingAddressNewComponent
     */
    changeDeliveryOptionType(deliveryOptionType: DeliveryOptionType): void {
        this.sAddressComponentSettings.deliveryOptionType = deliveryOptionType;
        this.sAddressComponentSettings.addressSubmitted = false;
        this.sAddressComponentSettings.shippingMethod = null;
        if (DeliveryOptionType.Delivery === deliveryOptionType) {
            if (!this.sAddressComponentSettings.displaySaveFutrueUse
                && !this.sAddressComponentSettings.address) {
                this.sAddressComponentSettings.displaySaveFutrueUse = true;
            }
        }
        this.saveCheckoutInformation(true);
        if (this.sAddressComponentSettings.deliveryOptionType === this.sAddressComponentSettings.deliveryOptions.Delivery) {
            this.sAddressComponentSettings.disableNextButton = false;
            this.removeValidationMessageFromCookie();
        }
        this._checkoutMessageService.setShipmethodTypeSelected(deliveryOptionType);
    }

    /**
     * @description remove the validation message from the cookie banner
     * @date 2019-03-15
     * @memberof ShippingAddressNewComponent
     */
    removeValidationMessageFromCookie(): void {
        const cookieState = this._cacheService.getCookieValue(CacheKey.CookieBanner) ? false : true;
        if (cookieState) {
            const cookieBannerData = {
                timeout: false,
                time: 2000,
                showDefault: true,
                showBanner: true
            };
            this._appMessageService.setCookieBannerData(cookieBannerData);
        } else {
            const data = { showBanner: false };
            this._appMessageService.setCookieBannerData(data);
        }
    }

    /**
    * @description this method will
    * process and validate shipping information,
    * @date 2018-07-20
    * @param {Event} $event
    * @memberof ShippingAddressNewComponent
    */
    submitShippingInformation($event: Event): void {
        // submiting shipping information
        if (this.sAddressComponentSettings.registerMemberType
            === this.sAddressComponentSettings.memberType.GUESTCUSTOMER) {
            this.sAddressComponentSettings.formSubmitted = true;
            if (this.sAddressComponentSettings.agreementCheck) {
                this.processGuestFlow();
            }
        } else {
            this.processAddressFlow(true);
        }
    }

    /**
     * @description this method
     * will excecute when we are enroll as
     * a guest flow
     * @date 2018-07-24
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private processGuestFlow(): void {
        if (!this.sAddressComponentSettings.guestFormSubmitted) {
            this._checkoutMessageService.setSubmitGuestForm(true);
        } else {
            this.processAddressFlow(this.sAddressComponentSettings.guestFormSubmitted);
        }
    }

    /**
     * @description this method
     * will excecute when we are enroll as
     * a guest flow
     * @date 2018-07-24
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private processAddressFlow(processNextStep: boolean, isAutopopulate?: boolean): void {
        if (this.sAddressComponentSettings.deliveryOptionType
            === this.sAddressComponentSettings.deliveryOptions.Delivery &&
            !this.sAddressComponentSettings.addressSubmitted && !isAutopopulate) {
            this.setShippingAddress(this.sAddressComponentSettings.addressSubmitted ? false : processNextStep);
        } else if (!isAutopopulate) {
            this.navigateBasedMemberInformation();
        }
    }

    /**
     * @description it used fire event in
     * address component to submit address
     * @date 2018-07-20
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private setShippingAddress(processAddressVerification: boolean): void {
        if (!this.sAddressComponentSettings.addressSubmitted) {
            this._appMessageService.setSubmitAddress(processAddressVerification);
        }
    }

    /**
     * @description  this method is used to
     * get the verified or sugggested address
     * @date 2018-07-20
     * @param {Address} address
     * @memberof ShippingAddressNewComponent
     */
    getShippingAddressInfo(addressComponentSettings: AddressComponentSettings): void {
        if (addressComponentSettings && addressComponentSettings.addressSubmitted) {
            this.sAddressComponentSettings.address = addressComponentSettings.address;
            this.sAddressComponentSettings.addressSubmitted = addressComponentSettings.addressSubmitted;
            this.navigateBasedMemberInformation();
        } else {
            this.sAddressComponentSettings.addressSubmitted = addressComponentSettings.addressSubmitted;
        }
    }

    /**
     * @description this method will fire when we chaneg textbox value
     * in address block
     * @date 2018-08-20
     * @memberof ShippingAddressNewComponent
     */
    getAddressOnInputChange(address: Address): void {
        this.sAddressComponentSettings.displaySaveFutrueUse = true;
    }

    /**
    * @description it used to navigate from
    * next page
    * @date 2018-07-20
    * @memberof ShippingAddressNewComponent
    */
    private navigateToNextPage(): void {
        this.saveCheckoutInformation();
        const wizardStep = this._cacheService.get(CacheKey.WizardSteps);
        if (this.sAddressComponentSettings.addressSubmitted &&
            this.sAddressComponentSettings.deliveryOptionType
            === this.sAddressComponentSettings.deliveryOptions.Delivery) {
            if (wizardStep <= WizardStep.SHIPPING) {
                this._cacheService.set(CacheKey.WizardSteps, WizardStep.SHIPPING);
            }
            this.routeNavigateByPath('/checkout/delivery');
        } else if (this.sAddressComponentSettings.shippingMethod &&
            this.sAddressComponentSettings.deliveryOptionType
            === this.sAddressComponentSettings.deliveryOptions.Pickup) {
            const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
            if (checkoutInfo && checkoutInfo.shippingMethodInformation
                && checkoutInfo.shippingMethodInformation.shippingMethod
                && checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation) {
                const memberCCLimitExceeded = this.getMemberCCLimit();
                if (memberCCLimitExceeded) {
                    const exceedMonthlyCCPopup: any = this._translateService
                        .get('common.Your cart contains a case credit value that brings your total monthly case credits above the limit');
                    const monthlyCCContent = exceedMonthlyCCPopup.value + ' <b class="helvetica-bold">'
                        + this.sAddressComponentSettings.monthlyCCValue + '</b>';
                    this._notificationService.createNotification('', monthlyCCContent, NotificationType.ERROR);
                } else {
                    const productRestrictionModel: ProductRestrictionModel =
                        this.prepareProductRestrictionModelRequest(checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation);
                    this._commonService.getProductRestrictions(productRestrictionModel).subscribe((response) => {
                        if (response && response.success && response.productModels) {
                            this.sAddressComponentSettings.productShippingRestriction
                                = this.prepareProductShippingRestrictions(response);
                            this.getRestrictedProducts(response);
                            this.shippingRestrictionModal.show();
                        } else {
                            if (wizardStep <= WizardStep.SHIPPING) {
                                this._cacheService.set(CacheKey.WizardSteps, WizardStep.SHIPPING);
                            }
                            this.placeOrder();
                        }
                    });
                }
            }
        }
    }

    /**
     * @description Place Order
     * @date 2018-08-02
     * @memberof ShippingAddressNewComponent
     */
    placeOrder(): void {
        this.sAddressComponentSettings.disableNextButton = true;
        this._appMessageService.setProcessOrder();
    }

    /**
     * @description this method subscribe the place order
     * request status
     * @date 2018-08-17
     * @memberof ShippingAddressNewComponent
     */
    subscribePlaceOrderEvent(): void {
        this.sAddressComponentSettings.placeOrderBtnSubscription = this._checkoutMessageService
            .getDisablePlaceOrderBtn()
            .subscribe((response: TaxValidationMessage) => {
                if (this.sAddressComponentSettings.store && this.sAddressComponentSettings.store.createOrderOnTaxFailure) {
                    if (response && response.validations && response.validations.length > 0) {
                        if (this.sAddressComponentSettings.deliveryOptionType === this.sAddressComponentSettings.deliveryOptions.Pickup) {
                            this.sAddressComponentSettings.disableNextButton = response.isDisablePlaceOrderBtn;
                        } else {
                            this.sAddressComponentSettings.disableNextButton = false;
                        }
                    } else {
                        this.sAddressComponentSettings.disableNextButton = response.isDisablePlaceOrderBtn;
                    }
                }
            });
    }

    /**
     * @description this method will
     * be used when member type is guest
     * validate information while navigate
     * to next page
     * @date 2018-07-24
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private navigateBasedMemberInformation(): void {
        if (this.sAddressComponentSettings.saveForFutureUse
            && this.sAddressComponentSettings.address) {
            this.sAddressComponentSettings.address.saveForFutureUse = this.sAddressComponentSettings.saveForFutureUse.value;
        }
        if (!this.sAddressComponentSettings.isAutoshipItems && this.sAddressComponentSettings.address) {
            this.sAddressComponentSettings.address.saveForFutureUse = true;
        }
        if (this.sAddressComponentSettings.registerMemberType
            === this.sAddressComponentSettings.memberType.GUESTCUSTOMER) {
            if (this.sAddressComponentSettings.guestFormSubmitted) {
                this.navigateToNextPage();
            }
        } else if (this.sAddressComponentSettings.registerMemberType
            === this.sAddressComponentSettings.memberType.RETAILCUSTOMER
            && !this.sAddressComponentSettings.userInfo) {
            this.navigateToNextPage();
        } else if (this.sAddressComponentSettings.userInfo
            && this.sAddressComponentSettings.deliveryOptionType
            === this.sAddressComponentSettings.deliveryOptions.Delivery
            && !this.sAddressComponentSettings.fpcOptIn
            && this.sAddressComponentSettings.address && this.sAddressComponentSettings.address.saveForFutureUse) {
            this.saveVerifiedAddress();
        } else {
            this.navigateToNextPage();
        }
    }

    /**
     * @description this method will save or update
     * entered address
     * @date 2018-08-01
     * @memberof ShippingAddressNewComponent
     */
    saveVerifiedAddress(): void {
        const saveAddressRequest = this.prepareSaveAddressRequest(this.sAddressComponentSettings.address);
        if ((!this.sAddressComponentSettings.selectedSavedAddress) ||
            (!this.sAddressComponentSettings.isAutoshipItems &&
                !this.sAddressComponentSettings.selectedSavedAddress.memberAddressDetailId &&
                !this.sAddressComponentSettings.selectedSavedAddress.id) ||
            (this.sAddressComponentSettings.selectedSavedAddress
                && this.sAddressComponentSettings.selectedSavedAddress.memberAddressDetailId
                && this.selectedAndEnteredAddressAreDiffer(this.sAddressComponentSettings
                    .selectedSavedAddress, this.sAddressComponentSettings.address))) {
            saveAddressRequest.id = null;
            saveAddressRequest.memberAddressDetailId = null;
            this._addressService.saveVerifiedAddress(saveAddressRequest)
                .subscribe((response: any) => {
                    if (response && response.addressDetail) {
                        this.sAddressComponentSettings.address.id = response.addressDetail.id;
                        this.navigateToNextPage();
                    }
                }, error => {
                    this.sAddressComponentSettings.translateParams = this._commonService.handleError(error);
                });
        } else if (this.sAddressComponentSettings.selectedSavedAddress
            && !this.sAddressComponentSettings.selectedSavedAddress.memberAddressDetailId
            && this.sAddressComponentSettings.selectedSavedAddress.id
            && this.selectedAndEnteredAddressAreDiffer(this.sAddressComponentSettings
                .selectedSavedAddress, this.sAddressComponentSettings.address)
            && this.sAddressComponentSettings.memberSavedAddresses && this.sAddressComponentSettings.memberSavedAddresses.length > 0) {
            const memberAddress = this.sAddressComponentSettings.memberSavedAddresses.find(x => x.id
                === this.sAddressComponentSettings.selectedSavedAddress.id);
            if (memberAddress && memberAddress.memberAddressDetailId) {
                saveAddressRequest.memberAddressDetailId = memberAddress.memberAddressDetailId;
                this._addressService.updateVerifiedAddress(saveAddressRequest, saveAddressRequest.memberAddressDetailId)
                    .subscribe((response: any) => {
                        if (response && response.addressDetail) {
                            this.sAddressComponentSettings.address.id = response.addressDetail.id;
                            this.navigateToNextPage();
                        }
                    }, error => {
                        this.sAddressComponentSettings.translateParams = this._commonService.handleError(error);
                    });
            } else {
                this.navigateToNextPage();
            }
        } else {
            this.sAddressComponentSettings.address.id = this.sAddressComponentSettings.selectedSavedAddress.id;
            this.sAddressComponentSettings.address.memberAddressDetailId = this.sAddressComponentSettings
                .selectedSavedAddress.memberAddressDetailId;
            this.navigateToNextPage();
        }
    }

    /**
     * @description this method will compare the selected saved address
     * and modified address
     * @date 2018-12-06
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private selectedAndEnteredAddressAreDiffer(savedAddress: Address, modifiedAddress: Address): boolean {
        if (savedAddress && modifiedAddress) {
            if (savedAddress.addressLine1 !== modifiedAddress.addressLine1) {
                return true;
            }
            if (savedAddress.addressLine2 !== modifiedAddress.addressLine2) {
                return true;
            }
            if (savedAddress.city !== modifiedAddress.city) {
                return true;
            }
            if (savedAddress.state !== modifiedAddress.state) {
                return true;
            }
            if (savedAddress.postalCode !== modifiedAddress.postalCode) {
                return true;
            }
            if (savedAddress.firstName !== modifiedAddress.firstName) {
                return true;
            }
            if (savedAddress.middleName !== modifiedAddress.middleName) {
                return true;
            }
            if (savedAddress.lastName !== modifiedAddress.lastName) {
                return true;
            }
        }
    }

    /**
     * @description this ,ethod will prepare address save request
     * @date 2018-08-01
     * @param {Address} address
     * @memberof ShippingAddressNewComponent
     */
    prepareSaveAddressRequest(address: Address): Address {
        const addressRequest: Address = {
            id: this.sAddressComponentSettings.selectedSavedAddress ?
                this.sAddressComponentSettings.selectedSavedAddress.id : null,
            memberId: this._activeSessionService.getMemberId(),
            memberAddressDetailId: this.sAddressComponentSettings.selectedSavedAddress ?
                this.sAddressComponentSettings.selectedSavedAddress.memberAddressDetailId : null,
            defaultAddress: false,
            firstName: address.firstName,
            middleName: address.middleName,
            lastName: address.lastName,
            addressLine1: address.addressLine1,
            addressLine2: address.addressLine2,
            addressLine3: '',
            addressLine4: '',
            shipToName: address.name ? address.name : this._activeSessionService.getUserName(),
            city: address.city,
            state: address.state,
            country: address.country,
            stateId: address.stateId,
            countryId: address.countryId,
            postalCode: address.postalCode || address.zip,
            addressVerified: address.addressVerified || address.validAddress,
            validAddress: address.validAddress,
            phone: address.phone ? address.phone.replace(/[^a-zA-Z0-9]/g, '') : null,
            addressTypeId: AddressType.SHIPPING,
            loggedInUserId: this._activeSessionService.getUserId(),
            responseCodes: address.responseCodes ? address.responseCodes : null,
            phoneNumber: address.phone ? address.phone.replace(/[^a-zA-Z0-9]/g, '') : null,
            saveForFutureUse: address.saveForFutureUse,
            phoneType: address.phoneType
        };
        return addressRequest;
    }

    /**
     * @description this method
     * will used to navigate by route path
     * @date 2018-07-23
     * @private
     * @param {string} path
     * @memberof ShippingAddressNewComponent
     */
    private routeNavigateByPath(routePath: string): void {
        this._router.navigate([this.sAddressComponentSettings.isoCountryCode + '/'
            + this.sAddressComponentSettings.languageCode.toLowerCase() + routePath]);
    }

    /**
     * @description get selected shipping method while
     * delivery type is pick up
     * @date 2018-07-23
     * @param {ShippingMethod} shippingMethod
     * @memberof ShippingAddressNewComponent
     */
    getSelectedDeliveryOption(shippingMethod: ShippingMethod): void {
        this.sAddressComponentSettings.shippingMethod = shippingMethod;
    }

    /**
     * @description get selected shipping method while
     * delivery type is pick up
     * @date 2018-07-23
     * @param {ShippingMethod} shippingMethod
     * @memberof ShippingAddressNewComponent
     */
    getGuestPersonalInfo(gpiComponentSettings: GuestPersonalInfoComponentSettings): void {
        if (gpiComponentSettings && gpiComponentSettings.autoPopulate) {
            this.sAddressComponentSettings.displayAddressForm = false;
            this.sAddressComponentSettings.isAutoPopulate = true;
            this.loadAutoPopulateAddressInGuestFlow(gpiComponentSettings);
        }
        if (gpiComponentSettings && gpiComponentSettings.guestPersonalInfoFormValidated) {
            this.sAddressComponentSettings.personalInformation = gpiComponentSettings.personalInformation;
            this.sAddressComponentSettings.guestFormSubmitted = gpiComponentSettings.guestPersonalInfoFormValidated;
        } else {
            this.sAddressComponentSettings.addressSubmitted = gpiComponentSettings.guestPersonalInfoFormValidated;
        }
        this.processAddressFlow(this.sAddressComponentSettings.guestFormSubmitted, gpiComponentSettings.autoPopulate);
    }

    /**
     * @description this method will get the status of verify email
     * account
     * @date 2018-08-27
     * @memberof ShippingAddressNewComponent
     */
    getVerifyEmailAccountStatus(verifyAccountInProgess: boolean): void {
        this.sAddressComponentSettings.verifyAccountInProgess = verifyAccountInProgess;
    }

    /**
     * @description this method will load address while guest flow
     * @date 2018-08-09
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private loadAutoPopulateAddressInGuestFlow(gpiComponentSettings: GuestPersonalInfoComponentSettings): void {
        if (gpiComponentSettings.personalInformation) {
            this.sAddressComponentSettings.personalInformation = gpiComponentSettings.personalInformation;
            this.sAddressComponentSettings.address = gpiComponentSettings.personalInformation.address;
            this.saveCheckoutInformation();
        }
        setTimeout(() => {
            this.sAddressComponentSettings.displayAddressForm = true;
        }, 50);
        if (this.sAddressComponentSettings.isAutoPopulate) {
            setTimeout(() => {
                this.sAddressComponentSettings.isAutoPopulate = false;
            }, 2000);
        }
    }

    /**
     * @description Saving Checkout Information
     * @date 2018-07-20
     * @memberof ShippingAddressNewComponent
     */
    private saveCheckoutInformation(reLoad?: boolean): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        if (reLoad && checkoutInformation.shippingInformation) {
            checkoutInformation.shippingInformation.deliveryOptionType = this.sAddressComponentSettings.deliveryOptionType;
        } else {
            checkoutInformation.shippingInformation = this.prepareShippingInformation();
        }
        if (this.sAddressComponentSettings.deliveryOptionType === DeliveryOptionType.Pickup) {
            checkoutInformation.mailingAddress = this.getMemberMailingAddress();
        }
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
    }

    /**
     * @description this method will
     * prepare shipping information related to
     * delivery type
     * @date 2018-07-23
     * @returns {ShippingInformation}
     * @memberof ShippingAddressNewComponent
     */
    private prepareShippingInformation(): ShippingInformation {
        if (this.sAddressComponentSettings.address) {
            if (this.sAddressComponentSettings.address.phone) {
                this.sAddressComponentSettings.address.phone = this.sAddressComponentSettings
                    .address.phone.replace(/[^a-zA-Z0-9]/g, '');
            } else {
                this.sAddressComponentSettings.address.phone = null;
            }
            if (this.sAddressComponentSettings.address.phoneNumber) {
                this.sAddressComponentSettings.address.phoneNumber = this.sAddressComponentSettings
                    .address.phoneNumber.replace(/[^a-zA-Z0-9]/g, '');
            } else {
                this.sAddressComponentSettings.address.phoneNumber = null;
            }
        }
        const shippingInformation: ShippingInformation = {
            shippingAddress: this.sAddressComponentSettings.deliveryOptionType === DeliveryOptionType.Delivery ?
                this.sAddressComponentSettings.address : null,
            deliveryOptionType: this.sAddressComponentSettings.deliveryOptionType
        };
        return shippingInformation;
    }

    /**
    * Removes the Query Parameters from URL
    */
    removeQueryParamFromCurrentUrl(): void {
        if (window.location.href.indexOf('?') > -1) {
            this._location.replaceState('/' + this.sAddressComponentSettings.isoCountryCode +
                '/' + this.sAddressComponentSettings.languageCode + '/checkout/shipping');
        }
    }
    /**
     * @description this method will get
     * memeber saved address selected by user
     * @date 2018-07-25
     * @param {Address} address
     * @memberof ShippingAddressNewComponent
     */
    selectMemberSavedAddress(address: Address): void {
        this.sAddressComponentSettings.address = address;
        this.addressFieldsValidation();
        if (this.sAddressComponentSettings.saveForFutureUse) {
            this.sAddressComponentSettings.saveForFutureUse.setValue(false);
        }
        this.sAddressComponentSettings.displaySaveFutrueUse = false;
        this.sAddressComponentSettings.selectedSavedAddress = address;
        if (!this.sAddressComponentSettings.isAutoshipEnabled) {
            this.sAddressComponentSettings.displayMemberSavedAddress = false;
            this.sAddressComponentSettings.displayAddressForm = true;
        }
    }

    /**
     * @description this method will show new address form
     * for entering new address
     * @date 2018-08-01
     * @memberof ShippingAddressNewComponent
     */
    addNewAddress(): void {
        this.sAddressComponentSettings.selectedSavedAddress = null;
        this.sAddressComponentSettings.address = null;
        this.sAddressComponentSettings.addressSubmitted = false;
        this.sAddressComponentSettings.displayMemberSavedAddress = false;
        if (this.sAddressComponentSettings.saveForFutureUse && this.sAddressComponentSettings.isAutoshipItems) {
            this.sAddressComponentSettings.saveForFutureUse.setValue(false);
        }
        this.sAddressComponentSettings.displaySaveFutrueUse = false;
        this.sAddressComponentSettings.displayAddressForm = true;
    }

    /**
     * @description this method will be used to get addressverification info
     * if we get value true will hide the personalinfo and sponsor info section
     * if we get will display the personalinfo and sponsor info section
     * this processs will occur while browsing from mobile
     * @date 2018-08-03
     * @memberof ShippingAddressNewComponent
     */
    getAddressVerificationInfo(displayAddressVerification: boolean): void {
        this.sAddressComponentSettings.displayAddressVerification = displayAddressVerification;
    }

    /**
     * @description get Terms and Conditions Document
     * fetchTermsConditionDocument
     * @memberof ShippingAddressNewComponent
     */
    fetchTermsConditionDocument(): void {
        const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
        const registerMemberType = this._cacheService.get(CacheKey.RegisterMemberType);
        if (!userInfo && registerMemberType === MemberType.GUESTCUSTOMER) {
            const customerTypeId = this._commonService.getCustomerTypeId();
            const sectionId = DisplaySectionId.Payment;
            this._commonService.getDocuments(Portal.Join,
                customerTypeId, sectionId)
                .subscribe((response) => {
                    this.validateAgreementDocuments(response);
                }, (error: any) => {
                    this.sAddressComponentSettings.translateParams = this._commonService.handleError(error);
                });
        } else {
            this.sAddressComponentSettings.agreementCheck = true;
        }
    }

    /**
     * @description This method used for validating agreement documents
     * validateAgreementDocuments
     * @memberof ShippingAddressNewComponent
     */
    validateAgreementDocuments(response: any): void {
        const documents = this._cacheService.get(CacheKey.FBOTerms);
        if (response && response.length > 0 && response[0].body && response[0].body.length > 0) {
            this.sAddressComponentSettings.agreementDocuments = response[0].body;
            if (documents && documents.paymentPolicies && documents.paymentPolicies.length > 0) {
                const selectedDocuments = documents.paymentPolicies
                    .filter(document => document.isSelected);
                if (selectedDocuments && selectedDocuments.length
                    === this.sAddressComponentSettings.agreementDocuments.length) {
                    this.sAddressComponentSettings.agreementDocuments.forEach(agreement => agreement.isSelected = true);
                    this.sAddressComponentSettings.agreementCheck = true;
                } else {
                    this.sAddressComponentSettings.agreementDocuments.forEach(agreement => agreement.isSelected = false);
                }
            } else {
                const guestdocuments = { paymentPolicies: [] };
                guestdocuments.paymentPolicies = response[0].body;
                this._cacheService.set(CacheKey.FBOTerms, guestdocuments);
                this.sAddressComponentSettings.agreementDocuments.forEach(agreement => agreement.isSelected = false);
            }
        }
    }

    /**
   * @description
   * @date 2018-09-17
   * @memberof ShippingAddressNewComponent
   */
    onChangeAgreements(index: number): void {
        this.sAddressComponentSettings.agreementDocuments[index].isSelected
            = !this.sAddressComponentSettings.agreementDocuments[index].isSelected;
        const unselectedAgreements = this.sAddressComponentSettings.agreementDocuments.filter(agreement => !agreement.isSelected);
        if (unselectedAgreements && unselectedAgreements.length > 0) {
            this.sAddressComponentSettings.agreementCheck = false;
        } else {
            this.sAddressComponentSettings.agreementCheck = true;
            const guestdocuments = { paymentPolicies: [] };
            guestdocuments.paymentPolicies = this.sAddressComponentSettings.agreementDocuments;
            this._cacheService.set(CacheKey.FBOTerms, guestdocuments);
        }
    }

    /**
    * Trackby will change the DOM
    *  for only added or removed element(not entire DOM Collection)
    * @param  {number} index
    * @param  {Address} item
    * @returns number
    */
    trackAddressBy(index: number, address: Address): number {
        return index;
    }

    /**
     * @description  this method will prepare shipping restrictions
     * based on shipping address and shipping options response
     * @private
     * @memberof ShippingAddressNewComponent
     */
    private prepareProductShippingRestrictions(shippingOptionsResponse: ShippingOptionsResponse): ProductShippingRestriction {
        const productShippingRestriction: ProductShippingRestriction = {
            productModelResponse: true,
            shippingResponse: shippingOptionsResponse.success ? shippingOptionsResponse.success : false,
            productError: this.getShippingRestrictionError(shippingOptionsResponse),
            itemNumbers: this.getRestrictedItemNumbers(shippingOptionsResponse),
            itemNo: this.getShippingRestrictionItemNo(shippingOptionsResponse)
        };
        return productShippingRestriction;
    }

    /**
     * @description this method will give the product error descriptions
     * @private
     * @param {*} restrictedProduct
     * @returns {string}
     * @memberof ShippingAddressNewComponent
     */
    private getShippingRestrictionError(restrictedProduct: ShippingOptionsResponse): string {
        let productError = '';
        const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (restrictedProduct && restrictedProduct.productModels
            && restrictedProduct.productModels.length === 1) {
            productError = restrictedProduct.productModels[0].errorDescription;
        } else {
            if (checkoutInfo && checkoutInfo.shippingMethodInformation
                && checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation
                && checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation
                && checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation.stateCode
                && checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation.countryId) {
                productError = this.getProductError(checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation.countryId
                    , checkoutInfo.shippingMethodInformation.shippingMethod.pickUpLocation.stateCode);
            } else {
                const error: any = this._translateService.get('checkout.Following products are not allowed for selected pickup address.');
                productError = error.value;
            }

        }
        return productError;
    }


    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof ShippingAddressNewComponent
     */
    private getProductError(countryId: number, stateCode: string): string {
        let productError = '';
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            const stateName: string = storedStates.find(x => x.stateCode === stateCode).stateName;
            const error: any =
                this._translateService.get('checkout.' + stateName + ' ' + 'does not allow for the following items to be shipped:');
            productError = error.value;
        } else if (countryId) {
            this._commonService.getStatesByCountry(countryId).subscribe((res: State[]) => {
                const stateName: string = res.find(x => x.stateCode === stateCode).stateName;
                const error: any =
                    this._translateService.get(decodeURIComponent(encodeURIComponent('checkout.' + stateName))
                        + ' ' + 'does not allow for the following items to be shipped:');
                this.sAddressComponentSettings.productErrorMsg = error.value;
            }, (err: any) => {
            });
        }
        return productError;
    }

    /**
     * @description this method will get the restriced items nummbers list
     * @param {*} restrictedProduct
     * @memberof ShippingAddressNewComponent
     */
    private getRestrictedItemNumbers(restrictedProduct: ShippingOptionsResponse): Item[] {
        const itemNumbers: Item[] = [];
        restrictedProduct.productModels.forEach((x: any) => {
            itemNumbers.push(x);
        });
        return itemNumbers;
    }

    /**
     * @description this method will give restricted items numbers
     * @private
     * @param {*} restrictedProduct
     * @returns {string}
     * @memberof ShippingAddressNewComponent
     */
    private getShippingRestrictionItemNo(restrictedProduct: ShippingOptionsResponse): string {
        let itemNumber = '';
        if (restrictedProduct && restrictedProduct.productModels
            && restrictedProduct.productModels.length > 1) {
            itemNumber = restrictedProduct.productModels[0].itemNumber;
        }
        return itemNumber;
    }

    getRestrictedProducts(response: any): void {
        const restrictedItems = [];
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        this.sAddressComponentSettings.shoppingCart
            = new Cart(cartSession, this.sAddressComponentSettings.store);
        const cartItems: Item[] = this.sAddressComponentSettings.shoppingCart.items;
        cartItems.forEach(element => {
            response.productModels.forEach(x => {
                if (element.itemNumber === x.itemNumber) {
                    const error: any = this._translateService.get('checkout.' + x.errorDescription);
                    element['errorDescription'] = error.value;
                    if (x.errorDescription) {
                        restrictedItems.push(element);
                    }
                }
            });
        });
        this.sAddressComponentSettings.restrictedProducts = restrictedItems;
    }

    /**
    * @returns void
    */
    onHidden(): void {
        this.shippingRestrictionModal.hide();
    }

    /**
     * @description this method redirects user to shopping bag page
     * @memberof ShippingAddressNewComponent
     */
    removeNonShippableProducts(): void {
        this._router.navigateByUrl('/' + this.sAddressComponentSettings.isoCountryCode.toLowerCase()
            + '/' + this.sAddressComponentSettings.languageCode.toLowerCase() + '/cart');
    }

    /**
     * @description this method redirects the user to shipping address section page
     * @memberof ShippingAddressNewComponent
     */
    changeShippingAddress(): void {
        this.onHidden();
        this._router.navigateByUrl('/' + this.sAddressComponentSettings.isoCountryCode.toLowerCase()
            + '/' + this.sAddressComponentSettings.languageCode.toLowerCase() + '/checkout/shipping');
    }

    /**
     * @description this method used for preparing product restriction odel request for pickup
     * @memberof ShippingAddressNewComponent
     */
    prepareProductRestrictionModelRequest(pickupAddress: PickupLoaction): ProductRestrictionModel {
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        let productRestrictionModel: ProductRestrictionModel;
        productRestrictionModel = {
            countryCode: pickupAddress.countryCode,
            stateCode: pickupAddress.stateCode
        };
        const productModel: ProductModel[] = [];
        if (cartSession && cartSession.items && cartSession.items.length > 0) {
            cartSession.items.forEach(item => {
                productModel.push({ itemNumber: item.itemNumber });
            });
        }
        productRestrictionModel.productModels = productModel;
        return productRestrictionModel;

    }

    /**
     * @description this method used for handling error for shipping methods
     * @memberof ShippingAddressNewComponent
     */
    errorHandler(translateParams: TranslateParam): void {
        this.sAddressComponentSettings.translateParams = translateParams;
    }

    ngOnDestroy(): void {
        if (this.sAddressComponentSettings.placeOrderBtnSubscription) {
            this.sAddressComponentSettings.placeOrderBtnSubscription.unsubscribe();
        }
        if (this.sAddressComponentSettings.breadcrumbSubscription) {
            this.sAddressComponentSettings.breadcrumbSubscription.unsubscribe();
        }
    }
}
