export interface DefaultPayment {
    value: string;
  }
