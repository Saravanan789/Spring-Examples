import { HttpServiceResponse } from '../../shared/interfaces';
import { AutoshipFrequencyType } from './autoship-frequency-type.interface';

export interface AutoshipFrequencyResponse extends HttpServiceResponse {
    body: AutoshipFrequencyType[];
}
