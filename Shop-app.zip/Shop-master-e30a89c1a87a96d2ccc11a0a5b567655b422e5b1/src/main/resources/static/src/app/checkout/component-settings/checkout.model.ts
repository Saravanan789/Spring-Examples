import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { Country } from '../../shared/interfaces';
import { CheckoutInformation, WorldPayRedirectUrl, OrderResponse, SponsorInformation, Order, Autoship } from '../interfaces';
import { CartSummaryComponentSettings } from './cart-summary.model';
import { Subscription } from 'rxjs/Subscription';
import { DeliveryOptionType, BreadcrumbStep, WizardStep } from '../enums';
import { CheckoutConstants } from '../constants';
import { MemberType } from '../../shared/enums';
import { environment } from '../../../environments/environment';

export class CheckoutComponentSettings extends BaseSettings {
    isAutoshipEnabled: boolean;
    fieldErrors: any[];
    selectedCountry: Country;
    isPreferredCustomer: boolean;
    pollCount = 0;
    maxPollCount = 15;
    checkoutInformation: CheckoutInformation;
    worldPayRedirectUrl: WorldPayRedirectUrl;
    orderResponse: Order;
    cartSummaryComponentSettings: CartSummaryComponentSettings;
    isSponsorFound: boolean;
    defaultOrReferalSponsor: SponsorInformation;
    defaultSponsorId = CheckoutConstants.DEFAULT_SPONSORID;
    shippingMethodSubscription: Subscription;
    routeChangeEventSubscription: Subscription;
    deliveryOptionType: DeliveryOptionType = DeliveryOptionType.Delivery;
    deliveryOptions = DeliveryOptionType;
    breadcrumbStep = BreadcrumbStep;
    wizardStep = WizardStep;
    currentStep: BreadcrumbStep;
    showBackBtn: boolean;
    memberTypes = MemberType;
    fpcOptIn: boolean;
    autoshipPreference: Autoship;
    sponsorPollCount = 0;
    sponsorMaxPollCount = environment.longPollCount;
    // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
    configuredCountries: string[] = ['GBR', 'NLD', 'BEL', 'LUX'];
}

