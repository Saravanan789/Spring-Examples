import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Observable } from 'rxjs/Observable';
import * as crypto from 'crypto-js';
import {
    WorldpayXMLRegistration, PaymentRegistrationResponse, PayvisionSavedCardResponse
} from '../interfaces';
import { environment } from '../../../environments/environment';

/**
 * @description this service help comunicate with payment service
 * when provider is WorldPayXML
 * @date 2018-08-08
 * @export
 * @class WorldpayXMLService
 */
@Injectable()
export class WorldpayXMLService {

    constructor(private _http: Http) { }

    /**
     * @description to get the Worldpay XML checkout
     *  registration form
     * @date 2018-07-27
     * @param {number} storeId
     * @param {paymentRegistrationRequest} WorldpayXMLRegistration
     * @returns {Observable<any>}
     * @memberof WorldpayXMLService
     */
    getWorldpayXMLForm(storeId: number, paymentRegistrationRequest: WorldpayXMLRegistration)
        : Observable<PaymentRegistrationResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .post(ApiUrlConstants.paymentApiUrl + '/payments/store/' + storeId +
                '/payment-checkout-form ', paymentRegistrationRequest, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this is used to get
     * payment headers
     * @date 2018-07-26
     * @returns {Headers}
     * @memberof WorldpayXMLService
     */
    getPaymentHeaders(): Headers {
        const headers = new Headers();
        const authHeader = 'PAY ' + environment.paymentApiKey + ':' + this.getHashedValue();
        headers.append('authorization', authHeader);
        return headers;
    }

    /**
     * @description this method is used to
     * get payment crypto hashed value
     * @date 2018-07-26
     * @returns {string}
     * @memberof WorldpayXMLService
     */
    getHashedValue(): string {
        const shavalue = crypto.HmacSHA1(environment.paymentSecurityKey, environment.paymentServiceKey);
        return crypto.enc.Base64.stringify(shavalue);
    }

    /**
    * To handle the obervable error response
    * @param  {Response|any} error
    */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error);
    }

    /**
     * @description this method will retrive ssaved payvison cards
     * for logged in user
     * @date 2018-08-14
     * @returns {void}
     * @memberof PayvisionService
     */
    getSavedWorldpayCards(memberId: number, isoCountryCode: string)
        : Observable<PayvisionSavedCardResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/members/' + memberId +
                '/cards?countryCode=' + isoCountryCode, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

}
