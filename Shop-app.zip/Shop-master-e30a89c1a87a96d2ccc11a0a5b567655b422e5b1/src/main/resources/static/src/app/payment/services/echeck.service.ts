import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import * as crypto from 'crypto-js';
import { Observable } from '../../../../node_modules/rxjs/Observable';
import { PersonalCheck } from '../interfaces/payment-echeckrequest.interface';
import { ValidateEcheckResponse } from '../interfaces/validate-echeck-response.interface';
import { TokenResponse, ValidateEcheckRequest } from '../interfaces';
import { environment } from '../../../environments/environment';


/**
 *
 *
 * @export
 * @class EcheckService
 */
@Injectable()
export class EcheckService {
    constructor(private _http: Http) { }


    /**
     *
     * @date 2018-08-07
     * @param {number} memberId
     * @param {*} personalCheck
     * @returns {Observable<TokenResponse>}
     * @memberof EcheckService
     */
    savePersonalCheck(memberId: number, personalCheck: PersonalCheck): Observable<TokenResponse> {
        const headers = this.getPaymentHeaders();
        return this._http.post(ApiUrlConstants.paymentApiUrl + '/members/' + memberId +
            '/personal-check', personalCheck, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     *
     * @date 2018-08-07
     * @param {ValidateEcheckRequest} echeckRequest
     * @returns {Observable<ValidateEcheckResponse>}
     * @memberof EcheckService
     */
    validateEcheck(echeckRequest: ValidateEcheckRequest): Observable<ValidateEcheckResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .post(ApiUrlConstants.paymentApiUrl + '/payments/validate-payment-check', echeckRequest, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     *
     * @date 2018-08-07
     * @param {number} memberId
     * @param {string} countryCode
     * @returns {Observable<IPersonalCheck[]>}
     * @memberof EcheckService
     */
    getSavedEchecks(memberId: number, countryCode: string): Observable<PersonalCheck[]> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/members/' + memberId +
                '/personal-checks?countryCode=' + countryCode, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this is used to get
     * payment headers
     * @date 2018-08-07
     * @returns {Headers}
     * @memberof EcheckService
     */
    getPaymentHeaders(): Headers {
        const headers = new Headers();
        const authHeader = 'PAY ' + environment.paymentApiKey + ':' + this.getHashedValue();
        headers.append('authorization', authHeader);
        return headers;
    }

    /**
     * get payment crypto hashed value
     * @date 2018-08-07
     * @returns {string}
     * @memberof EcheckService
     */
    getHashedValue(): string {
        const shavalue = crypto.HmacSHA1(environment.paymentSecurityKey, environment.paymentServiceKey);
        return crypto.enc.Base64.stringify(shavalue);
    }

    /**
     * To handle the obervable error response
     * @date 2018-08-07
     * @private
     * @param {(Response | any)} error
     * @returns
     * @memberof EcheckService
     */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error);
    }


}
