import { OnInit, Component, OnDestroy, Output, EventEmitter, Input } from '@angular/core';
import {
    CacheService, CommonService, CartService,
    ConfigurationService, ActiveSessionService, DataShareService
} from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Cart, Item } from '../../shared/models';
import { State, Country } from '../../shared/interfaces';
import { MemberType } from '../../shared/enums';
import {
    WholesaleQualifiedResponse, TaxRequest, TaxResponse, TaxCart,
    TaxItems, CheckoutInformation, Autoship,
    AutoshipProfileResponse, AutoshipFrequencyResponse, TaxValidationMessage
} from '../interfaces';
import {
    OrderTaxService, ShippingMethodService,
    CheckoutMessageService, AutoshipService
} from '../services';
import { CurrencyPipe } from '../../common/pipes/currency-format.pipe';
import {
    ShippingType, OrderType,
    DeliveryOptionType, AutoshipFrequency, TaxType
} from '../enums';
import { OrderSource } from '../constants/order-source.constants';
import { CartSummaryComponentSettings } from '../component-settings';
import { environment } from '../../../environments/environment';
import { Translations } from '../constants';
import { TranslateService } from '@ngx-translate/core';
import { AppMessageService } from '../../app-message.service';
import { Address } from '../../common/interfaces';
import { Product } from '../../products/interfaces/product.interface';
import { Router } from '@angular/router';

/**
 * @description Retrieving the Cart Summary
 * which includes the order cart and Autoship cart
 * along with the shipping Restriction
 * @author NextSphere Technologies
 * @date 2018-07-19
 * @export
 * @class CartSummaryComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-cart-summary',
    templateUrl:
        '../templates/template3/views/cart-summary_new.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/cart-summary_new.component.less'
    ]
})

export class CartSummaryComponent implements OnInit, OnDestroy {
    cartSummaryComponentSettings: CartSummaryComponentSettings = new CartSummaryComponentSettings();

    // Output variables
    @Output() getCartSummary = new EventEmitter<any>();

    constructor(private _cacheService: CacheService,
        private _commonService: CommonService,
        private _taxService: OrderTaxService,
        private _currencyPipe: CurrencyPipe,
        private _cartService: CartService,
        private _translatePipe: TranslateService,
        private _configurationService: ConfigurationService,
        private _shippingMethodService: ShippingMethodService,
        private _activeSessionService: ActiveSessionService,
        private _checkoutMessageService: CheckoutMessageService,
        private _autoshipService: AutoshipService,
        private _appMessageService: AppMessageService,
        private _router: Router,
        private _dataService: DataShareService) {
    }

    ngOnInit() {
        this.loadDefaultSettings();
    }

    /**
     * @description Used to load default Cart summary
     * Configuration for the user
     * @date 2018-07-20
     * @memberof CartSummaryComponent
     */
    loadDefaultSettings() {
        this.cartSummaryComponentSettings.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        this.cartSummaryComponentSettings.autoshipDetails = this._cacheService.get(CacheKey.AutoshipDetails);
        this.cartSummaryComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.cartSummaryComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.cartSummaryComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.cartSummaryComponentSettings.store = this._configurationService.getStoreData();
        this.cartSummaryComponentSettings.memberTitleId = this._activeSessionService.getMemberTitleId();
        this.getCartItems();
        this.getAutoshipDates();
        this.getAutoshipCart();
        this.getCountriesLookup();
        this.getTaxInformation();
        this.getFrequencyTypes();
        this.getProcessOrderEvent();
        this.getCartSessionInfo();
        this.subscribePlaceOrderEvent();
        this.shippingMethodSubscription();
    }

    /**
     * shipping Mthodtype subscription
     * for progressbar status change
     * @memberof CheckoutNewComponent
     */
    shippingMethodSubscription(): void {
        const checkoutInfo = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInfo && checkoutInfo.shippingInformation &&
            checkoutInfo.shippingInformation.deliveryOptionType) {
            this.cartSummaryComponentSettings.deliveryOptionType = checkoutInfo.shippingInformation.deliveryOptionType;
        }
        this.cartSummaryComponentSettings.deliveryOptionType = this.cartSummaryComponentSettings.deliveryOptionType
            || DeliveryOptionType.Delivery;
        this._checkoutMessageService.getShipmethodTypeSelected().subscribe((deliveryOptionType: DeliveryOptionType) => {
            this.cartSummaryComponentSettings.deliveryOptionType = deliveryOptionType;
            if (deliveryOptionType !== this.cartSummaryComponentSettings.deliveryOptions.Pickup
                && this.cartSummaryComponentSettings.userInfo
                && this.cartSummaryComponentSettings.userInfo.memberTypeId !== MemberType.RETAILCUSTOMER) {
                this.cartSummaryComponentSettings.taxableAmount = 0;
                this.cartSummaryComponentSettings.gstTax = 0;
                this.cartSummaryComponentSettings.pstTax = 0;
                this.cartSummaryComponentSettings.shippingTotal = 0;
            }
        });
    }

    /**
     * @description this method will triggrer when laoding of
     * cart items done from service
     * @date 2018-08-01
     * @private
     * @memberof CartSummaryComponent
     */
    private getCartSessionInfo(): void {
        this.cartSummaryComponentSettings.cartSubscription
            = this._appMessageService.getCartItemsChanges()
                .subscribe((response) => {
                    this.getCartItems();
                });
    }


    /**
     * @description this method will
     * subscribe message when we select
     * shipping method
     * @date 2018-07-23
     * @memberof CartSummaryComponent
     */
    getTaxInformation(): void {
        this.cartSummaryComponentSettings.taxCalcSubscription = this._checkoutMessageService
            .getTaxCalc()
            .subscribe((isReloadCart: boolean) => {
                if (isReloadCart) {
                    this.cartSummaryComponentSettings.autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
                }
                this.calculateOrderTax();
                this.ExecuteCalculateAutoshipTax();
            });
    }

    trackByItem(index: number): number {
        return index;
    }
    /**
     * @description this method will trigger event when
     * we are excuted from payment page
     * @date 2018-08-01
     * @memberof CartSummaryComponent
     */
    getProcessOrderEvent(): void {
        this.cartSummaryComponentSettings.processOrderSubscription = this._appMessageService
            .getProcessOrder()
            .subscribe((recreateOrder: boolean) => {
                this.cartSummaryComponentSettings.disableChangeCartBtn = true;
                this.cartSummaryComponentSettings.recreateOrder = recreateOrder;
                this.getCartSummary.emit(this.cartSummaryComponentSettings);
            });
    }

    /**
     * @description this method subscribe the place order
     * request status
     * @date 2018-08-17
     * @memberof ShippingMethodsNewComponent
     */
    subscribePlaceOrderEvent(): void {
        this.cartSummaryComponentSettings.placeOrderCartSubscription = this._checkoutMessageService
            .getDisablePlaceOrderBtn()
            .subscribe((response: TaxValidationMessage) => {
                this.cartSummaryComponentSettings.disableChangeCartBtn = response.isDisablePlaceOrderBtn;
            });
    }

    /**
     * @description Calculate Autsohip Tax
     * @date 2018-10-25
     * @memberof CartSummaryComponent
     */
    ExecuteCalculateAutoshipTax(): void {
        if (this.cartSummaryComponentSettings.autoshipCart && !this.cartSummaryComponentSettings.isAutoshipEnabled
            && !this.cartSummaryComponentSettings.autoshipDetails) {
            this.calculateAutoshipTax();
        }
    }

    /**
     * @description Get Countries
     * @date 2018-07-19
     * @private
     * @memberof CartSummaryComponent
     */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.cartSummaryComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            this.cartSummaryComponentSettings.selectedCountry =
                this.cartSummaryComponentSettings.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
                    this.cartSummaryComponentSettings.isoCountryCode.toLowerCase());
            if (this.cartSummaryComponentSettings.selectedCountry && this.cartSummaryComponentSettings.selectedCountry.countryId) {
                this.getStatesLookup(this.cartSummaryComponentSettings.selectedCountry.countryId);
            }
        } else {
            this._commonService.getCountries().subscribe((res: Country[]) => {
                if (res && res.length > 0) {
                    this.cartSummaryComponentSettings.countries = res;
                    this._cacheService.set(CacheKey.Countries, this.cartSummaryComponentSettings.countries);
                    this.cartSummaryComponentSettings.selectedCountry = this.cartSummaryComponentSettings.countries.
                        find((x: Country) => x.isocodeThree.toLowerCase()
                            === this.cartSummaryComponentSettings.isoCountryCode.toLowerCase());
                    if (this.cartSummaryComponentSettings.selectedCountry && this.cartSummaryComponentSettings.selectedCountry.countryId) {
                        this.getStatesLookup(this.cartSummaryComponentSettings.selectedCountry.countryId);
                    }
                }
            });
        }
    }

    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof CartSummaryComponent
     */
    private getStatesLookup(countryId: number) {
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            this.cartSummaryComponentSettings.states = storedStates;
        } else {
            if (countryId) {
                this._commonService.getStatesByCountry(countryId).subscribe((res: State[]) => {
                    this.cartSummaryComponentSettings.states = res;
                }, (err: any) => {
                });
            }
        }
    }

    /**
     * @description To get Cart Items
     * @date 2018-07-19
     * @memberof CartSummaryComponent
     */
    getCartItems(): void {
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        if (cartSession && cartSession.items && cartSession.items.length > 0) {
            this.cartSummaryComponentSettings.cartItemsList = [];
            this.cartSummaryComponentSettings.shoppingCart = new Cart(cartSession, this.cartSummaryComponentSettings.store);
            if (this.cartSummaryComponentSettings.isPreferredCustomer &&
                this.cartSummaryComponentSettings.store && this.cartSummaryComponentSettings.store.distributorMaxCC) {
                // If Preferred Customer - check if the wholesale qualified limit is reached by adding cart CC and already availed CC.
                this.wholesaleQualifiedCheck();
            }
            this.calculateOrderTax();
            if (this.cartSummaryComponentSettings.autoshipCart && this.cartSummaryComponentSettings.autoshipCart.items
                && this.cartSummaryComponentSettings.autoshipCart.items.length) {
                this.calculateAutoshipTax();
            }
            this.verifyBussinesOrderRules();
            this.cartSummaryComponentSettings.shoppingCart.items.forEach((x: Item) => {
                this.cartSummaryComponentSettings.cartItemsList.push(x);
            });
        }
    }

    /**
     * @description Verify the Bussiness Order Rules
     * @date 2018-07-19
     * @private
     * @memberof CartSummaryComponent
     */
    private verifyBussinesOrderRules(): void {
        this.cartSummaryComponentSettings.orderRules = this._cacheService.get(CacheKey.OrderRules);
        this.cartSummaryComponentSettings.memberOrderCCInfo = this._cacheService.get(CacheKey.MemberOrderRules);
        if (this.cartSummaryComponentSettings.orderRules) {
            const validateOrderRule = this._commonService.verifyOrderRules();
            this.cartSummaryComponentSettings.thresholdCrossed = validateOrderRule.thresholdCrossed;
            this.cartSummaryComponentSettings.memberCCLimitExceeded = validateOrderRule.monthlyCCValid;
        }
    }


    /**
     * @description Wholesale Qualified Eligibility Check
     * @date 2018-07-19
     * @memberof CartSummaryComponent
     */
    wholesaleQualifiedCheck(): void {
        this.cartSummaryComponentSettings.isCCLimitCrossed = this.calculateCCLimit();
        this.cartSummaryComponentSettings.hasSelectedAsFBO = this._cacheService.get(CacheKey.OptInSelection) ?
            JSON.parse(this._cacheService.get(CacheKey.OptInSelection)) : this.cartSummaryComponentSettings.hasSelectedAsFBO;
        if (this.cartSummaryComponentSettings.isCCLimitCrossed === false && this.cartSummaryComponentSettings.hasSelectedAsFBO === true) {
            this.cartSummaryComponentSettings.hasSelectedAsFBO = false;
            this.cartSummaryComponentSettings.isSelected = false;
            this._cacheService.set(CacheKey.OptInSelection, JSON.stringify(this.cartSummaryComponentSettings.hasSelectedAsFBO));
        }
        if (this.cartSummaryComponentSettings.isCCLimitCrossed === true && this.cartSummaryComponentSettings.hasSelectedAsFBO === true) {
            this.cartSummaryComponentSettings.isSelected = true;
        }
    }

    /**
     * @description Calculate CC Limit
     * @date 2018-07-20
     * @returns {boolean}
     * @memberof CartSummaryComponent
     */
    calculateCCLimit(): boolean {
        if ((this.cartSummaryComponentSettings.shoppingCart.totalPoints + this.cartSummaryComponentSettings.existingCC)
            > this.cartSummaryComponentSettings.store.distributorMaxCC) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @description Calculate Order Tax
     * @date 2018-07-19
     * @param {*} checkoutInfo
     * @memberof CartSummaryComponent
     */
    calculateOrderTax(): void {
        const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInfo && checkoutInfo.shippingMethodInformation
            && checkoutInfo.shippingInformation && (checkoutInfo.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup ||
                (checkoutInfo.shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery
                    && this._shippingMethodService.getShippingAddress(this.cartSummaryComponentSettings.states)))) {
            this.cartSummaryComponentSettings.isTaxCalculating = true;
            this.cartSummaryComponentSettings.orderTaxValid = false;
            this.mapCartInformation(checkoutInfo);
            const taxRequest: TaxRequest = this.prepareTaxRequest(checkoutInfo, false);
            this._checkoutMessageService.setDisablePlaceOrderBtn(this.constructTaxValidation(true, null));
            this._taxService.calculateOrderTax(taxRequest)
                .subscribe((taxResponse: TaxResponse) => {
                    this._checkoutMessageService.setDisablePlaceOrderBtn(this.constructTaxValidation(false, null));
                    if (taxResponse && taxResponse.success) {
                        if (taxResponse.cart && taxResponse.cart.totalTax >= 0) {
                            this.mapTaxResponse(taxResponse);
                        }
                    } else {
                        this.cartSummaryComponentSettings.orderTaxValid = false;
                        this.mapTaxResponse(null);
                    }
                    this.cartSummaryComponentSettings.isTaxCalculating = false;
                }, (error: any) => {
                    if (error) {
                        const taxResponse = error.json();
                        if (taxResponse.validations && taxResponse.validations.length > 0) {
                            this.cartSummaryComponentSettings.taxValidation = taxResponse.validations[0].message;
                            if (taxResponse.validations[0].errorId) {
                                this.cartSummaryComponentSettings.errorId = taxResponse.validations[0].errorId;
                            }
                        }
                    }
                    this._checkoutMessageService.setDisablePlaceOrderBtn(
                        this.constructTaxValidation(true, this.cartSummaryComponentSettings.taxValidation,
                            this.cartSummaryComponentSettings.errorId));
                    this.cartSummaryComponentSettings.orderTaxValid = true;
                    this.mapTaxResponse(null);
                    this.cartSummaryComponentSettings.isTaxCalculating = false;
                });
        }
    }

    /**
     * @description map tax validation error changes
     * @date 2019-03-14
     * @param {boolean} isDisablePlaceOrderBtn
     * @returns {TaxValidationMessages}
     * @memberof CartSummaryComponent
     */
    constructTaxValidation(isDisablePlaceOrderBtn: boolean, validationMessages: string, errorId?: string): TaxValidationMessage {
        const taxValidationErrors: TaxValidationMessage = {
            isDisablePlaceOrderBtn: isDisablePlaceOrderBtn,
            validations: validationMessages,
            errorId: errorId ? errorId : null
        };
        return taxValidationErrors;
    }


    /**
     * @description Calculate Autoship Tax
     * @date 2018-10-15
     * @memberof CartSummaryComponent
     */
    calculateAutoshipTax(): void {
        const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInfo && checkoutInfo.autoshipShippingMethodInformation) {
            this.mapAutoshipCartInformation(checkoutInfo);
            const taxRequest: TaxRequest = this.prepareTaxRequest(checkoutInfo, true);
            this._taxService.calculateOrderTax(taxRequest)
                .subscribe((taxResponse: TaxResponse) => {
                    if (taxResponse && taxResponse.success) {
                        if (taxResponse.cart && taxResponse.cart.totalTax >= 0) {
                            this.mapAutoshipTaxResponse(taxResponse);
                        }
                    } else {
                        this.mapAutoshipTaxResponse(null);
                    }
                }, (err: any) => {
                    this.mapAutoshipTaxResponse(null);
                });
        }
    }

    /**
     * @description this method used
     * to load checkout information
     * @date 2018-07-23
     * @private
     * @param {CheckoutInformation} checkoutInfo
     * @memberof CartSummaryComponent
     */
    private mapCartInformation(checkoutInfo: CheckoutInformation): void {
        const isAutoshipEnabled: boolean = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (checkoutInfo.shippingMethodInformation &&
            checkoutInfo.shippingMethodInformation.shippingMethod) {
            if (isAutoshipEnabled) {
                this.cartSummaryComponentSettings.autoshipShippingTotal =
                    checkoutInfo.shippingMethodInformation.shippingMethod.shippingCharge;
                this.cartSummaryComponentSettings.autoshipImportFeeValue =
                    checkoutInfo.shippingMethodInformation.shippingMethod.importFeeValue;
                this.cartSummaryComponentSettings.autoshipImportFeeEnabled =
                    checkoutInfo.shippingMethodInformation.shippingMethod.importFeeEnabled;
            }
            this.cartSummaryComponentSettings.shippingTotal = checkoutInfo.shippingMethodInformation.shippingMethod.shippingCharge;
            this.cartSummaryComponentSettings.importFeeValue = checkoutInfo.shippingMethodInformation.shippingMethod.importFeeValue;
            this.cartSummaryComponentSettings.importFeeEnabled = checkoutInfo.shippingMethodInformation.shippingMethod.importFeeEnabled;
            this.cartSummaryComponentSettings.shoppingCart = new Cart(this.cartSummaryComponentSettings.shoppingCart,
                this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.shippingTotal +
                this.cartSummaryComponentSettings.importFeeValue);
            if (isAutoshipEnabled) {
                this.cartSummaryComponentSettings.autoshipCart = new Cart(this.cartSummaryComponentSettings.autoshipCart,
                    this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.shippingTotal
                    + this.cartSummaryComponentSettings.importFeeValue);
                this._cacheService.set(CacheKey.AutoshipCart, this.cartSummaryComponentSettings.autoshipCart);
            }

        }
    }

    /**
     * @description this method used
     * to load checkout information
     * @date 2018-10-14
     * @private
     * @param {CheckoutInformation} checkoutInfo
     * @memberof CartSummaryComponent
     */
    private mapAutoshipCartInformation(checkoutInfo: CheckoutInformation): void {
        if (checkoutInfo.autoshipShippingMethodInformation.shippingMethod) {
            this.cartSummaryComponentSettings.autoshipShippingTotal =
                checkoutInfo.autoshipShippingMethodInformation.shippingMethod.shippingCharge;
            this.cartSummaryComponentSettings.autoshipImportFeeValue =
                checkoutInfo.autoshipShippingMethodInformation.shippingMethod.importFeeValue;
            this.cartSummaryComponentSettings.autoshipImportFeeEnabled =
                checkoutInfo.autoshipShippingMethodInformation.shippingMethod.importFeeEnabled;
            this.cartSummaryComponentSettings.autoshipCart = new Cart(this.cartSummaryComponentSettings.autoshipCart,
                this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.autoshipShippingTotal
                + this.cartSummaryComponentSettings.autoshipImportFeeValue);
            this._cacheService.set(CacheKey.AutoshipCart, this.cartSummaryComponentSettings.autoshipCart);
        }
    }

    /**
     * @description Prepare Tax Request
     * @date 2018-07-19
     * @private
     * @param {*} checkoutInfo
     * @returns {TaxRequest}
     * @memberof CartSummaryComponent
     */
    private prepareTaxRequest(checkoutInfo: CheckoutInformation, isAutoship: boolean): TaxRequest {
        const taxRequest: TaxRequest = {
            orderID: 0,
            memberID: this.cartSummaryComponentSettings.userInfo ? this.cartSummaryComponentSettings.userInfo.memberId : 0,
            shopingCart: isAutoship ? this.mapAutoshipCartToTaxCart(checkoutInfo) : this.mapCartToTaxCart(checkoutInfo),
            fromAddress: (checkoutInfo && checkoutInfo.shippingInformation &&
                checkoutInfo.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup) ?
                this.getTaxPickUpAddress()
                : this._configurationService.getWarehouseAddress(this.cartSummaryComponentSettings.isoCountryCode),
            toAddress: this._shippingMethodService.getShippingAddress(this.cartSummaryComponentSettings.states),
            memberNumber: this.cartSummaryComponentSettings.userInfo ? this.cartSummaryComponentSettings.userInfo.distributorId : null,
            orderNumber: 0,
            storeID: this.cartSummaryComponentSettings.store.id,
            priceTierName: this.getPriceTier(isAutoship),
            currencyCode: this.cartSummaryComponentSettings.store.currencyCode,
            countryCode: this.cartSummaryComponentSettings.isoCountryCode,
            deliveryTypeId: this.getDeliveryTypeId(checkoutInfo, isAutoship),
            orderSource: OrderSource.WEB,
            orderTypeId: this._activeSessionService.getOrderTypeId(),
            conversionRate: 1,
            memberLevelId: this._activeSessionService.getMemberTitleId(),
            wholesaleQualified: this.cartSummaryComponentSettings.userInfo
                && this.cartSummaryComponentSettings.userInfo.wholesaleQualified ? true : false
        };
        return taxRequest;
    }

    /**
     * @description get Delivery option id
     * @date 2018-10-15
     * @param {CheckoutInformation} checkoutInfo
     * @param {boolean} isAutoship
     * @returns {ShippingType}
     * @memberof CartSummaryComponent
     */
    getDeliveryTypeId(checkoutInfo: CheckoutInformation, isAutoship: boolean): ShippingType {
        if (isAutoship) {
            return ShippingType.DELIVERY;
        } else {
            return checkoutInfo && checkoutInfo.shippingInformation &&
                checkoutInfo.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup
                ? ShippingType.PICKUP : ShippingType.DELIVERY;
        }
    }

    /**
     * @description map Tax Response
     * @date 2018-07-20
     * @private
     * @param {TaxResponse} taxResponse
     * @memberof CartSummaryComponent
     */
    private mapTaxResponse(taxResponse: TaxResponse): void {
        const isAutoshipEnabled: boolean = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (taxResponse) {
            taxResponse.cart.totalTax = this._currencyPipe.getFormatedCurrency(taxResponse.cart.totalTax);
            this.cartSummaryComponentSettings.orderTaxResponse = taxResponse;
            this.cartSummaryComponentSettings.taxableAmount = taxResponse.cart.totalTax;
            if (this.cartSummaryComponentSettings.orderTaxResponse && this.cartSummaryComponentSettings.orderTaxResponse.taxMetaData
                && this.cartSummaryComponentSettings.orderTaxResponse.taxMetaData.orderTaxCharges
                && this.cartSummaryComponentSettings.orderTaxResponse.taxMetaData.orderTaxCharges.length) {
                const gst = this.cartSummaryComponentSettings.orderTaxResponse.taxMetaData.orderTaxCharges
                    .find(tax => tax.taxChargeType === TaxType.GST_TAX);
                const pst = this.cartSummaryComponentSettings.orderTaxResponse.taxMetaData.orderTaxCharges
                    .find(tax => tax.taxChargeType === TaxType.PST_TAX);
                this.cartSummaryComponentSettings.gstTax = gst ? gst.taxAmount : 0;
                this.cartSummaryComponentSettings.pstTax = pst ? pst.taxAmount : 0;
            }
            if (isAutoshipEnabled) {
                this.cartSummaryComponentSettings.autoshipTaxableAmount = taxResponse.cart.totalTax;
            }
        } else {
            this.cartSummaryComponentSettings.orderTaxResponse = null;
            this.cartSummaryComponentSettings.taxableAmount = 0;
        }
        this.cartSummaryComponentSettings.shoppingCart = new Cart(this.cartSummaryComponentSettings.shoppingCart,
            this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.shippingTotal
            + this.cartSummaryComponentSettings.importFeeValue, this.cartSummaryComponentSettings.taxableAmount);
        if (isAutoshipEnabled) {
            this.cartSummaryComponentSettings.autoshipCart = new Cart(this.cartSummaryComponentSettings.autoshipCart,
                this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.shippingTotal
                + this.cartSummaryComponentSettings.importFeeValue, this.cartSummaryComponentSettings.taxableAmount);
            this._cacheService.set(CacheKey.AutoshipCart, this.cartSummaryComponentSettings.autoshipCart);
        }
    }

    /**
     * @description Map Autoship Tax Response
     * @date 2018-10-15
     * @private
     * @param {TaxResponse} taxResponse
     * @memberof CartSummaryComponent
     */
    private mapAutoshipTaxResponse(taxResponse: TaxResponse): void {
        if (taxResponse) {
            taxResponse.cart.totalTax = this._currencyPipe.getFormatedCurrency(taxResponse.cart.totalTax);
            this.cartSummaryComponentSettings.autoshipOrderTaxResponse = taxResponse;
            this.cartSummaryComponentSettings.autoshipTaxableAmount = taxResponse.cart.totalTax;
            if (taxResponse.taxMetaData
                && taxResponse.taxMetaData.orderTaxCharges
                && taxResponse.taxMetaData.orderTaxCharges.length) {
                const gst = taxResponse.taxMetaData.orderTaxCharges
                    .find(tax => tax.taxChargeType === TaxType.GST_TAX);
                const pst = taxResponse.taxMetaData.orderTaxCharges
                    .find(tax => tax.taxChargeType === TaxType.PST_TAX);
                this.cartSummaryComponentSettings.gstTax = gst ? gst.taxAmount : 0;
                this.cartSummaryComponentSettings.pstTax = pst ? pst.taxAmount : 0;
            }
        } else {
            this.cartSummaryComponentSettings.autoshipOrderTaxResponse = null;
            this.cartSummaryComponentSettings.autoshipTaxableAmount = 0;
        }
        this.cartSummaryComponentSettings.autoshipCart = new Cart(this.cartSummaryComponentSettings.autoshipCart,
            this.cartSummaryComponentSettings.store, this.cartSummaryComponentSettings.autoshipShippingTotal
            + this.cartSummaryComponentSettings.autoshipImportFeeValue, this.cartSummaryComponentSettings.autoshipTaxableAmount);
        this._cacheService.set(CacheKey.AutoshipCart, this.cartSummaryComponentSettings.autoshipCart);
    }

    /**
     * @description Mapping Cart To Tax Cart
     * @date 2018-07-19
     * @private
     * @param {*} checkoutInfo
     * @returns {TaxCart}
     * @memberof CartSummaryComponent
     */
    private mapCartToTaxCart(checkoutInfo: CheckoutInformation): TaxCart {
        const isAutoshipEnabled: boolean = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        const taxCart: TaxCart = {
            shippingTaxInclusive: this.cartSummaryComponentSettings.shoppingCart.isShippingTaxInclusive,
            totalTax: this.cartSummaryComponentSettings.shoppingCart.totalTax,
            shippingTax: this.cartSummaryComponentSettings.shoppingCart.shippingTax,
            shipMethodId: this.getShippingMethodId(checkoutInfo, false),
            shippingCost: this.cartSummaryComponentSettings.shippingTotal,
            importFeeValue: this.getImportFeeValue(checkoutInfo, false),
            orderLineItems: this.mapItemstoTaxItems(isAutoshipEnabled ?
                this.cartSummaryComponentSettings.autoshipCart : this.cartSummaryComponentSettings.shoppingCart)
        };
        return taxCart;
    }

    /**
     * @description Map Autoship Cart To Tax Cart
     * @date 2018-10-15
     * @private
     * @param {CheckoutInformation} checkoutInfo
     * @returns {TaxCart}
     * @memberof CartSummaryComponent
     */
    private mapAutoshipCartToTaxCart(checkoutInfo: CheckoutInformation): TaxCart {
        const taxCart: TaxCart = {
            shippingTaxInclusive: this.cartSummaryComponentSettings.autoshipCart.isShippingTaxInclusive,
            totalTax: this.cartSummaryComponentSettings.autoshipCart.totalTax,
            shippingTax: this.cartSummaryComponentSettings.autoshipCart.shippingTax,
            shipMethodId: this.getShippingMethodId(checkoutInfo, true),
            shippingCost: this.cartSummaryComponentSettings.autoshipShippingTotal,
            importFeeValue: this.getImportFeeValue(checkoutInfo, true),
            orderLineItems: this.mapItemstoTaxItems(this.cartSummaryComponentSettings.autoshipCart)
        };
        return taxCart;
    }

    /**
     * @description this method is used
     * to get shipping methodid from seleted shipping option
     * @date 2018-07-23
     * @private
     * @returns {number}
     * @memberof CartSummaryComponent
     */
    private getShippingMethodId(checkoutInfo: CheckoutInformation, isAutoship: boolean): number {
        if (isAutoship) {
            return checkoutInfo && checkoutInfo.autoshipShippingMethodInformation &&
                checkoutInfo.autoshipShippingMethodInformation.shippingMethod
                ? checkoutInfo.autoshipShippingMethodInformation.shippingMethod.shippingMethodId : 0;
        } else {
            return checkoutInfo && checkoutInfo.shippingMethodInformation && checkoutInfo.shippingMethodInformation.shippingMethod
                ? checkoutInfo.shippingMethodInformation.shippingMethod.shippingMethodId : 0;
        }
    }

    /**
     * @description this method is used
     * to get importFeeValue from seleted shipping option
     * @date 2018-07-23
     * @private
     * @returns {number}
     * @memberof CartSummaryComponent
     */
    private getImportFeeValue(checkoutInfo: CheckoutInformation, isAutoship: boolean): number {
        if (isAutoship) {
            return checkoutInfo && checkoutInfo.autoshipShippingMethodInformation &&
                checkoutInfo.autoshipShippingMethodInformation.shippingMethod
                ? checkoutInfo.autoshipShippingMethodInformation.shippingMethod.importFeeValue : 0;
        } else {
            return checkoutInfo && checkoutInfo.shippingMethodInformation && checkoutInfo.shippingMethodInformation.shippingMethod
                ? checkoutInfo.shippingMethodInformation.shippingMethod.importFeeValue : 0;
        }
    }


    /**
     * @description Mapping Items to Tax Items
     * @date 2018-07-19
     * @private
     * @returns {TaxItems[]}
     * @memberof CartSummaryComponent
     */
    private mapItemstoTaxItems(cart: Cart): TaxItems[] {
        const taxItems: TaxItems[] = [];
        if (cart && cart.items && cart.items.length > 0) {
            let itemLineNumber = 0;
            cart.items.forEach((x: Item) => {
                const taxItem: TaxItems = {
                    lineNumber: ++itemLineNumber,
                    itemNumber: x.itemNumber,
                    taxablePrice: x.applicablePrice,
                    quantity: x.quantity,
                    taxCode: null,
                    description: x.shortDescription,
                    taxInclusive: false,
                    resale: false,
                    resalePrice: 0,
                    taxBreakDown: x.taxBreakDown,
                    productIdentifier: null,
                    retailPrice: x.retailPrice,
                    paidPrice: x.applicablePrice,
                    wholeSalePrice: x.wholesalePrice,
                    salesTax: 0,
                    revisionNumber: x.revisionNumber,
                    itemWeight: x.weight,
                    importedMeasurementUnit: x.importedMeasurementUnit
                };
                taxItems.push(taxItem);
            });
        }
        return taxItems;
    }

    /**
     * @description Get Pickup Address
     * @date 2018-07-19
     * @private
     * @returns {Address}
     * @memberof CartSummaryComponent
     */
    private getTaxPickUpAddress(): Address {
        const checkOutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkOutInfo) {
            if (checkOutInfo.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup &&
                checkOutInfo.shippingMethodInformation.shippingMethod
                && checkOutInfo.shippingMethodInformation.shippingMethod.pickUpLocation) {
                return this._shippingMethodService.getPickupAddress(checkOutInfo.shippingMethodInformation.shippingMethod,
                    this.cartSummaryComponentSettings.states, this.cartSummaryComponentSettings.countries);
            }
        } else {
            return this._configurationService.getWarehouseAddress(this.cartSummaryComponentSettings.isoCountryCode);
        }
    }

    /**
   * @description Get Price Tier
   * @date 2018-07-19
   * @returns
   * @memberof CartSummaryComponent
   */
    getPriceTier(isAutoship: boolean): string {
        let priceTierName = '';
        if (isAutoship && this.cartSummaryComponentSettings.autoshipCart && this.cartSummaryComponentSettings.autoshipCart.items
            && this.cartSummaryComponentSettings.autoshipCart.items.length > 0) {
            priceTierName = this.cartSummaryComponentSettings.autoshipCart.items[0].priceTierName;
        } else if (this.cartSummaryComponentSettings.shoppingCart && this.cartSummaryComponentSettings.shoppingCart.items
            && this.cartSummaryComponentSettings.shoppingCart.items.length > 0) {
            priceTierName = this.cartSummaryComponentSettings.shoppingCart.items[0].priceTierName;
        }
        return priceTierName;
    }

    /** AutoShip */

    /**
     * @description Get Autoship Cart
     * @date 2018-07-20
     * @memberof CartSummaryComponent
     */
    getAutoshipCart(): void {
        this.cartSummaryComponentSettings.autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
        if (this.cartSummaryComponentSettings.isAutoshipEnabled && this.cartSummaryComponentSettings.autoshipCart) {
            this._appMessageService.setMiniCart(this.cartSummaryComponentSettings.autoshipCart);
        }
        if (this.cartSummaryComponentSettings.autoshipCart && this.cartSummaryComponentSettings.autoshipCart.itemsCount > 0) {
            this.cartSummaryComponentSettings.hasAutoshipItems = true;
            if (this.cartSummaryComponentSettings.userInfo) {
                const autoshipDate = this._cacheService.get(CacheKey.AutoshipDate);
                if (autoshipDate) {
                    this.cartSummaryComponentSettings.autoshipDate = autoshipDate;
                }
            }
        }
    }

    /**
     * @description Validating Autoship Profile name
     * @date 2018-07-20
     * @param {string} autoShipName
     * @memberof CartSummaryComponent
     */
    validateAutoShipProfileName(autoShipName: string) {
        if (this.cartSummaryComponentSettings.userInfo && this.cartSummaryComponentSettings.userInfo.memberId) {
            this._cartService
                .validateAutoShipProfileName(this.cartSummaryComponentSettings.userInfo.memberId)
                .subscribe(response => {
                    this.processAutoShipProfileResponse(response, autoShipName);
                }, error => {
                    this.removeAutoshipValidation();
                });
        }
    }

    /**
     * @description this method used
     * to process the autoship response
     * @date 2018-07-23
     * @private
     * @param {*} response
     * @memberof CartSummaryComponent
     */
    private processAutoShipProfileResponse(autoshipProfileResponse: AutoshipProfileResponse[],
        autoShipName: string): void {
        if (autoshipProfileResponse && autoshipProfileResponse[0].body && autoshipProfileResponse[0].body.length > 0) {
            const autoShipProfiles: Autoship[] = autoshipProfileResponse[0].body;
            if (autoShipProfiles && autoShipProfiles.length) {
                const existingAutoshipName = autoShipProfiles.find(x => x.name.toLowerCase() === autoShipName.toLowerCase());
                if (existingAutoshipName) {
                    this.cartSummaryComponentSettings.showAutoShipErrorMessage = true;
                    const error: any = this._translatePipe.get('checkout.' + Translations.AutoShipProfileName);
                    this.cartSummaryComponentSettings.errorAutoShipMessage = error.value;
                } else {
                    this.removeAutoshipValidation();
                }
            } else {
                this.removeAutoshipValidation();
            }
        } else {
            this.removeAutoshipValidation();
        }
    }

    /**
     * @description remove Autoship validations
     * @date 2018-07-20
     * @memberof CartSummaryComponent
     */
    removeAutoshipValidation(): void {
        this.cartSummaryComponentSettings.showAutoShipErrorMessage = false;
        this.cartSummaryComponentSettings.errorAutoShipMessage = null;
    }

    /**
     * @description change Autoship Name and Date
     * @date 2018-07-20
     * @param {string} autoshipName
     * @param {*} autoshipDate
     * @memberof CartSummaryComponent
     */
    changeAutoshipNameAndDate(autoshipDate: Date) {
        const date = new Date(autoshipDate);
        this._cacheService.set(CacheKey.AutoshipDate, date);
    }

    /**
    * @description Enable the dates only in given Range
    */
    public myFilter = (d: any): boolean => {
        if (d) {
            const date = d._d.getDate();
            if (date >= environment.autoShipStartDay && date <= environment.autoShipEndDay) {
                return true;
            }
        }
    }

    /**
     * @description set Current Date for Autoship
     * @date 2018-07-20
     * @memberof CartSummaryComponent
     */
    setCurrentDate(): void {
        const date = new Date().toJSON().split('T')[0];
        this.cartSummaryComponentSettings.autoshipDate = new Date(date);
    }

    /**
     * @description Get Autoship Dates
     * @date 2018-07-20
     * @memberof CartSummaryComponent
     */
    getAutoshipDates(): void {
        const currentDate = new Date();
        this.cartSummaryComponentSettings.minDate = new Date();
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth() + (environment.autoShipMaxMonths);
        const day = environment.autoShipEndDay;
        this.cartSummaryComponentSettings.maxDate = new Date(year, month, day);
    }

    /**
     * @description load autoship frequencies
     * @date 2018-07-31
     * @memberof CartSummaryComponent
     */
    getFrequencyTypes(): void {
        this._autoshipService.getFrequencyTypes()
            .subscribe((response: AutoshipFrequencyResponse[]) => {
                if (response && response[0] && response[0].body) {
                    const frequencyTypes = response[0].body;
                    this.cartSummaryComponentSettings.frequencyTypeId = frequencyTypes
                        .filter((x) => x.id === AutoshipFrequency.Monthly)[0].id;
                }
            });
    }


    /**
     * @description Navigates to product detail
     * @param {Product} product
     * @memberof CartSummaryComponent
     */
    navigateToProductDetail(product: Product): void {
        let selectedCategory;
        if (product.categories) {
            selectedCategory = product.categories[0];
        }
        if (product.parentProductSlug) {
            product.slug = product.parentProductSlug;
            this._dataService.variableProductOption = product.selectedOption;
        }
        if (selectedCategory && selectedCategory.slug) {
            this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
            this._router.navigate([this.cartSummaryComponentSettings.isoCountryCode.toLowerCase() + '/'
                + this.cartSummaryComponentSettings.languageCode.toLowerCase()
                + '/products/' + selectedCategory.slug + '/' + product.slug]);
        } else {
            this._router.navigate([this.cartSummaryComponentSettings.isoCountryCode.toLowerCase() + '/'
                + this.cartSummaryComponentSettings.languageCode.toLowerCase() + '/products/' + product.slug]);
        }
    }

    /** End Autoship */

    ngOnDestroy(): void {
        if (this.cartSummaryComponentSettings.taxCalcSubscription) {
            this.cartSummaryComponentSettings.taxCalcSubscription.unsubscribe();
        }
        if (this.cartSummaryComponentSettings.processOrderSubscription) {
            this.cartSummaryComponentSettings.processOrderSubscription.unsubscribe();
        }
        if (this.cartSummaryComponentSettings.cartSubscription) {
            this.cartSummaryComponentSettings.cartSubscription.unsubscribe();
        }
        if (this.cartSummaryComponentSettings.placeOrderCartSubscription) {
            this.cartSummaryComponentSettings.placeOrderCartSubscription.unsubscribe();
        }
    }
}


