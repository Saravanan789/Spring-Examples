export interface AutoshipShippingInformation {
    id?: number;
    deliverypreferenceId: number;
    shipMethodId: number;
    shippingAddressId: number;
    createdBy: number;
    updatedBy: number;
}
