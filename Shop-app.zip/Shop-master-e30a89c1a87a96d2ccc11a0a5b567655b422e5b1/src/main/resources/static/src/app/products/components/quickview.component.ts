
import { CartService } from '../../shared/services/cart.service';
import { ProductType } from '../enums/product-types.enum';
import { Options } from '../interfaces/options.interface';
import * as _ from 'lodash';

import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CacheService } from '../../shared/services/cache.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SwiperConfigInterface, SwiperComponent } from 'ngx-swiper-wrapper';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ImageType } from '../enums/image-type.enum';
import { ProductService } from '../services/product.service';
import { Product } from '../interfaces/product.interface';
import { CommonService } from '../../shared/services/common.service';
import { Quickview } from '../interfaces/product-quickview.interface';
import { AppMessageService } from '../../app-message.service';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { ImageTypeFilterPipe } from '../../common/pipes/image-type-filter.pipe';
import { TranslateService } from '@ngx-translate/core';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { Member } from '../../shared/interfaces/member.interface';
import { BsModalService } from 'ngx-bootstrap';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { ENGINE_METHOD_CIPHERS } from 'constants';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { NotificationType } from '../../common/enums/notification-type.enum';
import { NotificationService } from '../../shared/services/notification.service';
import { Cart } from '../../shared/models/cart.model';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { Item } from '../../shared/models/item.model';
import { CookieBannerType } from '../../shared/enums/cookie-banner-type';
import { CookieBannerResponse } from '../../shared/interfaces/cookie-banner-reponse';
import { ProductMessageService } from '../services/product-message.service';
import { Subscription } from 'rxjs/Subscription';
import { CookieBannerMessageType } from '../../shared/enums/cookie-message-types.enum';
import { ProductDetailService } from '../services/product-detail.service';
import { ActiveSessionService } from '../../shared/services';
import { MemberLevel } from '../../shared/enums';
@Component({
  selector: 'app-quickview',
  templateUrl:
    '../templates/template3/views/quickview.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/quickview.component.less'
  ],
  providers: [ImageTypeFilterPipe]

})
export class QuickviewComponent implements OnInit, OnDestroy {
  isPersonalPurchaseFlow = false;
  personalPurchaseFlow: string = PurchaseFlow.PERSONAL;
  purchaseFlows: any[] = [];
  storeId: number;
  store: StoreConfig;
  selectedFilter: any = {};
  options: Options[];
  languageCode: any;
  quickViewItem: any;
  public isModalShown = false;
  defaultProductsUnSubscription: any;
  products: Product[] = [];
  showOptions = false;
  quantity = 1;
  isoCountryCode: string;
  userLoggedIn: Member;
  productSlug: string;
  product: any;
  productDetails: Product;
  errorMessages: string;
  imageTypes = ImageType;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  disableDecrement: boolean;
  isAutoshipEnabled: boolean;
  quickViewSubscription: Subscription;
  constructor(
    private _cacheService: CacheService,
    private _productDetailervice: ProductDetailService,
    private _commonService: CommonService,
    private _productMessageService: ProductMessageService,
    private _configurationService: ConfigurationService,
    private _notificationService: NotificationService,
    private _appMessageService: AppMessageService,
    public bsModalRef: BsModalRef,
    private _cartService: CartService,
    private _translatePipe: TranslateService,
    private _router: Router,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    this.personalPurchaseFlow = this.isAutoshipEnabled ? PurchaseFlow.AUTOSHIP : PurchaseFlow.PERSONAL;
    this.getStoreData();
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._commonService.getLanguageCode();
    // this.getQuickViewSubscription();
    if (this.productDetails) {
      this.productDetails.parentProductSlug = this.productDetails.slug;
      this.quickViewItem = this.productDetails;
      this.getVariableProductOptions();
    }
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
  }


  /**
* To show quick view popup
* @param  {any} prodId
* @returns void
*/
  getVariableProductOptions(): void {
    if (this.quickViewItem && this.quickViewItem.options && this.quickViewItem.options.length > 0 &&
      ProductType.Variable === this.quickViewItem.productTypeMasterId) {
      this.options = this.quickViewItem.options.filter(
        x => x.name != null && x.productOptionValueMasterId != null
      );
      this.options[0].isPrimary = true;
      this.quickViewItem.options[0].selected = this.quickViewItem.options[0].values[0].name;
      this.quickViewItem.selectedOption = this.quickViewItem.options[0].selected;
      this.optionsChange(this.quickViewItem, this.options[0].values[0].name, this.options[0], true);
    }
    // this.quantity = this.getQuantity(product.id);
    if (ProductType.Variable === this.quickViewItem.productTypeMasterId) {
      this.showOptions = true;
    } else {
      this.showOptions = false;
    }
  }




  /**
  * @param  {string} optType
  * @param  {string} optValue
  */
  optionsChange(quickViewItem: Quickview, optValue: string, option: Options, defaultValue: boolean): void {
    this.selectedFilter = { selectedOption: '', selectedValue: '' };
    this.selectedFilter.selectedOption = option.productOptionValueMasterId;
    this.selectedFilter.selectedValue = optValue;
    let selectedProd: any = [];
    const oneOption = this.options.filter(x => x.productOptionValueMasterId !== option.productOptionValueMasterId);
    if (oneOption && oneOption.length > 0) {
      this.options.filter(x => x.productOptionValueMasterId !== option.productOptionValueMasterId).forEach(x => {
        x.selected = '';
        x.values.forEach(val => {
          if (selectedProd && selectedProd.length === 0) {
            selectedProd = quickViewItem.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue
              && z[x.name] === val.name);
            selectedProd = selectedProd && selectedProd.length === 0 && (!val.hide) ? selectedProd : selectedProd;
          }
          if (defaultValue) {
            val.hide = true;
          } else {
            val.hide = quickViewItem.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue
              && z[x.name] === val.name).length <= 0;
            x.selected = x.selected.length === 0 && (!val.hide) ? val.name : x.selected;
          }
        });
        // reset all drop down's to select except first option
        if (option.name !== x.name) {
          const el: any = document.getElementById('option_' + x.name);
          if (el) {
            // reset option to select
            if (x.values.map(y => y.name).indexOf(el.value) === -1) {
              el.value = '';
            } else {
              el.value = x.values.find(value => !value.hide).name;
            }
          }
        }
      });
    } else {
      selectedProd = quickViewItem.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue);
    }

    if (selectedProd && selectedProd[0]) {
      this.getProductByOptions(selectedProd[0].productId);
    }
  }

  /**
  * Get Products by options selections
  * @param  {number} productId
  */
  getProductByOptions(productId: number): void {
    if (this.storeId && productId) {
      this._productDetailervice
        .getProductDetailById(productId, this.storeId, this.languageCode)
        .subscribe(response => {
          if (response) {
            const prodDetail: Product = response[0];
            prodDetail.productQuantity = 1;
            prodDetail.optionCombinationValues = this.quickViewItem.optionCombinationValues;
            prodDetail.options = this.quickViewItem.options;
            prodDetail.parentProductSlug = this.quickViewItem.parentProductSlug || this.quickViewItem.slug;
            prodDetail.selectedOption = this.selectedFilter.selectedValue;
            this.quickViewItem = prodDetail;
            this.options = prodDetail.options;
            this.loadWishListProducts();
            // this.filterParentImage();
          }
        });
    }
  }

  /**
   * load wishlist
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      wishListCart.items.forEach(y => {
        if (y.productId === this.quickViewItem.id) {
          this.quickViewItem.wishListItem = true;
        }
      });
    }
  }


  /**
     * To hide quick view popup
     * @returns void
     */
  hideModal(): void {
    // this.autoShownModal.hide();
  }

  /**
     * @returns void
     */
  onHidden(): void {
    this.isModalShown = false;
    //  this.autoShownModal.hide();
  }

  /**
   * get Store Data
   */
  getStoreData(): void {
    const storeConfig: StoreConfig = this._configurationService.getStoreData();
    if (storeConfig) {
      this.store = storeConfig;
      this.storeId = this.store.id;
      this.purchaseFlows = storeConfig.purchaseFlows;
      this.hasPurchaseFlow();
    }
  }

  hasPurchaseFlow(): void {
    if (this.purchaseFlows && this.purchaseFlows.length > 0 && (this.store.purchaseFlows !== null && this.store.purchaseFlows.length > 0)) {
      this.purchaseFlows.forEach(flow => {
        this.store.purchaseFlows.forEach((storeFlow: any) => {
          if (flow.id === storeFlow.id && flow.name === this.personalPurchaseFlow) {
            this.isPersonalPurchaseFlow = true;
          }
        });
      });
    }
  }

  /**
  * Increment the product Quantity
  * @returns void
  */
  incrementQuantity(prod): void {
    prod.productQuantity = ++prod.productQuantity;
    this.disableDecrement = false;
    if (prod.productQuantity > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      this.outofStockNotification(prod);
    }
  }

  /**
   * Out of Stock Notification
   * @param product
   */
  outofStockNotification(product: Product) {
    // const cartStockErrorForItem: any = this._translatePipe.get('stockError.No Stock Available for Item Number');
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">' +
      product.stockQuantity + '</span>', NotificationType.ERROR);
  }

  /**
  * Decrement the product Quantity
  * @returns void
  */
  decrementQuantity(prod): void {
    if (prod.productQuantity > 1) {
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      // this.quantity = +this.quantity - 1;
    }
    if (prod.productQuantity === 1) {
      this.disableDecrement = true;
    }
  }

  /**
  * to update product quantity
  */
  updateQuantity(prod: Product | any) {
    const qty = parseInt(prod.productQuantity, 10);
    if (qty > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = prod.stockQuantity;
      this.outofStockNotification(prod);
    } else {
      prod.productQuantity = qty || null;
    }
    this.disableDecrement = this.quantity > 1 ? false : true;
  }

  /**
     * show cart / Product detail based on variant.
     */
  addToCart(product: any, cartType: number): void {
    this.getShippingRestrictedProducts(product.itemNumber);
    this.manageShoppingCart(product, cartType);
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(product: Product, cartType: CartTypes) {
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      this._notificationService.createNotification('', 'Item added to Autoship Cart', NotificationType.SUCCESS);
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    const item: Item = this._cartService.convertProductToItemMappper(product, cartSessionInfo);
    if (cartSessionInfo) {
      const cartItem = cartSessionInfo.items.filter(x => x.productId === item.productId)[0];
      if (cartItem) {
        item.quantity = cartItem.quantity + item.quantity;
        if (item.quantity > product.stockQuantity && product.manageStock && !product.backOrderAllowed) {
          item.quantity = cartItem.quantity;
          product.errorMessage = true;
          setTimeout(() => {
            product.errorMessage = false;
          }, 2000);
          this.outofStockNotification(product);
          return;
        }
      }
    }
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      const autoshipCart = new Cart(cartSessionInfo, this.store);
      const cartItemDetails = {
        count: autoshipCart.itemsCount,
        cartType: cartType
      };
      this.bsModalRef.hide();
      this._appMessageService.setMiniCart(cartSession);
      this._appMessageService.setCartItemsChanges(cartItemDetails);
      this._commonService.scrollTo('cart-component', 500);
      this._commonService.focusTargetElement('minicart-shop-msg');
    } else if (cartSessionInfo) {
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: Cart) => {
        if (response) {
          this.bsModalRef.hide();
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: Cart) => {
        if (response) {
          this.bsModalRef.hide();
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      });
    }
  }
  /**
  * verifying whether the product is shippable to the selected shipping address or not
  * @returns Address
  */
  getShippingRestrictedProducts(itemNumber: string): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (userDefaultAddressDetails && itemNumber) {
      this._commonService.getShippingRestrictedProducts(itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            this._notificationService.createNotification('', response.productModels[0].errorDescription, NotificationType.ERROR);
          }
        });
    }
  }

  /**
  * To add an item
  * @param  {Product} product
  */
  addToWishList(product: Product): void {
    // TODO amruth - need to move text to s3 and translate
    if (!this.userLoggedIn) {
      return;
    }
    this._translatePipe.get('quickview.Item added to Favorites');
    this._translatePipe.get('quickview.Item removed from Favorites');
    product.wishListItem = !product.wishListItem ? true : false;
    const item: Item = this._cartService.convertProductToItemMappper(product);
    let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length > 0 && wishListCart.sessionGuid) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .updateCart([item], CartTypes.WishlistCart, wishListCart)
        .subscribe((response: Cart) => {
          if (response) {
            //  this._commonService.createNotification('', itemAddedNotification.value, 'success');
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
            this.bsModalRef.hide();
          }
        });
    } else if (product.wishListItem) {
      this._cartService
        .saveCart([item], CartTypes.WishlistCart)
        .subscribe((response: Cart) => {
          if (response) {
            this.bsModalRef.hide();
            //    this._commonService.createNotification('', itemAddedNotification.value, 'success');
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }
        });
    } else if (!product.wishListItem) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .removeCartItem(wishListCart.sessionGuid, cartItem.id)
        .subscribe(response => {
          // this._commonService.createNotification('', itemDeletedNotification.value, 'success');
          wishListCart = new Cart(wishListCart, this.store);
          this._cacheService.set(CacheKey.WishListSession, wishListCart);
          this._appMessageService.setWishListItems();
        });
    }
  }

  /**
  * redirect to sso login url
  * @param  {boolean} isLogin
  * @returns void
  */
  gotoLogin(isLogin: boolean, product: Product): void {
    this._cacheService.set(CacheKey.RedirectToFavourites, true);
    this._cacheService.set(CacheKey.WishListProduct, product);
    this._appMessageService.setNotifyLoginStatus(isLogin);
  }

  /**
   * @description Navigate to the product detail page
   * @date 2018-08-14
   * @param {Product} product
   * @memberof QuickviewComponent
   */
  navigateToProductDetail(product: Product): void {
    this.bsModalRef.hide();
    let selectedCategory;
    if (product.categories) {
      selectedCategory = product.categories[0];
    }
    if (selectedCategory && selectedCategory.slug) {
      this._router.navigate
        (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() +
          '/products/' + selectedCategory.slug + '/' + product.slug]);
    } else {
      this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' +
        this.languageCode.toLowerCase() + '/products/' + product.slug]);
    }
  }

  ngOnDestroy(): void {
    // this.defaultProductsUnSubscription.unsubscribe();
  }
}
