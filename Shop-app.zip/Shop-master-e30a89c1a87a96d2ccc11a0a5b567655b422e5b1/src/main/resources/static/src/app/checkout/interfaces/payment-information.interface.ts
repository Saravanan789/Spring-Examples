import { PayvisionInformation } from './payvision-information';
import { Address } from '../../common/interfaces';
import { StorePaymentMethod } from '../../payment/interfaces';
import { PaymentEcheck } from './payment-echeck.interface';

export interface PaymentInformation {
    payvisionInformation?: PayvisionInformation;
    paymentToken: string;
    billingAddress: Address;
    isEnrollment: boolean;
    selectedPaymentMethod: StorePaymentMethod;
    isCompleteRedirection: boolean;
    paymentECheck?: PaymentEcheck;
}
