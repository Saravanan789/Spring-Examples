
export enum AddressOptions {
    SHIPPING = 'Shipping',
    ORIGINALADDRESS = 'originalAddress',
    SUGGESTEDADDRESS = 'suggestedAddress'
}
