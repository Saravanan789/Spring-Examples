import { Pipe, PipeTransform } from '@angular/core';
import { ConfigurationService } from '../../shared/services/configuration.service';
import 'intl';
import 'intl/locale-data/jsonp/en.js';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';

@Pipe({
    name: 'currencyFormat'
})
export class CurrencyPipe implements PipeTransform {
    store: StoreConfig;
    getStoreData() {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result != null) {
            this.store = result;
        }
    }

    /**
     * get currecny by store decimals
     * @param  {number} value
     * @returns number
     */
    getFormatedCurrency(value: number): number {
        // tslint:disable-next-line:no-bitwise
        return value ? Number(value.toFixed(Math.max(0, ~~this.store.numberDecimals))) : 0;
    }


    getCurrencyFormat(format: string, value: number, removeCurrencyCode: boolean = false,
        removeCurrencySymbol: boolean = false, removeSymbolAndCode: boolean = false, priceOnly: boolean = false) {
        const chunkLength = 3;
        value = value || 0;
        // tslint:disable-next-line:no-bitwise
        const num = value.toFixed(Math.max(0, ~~this.store.numberDecimals));
        const result: string = '\\d(?=(\\d{' + chunkLength + '})+' + (this.store.numberDecimals > 0 ? '\\D' : '$') + ')';
        let formattedCurrency = '';
        let currencyCode: string = removeCurrencyCode ? '' : this.store.currencyCode;
        let currencySymbol: string = removeCurrencySymbol ? '' : this.store.currencySymbol;
        if (removeSymbolAndCode) {
            currencyCode = '';
            currencySymbol = '';
        }
        if (priceOnly) {
            format = '';
        }
        switch (format) {
            case 'CL':
                formattedCurrency = currencyCode + (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator);
                break;
            case 'CR':
                formattedCurrency = (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator) + ' ' + currencyCode;
                break;
            case 'SL':
                formattedCurrency = currencySymbol + (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator);
                break;
            case 'SR':
                formattedCurrency = (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator) + currencySymbol;
                break;
            case 'CRSL':
                formattedCurrency = currencySymbol + (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator) + ' ' + currencyCode;
                break;
            case 'SRCL':
                formattedCurrency = currencyCode + (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator) + currencySymbol;
                break;
            default:
                formattedCurrency = currencySymbol + (this.store.decimalSeparator ?
                    num.replace('.', this.store.decimalSeparator) : num).replace(new RegExp(result, 'g'), '$&' +
                        this.store.thousandSeperator);
                break;
        }
        return formattedCurrency;
    }
    constructor(private _configurationService: ConfigurationService) {
        this.getStoreData();
    }

    transform(value: number, removeCurrencyCode: boolean = false, removeCurrencySymbol: boolean = false,
        removeSymbolAndCode: boolean = false, priceOnly: boolean = false): string {
        return this.getCurrencyFormat(this.store.currencyFormatCode, value, removeCurrencyCode,
            removeCurrencySymbol, removeSymbolAndCode, priceOnly);
    }
}
