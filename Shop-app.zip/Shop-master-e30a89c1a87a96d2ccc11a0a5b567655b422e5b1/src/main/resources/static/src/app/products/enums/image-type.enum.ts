export enum ImageType {
    Icon = 'Icon',
    Thumbnail = 'thumbnail',
    ShoppingCart = 'shopping bag',
    ZoomedImage = 'ZoomedImage',
    Video = 'Video',
    Category = 'category',
    MiniCart = 'mini cart',
    Main = 'main'
}
