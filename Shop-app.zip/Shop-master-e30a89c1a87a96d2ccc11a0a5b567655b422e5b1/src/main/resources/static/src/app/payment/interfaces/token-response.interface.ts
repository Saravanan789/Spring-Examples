export interface TokenResponse {
    value: string;
}
