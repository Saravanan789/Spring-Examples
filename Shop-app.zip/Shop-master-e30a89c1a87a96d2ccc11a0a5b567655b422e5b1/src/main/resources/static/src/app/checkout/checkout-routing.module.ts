import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
  CheckoutNewComponent, PersonalInfoComponent,
  ShippingAddressNewComponent, ShippingMethodsNewComponent, OrderSummaryNewComponent
} from './components';
import {
  CanActivatePersonalGuard, CanActivateCheckoutGuard,
  CanActivateCheckoutNewGuard
} from './guards';

const checkoutModuleRoutes: Routes = [
  {
    path: '', component: CheckoutNewComponent,
    children: [
      { path: 'shipping', component: ShippingAddressNewComponent },
      { path: 'delivery', component: ShippingMethodsNewComponent },
      { path: 'payment', loadChildren: '../payment/payment.module#PaymentModule' }
    ],
    canActivate: [CanActivateCheckoutNewGuard],
  },
  {
    path: 'personalinfo',
    component: PersonalInfoComponent,
    canActivate: [CanActivateCheckoutNewGuard, CanActivatePersonalGuard],
  },
  { path: 'member/ordersummary/:memberId', component: OrderSummaryNewComponent },
  { path: 'ordersummary/:webOrderId', component: OrderSummaryNewComponent },
  { path: 'ordersummary', component: OrderSummaryNewComponent }
];

@NgModule({
  imports: [RouterModule.forChild(checkoutModuleRoutes)],
  providers: [CanActivateCheckoutGuard, CanActivatePersonalGuard, CanActivateCheckoutNewGuard],
  exports: [RouterModule]
})
export class CheckoutRoutingModule { }
