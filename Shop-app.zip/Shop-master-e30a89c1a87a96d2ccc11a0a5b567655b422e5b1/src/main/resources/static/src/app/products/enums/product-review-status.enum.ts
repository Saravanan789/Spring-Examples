export enum ProductReviewStatusCode {
    Submitted = 1,
    Approved = 2
}
