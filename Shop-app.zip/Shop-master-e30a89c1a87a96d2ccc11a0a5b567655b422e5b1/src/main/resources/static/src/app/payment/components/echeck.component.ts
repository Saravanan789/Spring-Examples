import { OnInit, Component, Input, Output, EventEmitter } from '@angular/core';
import { EcheckComponentSettings, PaymentComponentSettings } from '../component-settings';
import { Validators, FormBuilder } from '@angular/forms';
import { AccountType } from '../enums';
import { environment } from '../../../environments/environment';
import { AppMessageService } from '../../app-message.service';
import { PaymentInformation } from '../../checkout/interfaces';
import {
    TokenResponse, ValidateEcheckResponse,
    PaymentEcheck, PersonalCheck, PaymentEcheckRequest
} from '../interfaces';
import { Address } from '../../common/interfaces';
import { Country } from '../../shared/interfaces';
import { AddressComponentSettings } from '../../common/component-settings';
import { TranslateService } from '@ngx-translate/core';
import { PaymentService, EcheckService } from '../services';
import { DeliveryOptionType } from '../../checkout/enums';
import { CustomValidator } from '../../common/components';
import { MaskPipe } from 'ngx-mask';
import { CommonService } from '../../shared/services';
import { PhoneCodesConstants } from '../../common/constants/phone-codes.constant';
import { EcheckPhoneNumberValidation } from '../../common/directives/echeck-phone-validation';

/**
 * @description this component provides payment functionality
 * load base settings from parent
 * payment component like store and countries
 * @date 2018-08-07
 * @export
 * @class EcheckComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-echeck',
    templateUrl: '../templates/template3/views/echeck.component.html',
    styleUrls: ['../templates/template3/themes/default/less/echeck.component.less']
})

export class EcheckComponent implements OnInit {
    echeckComponentSettings: EcheckComponentSettings = new EcheckComponentSettings();

    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;
    // tslint:disable-next-line:no-input-rename
    @Input('enablePlaceOrder') enablePlaceOrder: boolean;
    // Output variables
    @Output() submitPayment = new EventEmitter<any>();

    constructor(
        private formBuilder: FormBuilder,
        private _echeckService: EcheckService,
        private _appMessageService: AppMessageService,
        private _translatePipe: TranslateService,
        private _paymentService: PaymentService,
        private _commonService: CommonService,
        private _maskPipe: MaskPipe
    ) { }
    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
    * @description Load Default shipping Settings
    * for the current user
    * @date 2018-08-07
    * @memberof EcheckComponent
    */
    loadDefaultSettings(): void {
        this.echeckComponentSettings = Object.assign(this.echeckComponentSettings, this.paymentComponentSettings);
        this.echeckComponentSettings.echeckSchemaUrl = this.echeckComponentSettings.isoCountryCode.toLowerCase()
            + '-billing-schema-form.json';
        this.echeckComponentSettings.isPaymentWithSavedEcheck =
            this.echeckComponentSettings.userInfo ? true : false;
        if (this.echeckComponentSettings.checkoutInformation
            && this.echeckComponentSettings.checkoutInformation.shippingInformation
            && this.echeckComponentSettings.checkoutInformation
                .shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery) {
            this.echeckComponentSettings.shippingAddress = this.echeckComponentSettings.checkoutInformation
                .shippingInformation.shippingAddress;
        }
        this.echeckComponentSettings.accountTypes = [AccountType.Checking, AccountType.Savings];
        this.echeckComponentSettings.isSaveEcheckForFuture = false;
        this.echeckComponentSettings.viewBillingAddress = true;
        this.createEcheckForm();
        this.getSavedEchecks();
        this.echeckComponentSettings.phoneNumberFormat =
            this._commonService.getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode);
    }

    /**
     * @description create echeck form
     *
     * @memberof EcheckComponent
     */
    createEcheckForm(): void {
        let phone = '';
        let email = '';
        if (this.echeckComponentSettings.userInfo) {
            email = this.echeckComponentSettings.userInfo.email;
            phone = this._maskPipe.transform(this.echeckComponentSettings.userInfo.phone, this._commonService
                .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
        }
        this.echeckComponentSettings.echeckForm = this.formBuilder.group({
            routingNumber: [],
            accountNumber: ['', Validators.required],
            nameOnBankAccount: ['', Validators.required],
            bankName: ['', Validators.required],
            accountType: ['-1', [Validators.required, CustomValidator.checkIfAccountSelected()]],
            shippingAsBilling: [this.echeckComponentSettings.shippingAddress ? true : false],
            email: [email, Validators.required],
            phone: [phone, [Validators.required, EcheckPhoneNumberValidation.PhoneNumberValidation]]
        });
    }

    /**
     * @description gets saved echeck
     * @memberof EcheckComponent
     */
    getSavedEchecks(): void {
        if (this.echeckComponentSettings.userInfo && this.echeckComponentSettings.userInfo.memberId) {
            this._echeckService.getSavedEchecks(this.echeckComponentSettings.userInfo.memberId,
                this.echeckComponentSettings.isoCountryCode)
                .subscribe((response: PersonalCheck[]) => {
                    if (response && response.length > 0) {
                        this.echeckComponentSettings.viewBillingAddress = false;
                        this.echeckComponentSettings.savedEchecks = response;
                        this.selectDefaultEcheck();
                        this.echeckComponentSettings.isPaymentWithSavedEcheck = true;
                    } else {
                        this.echeckComponentSettings.savedEchecks = [];
                        this.echeckComponentSettings.isPaymentWithSavedEcheck = false;
                        this.echeckComponentSettings.viewBillingAddress = true;
                    }
                });
        }
    }

    /**
     * @description select default echeck
     *
     * @private
     * @memberof EcheckComponent
     */
    private selectDefaultEcheck(): void {
        const defaultEcheck: PersonalCheck =
            this.echeckComponentSettings.savedEchecks.find(x => x.defaultECheck);
        if (defaultEcheck) {
            this.selectSavedEcheck(defaultEcheck.id);
        }
    }

    /**
     * @description select saved echeck
     *
     * @param {number} value
     * @memberof EcheckComponent
     */
    selectSavedEcheck(value: number): void {
        this.echeckComponentSettings.echeckErrorMessage = '';
        this.echeckComponentSettings.isPaymentWithSavedEcheck = true;
        this.echeckComponentSettings.viewBillingAddress = false;
        this.echeckComponentSettings.selectedEcheck =
            this.echeckComponentSettings.savedEchecks.find(x => x.id === value);
        this.constructBillingNameAndCountry(
            this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired);
    }

    /**
     * @description add new echeck
     *
     * @memberof EcheckComponent
     */
    addNewEcheck(): void {
        this.echeckComponentSettings.echeckErrorMessage = '';
        this.echeckComponentSettings.billingAddress = null;
        this.createEcheckForm();
        this.echeckComponentSettings.isPaymentWithSavedEcheck = false;
        this.echeckComponentSettings.viewBillingAddress = this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired;
    }

    /**
     * @description constructs selected echeck billing address name and country
     *
     * @param {boolean} billingAddressRequired
     * @memberof EcheckComponent
     */
    constructBillingNameAndCountry(billingAddressRequired: boolean): void {
        const selectedEcheckBillingAddress = this.echeckComponentSettings.selectedEcheck.billingAddress;
        if (billingAddressRequired && selectedEcheckBillingAddress) {
            this.echeckComponentSettings.billingAddress = selectedEcheckBillingAddress;
            // for selected echeck - (name  - from service we will get it as firstName)
            this.echeckComponentSettings.billingAddress.name = selectedEcheckBillingAddress.firstName;
            this.echeckComponentSettings.billingAddress.country = selectedEcheckBillingAddress.countryCode;
        }
    }

    /**
     * @description on click of checkbox (same as shipping address) this method triggers
     *
     * @param {*} event
     * @memberof EcheckComponent
     */
    showBillingAddress(event: any): void {
        const target = event.target;
        if (target.checked) {
            this.useShippingAsBilling(true);
            this.echeckComponentSettings.viewBillingAddress = false;
            this.echeckComponentSettings.echeckForm.controls['shippingAsBilling'].setValue(true);
            this.echeckComponentSettings.billingAddress = null;
        } else {
            this.useShippingAsBilling(false);
            this.echeckComponentSettings.viewBillingAddress = true;
            this.echeckComponentSettings.echeckForm.controls['shippingAsBilling'].setValue(false);
        }
    }

    /**
     * @description sets shippingAsBilling value
     * @private
     * @param {Address} shippingAddress
     * @param {boolean} useShipping
     * @memberof EcheckComponent
     */
    private useShippingAsBilling(useShipping: boolean): void {
        if (this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired) {
            if (useShipping) {
                this.echeckComponentSettings.viewBillingAddress = false;
                this.echeckComponentSettings.echeckForm.controls['shippingAsBilling'].setValue(true);
                this.echeckComponentSettings.billingAddress = this.constructBillingAddress();
            } else {
                this.echeckComponentSettings.echeckForm.controls['shippingAsBilling'].setValue(false);
            }
        } else {
            this.echeckComponentSettings.viewBillingAddress = false;
        }
    }

    /**
     * @description add mask while chnaging phone number
     *
     * @memberof EcheckComponent
     */
    onChangeEcheckPhone($event: any) {
        const value = this.echeckComponentSettings.echeckForm.controls['phone'].value;
        let updatedValue = value;
        const alphaNumericValue = value.replace(/[^a-z0-9]/gi, '');
        if (value.match(/[a-zA-Z]/)) {
            if (alphaNumericValue.substr(0, 3).match(/[a-zA-Z]/)) {
                updatedValue = value.replace(/[^a-z0-9]/gi, '');
            } else if (alphaNumericValue.substr(3, 3).match(/[a-zA-Z]/)) {
                updatedValue = this._maskPipe.transform(value, '(000) AAAAAAA');
            } else if (alphaNumericValue.substr(6, 4).match(/[a-zA-Z]/)) {
                updatedValue = this._maskPipe.transform(value, '(000) 000-AAAA');
            }
        } else {
            if (alphaNumericValue.length !== 3) {
                updatedValue = this._maskPipe.transform(value, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
            }
        }
        this.echeckComponentSettings.echeckForm.controls['phone'].setValue(updatedValue);
    }

    /**
     * @description gets echeck request
     *
     * @memberof EcheckComponent
     */
    getEcheckRequest(): void {
        const echeckFormValue = this.echeckComponentSettings.echeckForm.value;
        const accountTypeEcheck = echeckFormValue.accountType === AccountType.Checking ? AccountType.Checking : AccountType.Savings;
        if (echeckFormValue.phone) {
            const phoneCode = PhoneCodesConstants.phoneCodes.find(x => echeckFormValue.phone.toUpperCase().indexOf(x.name) > -1);
            if (phoneCode) {
                echeckFormValue.phone = echeckFormValue.phone;
            } else {
                echeckFormValue.phone = this._maskPipe.transform(echeckFormValue.phone, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
            }
        }
        if (!this.echeckComponentSettings.isPaymentWithSavedEcheck) {
            this.echeckComponentSettings.echeckRequest = {
                bankName: echeckFormValue.bankName,
                accountNumber: echeckFormValue.accountNumber,
                accountType: accountTypeEcheck,
                routingNumber: echeckFormValue.routingNumber,
                mecTransactionID: '',
                nameOnBankAccount: echeckFormValue.nameOnBankAccount,
                customMessage: '',
                reusable: this.echeckComponentSettings.isSaveEcheckForFuture,
                defaultEcheck: false,
                eCheckID: 0,
                email: echeckFormValue.email,
                phone: echeckFormValue.phone
            };
        } else {
            this.echeckComponentSettings.echeckRequest = this.constructPaymentEcheckRequest();
            this.echeckComponentSettings.echeckRequest.eCheckID = this.echeckComponentSettings.selectedEcheck.id;
        }
    }

    /**
     * @description constructs payment eheck request from selected echeck
     * @returns {PaymentEcheckRequest}
     * @memberof EcheckComponent
     */
    constructPaymentEcheckRequest(): PaymentEcheckRequest {
        const selectedEcheck = this.echeckComponentSettings.selectedEcheck;
        const echeckRequest = {
            bankName: selectedEcheck.bankName,
            accountNumber: selectedEcheck.accountNumber,
            routingNumber: selectedEcheck.routingNumber,
            accountType: selectedEcheck.accountType,
            mecTransactionID: '',
            nameOnBankAccount: selectedEcheck.nameOnBankAccount,
            customMessage: selectedEcheck.customMessage,
            reusable: selectedEcheck.reusable,
            defaultEcheck: selectedEcheck.defaultECheck,
            eCheckID: selectedEcheck.id,
            email: selectedEcheck.email,
            phone: selectedEcheck.phone
        };
        return echeckRequest;
    }

    /**
     * @description payment with stored echeck
     *
     * @returns {void}
     * @memberof EcheckComponent
     */
    storedEcheckPayment(): void {
        if (!this.echeckComponentSettings.selectedEcheck) {
            this._paymentService.scrollToTop(10);
            const translatedText =
                this._translatePipe.get('checkout.Either select from saved echeck(s) or create new one to proceed further');
            this.echeckComponentSettings.echeckErrorMessage = translatedText['value'] + '.';
            return;
        }
        this.validateEcheckRequest(true);
    }

    /**
     * @description submit echeck - saving echeck
     *
     * @param {boolean} isEcheckValid
     * @memberof EcheckComponent
     */
    submitEcheck(isEcheckValid?: boolean): void {
        this._appMessageService.setSubmitAddress(true);
        this.echeckComponentSettings.isEcheckSubmitted = true;
        if (isEcheckValid || this.echeckComponentSettings.isPaymentWithSavedEcheck) {
            this.validateEcheckRequest(false);
        }
    }

    /**
     * @description validates echeck request
     *
     * @param {boolean} isFromSavedEcheck
     * @memberof EcheckComponent
     */
    validateEcheckRequest(isFromSavedEcheck: boolean): void {
        this.getEcheckRequest();
        this.echeckComponentSettings.paymentCheck = this.constructPaymentEcheck();
        this.constructValidateEcheckRequest();
        this.enablePlaceOrder = false;
        if (!isFromSavedEcheck) {
            this._echeckService.validateEcheck(this.echeckComponentSettings.validatePersonalCheckRequest)
                .subscribe((response: ValidateEcheckResponse) => {
                    this.processEcheckValidationResponse(response, isFromSavedEcheck);
                }, error => {
                    this.enablePlaceOrder = true;
                });
        } else {
            this.enablePlaceOrder = false;
            const echeck = this.echeckComponentSettings.selectedEcheck;
            this.echeckComponentSettings.echeckRequest.eCheckID = echeck.id;
            if (this.echeckComponentSettings.paymentCheck) {
                this.echeckComponentSettings.paymentCheck.eCheckID = echeck.id;
            }
            this.submitPaymentInformation();
        }
    }

    /**
     * @description process validate echeck response
     *
     * @param {ValidateEcheckResponse} response
     * @param {boolean} isFromSavedEcheck
     * @memberof EcheckComponent
     */
    processEcheckValidationResponse(response: ValidateEcheckResponse,
        isFromSavedEcheck: boolean): void {
        if (response && response.success) {
            if (isFromSavedEcheck) {
                const echeck = this.echeckComponentSettings.selectedEcheck;
                this.echeckComponentSettings.echeckRequest.eCheckID = echeck.id;
                if (this.echeckComponentSettings.paymentCheck) {
                    this.echeckComponentSettings.paymentCheck.eCheckID = echeck.id;
                }
                this.submitPaymentInformation();
            } else {
                this.savePersonalCheck();
            }
        } else if (response && !response.success && response.validations
            && response.validations.length > 0) {
            this.enablePlaceOrder = false;
            const translatedText = this._translatePipe.get('checkout.Please check the below Fields');
            this.echeckComponentSettings.echeckErrorMessage = translatedText['value'] + ' <br/>';
            // displaying validation message which comes from service.
            for (let i = 0; i < response.validations.length; i++) {
                this.echeckComponentSettings.echeckErrorMessage =
                    this.echeckComponentSettings.echeckErrorMessage + response.validations[i].message + ', ';
            }
            this.echeckComponentSettings.echeckErrorMessage =
                this.echeckComponentSettings.echeckErrorMessage.trim()
                    .substr(0, this.echeckComponentSettings.echeckErrorMessage.length - 2);
        }
    }

    /**
     * @description Constructs validate echeck request.
     *
     * @memberof EcheckComponent
     */
    constructValidateEcheckRequest(): void {
        const paymentWithSavedEcheck = this.echeckComponentSettings.isPaymentWithSavedEcheck;
        const billingAddress = this.getBillingAddressByCondition(paymentWithSavedEcheck);
        let addressCountry = null;
        if (this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired && billingAddress) {
            addressCountry = this.echeckComponentSettings.countries
                .find(z => z.isocodeThree.toUpperCase() === billingAddress.countryCode.toUpperCase());
            if (!addressCountry) {
                addressCountry = this.echeckComponentSettings.countries
                    .find(z => z.isocodeTwo.toUpperCase() === billingAddress.countryCode.toUpperCase());
            }
        }
        this.constructValidatePersonalCheck(billingAddress, addressCountry);
    }

    /**
     * @description gets billing address by condition
     *
     * @param {boolean} paymentWithSavedEcheck
     * @returns {Address}
     * @memberof EcheckComponent
     */
    getBillingAddressByCondition(paymentWithSavedEcheck: boolean): Address {
        if (paymentWithSavedEcheck) {
            const echeck = this.echeckComponentSettings.selectedEcheck;
            return echeck && echeck.billingAddress ? echeck.billingAddress : null;
        } else {
            if (this.echeckComponentSettings.echeckForm.value.shippingAsBilling) {
                if (!this.echeckComponentSettings.shippingAddress.name && this.echeckComponentSettings.shippingAddress.firstName) {
                    this.echeckComponentSettings.shippingAddress.name = this.echeckComponentSettings.shippingAddress.firstName + ' ' +
                        this.echeckComponentSettings.shippingAddress.lastName;
                }
                return this.echeckComponentSettings.shippingAddress;
            }
            return this.echeckComponentSettings.billingAddress;
        }
    }

    /**
     * @description construct personal check
     *
     * @private
     * @param {Address} billing
     * @param {Address} billingAddress
     * @param {State[]} addressState
     * @param {Country[]} addressCountry
     * @memberof EcheckComponent
     */
    private constructValidatePersonalCheck(billingAddress: Address, addressCountry: Country): void {
        const isSavedEcheck = this.echeckComponentSettings.isPaymentWithSavedEcheck;
        const selectedEcheck = this.echeckComponentSettings.selectedEcheck;
        const echeckRequest = this.echeckComponentSettings.echeckRequest;
        const isBillingRequired = this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired;
        const echeckAddress = this.getValidateEcheckAddress(isBillingRequired, isSavedEcheck,
            billingAddress, addressCountry);
        let phone = isSavedEcheck ? selectedEcheck.phone : echeckRequest.phone;
        if (phone) {
            const phoneCode = PhoneCodesConstants.phoneCodes.find(x => phone.toUpperCase().indexOf(x.name) > -1);
            if (phoneCode) {
                phone = phone;
            } else {
                phone = this._maskPipe.transform(phone, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
            }
        }
        const personalCheckRequest = {
            name: echeckAddress.name,
            addressOne: echeckAddress.addressLine1,
            addressTwo: echeckAddress.addressLine2,
            city: echeckAddress.city,
            zip: echeckAddress.zip,
            state: echeckAddress.state,
            country: echeckAddress.country,    // contains 2 digit code
            accountNumber: isSavedEcheck ? selectedEcheck.accountNumber : echeckRequest.accountNumber,
            routingNumber: isSavedEcheck ? selectedEcheck.routingNumber : echeckRequest.routingNumber,
            bankName: isSavedEcheck ? selectedEcheck.bankName : echeckRequest.bankName,
            accountType: isSavedEcheck ? selectedEcheck.accountType : echeckRequest.accountType,
            checkDate: this.getCheckDateAsString(),
            mecTransactionID: '',
            email: isSavedEcheck ? selectedEcheck.email : echeckRequest.email,
            phone: phone
        };
        this.echeckComponentSettings.validatePersonalCheckRequest = personalCheckRequest;
    }

    /**
     * @description gets date as string
     *
     * @returns {string}
     * @memberof EcheckComponent
     */
    getCheckDateAsString(): string {
        const currentDate = new Date();
        return currentDate.getFullYear() + '' + (('0' + (currentDate.getMonth() + 1)).slice(-2))
            + '' + (('0' + currentDate.getDate()).slice(-2)) + '';
    }

    /**
     * @description simplifying the request.
     *
     * @private
     * @returns {Address}
     * @memberof EcheckComponent
     */
    private getValidateEcheckAddress(isBillingRequired: boolean, isSavedEcheck: boolean,
        billingAddress: Address, addressCountry: Country): Address {
        const address = {
            name: isSavedEcheck ? billingAddress.firstName :
                (isBillingRequired && billingAddress && billingAddress.name) ? billingAddress.name :
                    (billingAddress.firstName && billingAddress.lastName) ? billingAddress.firstName + ' ' + billingAddress.lastName : '',
            addressLine1: isBillingRequired && billingAddress &&
                billingAddress.addressLine1 ? billingAddress.addressLine1 : '',
            addressLine2: isBillingRequired && billingAddress &&
                billingAddress.addressLine2 ? billingAddress.addressLine2 : '',
            city: isBillingRequired && billingAddress &&
                billingAddress.city ? billingAddress.city : '',
            zip: isBillingRequired && billingAddress &&
                billingAddress.zip ? billingAddress.zip : '',
            state: isBillingRequired && billingAddress
                && billingAddress.state ? billingAddress.state : '',
            country: addressCountry ? addressCountry.isocodeTwo : '',
        };
        return address;
    }

    /**
     * @description save and get personalCheck Id
     *
     * @memberof EcheckComponent
     */
    savePersonalCheck(): void {
        this.echeckComponentSettings.savePersonalCheckRequest = this.constructSavePersonalCheckRequest();
        const memberId = this.echeckComponentSettings.userInfo ? this.echeckComponentSettings.userInfo.memberId : 0;
        if (memberId) {
            this._echeckService.savePersonalCheck(memberId, this.echeckComponentSettings.savePersonalCheckRequest)
                .subscribe((response: TokenResponse) => {
                    if (response && response.value) {
                        this.echeckComponentSettings.echeckRequest.eCheckID = parseInt(atob(response.value), 10);
                        if (this.echeckComponentSettings.paymentCheck) {
                            this.echeckComponentSettings.paymentCheck.eCheckID = parseInt(atob(response.value), 10);
                        }
                        this.submitPaymentInformation();
                    }
                }, (err: any) => {
                    this.enablePlaceOrder = true;
                });
        }
    }

    /**
    * @description constructs personal check - request for savePersonalEcheck
    * @returns {PersonalCheck}
    * @memberof EcheckComponent
    */
    constructSavePersonalCheckRequest(): PersonalCheck {
        const billingAddress = this.echeckComponentSettings.echeckForm.value.shippingAsBilling ?
            this.echeckComponentSettings.shippingAddress : this.echeckComponentSettings.billingAddress;
        billingAddress.firstName = billingAddress ? billingAddress.name : '';
        if (billingAddress) {
            if (billingAddress.phone) {
                billingAddress.phone = billingAddress.phone.replace(/[^a-zA-Z0-9]/g, '');
            } else {
                billingAddress.phone = null;
            }
        }
        const echeck = this.echeckComponentSettings.echeckRequest;
        if (echeck.phone) {
            const phoneCode = PhoneCodesConstants.phoneCodes.find(x => echeck.phone.toUpperCase().indexOf(x.name) > -1);
            if (phoneCode) {
                echeck.phone = echeck.phone;
            } else {
                echeck.phone = this._maskPipe.transform(echeck.phone, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
            }
        }
        const personalCheck: PersonalCheck = {
            id: echeck.eCheckID,
            accountNumber: echeck.accountNumber,
            routingNumber: echeck.routingNumber,
            bankName: echeck.bankName,
            accountType: echeck.accountType,
            nameOnBankAccount: echeck.nameOnBankAccount,
            reusable: this.echeckComponentSettings.isSaveEcheckForFuture,
            defaultECheck: false,
            customerId: this._paymentService.getCustomerId(),
            billingAddress: billingAddress,
            billingAddressId: billingAddress && billingAddress.id ? billingAddress.id : 0,
            billingAddressRequired: this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired,
            customMessage: '',
            storeId: this.echeckComponentSettings.store.id,
            email: echeck.email,
            phone: echeck.phone
        };
        return personalCheck;
    }

    /**
     * @description submit payment information
     * @memberof EcheckComponent
     */
    submitPaymentInformation() {
        this.echeckComponentSettings.paymentInformation = this.getPaymentInformation();
        // navigates to its parent component - and process the request.
        this.submitPayment.emit(this.echeckComponentSettings.paymentInformation);
    }

    /**
     * @description Process payment on click of continue (from billing schema form)
     * @param {AddressComponentSettings} address
     * @memberof EcheckComponent
     */
    getBillingAddressInfo(addressComponentSettings: AddressComponentSettings): void {
        if (addressComponentSettings) {
            this.echeckComponentSettings.billingAddress = addressComponentSettings.address;
        }
    }

    /**
     * @description payment echeck construction -- Saves in checkout information
     * @param {number} [eCheckId]
     * @returns {PaymentEcheck}
     * @memberof EcheckComponent
     */
    constructPaymentEcheck(eCheckId?: number): PaymentEcheck {
        const echeck = this.echeckComponentSettings.echeckRequest;
        if (echeck.phone) {
            const phoneCode = PhoneCodesConstants.phoneCodes.find(x => echeck.phone.toUpperCase().indexOf(x.name) > -1);
            if (phoneCode) {
                echeck.phone = echeck.phone;
            } else {
                echeck.phone = this._maskPipe.transform(echeck.phone, this._commonService
                    .getPhoneNumberFormatByCountryCode(this.echeckComponentSettings.isoCountryCode));
            }
        }
        const paymentEcheck: PaymentEcheck = {
            bankName: echeck.bankName,
            accountNumber: echeck.accountNumber,
            routingNumber: echeck.routingNumber,
            accountType: echeck.accountType,
            mecTransactionID: '',
            nameOnBankAccount: echeck.nameOnBankAccount,
            customMessage: '',
            reusable: echeck.reusable,
            // defaultEcheck: echeck.defaultEcheck,
            eCheckID: eCheckId,
            email: echeck.email,
            phone: echeck.phone
        };
        return paymentEcheck;
    }

    /**
   * @description method to get payment information
   * @date 2018-08-08
   * @private
   * @returns {PaymentInformation}
   * @memberof EcheckComponent
   */
    private getPaymentInformation(): PaymentInformation {
        const paymentInformation: PaymentInformation = {
            paymentECheck: this.echeckComponentSettings.paymentCheck,
            paymentToken: null,
            billingAddress: this.constructBillingAddress(),
            isEnrollment: false,
            selectedPaymentMethod: this.echeckComponentSettings.selectedPaymentMethod,
            isCompleteRedirection: false,
        };
        return paymentInformation;
    }

    /**
         * @description constructing billing address
         * @date 2018-07-31
         * @returns {Address}
         * @memberof EcheckComponent
         */
    constructBillingAddress(): Address {
        if (this.echeckComponentSettings.selectedPaymentMethod.billingAddressRequired) {
            const paymentWithSavedEcheck = this.echeckComponentSettings.isPaymentWithSavedEcheck;
            const shippingAddress = this.getBillingAddressByCondition(paymentWithSavedEcheck);
            let country: Country;
            if (shippingAddress) {
                country = this.echeckComponentSettings.countries
                    .find(z => z.isocodeThree.toUpperCase() === shippingAddress.country.toUpperCase());
                if (!country) {
                    country = this.echeckComponentSettings.countries
                        .find(z => z.isocodeTwo.toUpperCase() === shippingAddress.country.toUpperCase());
                }
            }
            if (shippingAddress) {
                const billingAddress: Address = {
                    firstName: shippingAddress.firstName || shippingAddress.name,
                    lastName: shippingAddress.lastName,
                    addressLine1: shippingAddress.addressLine1,
                    addressLine2: shippingAddress.addressLine2,
                    city: shippingAddress.city,
                    country: shippingAddress.country,
                    countryCode: shippingAddress.country,
                    id: null,
                    memberAddressDetailId: null,
                    // for saved echecks we are getting countrycodetwo in country
                    countryCodeTwo: country ? country.isocodeTwo : '',
                    state: shippingAddress.state,
                    zip: shippingAddress.zip,
                    phone: shippingAddress.phone,
                    name: shippingAddress.firstName || shippingAddress.name,
                    postalCode: shippingAddress.zip || shippingAddress.postalCode
                };
                return billingAddress;
            }
        }
        return null;
    }
}
