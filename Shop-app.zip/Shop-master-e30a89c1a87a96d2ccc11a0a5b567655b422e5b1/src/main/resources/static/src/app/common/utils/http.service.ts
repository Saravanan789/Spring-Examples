import {environment} from '../../../environments/environment';
import {ConnectionBackend, Headers, Http, Request, RequestOptions, RequestOptionsArgs, Response} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import {SSO} from '../../sso/sso.constants';
import {CookieService} from 'ngx-cookie-service';
import {RealmType} from '../../shared/enums/realm-type.enum';
import {EncryptionService} from "../../sso/encryption.service";

declare let userLoginStatus: any;
declare let loggedInMemberId: any;
declare let canShowSplashInitally: any;

export class HttpService extends Http {
  private cookieService: CookieService = new CookieService(document);

  constructor(backend: ConnectionBackend,
              defaultOptions: RequestOptions) {
    super(backend, defaultOptions);
  }

  /**
   * Performs any type of http request.
   * @param url
   * @param options
   * @returns {Observable<Response>}
   */
  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    return super.request(url, options);
  }

  /**
   * Performs a request with `get` http method.
   * @param url
   * @param options
   * @returns {Observable<>}
   */
  get(url: string, options?: RequestOptionsArgs): Observable<any> {
    this.requestInterceptor(options);
    return super.get(this.getFullUrl(url), this.requestOptions(url, options))
      .do((res: Response) => {
        this.onSubscribeSuccess(res);
      }, (error: any) => {
        this.onSubscribeError(error);
      })
      .catch(this.onCatch)
      .finally(() => {
        this.onFinally();
      });
  }

  getLocal(url: string, options?: RequestOptionsArgs): Observable<any> {
    return super.get(url, options);
  }

  /**
   * Performs a request with `post` http method.
   * @param url
   * @param body
   * @param options
   * @returns {Observable<>}
   */
  post(url: string, body: any, options?: RequestOptionsArgs): Observable<any> {
    this.requestInterceptor(options);
    return super.post(this.getFullUrl(url), body, this.requestOptions(url, options))
      .catch(this.onCatch)
      .do((res: Response) => {
        this.onSubscribeSuccess(res);
      }, (error: any) => {
        this.onSubscribeError(error);
      })
      .finally(() => {
        this.onFinally();
      });
  }

  /**
   * Performs a request with `put` http method.
   * @param url
   * @param body
   * @param options
   * @returns {Observable<>}
   */
  put(url: string, body: string, options?: RequestOptionsArgs): Observable<any> {
    this.requestInterceptor(options);
    return super.put(this.getFullUrl(url), body, this.requestOptions(url, options))
      .catch(this.onCatch)
      .do((res: Response) => {
        this.onSubscribeSuccess(res);
      }, (error: any) => {
        this.onSubscribeError(error);
      })
      .finally(() => {
        this.onFinally();
      });
  }

  /**
   * Performs a request with `delete` http method.
   * @param url
   * @param options
   * @returns {Observable<>}
   */
  delete(url: string, options?: RequestOptionsArgs): Observable<any> {
    this.requestInterceptor(options);
    return super.delete(this.getFullUrl(url), this.requestOptions(url, options))
      .catch(this.onCatch)
      .do((res: Response) => {
        this.onSubscribeSuccess(res);
      }, (error: any) => {
        this.onSubscribeError(error);
      })
      .finally(() => {
        this.onFinally();
      });
  }


  /**
   * Performs a request with `delete` http method.
   * @param url
   * @param options
   * @returns {Observable<>}
   */
  patch(url: string, body: string, options?: RequestOptionsArgs): Observable<any> {
    this.requestInterceptor(options);
    return super.patch(this.getFullUrl(url), body, this.requestOptions(url, options))
      .catch(this.onCatch)
      .do((res: Response) => {
        this.onSubscribeSuccess(res);
      }, (error: any) => {
        this.onSubscribeError(error);
      })
      .finally(() => {
        this.onFinally();
      });
  }


  /**
   * Request options.
   * @param options
   * @returns {RequestOptionsArgs}
   */
  private requestOptions(url: string, options?: RequestOptionsArgs): RequestOptionsArgs {
    if (options == null) {
      options = new RequestOptions();
    }
    if (options.headers == null) {
      options.headers = new Headers();
    }
    options.headers.append('Content-Type', 'application/json');
    if (url.startsWith(environment.apiUrl) && !url.startsWith(environment.apiUrl + '/payment')) {
      const uuid = SSO.getnonce();
      options.headers.append('UUID', uuid);
      let ssoToken: string;
      if (SSO.isRemoveObsoleteCookie()) {
        ssoToken = localStorage.getItem(SSO.ACCESS_TOKEN);
      } else {
        ssoToken = this.cookieService.get(SSO.ACCESS_TOKEN);
      }
      if (ssoToken === null || ssoToken === undefined || ssoToken === '') {
        if (SSO.isRemoveObsoleteCookie()) {
          localStorage.removeItem(SSO.REFRESH_TOKEN);
        } else {
          this.cookieService.delete(SSO.REFRESH_TOKEN, environment.cookiePath, environment.cookieDomain);
        }
        this.cookieService.delete(SSO.MEMBER_ID, environment.cookiePath, environment.cookieDomain);
        this.cookieService.delete(SSO.NONCE, environment.cookiePath, environment.cookieDomain);
        const userInfo = localStorage.getItem('appshop.userInfo');
        if ((userInfo !== null && userInfo !== undefined && userInfo !== '') || userLoginStatus === true) {
          if (userInfo !== null && userInfo !== undefined && userInfo !== '') {
            localStorage.removeItem('appshop.userInfo');
          }
          userLoginStatus = false;
          window.location.reload();
        }
      }
      const userId = this.cookieService.get(SSO.MEMBER_ID);
      if (userId && (canShowSplashInitally !== true)) {
        if (loggedInMemberId !== userId) {
          loggedInMemberId = userId;
          window.location.reload();
        }
      }

      if (!userId) {
        const userInfo = localStorage.getItem('appshop.userInfo');
        if (userInfo) {
          localStorage.removeItem('appshop.userInfo');
          if (SSO.isRemoveObsoleteCookie()) {
            localStorage.removeItem(SSO.ACCESS_TOKEN);
            localStorage.removeItem(SSO.REFRESH_TOKEN);
            localStorage.removeItem(SSO.LOCAL_MEMBER_SESSION_ID);
            localStorage.removeItem(SSO.IS_NEW_TOKEN);
            this.cookieService.delete(SSO.MEMBER_SESSIONID, environment.cookiePath, environment.cookieDomain);
          } else {
            this.cookieService.delete(SSO.ACCESS_TOKEN, environment.cookiePath, environment.cookieDomain);
            this.cookieService.delete(SSO.REFRESH_TOKEN, environment.cookiePath, environment.cookieDomain);
          }
          userLoginStatus = false;
          window.location.reload();
        }
      }
      let accessToken = SSO.isRemoveObsoleteCookie() ? localStorage.getItem(SSO.ACCESS_TOKEN) : this.cookieService.get(SSO.ACCESS_TOKEN);
      let realmType = RealmType.TITAN_EXTERNAL;
      if (!accessToken) {
        accessToken = localStorage.getItem('appshop.guestToken');
        realmType = RealmType.TITAN_GUEST;
      }
      const header = 'Bearer ' + accessToken + '&&' + realmType;
      if (environment.enableAuthorization) {
        options.headers.append('Authorization', this.getAuthorizationHeader(header, uuid));
      }
      if (environment.enableAuthentication) {
        options.headers.append('Authentication', header);
      }

    }
    return options;
  }

  private getAuthorizationHeader(token: string, uuid: string): string {
    const data = uuid + '||' + token;
    return EncryptionService.encryptText(data);
  }


  /**
   * Build API url.
   * @param url
   * @returns {string}
   */
  private getFullUrl(url: string): string {
    // return full URL to API here
    return url;
  }

  /**
   * Request interceptor.
   */
  private requestInterceptor(options?: RequestOptionsArgs): void {
    // this.loaderService.showPreloader();
  }

  /**
   * Response interceptor.
   */
  private responseInterceptor(): void {
    // this.loaderService.hidePreloader();
  }

  /**
   * Error handler.
   * @param error
   * @param caught
   * @returns {ErrorObservable}
   */
  private onCatch(error: any, caught: Observable<any>): Observable<any> {
    if (error.url.startsWith(environment.ssoApiURL.split('/auth/realm')[0]) || error.url.startsWith(environment.apiUrl)) {
      if (error.status === 401) {
        window.location.href = decodeURIComponent(encodeURIComponent(window.location.href));
      } else if (error.status === 403) {
        // alert('Unauthorised Access');
      }
    }
    return Observable.throw(error);
  }

  /**
   * onSubscribeSuccess
   * @param res
   */
  private onSubscribeSuccess(res: Response): void {
    if (res !== null && res !== undefined) {
      const body = res.json();
      const url = res.url;
    }
  }

  /**
   * onSubscribeError
   * @param error
   */
  private onSubscribeError(error: any): void {
    const errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
  }

  /**
   * onFinally
   */
  private onFinally(): void {
    this.responseInterceptor();
  }
}
