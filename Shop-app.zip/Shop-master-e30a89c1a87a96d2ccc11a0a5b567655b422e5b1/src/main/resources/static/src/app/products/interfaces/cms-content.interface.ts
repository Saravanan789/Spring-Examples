export interface CmsContent {
    name: string;
    description: string;
    images: any[];
}
