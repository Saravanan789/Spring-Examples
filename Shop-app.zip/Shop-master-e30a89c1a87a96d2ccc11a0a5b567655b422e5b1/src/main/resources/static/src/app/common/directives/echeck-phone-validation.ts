import { FormControl } from '@angular/forms';
import { PhoneCodesConstants } from '../constants/phone-codes.constant';
export class EcheckPhoneNumberValidation {

    static PhoneNumberValidation(control: FormControl): any {
        const phone = control.value;
        if (phone && phone.match(/[a-zA-Z]/)) {
            const phoneCode = PhoneCodesConstants.phoneCodes.find(x => phone.toUpperCase() === x.name);
            if (!phoneCode) {
                return { 'InvalidPhoneNo': true };
            }
        } else if (phone && phone.replace(/[^0-9]/gi, '').length !== 10) {
            return { 'InvalidPhoneNo': true };
        }
        return undefined;
    }
}
