export interface MemberIdentification {
    value: string;
    identificationId: number;
}
