import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { ShippingMethod, ProductShippingRestriction, RestrictedProduct, CheckoutInformation } from '../interfaces';
import { DeliveryOptionType } from '../enums';
import { Cart, Item } from '../../shared/models';
import { Subscription } from 'rxjs/Subscription';
import { FormGroup } from '@angular/forms';
import { Address, TranslateParam } from '../../common/interfaces';

export class ShippingMethodsComponentSettings extends BaseSettings {
    shippingMethods: ShippingMethod[];
    shippingValidations: Array<any>;
    deliveryOptionType: string;
    deliveryOptions = DeliveryOptionType;
    shippingAddress: Address;
    shoppingCart: Cart;
    shippingMehtod: ShippingMethod;
    cartSubscription: Subscription;
    placeOrderSubscription: Subscription;
    shippingMethodForm: FormGroup;
    productShippingRestriction: ProductShippingRestriction;
    restrictedProducts: RestrictedProduct[];
    disableNextButton: boolean;
    breadcrumbSubscription: Subscription;
    checkoutInformation: CheckoutInformation;
    autoshipShippingMethod: ShippingMethod;
    autoshipShippingMethods: ShippingMethod[];
    autoshipMethodInterval: any;
    productErrorMsg: string;
    isReloadCart: boolean;
    thresholdCrossed: boolean;
    memberCCLimitExceeded: boolean;
    monthlyCCValue: number;
    translateParams: TranslateParam;
}
