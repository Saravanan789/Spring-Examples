import {
    PurchaseFlow, MemberType,
    MemberTypeValue
} from '../../shared/enums';

export interface DeliveryOptionTypeRequest {
    memberTypeId: MemberType;
    memberType: MemberTypeValue;
    purchaseFlow: PurchaseFlow;
    countryCode: string;
}
