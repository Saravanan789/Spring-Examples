export enum AutoshipFrequency {
    Monthly= 3,
    Quarterly = 4,
    AlternativeMonth = 7
}

export enum PromotionsTypes {
    Autoship = 1,
    Join = 2
}

