export interface RestrictedProduct {
    itemNumber: string;
    productID: number;
    productWeight: number;
    productHeight: number;
    productWidth: number;
    productLength: number;
    sellingPrice: number;
    wholesalePrice: number;
    retailPrice: number;
    weightMetricId: number;
    productQuantity: number;
    isOrderLiteratureOnly: boolean;
    errorCode: string;
    errorDescription: string;
    orderLiteratureOnly: boolean;
    shippable: boolean;
}
