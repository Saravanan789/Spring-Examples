import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { DeliveryOptionType } from '../enums/delivery-option-type.enum';
import { Address } from '../../common/interfaces';
import { PersonalInfoComponentSettings } from '../component-settings';
import { TaxValidationMessage } from '../interfaces';

/**
 * @description this message service
 * will be used to communicate between
 * components
 * @date 2018-07-20
 * @export
 * @class CheckoutMessageService
 */
@Injectable()
export class CheckoutMessageService {
    private suggestSponsorPreference: Subject<any> = new Subject<any>();
    private sponsorEligibility: Subject<any> = new Subject<any>();
    private taxCalcSubject: Subject<any> = new Subject<any>();
    private submitGuestForm: Subject<any> = new Subject<any>();
    private shipmethodTypeSubject: Subject<DeliveryOptionType> = new Subject<DeliveryOptionType>();
    private enablePlaceOrderBtn: Subject<TaxValidationMessage> = new Subject<TaxValidationMessage>();
    private validateCurrentStep: Subject<string> = new Subject<string>();

    getValidateCurrentStep$(): Observable<string> {
        return this.validateCurrentStep.asObservable();
    }

    setValidateCurrentStep(step: string): void {
        this.validateCurrentStep.next(step);
    }

    getSponsorPreference(): Observable<PersonalInfoComponentSettings> {
        return this.suggestSponsorPreference.asObservable();
    }

    setSponsorPreference(pInfoComponentSettings: PersonalInfoComponentSettings): void {
        this.suggestSponsorPreference.next(pInfoComponentSettings);
    }

    getSponsorEligibility(): Observable<any> {
        return this.sponsorEligibility.asObservable();
    }

    setSponsorEligibility(isEligible: boolean): void {
        this.sponsorEligibility.next(isEligible);
    }

    setTaxCalc(isReloadCart: boolean) {
        this.taxCalcSubject.next(isReloadCart);
    }

    getTaxCalc(): Observable<any> {
        return this.taxCalcSubject.asObservable();
    }

    getSubmitGuestForm(): Observable<any> {
        return this.submitGuestForm.asObservable();
    }

    setSubmitGuestForm(isSubmit: boolean): void {
        this.submitGuestForm.next(isSubmit);
    }
    /**
     * To emit the shipmethod type selected property
     * @param {DeliveryOptionType} methodType
     * @memberof MessageService
     */
    setShipmethodTypeSelected(methodType: DeliveryOptionType) {
        this.shipmethodTypeSubject.next(methodType);
    }

    /**
     * To get the emited shipmethod type property
     * @returns {Observable<DeliveryOptionType>}
     * @memberof MessageService
     */
    getShipmethodTypeSelected(): Observable<DeliveryOptionType> {
        return this.shipmethodTypeSubject.asObservable();
    }

    /**
     * @description this subject used for
     * disable and enabble place order button
     * @date 2018-08-17
     * @returns {Observable<any>}
     * @memberof CheckoutMessageService
     */
    getDisablePlaceOrderBtn(): Observable<TaxValidationMessage> {
        return this.enablePlaceOrderBtn.asObservable();
    }

    /**
     * @description this subject used for
     * disable and enabble place order button
     * @date 2018-08-17
     * @returns {Observable<any>}
     * @memberof CheckoutMessageService
     */
    setDisablePlaceOrderBtn(taxValidationMessage: TaxValidationMessage) {
        this.enablePlaceOrderBtn.next(taxValidationMessage);
    }
}
