import { ProductComponent } from './products/components/product.component';
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { WishlistProductsComponent } from './common/components/wishlist-products.component';
import { PageNotFoundComponent } from './shared/components/not-found.component';
import { AppMaintenanceComponent } from './shared/components/app-maintenance.component';
import { ComponentNames } from './shared/constants/component-names.constants';
import { LogoutGuard } from './common/components/member-upgrade-logout-guard';
import { CanActivateNotFoundGuard } from './shared/guards/can-activate-not-found.guard';

const appModuleRoutes: Routes = [
  { path: ':countryCode/:languageCode/checkout', loadChildren: './checkout/checkout.module#CheckoutModule' },
  { path: ':countryCode/:languageCode/cart', loadChildren: './cart/cart.module#CartModule', canActivate: [LogoutGuard] },
  { path: ':countryCode/:languageCode/favorite', component: WishlistProductsComponent, canActivate: [LogoutGuard] },
  { path: ':countryCode/:languageCode/notfound', component: PageNotFoundComponent, canActivate: [LogoutGuard] },
  { path: ':countryCode/:languageCode/comingsoon', component: AppMaintenanceComponent, canActivate: [LogoutGuard] },
  { path: ':countryCode/:languageCode/:slug', component: ProductComponent,
   data: { name: ComponentNames.PRODUCT_COMPONENT }, canActivate: [LogoutGuard] },
  { path: '', redirectTo: '/usa/en-us/products', pathMatch: 'full', canActivate: [LogoutGuard] },
  { path: '**', component: PageNotFoundComponent, canActivate: [CanActivateNotFoundGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(appModuleRoutes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
