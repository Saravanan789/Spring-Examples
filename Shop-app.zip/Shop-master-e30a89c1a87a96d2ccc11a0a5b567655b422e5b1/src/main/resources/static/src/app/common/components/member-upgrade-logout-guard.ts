import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppMessageService } from '../../app-message.service';
import { CacheService } from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';

@Injectable()
export class LogoutGuard implements CanActivate {
  constructor(
    private _appMessageService: AppMessageService,
    private _cacheService: CacheService) {}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      const url: string = state.url;

    return this.memberUpgradeLogout(url);
  }

  /**
   * @description logout while enrolling for retail user
   * @date 2019-04-24
   * @memberof OrderSummaryNewComponent
   */
  memberUpgradeLogout(url: string): boolean {
    const fpcCachekeKey = this._cacheService.get(CacheKey.FPCOptIn);
    const isFPCOptIn = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
    if (window.location.pathname.indexOf('ordersummary') > -1 && isFPCOptIn) {
      this._appMessageService.setMemberUpgradeNotification(true);
    } else {
      return true;
    }
  }
}
