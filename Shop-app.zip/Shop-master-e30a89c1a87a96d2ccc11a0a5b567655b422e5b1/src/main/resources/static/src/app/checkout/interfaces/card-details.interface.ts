export interface CardDetails {
    cardHolderName: string;
    cardNumber: string;
    cardExpirationMonth: number;
    cardExpirationYear: number;
    cardCVV: number;
}
