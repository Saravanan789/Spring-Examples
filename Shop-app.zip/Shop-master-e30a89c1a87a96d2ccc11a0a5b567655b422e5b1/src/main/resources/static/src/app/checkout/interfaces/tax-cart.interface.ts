import { TaxItems } from './tax-items.interface';
import { TaxBreakDown } from '../../shared/models/taxbreakdown.model';
export class TaxCart {
  shippingTaxInclusive: boolean;
  totalTax: number;
  shippingTax: number;
  shipMethodId: number;
  taxBreakDown?: TaxBreakDown;
  shippingCost: number;
  importFeeValue?: number;
  orderLineItems: TaxItems[] = [];
}
