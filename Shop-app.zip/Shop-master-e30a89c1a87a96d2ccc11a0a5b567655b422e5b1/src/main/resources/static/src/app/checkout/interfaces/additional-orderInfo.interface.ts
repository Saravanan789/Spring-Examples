export interface AdditionalOrderInfo {
    key: string ;
    value: number ;
    lineItemTypeId: number ;
}
