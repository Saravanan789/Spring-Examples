
export class PhoneCodesConstants {
    public static phoneCodes = [
        { value: '77676547', name: 'PROPOLIS' },
        { value: '3733366', name: 'FREEDOM' },
        { value: '76692', name: 'SONYA' },
        { value: '26626', name: 'COMBO' },
        { value: '228482867', name: 'ACTIVATOR' },
        { value: '5565626', name: 'JOJOBA' },
        { value: '568466', name: 'LOTION' },
        { value: '44656', name: 'GINKO' },
        { value: '86637', name: 'TONER' },
        { value: '46639', name: 'HONEY' }
    ];
}
