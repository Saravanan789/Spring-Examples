import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { FormGroup } from '@angular/forms';
import { PersonalInformation, PersonalInfoFormFields } from '../interfaces';
import { Subscription } from 'rxjs/Subscription';
import { ContactTypeConstants } from '../constants';
import { environment } from '../../../environments/environment';

export class GuestPersonalInfoComponentSettings extends BaseSettings {
    formSubmitted: boolean;
    mailAlreadyExist: boolean;
    guestUser: boolean;
    guestPersonalInfoFormValidated: boolean;
    guestPersonalInformationForm: FormGroup;
    personalInformation: PersonalInformation;
    autoPopulate: boolean;
    guestPersonalInfoSubscription: Subscription;
    verifyEmailAccountInProgess = false;
    isShowLoader = false;
    phoneNumberAlreadyExists: boolean;
    isShowPhoneNumberLoader = false;
    personalInfoFormFields: PersonalInfoFormFields;
    phoneNumberFormat: string;
    contactTypes = ContactTypeConstants.phoneTypes;
    isLegacyUser = false;
    intialPollCount = 0;
    maxPollCount = environment.longPollCount;
    enableEasterEgg = environment.enableEasterEgg;
}
