import { ImageModel } from '../../products/interfaces/image-model.interface';
import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ImageType } from '../../products/enums/image-type.enum';

@Pipe({
  name: 'singleimageFilter'
})
export class SingleImageFilterPipe implements PipeTransform {
  transform(imagesList: Array<ImageModel>, imageType: string): string {
    if (imagesList && imagesList.length > 0  && imagesList[0].details && imagesList[0].details.length > 0) {
      const zoomedImage = imagesList.find(img => img.type === ImageType.ZoomedImage && img.isDefault);
      const productImage = zoomedImage ? zoomedImage.details.filter(item => item.type === imageType)[0] : null;
      if (productImage) {
        if (productImage.url.indexOf('http') === -1) {
          return (environment.cdnURL + '/' + productImage.url);
        } else {
          return productImage.url;
        }
      } else {
        return environment.uiTemplateBaseUrl + '/images/no_image.png';
      }
    } else {
      return environment.uiTemplateBaseUrl + '/images/no_image.png';
    }
  }
}
