import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { CacheService, CommonService, ConfigurationService, ActiveSessionService } from '../../shared/services';
import { Observable } from 'rxjs/Observable';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import * as crypto from 'crypto-js';
import {
    StorePaymentMethod, ProcessorConfigResponse, PaymentTokenResponse, TokenResponse, PaymentFailResponse
} from '../interfaces';
import { PaymentConstants } from '../constants';
import { PaymentRequestModel } from '../interfaces/payment-request-model.interface';
import { StoreConfig, Country, Member } from '../../shared/interfaces';
import { Address } from '../../common/interfaces';
import { CheckoutInformation, PaymentInformation, EnrollInfo } from '../../checkout/interfaces';
import { AddressType } from '../../common/enums';
import { PaymentResponseModel } from '../interfaces/payment-response-model.interface';
import { PaymentComponentSettings } from '../component-settings';
import { PaymentMethodTypes, PaymentProcessor, PaymentStatus } from '../enums';
import { environment } from '../../../environments/environment';
import { PurchaseFlow } from '../../shared/enums';
import { DefaultPayment } from '../interfaces/default-payment.interface';
import { Params } from '@angular/router';

@Injectable()
export class PaymentService {
    private _paymentFailResponse: PaymentFailResponse;

    constructor(private _http: Http,
        private _cacheService: CacheService,
        private _commonService: CommonService,
        private _configurationService: ConfigurationService,
        private _activeSessionService: ActiveSessionService) { }

    /**
     * @description this method will set the payment fail info
     * @date 2018-11-28
     * @param {PaymentFailResponse} _paymentFailResponse
     * @memberof PaymentService
     */
    setPaymentFailResponse(_paymentFailResponse: PaymentFailResponse): void {
        this._paymentFailResponse = _paymentFailResponse;
    }

    /**
     * @description this method will set the payment fail info
     * @date 2018-11-28
     * @param {PaymentFailResponse} _paymentFailResponse
     * @memberof PaymentService
     */
    getPaymentFailResponse(params: Params): PaymentFailResponse {
        if (!this._paymentFailResponse || (this._paymentFailResponse && !this._paymentFailResponse.paymentProcessor)) {
            this._paymentFailResponse = this.mapPaymentFailResponse(params);
        }
        return this._paymentFailResponse;
    }

    /**
    * @description this method will map payment fail
    * response
    * @date 2018-11-28
    * @private
    * @memberof PaymentStatusComponent
    */
    mapPaymentFailResponse(params: Params): PaymentFailResponse {
        const paymentProcessor = this._commonService.getParamValueFromUrl(PaymentConstants.PaymentProcessorParam);
        const errorCode = this._commonService.getParamValueFromUrl(PaymentConstants.PaymentErrorCodeParam);
        const paymentFailResposne: PaymentFailResponse = {
            errorCode: atob(this._commonService.getParamValueFromUrl(PaymentConstants.PaymentErrorCodeParam) || ''),
            errorMessage: atob(this._commonService.getParamValueFromUrl(PaymentConstants.PaymentErrorMessageParam) || ''),
            paymentProcessor: paymentProcessor,
            paymentStatus: params['paymentStatus'],
            displayRetryBtn: (errorCode || paymentProcessor || params['paymentStatus'] === PaymentStatus.FAILED) ? true : false
        };

        this.setPaymentFailResponse(paymentFailResposne.displayRetryBtn ? paymentFailResposne : null);
        return paymentFailResposne.displayRetryBtn ? paymentFailResposne : null;
    }

    /**
     * @description it will retrive all payemnt mehtods
     * what we have configured for the store
     * @date 2018-07-26
     * @param {number} storeId
     * @param {string} countryCode
     * @returns {Observable<any>}
     * @memberof PaymentService
     */
    getPaymentMethodsByStore(storeId: number, countryCode: string, isAutoshipEnabled: boolean): Observable<StorePaymentMethod[]> {
        const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        const headers = this.getPaymentHeaders();
        let purchaseFlowType: PurchaseFlow;
        if (isAutoshipEnabled) {
            purchaseFlowType = PurchaseFlow.AUTOSHIP;
        } else {
            purchaseFlowType = this._commonService.getPurchaseFlowType();
        }
        return this._http
            .get(ApiUrlConstants.paymentApiUrl
            + '/stores/' + storeId + '/country-code/' + countryCode + '/order-type/'
            + purchaseFlowType + '/culture-code/' + languageCode + '/payment-methods', { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }
    /**
     * @description it will retrive all payemnt processor
     * configration for the store
     * @date 2018-07-26
     * @param {number} storeId
     * @returns {Observable<ProcessorConfigResponse>}
     * @memberof PaymentService
     */
    getProcessorConfig(storeId: number): Observable<ProcessorConfigResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/payments/paymentMethods/' + storeId, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description to save the Payment token details
     * @date 2018-07-31
     * @param {PaymentTokenResponse} paymentTokenResponse
     * @returns {Observable<any>}
     * @memberof PaymentService
     */
    savePaymentTokenDetails(paymentTokenResponse: PaymentTokenResponse): Observable<TokenResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .post(ApiUrlConstants.paymentApiUrl + '/payments/token',
            JSON.stringify(paymentTokenResponse), { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * submit payment (on click of place order)
     *
     * @param {string} paymentMethod
     * @param {string} orderId
     * @param {PaymentInformation} paymentInformation
     * @returns {Observable<PaymentResponseModel>}
     * @memberof PaymentService
     */
    submitPayment(paymentMethod: string, paymentInformation: PaymentInformation,
        paymentComponentSettings: PaymentComponentSettings): Observable<PaymentResponseModel> {
        const headers = this.getPaymentHeaders();
        const request = this.constructPaymentRequestModel(paymentMethod, paymentInformation, paymentComponentSettings);
        const checkoutInformation = paymentComponentSettings.checkoutInformation;
        const orderId = checkoutInformation && checkoutInformation.orderDetails ?
            checkoutInformation.orderDetails.webOrderId : '';
        return this._http
            .post(ApiUrlConstants.paymentApiUrl + '/payments/' + orderId + '/create-payment-checks',
            JSON.stringify(request), { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * constructs payment request model
     *
     * @param {string} paymentMethod
     * @param {PaymentInformation} paymentInformation
     * @returns {PaymentRequestModel}
     * @memberof PaymentService
     */
    constructPaymentRequestModel(paymentMethod: string,
        paymentInformation: PaymentInformation, paymentComponentSettings: PaymentComponentSettings): PaymentRequestModel {
        const store: StoreConfig = this._configurationService.getStoreData();
        const checkoutInformation: CheckoutInformation = paymentComponentSettings.checkoutInformation;
        const cartSession = this._cacheService.get(CacheKey.CartSessionInfo);
        const orderDescription = cartSession && cartSession.items &&
            cartSession.items.length > 0 ? cartSession.items[0].name : 'order description';
        const paymentRequestModel: PaymentRequestModel = {
            token: paymentInformation.paymentToken,
            orderReferenceId: checkoutInformation && checkoutInformation.orderDetails
                ? checkoutInformation.orderDetails.id : null,
            orderDescription: orderDescription,
            amount: cartSession.total,
            storeId: store.id,
            countryCode: this.getCountryCodeBasedOnPayment(paymentInformation, paymentComponentSettings),
            currencyCode: store.currencyCode,
            paymentMethodType: paymentMethod,
            customerId: this.getCustomerId(),
            orderTypeId: this._activeSessionService.getOrderTypeId(),
            billingAddress: this.getBillingAddress(paymentInformation, paymentComponentSettings),
            paymentCheck: paymentInformation.paymentECheck,
            paymentRequestModel: null // for payvison - need to add logic
        };
        return paymentRequestModel;
    }

    /**
     * @description this method will give country code based
     * on payment method
     * @date 2018-08-14
     * @private
     * @param {string} paymentMethod
     * @param {PaymentInformation} paymentInformation
     * @param {PaymentComponentSettings} paymentComponentSettings
     * @returns {string}
     * @memberof PaymentService
     */
    private getCountryCodeBasedOnPayment(paymentInformation: PaymentInformation
        , paymentComponentSettings: PaymentComponentSettings): string {
        if (paymentComponentSettings.paymentProcessorConfig
            && paymentComponentSettings.paymentProcessorConfig.paymentProcessor === PaymentProcessor.PAYVISION
            && paymentComponentSettings.selectedPaymentMethod.paymentMethodName === PaymentMethodTypes.Credit_Card) {
            return paymentComponentSettings.isoTwoletterCountryCode;
        } else {
            return paymentComponentSettings.isoCountryCode;
        }
    }

    private getCountryId(paymentComponentSettings: PaymentComponentSettings): number {
        if (paymentComponentSettings.countries && paymentComponentSettings.countries.length > 0) {
            const country: Country = paymentComponentSettings.countries
                .find(x => x.isocodeThree.toLowerCase() === paymentComponentSettings.isoCountryCode.toLowerCase());
            return country ? country.countryId : null;
        }
    }

    /**
     * @description get billing address
     * @date 2018-08-10
     * @private
     * @returns {Address}
     * @memberof OrderService
     */
    private getBillingAddress(paymentInformation: PaymentInformation, paymentComponentSettings: PaymentComponentSettings): Address {
        if (paymentInformation && paymentInformation.billingAddress) {
            paymentInformation.billingAddress.addressType = AddressType.BILLING;
            paymentInformation.billingAddress.countryCode = this.getCountryCodeBasedOnPayment(paymentInformation, paymentComponentSettings);
            paymentInformation.billingAddress.country = this.getCountryCodeBasedOnPayment(paymentInformation, paymentComponentSettings);
            paymentInformation.billingAddress.countryId = this.getCountryId(paymentComponentSettings);
            return paymentInformation.billingAddress;
        }
    }


    /**
  * @param  {number} scrollDuration
  * @returns void
  */
    scrollToTop(scrollDuration: number): void {
        const scrollStep = -window.scrollY / (scrollDuration / 15),
            scrollInterval = setInterval(function () {
                if (window.scrollY !== 0) {
                    window.scrollBy(0, scrollStep);
                } else {
                    clearInterval(scrollInterval);
                }
            }, 15);
    }

    /**
   * @description this method will return customer id
   * from userinfo or enrollment user info
   * @date 2018-09-11
   * @returns {number}
   * @memberof PaymentService
   */
    getCustomerId(): number {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const userInfo: Member = this._activeSessionService.getUserInfo();
        let memberId = 0;
        if (checkoutInformation && checkoutInformation.enrollInformation
            && checkoutInformation.enrollInformation.personalInfo) {
            const enrollInformation: EnrollInfo = checkoutInformation.enrollInformation;
            memberId = enrollInformation.personalInfo.memberId;
        } else if (userInfo && userInfo.memberId) {
            memberId = userInfo.memberId;
        }
        return memberId;
    }

    /**
     *
     * @date 2018-08-07
     * @param {number} memberId
     * @param {string} countryCode
     * @returns {Observable<IPersonalCheck[]>}
     * @memberof EcheckService
     */
    getMemberDefaultPaymentMethod(memberId: number, storedId: number): Observable<DefaultPayment> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/payment-methods/member/' + memberId + '/store/' + storedId +
            '/default-payment-method', { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this is used to get
     * payment headers
     * @date 2018-07-26
     * @returns {Headers}
     * @memberof PaymentService
     */
    getPaymentHeaders(): Headers {
        const headers = new Headers();
        const authHeader = 'PAY ' + environment.paymentApiKey + ':' + this.getHashedValue();
        headers.append('authorization', authHeader);
        return headers;
    }

    /**
     * @description this method is used to
     * get payment crypto hashed value
     * @date 2018-07-26
     * @returns {string}
     * @memberof PaymentService
     */
    getHashedValue(): string {
        const shavalue = crypto.HmacSHA1(environment.paymentSecurityKey, environment.paymentServiceKey);
        return crypto.enc.Base64.stringify(shavalue);
    }

    /**
   * To handle the obervable error response
   * @param  {Response|any} error
   */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error);
    }

    /**
   * @description
   * Get Terms and conditions url
   * @param {string} countryCode
   * @param {number} portalId
   * @returns
   * @memberof PaymentService
   */
    getUserSpecificDocuments(countryCode: string, portalId: number) {
        return this._http
            .get(environment.uiTemplateBaseUrl + '/test/documents.json')
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }
}
