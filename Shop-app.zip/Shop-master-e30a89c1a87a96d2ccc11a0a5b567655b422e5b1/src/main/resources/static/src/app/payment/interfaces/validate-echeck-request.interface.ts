
export interface ValidateEcheckRequest {
    accountNumber: string;
    accountType: string;
    addressOne: string;
    addressTwo: string;
    bankName: string;
    checkDate: string;
    city: string;
    country: string;
    name: string;
    routingNumber: string;
    state: string;
    zip: string;
}
