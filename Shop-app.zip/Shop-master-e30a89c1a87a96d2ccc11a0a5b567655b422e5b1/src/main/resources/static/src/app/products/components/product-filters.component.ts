import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { UserTitleType } from '../../shared/enums/user-title-type.enum';
import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewEncapsulation
} from '@angular/core';
import { Http } from '@angular/http';
import { Subscription } from 'rxjs/Subscription';
import { CacheService } from '../../shared/services/cache.service';
import { ProductService } from '../services/product.service';
import { CommonService } from '../../shared/services/common.service';
import { Categories } from '../interfaces/categories.interface';
import { ProductMessageService } from '../services/product-message.service';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import * as _ from 'lodash';
import { ProductAttribute } from '../interfaces/product-attributes.interface';
import { ProductFilter } from '../interfaces/product-filters.interface';
import { AppConstants } from '../../common/constants/app.constants';
import { MemberLevel } from '../../shared/enums';
@Component({
  selector: 'app-product-filters',
  templateUrl: '../templates/template3/views/product-filters.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/product-filters.component.less',
  ],
  encapsulation: ViewEncapsulation.None
})
export class ProductFiltersComponent implements OnInit, OnDestroy {
  store: StoreConfig;
  languageCode: string;
  memberTitle =  MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  purchaseFlow: PurchaseFlow;
  sortTypes: any = [
    {
      key: 'FEATURED',
      value: 'Featured Products'
    },
    {
      key: 'PRICELOWHIGH',
      value: 'Price: Low to High'
    },
    {
      key: 'PRICEHIGHLOW',
      value: 'Price: High to Low'
    },
    {
      key: 'AVERAGERATINGS',
      value: 'Average Ratings'
    }
  ];
  storeId: number;
  category: Categories;
  hamburgerToggleItem = {};
  sortTypeValue: string = this.sortTypes[0].key;
  ingredientFilters: ProductAttribute;
  certificateFilters: ProductAttribute;
  ingredientsList = [];
  certificatesList = [];
  @Input() categoryState;
  isFilterHidden = true;

  constructor(
    private _productService: ProductService,
    private _productMessageService: ProductMessageService,
    private _configurationService: ConfigurationService,
    private _cacheService: CacheService
  ) {}

  ngOnInit() {
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.getStoreData();
    this.getIngredientAndCertificateFilters();
  }

  /**
   * @description
   * Get Ingredients and Certificates for the Products
   * @date 2018-09-03
   * @memberof CategoriesComponent
   */
  getIngredientAndCertificateFilters(): void {
    this._productService.getIngredientAndCertificateFilters(this.languageCode,
      this.store.id, this.sortTypeValue)
      .subscribe(response => {
        if (response) {
          this.certificateFilters = response.filter(x => x.attributeType === AppConstants.CERTIFICATE);
          this.ingredientFilters = response.filter(x => x.attributeType === AppConstants.INGREDIENT);
          this.rebindFilters();
        }
      });
  }

  /**
   * @description
   * @date 2018-09-04
   * @memberof CategoriesComponent
   */
  rebindFilters(): void {
    const selectedProductFilters = this._cacheService.get(CacheKey.SelectedProductFilters);
    if (selectedProductFilters) {
      this.ingredientsList = selectedProductFilters.ingredientsList;
      this.certificatesList = selectedProductFilters.certificatesList;
      this.hamburgerToggleItem[selectedProductFilters.hamburgerToggle] = true;
    }
  }

  /**
   * @description
   * @date 2018-09-03
   * @param {number} id
   * @memberof CategoriesComponent
   */
  createIngredientList(id: number): void {
    const index = this.ingredientsList.indexOf(id);
    if (index > -1) {
      this.ingredientsList.splice(index, 1);
    } else {
      this.ingredientsList.push(id);
    }
    this.storeProductFilterState();
  }

  /**
   * @description
   * @date 2018-09-03
   * @param {number} id
   * @memberof CategoriesComponent
   */
  createCertificateList(id: number): void {
    const index = this.certificatesList.indexOf(id);
    if (index > -1) {
      this.certificatesList.splice(index, 1);
    } else {
      this.certificatesList.push(id);
    }
    this.storeProductFilterState();
  }

  /**
   * @description
   * @date 2018-09-03
   * @memberof CategoriesComponent
   */
  storeProductFilterState(item?: string): void {
    const selectedProductFilters: ProductFilter = {
      'ingredientsList' : this.ingredientsList,
      'certificatesList' : this.certificatesList,
      'hamburgerToggle' : item
    };
    this._cacheService.set(CacheKey.SelectedProductFilters, selectedProductFilters);
    this._productMessageService.setProductsByCategory(this.categoryState);
  }

  /**
   * @description
   * Toggle Key Ingredients and Certifcations
   * @date 2018-09-03
   * @param {string} item
   * @memberof CategoriesComponent
   */
  toggleHamburgerItem(item: string): void {
    const toggleStatus = this.hamburgerToggleItem[item];
    this.hamburgerToggleItem = {};
    this.hamburgerToggleItem[item] = !toggleStatus;
    // if (!toggleStatus) {
    //   this.storeProductFilterState(item);
    // } else {
    //   this.storeProductFilterState('');
    // }
  }

  toggleFilters () {
    this.isFilterHidden = !this.isFilterHidden;
  }

  /**
   * @description
   * @date 2018-09-04
   * @memberof ProductFiltersComponent
   */
  getStoreData() {
    const result = this._configurationService.getStoreData();
    if (result != null) {
      this.store = result;
      this.storeId = this.store.id;
    }
  }

  /**
   * prevent memory leak when component destroyed
   */
  ngOnDestroy() {
  }
}
