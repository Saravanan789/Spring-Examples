import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Categories } from '../interfaces/categories.interface';

@Injectable()
export class CanActivateProductDetailGuard implements CanActivate {
    isoCountryCode = '';
    constructor(private router: Router,
        private _cacheService: CacheService) {
            this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        }

    /**
     * Checkout page Guard
     * @returns boolean
     */
    canActivate(route: ActivatedRouteSnapshot): boolean {
        const selectedCategoryState: Categories = this._cacheService.get(CacheKey.SelectedCategoryState);
        const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        if (selectedCategoryState && selectedCategoryState.slug) {
            if (window.location.pathname.split('/').length > 2 && window.location.pathname.split('/')[3] && route.params.productslug &&
                selectedCategoryState.slug.toLowerCase() !== route.params.productslug.toLowerCase()) {
                return true;
            } else {
                this.router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/' + languageCode.toLowerCase() + '/products');
            }
        } else {
            return true;
        }
        // default
        return true;
    }
}
