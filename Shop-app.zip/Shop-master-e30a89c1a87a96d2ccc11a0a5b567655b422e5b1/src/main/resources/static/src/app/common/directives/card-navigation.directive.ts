import { Directive, HostListener, EventEmitter, Output } from '@angular/core';

@Directive({
    selector: '[appDynamicNavigation]'
})
export class CardNavigationDirective {
    @Output() isNavClicked: EventEmitter<HTMLElement> = new EventEmitter<HTMLElement>();
    constructor() {
    }
    @HostListener('click', ['$event', '$event.target']) onListenerTriggered($event: any, element: HTMLElement): void {
        $event.preventDefault();
        if (element.attributes && element.nodeName === 'IMG') {
            $event.stopImmediatePropagation();
            element.parentElement.click();
        }
        if (element.attributes && element.nodeName === 'A') {
            // Prevent href from navigating and disabling page reload for Hotspot images
            $event.preventDefault();
            if ($event.target.attributes.href && $event.target.attributes.href.value) {
                this.isNavClicked.emit($event.target.attributes.href.value);
            }
        }
    }
}
