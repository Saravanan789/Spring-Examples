import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import { DateConstants } from '../constants/date.constants';

export class ValidateDateOfBirth {
    static momentConstructor: (value?: any) => moment.Moment = (<any>moment).default || moment;
    public static DOBFormat(control: AbstractControl): { [key: string]: boolean } {
        if (control.value === undefined || control.value === null || control.value instanceof Array) {
            return { 'dateValidation': true };
        }
        let value = control.value;
        if (value.length === 0) {
            return undefined;
        }
        // tslint:disable-next-line:max-line-length
        const datepattern = /^(?:(?:31(|-|)(?:0?[13578]|1[02]|(?:Jan|Mar|May|Jul|Aug|Oct|Dec|jan|mar|may|jul|aug|oct|dec|JAN|MAR|MAY|JUL|AUG|OCT|DEC)))\1|(?:(?:29|30)(|-|)(?:0?[1,3-9]|1[0-2]|(?:Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(|-|)(?:0?2|(?:Feb|feb|FEB))\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(|-|)(?:(?:0?[1-9]|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|jan|feb|mar|apr|may|jun|jul|aug|sep|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP))|(?:1[0-2]|(?:Oct|Nov|Dec|oct|nov|dec|OCT|NOV|DEC)))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;
        if (value && value._i && (typeof value._i === DateConstants.Object)) {
            value = ValidateDateOfBirth.momentConstructor(value._d).format(DateConstants.DateFormat);
        } else if (value && value._i && (typeof value._i === DateConstants.String) && value._i.length > 11) {
            value = ValidateDateOfBirth.momentConstructor(value._i).format(DateConstants.DateFormat);
        } else if (value && value._i && (typeof value._i === DateConstants.String)) {
            value = value._i;
        }
        if (!(new RegExp(datepattern).test(value))) {
            return { 'dateValidation': true };
        } else {
            /* This method used for configuring date option for Date of birth
            * disable Date should be less than 18 years
            */
            if (value && value.length >= 9) {
                const characterCheck = /[a-zA-z]/;
                let dateOfBirth = '';
                if (characterCheck.test(value[3])) {
                    dateOfBirth = moment(value, DateConstants.DateFormat)
                        .format(DateConstants.DOBConvertFormat);
                } else {
                    dateOfBirth = value;
                }

                const dateParts = dateOfBirth.split('-');
                if (dateParts[2] && dateParts[2].length === 4) {
                    const eighteenYearsBeforeNow = new Date(+dateParts[2] + 18, +dateParts[1] - 1, +dateParts[0]) <= new Date();
                    if (!eighteenYearsBeforeNow) {
                        return { 'eighteenYearsValidation': true };
                    }
                } else {
                    return { 'dateValidation': true };
                }
            }
        }
        return undefined;
    }
}