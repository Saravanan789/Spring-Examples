import { PayvisionSavedCard } from './payvision-saved-card.interface';

export interface PayvisionSavedCardResponse {
    savedCards: PayvisionSavedCard[];
}
