import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { CacheService } from '../../shared/services/cache.service';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { CommonService } from '../../shared/services/common.service';
import { ProductService } from '../services/product.service';
import { ProductMessageService } from '../services/product-message.service';
import { SSO } from '../../sso/sso.constants';
import { CookieService } from 'ngx-cookie-service';
import { AppMessageService } from '../../app-message.service';
import { CardType } from '../../shared/enums/card-types.enum';

@Component({
  selector: 'app-product',
  templateUrl:
    '../templates/template3/views/product.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/product.component.less'
  ]
})
export class ProductComponent implements OnInit, OnDestroy  {
  searchText: any;
  showSpinner = false;
  isNavCollapsed = true;
  isProductSearch = false;
  productSearchSubscription: Subscription;
  categorySubscription: Subscription;
  sideNavSubscription: Subscription;
  categoryBanners: Array<any>;
  productsByCategorySubscription: any;
  isoCountryCode: string;
  languageCode: string;
  userInfo: any;
  isUserLoggedIn: any;
  subscription: Subscription;
  searchedResultSize: number;
  bannerContent: any = false;
  categoryDescription = '';
  categoryName = '';
  cookieService: CookieService = new CookieService(document);
  public sliderConfig: SwiperConfigInterface = {
    slidesPerView: 1,
    touchRatio: 0.2,
  };
  constructor(
    private _productService: ProductService,
    private _cacheService: CacheService,
    private _productMessageService: ProductMessageService,
    private _appMessageService: AppMessageService,
    private _commonService: CommonService
  ) {
    this.sideNavSubscription = _productService.sideNavClose$.subscribe(
      status => {
        this.isNavCollapsed = status;
      });
    this.productsByCategorySubscription = this._productMessageService.getCardsSubject().subscribe((res: any) => {
      if (res) {
        // this.categoryBanners = res.imageUrls;
        this.bannerContent = false;
        if (res.cards) {
          const bannerContent = res.cards.filter((item) => {
            if (item.type.toLowerCase() === CardType.Banner.toLowerCase()) {
              return item;
            }
          });
          if (bannerContent && bannerContent.length > 0 &&  bannerContent[0].cardContent) {
            this.bannerContent = bannerContent[0].cardContent;
          }
        } else {
          this.bannerContent = '';
        }
          this.categoryName = res.name || '';
          this.categoryDescription = res.description || '';
      }
    });
  }

  checkProductSearch() {
    const searchCriteria = this.getSearchValue();
    if (searchCriteria) {
      this.isProductSearch = true;
      this.searchText = searchCriteria;
    }
    this.subscription = this._productMessageService.getLoadDefaultProducts().subscribe((productSearch: any) => {
      this.searchText = productSearch;
    });
  }

  ngOnInit() {
    this.isMobileDevice();
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.checkForLoggedInUser();
    this.checkProductSearch();
    // Collapse menu subscription
    this.productSearchSubscription = this._appMessageService.getShowProductBanner().subscribe((isOpen: boolean) => {
      this.isProductSearch = isOpen;
      this.showSpinner=true;
      if (this.isProductSearch) {
        this.bannerContent = '';
        this.categoryName = '';
        this.categoryDescription = '';
      }
    });
  }

  checkForLoggedInUser() {
    // this.userInfo = this._cacheService.get('userInfo');
    const session = SSO.isRemoveObsoleteCookie() ? this.cookieService.get(SSO.MEMBER_SESSIONID) : this.cookieService.get(SSO.ACCESS_TOKEN);
    if (session) {
      this.isUserLoggedIn = true;
    } else {
      this.isUserLoggedIn = false;
    }
  }
  /**
    * this is to open categories menu
    * @returns void
    */
  sideNavOpen(): void {
    this.isNavCollapsed = true;
    this._productService.sideNavOpen(true);
  }
  /**
   * this is for initially hide the categories menu
   * @returns void
   */
  sideNavClose() {
    this.isNavCollapsed = false;
    this._productService.sideNavClose(false);
  }

  /**
   * @description
   * @date 2018-10-03
   * @param {string} route
   * @memberof ProductComponent
   */
  navigateToPortal (route: string): void {
    if (route) {
      window.location.href = route;
    }
  }

  /**
   *  prevent memory leak when component destroyed
   */
  ngOnDestroy() {
    this.sideNavSubscription.unsubscribe();
    this.productsByCategorySubscription.unsubscribe();
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    if (this.productSearchSubscription) {
      this.productSearchSubscription.unsubscribe();
    }
    if (this.categorySubscription) {
      this.categorySubscription.unsubscribe();
    }
  }

  /**
   * focus element by Id
   * @param {string} elementId
   * @returns void
   */
  focusElementById(elementId: string) {
    this._commonService.focusTargetElement(elementId);
  }

  // Mobile device
  isMobileDevice(): void {
    const check = this._productService.isMobileDevice();
    if (check) {
      this.isNavCollapsed = false;
    }
  }
  showProductQuantity(data) {
    this.searchedResultSize = data;
    this.isProductSearch = true;
    this.showSpinner=false;
  }
  getSearchValue(): any {
    this.showSpinner=true;
    const searchValue = this._commonService.getParamValueFromUrl('search');
    let headerSearch: any = null;
    if (searchValue) {
       headerSearch = { searchValue: searchValue};
    }
    let cookieValue = this._cacheService.getCookieValue(CacheKey.HeaderSearch);
    if (cookieValue && cookieValue.length > 0) {
      cookieValue = JSON.parse(cookieValue);
    }
    return headerSearch || cookieValue;
  }
}

