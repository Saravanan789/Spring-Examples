import { OnInit, Component, Input, Output, EventEmitter } from '@angular/core';
import { SponsorService, CheckoutMessageService } from '../services';
import { CacheService, CommonService, ActiveSessionService } from '../../shared/services';
import { SponsorSelectionComponentSettings, PersonalInfoComponentSettings } from '../component-settings';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SponsorSearchOption, SponsorWizardSearchType, CommunicationPreferenceValues, ContactPreferenceType } from '../enums';
import { State, Country } from '../../shared/interfaces';
import {
  SponsorSearchRequest, SponsorSearchResponse,
  SponsorInformation, MemberCommunicationPreference
} from '../interfaces';
import { RebindSponsorData } from '../interfaces/sponsor-rebind-data.interface';
import { timeout } from 'rxjs/operators';
import { ResponseStatus } from '../constants';
import { environment } from '../../../environments/environment';
/**
 * @description Sponsor Selection
 * @author NextSphere Technologies
 * @date 2018-08-14
 * @export
 * @class SponsorSelectionComponentNew
 * @implements {OnInit}
 */
@Component({
  selector: 'app-sponsor-selection-new',
  templateUrl:
    '../templates/template3/views/sponsor-selection_new.component.html',
  styleUrls: ['../templates/template3/themes/default/less/sponsor-selection_new.component.less'
  ]
})

// tslint:disable-next-line:component-class-suffix
export class SponsorSelectionComponentNew implements OnInit {

  // tslint:disable-next-line:no-input-rename
  @Input('selectedSponsor') selectedSponsor: SponsorInformation;
  // tslint:disable-next-line:no-output-rename
  @Output('selectedSponsorInfo') selectedSponsorInfo = new EventEmitter<any>();

  ssComponentSettings: SponsorSelectionComponentSettings = new SponsorSelectionComponentSettings();

  constructor(
    private _cacheService: CacheService,
    private _sponsorService: SponsorService,
    private _commonService: CommonService,
    private _checkoutMessageService: CheckoutMessageService,
    private _formBuilder: FormBuilder,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.loadDefaultSettings();
  }

  /**
   * @description this method will load default data
   * @date 2018-08-18
   * @memberof SponsorSelectionComponentNew
   */
  loadDefaultSettings(): void {
    this.ssComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.ssComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.ssComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
    this.ssComponentSettings.fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
    this.getCountriesLookup();
    this.getSponsorSearchOptions();
    this.getContactSponsorOptions();
    this.ssComponentSettings.memberTitleId = this._activeSessionService.getMemberTitleId();
  }

  /**
   * @description this method will rebind sponsor information
   * @date 2018-08-18
   * @param {RebindSponsorData} rebindSponsorData
   * @memberof SponsorSelectionComponentNew
   */
  rebindSponsorData(rebindSponsorData: RebindSponsorData) {
    if (rebindSponsorData.sponsorWizardType) {
      const checkoutInfo = this._cacheService.get(CacheKey.CheckoutInformation) || {};
      if (rebindSponsorData.sponsorWizardType === SponsorWizardSearchType.SearchByIKnowSponsor) {
        this.resetVariable(SponsorWizardSearchType.SearchByIKnowSponsor);
        this.setSponsorWizard(rebindSponsorData.sponsorWizardType);
        this.ssComponentSettings.firstName = rebindSponsorData.firstName ? rebindSponsorData.firstName : '';
        this.ssComponentSettings.lastName = rebindSponsorData.lastName ? rebindSponsorData.lastName : '';
        this.ssComponentSettings.selectedSponsorCountry = rebindSponsorData.country ? rebindSponsorData.country : 0;
        this.getStatesLookup(this.ssComponentSettings.selectedSponsorCountry, false);
        this.ssComponentSettings.selectedSponsorState = rebindSponsorData.state ? rebindSponsorData.state : 0;
        this.ssComponentSettings.referringFboId = rebindSponsorData.sponsorId ? rebindSponsorData.sponsorId : '';
        if (this.ssComponentSettings.referringFboId) {
          this.searchSponsorWizardByFboId();
          this.disableFboIdOrName();
        } else {
          this.searchSponsorByName(this.ssComponentSettings.firstName, this.ssComponentSettings.lastName,
            this.ssComponentSettings.selectedSponsorCountry, this.ssComponentSettings.selectedSponsorState);
          this.disableFboIdOrName();
        }
      } else if (rebindSponsorData.sponsorWizardType === SponsorWizardSearchType.SearchByIDontHaveSponsor) {
        this.resetVariable(SponsorWizardSearchType.SearchByIKnowSponsor);
        this.setSponsorWizard(rebindSponsorData.sponsorWizardType);
        this.ssComponentSettings.city = rebindSponsorData.city ? rebindSponsorData.city : '';
        this.ssComponentSettings.setSuggestZipCode = rebindSponsorData.zipCode ? rebindSponsorData.zipCode : '';
        this.ssComponentSettings.setSuggestLanguage = rebindSponsorData.language ? rebindSponsorData.language : '';
        this.buildSuggestSponsorForm();
        if (checkoutInfo && checkoutInfo.sponsorInformation) {
          this.preloadSponsorInformation(rebindSponsorData, checkoutInfo.sponsorInformation);
        } else {
          this.suggestSponsor(this.ssComponentSettings.suggestSponsorForm, true);
        }
      }
      if (checkoutInfo && checkoutInfo.sponsorInformation) {
        this.ssComponentSettings.notifyMeCheckBoxControl.setValue(checkoutInfo.sponsorInformation.notifyMeAboutUpdates);
      }
    }
  }

  preloadSponsorInformation(rebindSponsorData: RebindSponsorData, sponsorInfo: SponsorInformation): void {
    this.selectedSponsor = sponsorInfo;
    const sponsors: SponsorInformation[] = [];
    sponsors.push(this.selectedSponsor);
    if (rebindSponsorData.sponsorWizardType === SponsorWizardSearchType.SearchByIDontHaveSponsor) {
      this.ssComponentSettings.searchBySuggestSponsors = sponsors;
      this.ssComponentSettings.suggestSponsorFound = true;
    }
    this.setSponsor(this.selectedSponsor);
    this.setSponsorInformation();
  }

  /**
   * @description this method will load referral fbo
   * details
   * @date 2018-08-17
   * @memberof SponsorSelectionComponentNew
   */
  loadReferralFBOID(): void {
    const referralFboId = this._cacheService.getSessionValue(CacheKey.RepSiteReferralId)
      || this._cacheService.get(CacheKey.ShareFBOID);
    if (referralFboId) {
      this.ssComponentSettings.sponsorWizard = this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor;
      this.ssComponentSettings.contactSponsor = true;
      this.getContactSponsorOptions();
      this.ssComponentSettings.isRepSiteSponsor = true;
      this.searchSponsorWizardByFboId(referralFboId);
    } else {
      this.ssComponentSettings.isRepSiteSponsor = false;
    }
  }

  /**
  * searchSponsorWizardByFboId used to prepare request for Search By FBO ID or Email
  * @param  {string} FboId?
  * @returns void
  */
  searchSponsorWizardByFboId(fboId?: string): void {
    fboId = fboId ? fboId : this.ssComponentSettings.referringFboId;
    if (!fboId) {
      this.ssComponentSettings.refFboIdErrorMessage = 'Enter Sponsor ID / Email';
      return;
    }
    fboId = fboId.indexOf('@') > -1 ? fboId : fboId.split('-').join('');
    const sponsorSearchRequest: SponsorSearchRequest = {
      UserName: fboId.indexOf('@') > -1 ? '' : fboId.trim(),
      Email: fboId.indexOf('@') > -1 ? fboId.trim() : '',
      FirstName: '',
      LastName: '',
      CountryId: '',
      PreferenceValue: '',
      PostalCode: '',
      StateId: '',
      City: '',
      Option: SponsorSearchOption.SearchByIKnowSponsor,
      EnableLongPoll: environment.enableLongPoll
    };
    this.getSponsorInformation(sponsorSearchRequest, SponsorSearchOption.SearchByIKnowSponsor);
  }

  /**
  * getSponsorInformation used to fetch sponsors from service
  * @param  {any} sponsorSearchRequest
  * @param  {number} option?
  * @returns void
  */
  getSponsorInformation(sponsorSearchRequest: SponsorSearchRequest, searchOption?: number): void {
    this.ssComponentSettings.isSponsorLoading = true;
    this.resetValidationMessage();
    this.ssComponentSettings.sponsorPollCount = 0;
    this._sponsorService
      .searchSponsors(sponsorSearchRequest)
      .subscribe((sponsorSearchResponse: SponsorSearchResponse) => {
        if (sponsorSearchResponse.requestStatus === ResponseStatus.COMPLETED) {
          this.processSearchSponsorResponse(sponsorSearchResponse, searchOption);
        } else if (sponsorSearchResponse.requestStatus === ResponseStatus.QUEUED ||
          sponsorSearchResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
          this.searchSponsorByPolling(sponsorSearchResponse, searchOption);
        } else {
          this.searchSponsorErrorResponse();
        }
      }, (error) => {
        this.searchSponsorErrorResponse();
      });
  }

  /**
   * @description we will load sponsor by pooling mechanism
   * @date 2019-03-18
   * @private
   * @param {SponsorSearchRequest} sponsorSearchRequest
   * @param {number} [searchOption]
   * @memberof SponsorSelectionComponentNew
   */
  private searchSponsorByPolling(
    searchResponse: SponsorSearchResponse, searchOption?: number): void {
    this._sponsorService
      .getSearchSponsorsByUUID(searchResponse)
      .subscribe((sponsorSearchResponse: SponsorSearchResponse) => {
        if (sponsorSearchResponse) {
          if (this.ssComponentSettings.sponsorPollCount < this.ssComponentSettings.sponsorMaxPollCount) {
            this.ssComponentSettings.sponsorPollCount = this.ssComponentSettings.sponsorPollCount + 1;
            if (sponsorSearchResponse.requestStatus === ResponseStatus.COMPLETED) {
              this.processSearchSponsorResponse(sponsorSearchResponse, searchOption);
            } else if (sponsorSearchResponse.requestStatus === ResponseStatus.QUEUED ||
              sponsorSearchResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
              this.searchSponsorByPolling(sponsorSearchResponse, searchOption);
            } else {
              this.searchSponsorErrorResponse();
            }
          } else {
            this.searchSponsorErrorResponse();
          }
        }
      }, (error) => {
        this.searchSponsorErrorResponse();
      });
  }

  /**
   * @description this method will process the search sponsor response
   * @date 2018-08-17
   * @private
   * @param {SponsorSearchResponse} sponsorSearchResponse
   * @param {number} [searchOption]
   * @returns {void}
   * @memberof SponsorSelectionComponentNew
   */
  private processSearchSponsorResponse(sponsorSearchResponse: SponsorSearchResponse,
    searchOption?: number): void {
    this.ssComponentSettings.isSponsorLoading = false;
    // this._sectionSpinnerService.stop('sponsorSelection');
    if (sponsorSearchResponse.sponsorSearchResultModels
      && sponsorSearchResponse.sponsorSearchResultModels.length > 0) {
      this.ssComponentSettings.isSelectedSponsorEligible = true;
      if (!this.ssComponentSettings.isRepSiteSponsor) {
        const sponsorResponse = sponsorSearchResponse.sponsorSearchResultModels;
        sponsorSearchResponse.sponsorSearchResultModels = sponsorSearchResponse.sponsorSearchResultModels.filter(x => {
          return x.wholesaleQualified === true;
        });
        if (sponsorResponse.length === 1 && sponsorResponse.length > sponsorSearchResponse.sponsorSearchResultModels.length) {
          this.ssComponentSettings.isSponsorEligible = false;
          this.ssComponentSettings.noSponsorFound = false;
          this.ssComponentSettings.referrerSponsorNotFound = false;
          if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor) {
            this.ssComponentSettings.searchBySuggestSponsors = null;
          } else {
            this.ssComponentSettings.searchByIDOrNameSponsors = null;
          }
        } else {
          this.preSelectSponsorBasedOnOption(sponsorSearchResponse, searchOption, true);
        }
      } else if (!sponsorSearchResponse.sponsorSearchResultModels[0].wholesaleQualified) {
        this.ssComponentSettings.isReferrerEligible = false;
        this.ssComponentSettings.referrerSponsorNotFound = false;
      } else {
        this.ssComponentSettings.isReferrerEligible = true;
        this.ssComponentSettings.referrerSponsorNotFound = false;
        this.prepareMemberMetadataModels(SponsorSearchOption.SearchByIKnowSponsor);
        this.setSponsor(sponsorSearchResponse.sponsorSearchResultModels[0]);
      }
    }
  }

  /**
   * @description this method will load when we got error in
   * sponsor search response
   * @date 2018-08-17
   * @private
   * @memberof SponsorSelectionComponentNew
   */
  private searchSponsorErrorResponse(): void {
    this.ssComponentSettings.isSponsorLoading = false;
    // this._sectionSpinnerService.stop('sponsorSelection');
    if (this.ssComponentSettings.isRepSiteSponsor) {
      this.ssComponentSettings.referrerSponsorNotFound = true;
    } else if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor) {
      this.ssComponentSettings.sponsorNotFound = true;
      this.ssComponentSettings.searchByIDOrNameSponsors = null;
      if (!this.ssComponentSettings.referringFboId) {
        this.ssComponentSettings.noSponsorFound = true;
      }
    } else if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor) {
      this.ssComponentSettings.noSuggestSponsorFound = true;
      this.ssComponentSettings.searchBySuggestSponsors = null;
    }
  }

  /**
   * assignSponsor method used to set sponsors based on selected option
   * @param  {any} response
   * @param  {number} option?
   * @returns void
   */
  preSelectSponsorBasedOnOption(sponsorSearchResponse: SponsorSearchResponse, option?: number, isSearch?: boolean): void {
    if (sponsorSearchResponse && sponsorSearchResponse.sponsorSearchResultModels && sponsorSearchResponse.isSuccess) {
      switch (this.ssComponentSettings.sponsorWizard) {
        case this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor:
          this.searchByIKnowSponsor(sponsorSearchResponse);
          break;
        case this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor:
          this.searchByIDontHaveSponsor(sponsorSearchResponse);
          break;
        default:
          break;
      }
      if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor) {
        this.ssComponentSettings.suggestSponsorFound = true;
      }
      if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByFBOName) {
        if (this.ssComponentSettings.searchByIDOrNameSponsors && this.ssComponentSettings.searchByIDOrNameSponsors.length > 0) {
          this.ssComponentSettings.noSponsorFound = false;
        } else {
          this.ssComponentSettings.noSponsorFound = true;
        }
      }
    } else if (this.ssComponentSettings.sponsorWizard ===
      this.ssComponentSettings.sponsorSearchWizardType.SearchByFBOName
      && sponsorSearchResponse && !sponsorSearchResponse.isSuccess) {
      this.ssComponentSettings.noSponsorFound = true;
      this.ssComponentSettings.sponsorErrorMessage = sponsorSearchResponse.responseMessage;
    } else if (this.ssComponentSettings.sponsorWizard ===
      this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor
      && sponsorSearchResponse && !sponsorSearchResponse.isSuccess) {
      this.ssComponentSettings.sponsorNotFound = true;
      this.ssComponentSettings.sponsorErrorMessage = sponsorSearchResponse.responseMessage;
    } else if (this.ssComponentSettings.sponsorWizard === this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor) {
      this.ssComponentSettings.noSuggestSponsorFound = true;
      this.ssComponentSettings.searchBySuggestSponsors = null;
    }
    if (!sponsorSearchResponse.sponsorSearchResultModels) {
      this.ssComponentSettings.noSponsorFound = true;
    }
  }

  /**
   * @description this method will excecute when the switch case
   * value is searchByIKnowSponsor
   * @date 2018-08-17
   * @private
   * @param {SponsorSearchResponse} sponsorSearchResponse
   * @returns {void}
   * @memberof SponsorSelectionComponentNew
   */
  private searchByIKnowSponsor(sponsorSearchResponse: SponsorSearchResponse): void {
    this.prepareMemberMetadataModels(SponsorSearchOption.SearchByIKnowSponsor);
    if (sponsorSearchResponse.sponsorSearchResultModels.length < 1) {
      this.ssComponentSettings.isSponsorEligible = false;
      this.ssComponentSettings.noSponsorFound = true;
      return;
    } else {
      this.ssComponentSettings.isSponsorEligible = true;
      this.ssComponentSettings.noSponsorFound = false;
      this.ssComponentSettings.searchByIDOrNameSponsors = sponsorSearchResponse.sponsorSearchResultModels;
      if (sponsorSearchResponse.sponsorSearchResultModels.length === 1) {
        const sponsorMapModel = this.ssComponentSettings.searchByIDOrNameSponsors[0];
        sponsorMapModel.address = this._sponsorService.mapAddressModel(sponsorMapModel);
        this.selectedSponsor = sponsorMapModel;
        this.ssComponentSettings.searchByIDOrNameSponsors[0]['isAutoSelect'] = true;
        this.setSelectedSponsorInformation();
        this.setSponsorInformation();
      } else {
        const checkoutInfo = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        const sponsor = sponsorSearchResponse.sponsorSearchResultModels.
          find(x => x.sponsorId === checkoutInfo.sponsorInformation.sponsorId);
        if (sponsor) {
          this.selectedSponsor = sponsor;
          this.setSponsor(this.selectedSponsor);
          this.setSponsorInformation();
        }
      }
    }
  }

  /**
   * @description this method will excecute when the switch case
   * value is searchByIDontHaveSponsor
   * @date 2018-08-17
   * @private
   * @memberof SponsorSelectionComponentNew
   */
  private searchByIDontHaveSponsor(sponsorSearchResponse: SponsorSearchResponse): void {
    this.prepareMemberMetadataModels(SponsorSearchOption.SearchByIDontHaveSponsor);
    this.ssComponentSettings.noSuggestSponsorFound = false;
    this.ssComponentSettings.suggestSponsorFound = true;
    this.ssComponentSettings.searchBySuggestSponsors = sponsorSearchResponse.sponsorSearchResultModels;
    if (this.ssComponentSettings.searchBySuggestSponsors.length >= 1) {
      const sponsorMapModel = this.ssComponentSettings.searchBySuggestSponsors[0];
      sponsorMapModel.address = this._sponsorService.mapAddressModel(sponsorMapModel);
      this.selectedSponsor = sponsorMapModel;
      this.ssComponentSettings.searchBySuggestSponsors[0]['isAutoSelect'] = true;
      this.setSelectedSponsorInformation();
      this.setSponsorInformation();
    } else {
      this.setSelectedSponsorInformation();
    }
  }

  /**
   * @description this method will prepare member
   * metamodels
   * @date 2018-08-17
   * @param {number} option
   * @memberof SponsorSelectionComponentNew
   */
  prepareMemberMetadataModels(option: number): void {
    if (!this.ssComponentSettings.isAutoAssign && this.ssComponentSettings.
      sponsorSearchOptions) {
      const filteredSponsorOption = this.ssComponentSettings.
        sponsorSearchOptions.filter(x => x.id === option)[0];
      const nameValues = {
        id: filteredSponsorOption.id,
        option: filteredSponsorOption.option,
        sponsorSearchValues: filteredSponsorOption.sponsorSearchValues,
      };
      this.ssComponentSettings.sponsorAssignedOptionId = filteredSponsorOption.id;
      this.ssComponentSettings.memberMetadataModels = [{
        code: 'SponsorSearch',
        name: JSON.stringify(nameValues),
        memberId: null,
        keyValueDesc: ''
      }];
    }
  }

  /**
   * @description this method will enable diable the textbox
   * based on selction
   * @date 2018-08-18
   * @memberof SponsorSelectionComponentNew
   */
  disableFboIdOrName(isFboNameSearch?: boolean): void {
    this.ssComponentSettings.sponsorNotFound = false;
    this.ssComponentSettings.isSponsorEligible = true;
    this.ssComponentSettings.searchByIDOrNameSponsors = null;
    this.selectedSponsor = null;
    this.selectedSponsorInfo.emit(this.selectedSponsor);
    if (this.ssComponentSettings.referringFboId && !isFboNameSearch) {
      this.ssComponentSettings.firstName = '';
      this.ssComponentSettings.lastName = '';
      this.ssComponentSettings.isFboNameEnabled = true;
      this.ssComponentSettings.isFboIdEnabled = false;
    } else if (this.ssComponentSettings.firstName || this.ssComponentSettings.lastName) {
      this.ssComponentSettings.referringFboId = '';
      this.ssComponentSettings.isFboNameEnabled = false;
      this.ssComponentSettings.isFboIdEnabled = true;
      if (this.ssComponentSettings.firstName) {
        this.ssComponentSettings.firstName = this.ssComponentSettings.firstName.trim();
        this.ssComponentSettings.isFirstNameError = false;
      }
      if (this.ssComponentSettings.lastName) {
        this.ssComponentSettings.lastName = this.ssComponentSettings.lastName.trim();
        this.ssComponentSettings.isLastNameError = false;
      }
    } else {
      this.ssComponentSettings.isFboNameEnabled = false;
      this.ssComponentSettings.isFboIdEnabled = false;
    }
  }

  /**
   * searchSponsorByName method used to prepare request for Search by Name
   * @param  {string} firstName
   * @param  {string} lastName
   * @param  {string} countryName
   * @returns void
   */
  searchSponsorByName(firstName: string, lastName: string, countryId: number, stateId: number): void {
    if (!this.ssComponentSettings.isSponsorLoading) {
      if (this.ssComponentSettings.referringFboId) {
        this.searchSponsorWizardByFboId();
      } else {
        if (!firstName || !lastName) {
          this.ssComponentSettings.searchBySponsorError = true;
          this.validateSearchByName(firstName, lastName);
          this.ssComponentSettings.searchByIDOrNameSponsors = null;
          this.ssComponentSettings.sponsorNotFound = false;
          this.ssComponentSettings.noSponsorFound = false;
        } else {
          this.ssComponentSettings.searchBySponsorError = false;
          this.ssComponentSettings.sponsorNotFound = false;
          this.ssComponentSettings.selectedSponsorId = 0;
          const country: Country = this.ssComponentSettings.countries.find((x: Country) =>
            (x.countryId) === +this.ssComponentSettings.selectedSponsorCountry);
          this.ssComponentSettings.sponsorErrorMessage = '';
          if (firstName.trim() === '' && lastName.trim() === '') {
            this.ssComponentSettings.noSponsorFound = true;
            return;
          }
          const sponsorSearchRequest: SponsorSearchRequest = {
            UserName: '',
            Email: '',
            FirstName: firstName ? firstName.trim() : '',
            LastName: lastName ? lastName.trim() : '',
            CountryId: country ? country.countryId.toString() : '',
            PreferenceValue: '',
            PostalCode: '',
            StateId: stateId && stateId > 0 ? stateId.toString() : '',
            City: '',
            Option: SponsorSearchOption.SearchByFBOName,
            EnableLongPoll: environment.enableLongPoll

          };
          this.getSponsorInformation(sponsorSearchRequest, SponsorSearchOption.SearchByIKnowSponsor);
        }
      }
    }
  }

  /**
    * @description
    * @date 2019-01-29
    * @param {string} firstName
    * @param {string} lastName
    * @memberof SponsorSelectionComponentNew
    */
  validateSearchByName(firstName: string, lastName: string) {
    if (!firstName && lastName) {
      this.ssComponentSettings.isFirstNameError = true;
      this.ssComponentSettings.searchBySponsorError = false;
      this.ssComponentSettings.isLastNameError = false;
    } else if (firstName && !lastName) {
      this.ssComponentSettings.isFirstNameError = false;
      this.ssComponentSettings.searchBySponsorError = false;
      this.ssComponentSettings.isLastNameError = true;
    }
  }

  /**
   *  Resetting validation message while searching sponsor info
   *  resetValidationMessage
   * @memberof SponsorSelectionComponentNew
   */
  resetValidationMessage() {
    this.ssComponentSettings.sponsorNotFound = false;
    this.ssComponentSettings.searchBySponsorError = false;
    this.ssComponentSettings.noSponsorFound = false;
    this.ssComponentSettings.isSponsorSelected = true;
    this.ssComponentSettings.cityOrZipcodeerrMsg = false;
    this.selectedSponsor = null;
    this.deSelectSponsor();
  }
  /**
   * suggestSponsor method used to prepare request for Suggest a Sponsor
   * @param  {any} form
   * @param  {boolean} isValid
   * @returns void
   */
  suggestSponsor(form: any, isValid: boolean): void {
    let languageId;
    if (!form.value.sponsorZipcode && !form.value.sponsorCity) {
      this.ssComponentSettings.cityOrZipcodeerrMsg = true;
      return;
    }
    if (form.value.sponsorLanguage && this.ssComponentSettings.setLanguagesByCountry) {
      languageId = this.ssComponentSettings.setLanguagesByCountry.find(x => x.languageName.toUpperCase()
        === form.value.sponsorLanguage.toUpperCase()).languageId;
    }
    const country: Country = this.ssComponentSettings.countries.find((x: Country) =>
      (x.isocodeThree).toLowerCase() === this.ssComponentSettings.isoCountryCode.toLowerCase());
    let addressLine1 = '';
    if (this.ssComponentSettings.addressLine1
      && this.ssComponentSettings.setSuggestZipCode && form.value.sponsorZipcode
      && (this.ssComponentSettings.setSuggestZipCode === form.value.sponsorZipcode)) {
      addressLine1 = this.ssComponentSettings.addressLine1;
    }
    const sponsorSearchRequest: SponsorSearchRequest = {
      UserName: '',
      Email: '',
      FirstName: '',
      LastName: '',
      CountryId: country ? country.countryId.toString() : '',
      CountryCode: country ? country.isocodeThree : '',
      AddressLine1: addressLine1,
      PreferenceValue: languageId,
      PostalCode: form.value.sponsorZipcode ? form.value.sponsorZipcode : '',
      StateId: '',
      City: form.value.sponsorCity ? form.value.sponsorCity : '',
      Option: SponsorSearchOption.SearchByIDontHaveSponsor,
      EnableLongPoll: environment.enableLongPoll
    };
    if (!this.ssComponentSettings.formSubmitted) {
      this.ssComponentSettings.formSubmitted = true;
      this.markControlsAsTouched(this.ssComponentSettings.suggestSponsorForm);
    }
    if (isValid || !form.value.sponsorZipcode) {
      this.getSponsorInformation(sponsorSearchRequest, SponsorSearchOption.SearchByIDontHaveSponsor);
    }
  }

  /**
   * @description
   * @param {SponsorInformation} sponsor
   * @param {number} [index]
   * @memberof SponsorSelectionComponentNew
   */
  setSponsor(sponsor: SponsorInformation, index?: number): void {
    sponsor.address = this._sponsorService.mapAddressModel(sponsor);
    this.selectedSponsor = sponsor;
    this.setSelectedSponsorInformation();
    this.setSponsorInformation();
  }

  /**
  * @description UnselectSponsor method used to unselect the sponsor
  * @returns void
  */
  deSelectSponsor(): void {
    this.selectedSponsor = null;
    this.ssComponentSettings.showAuthorizedFBO = false;
    this.ssComponentSettings.selectedSponsorId = 0;
    this.selectedSponsorInfo.emit(this.selectedSponsor);
  }

  /**
   * @description method to get sponsor search options
   * @memberof SponsorSelectionComponentNew
   */
  getSponsorSearchOptions(): void {
    this._sponsorService
      .sponsorOptions()
      .subscribe((response: any) => {
        this.ssComponentSettings.sponsorSearchOptions = response.sponsorSearchOptions;
        const checkoutInfo = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        let sponsorId = '';
        if (checkoutInfo.sponsorInformation) {
          sponsorId = checkoutInfo.sponsorInformation.sponsorId ?
            checkoutInfo.sponsorInformation.sponsorId : '';
        }
        const referralFboId = this._cacheService.getSessionValue(CacheKey.RepSiteReferralId)
          || this._cacheService.get(CacheKey.ShareFBOID);
        if (referralFboId) {
          this._cacheService.remove(CacheKey.RebindSponsor);
        }
        const rebindSponsorData: RebindSponsorData = this._cacheService.get(CacheKey.RebindSponsor) || {};
        if (sponsorId && rebindSponsorData && !rebindSponsorData.isDefaultSponsorSelected && rebindSponsorData.sponsorWizardType) {
          this.rebindSponsorData(rebindSponsorData);
        } else if (this.ssComponentSettings.userInfo && this.ssComponentSettings.userInfo.sponsorId) {
          this.getDefaultSponsor();
          this.getMemberCommunication();
        } else {
          this.setSponsorWizard(this.ssComponentSettings.sponsorWizard);
        }
        if (checkoutInfo && checkoutInfo.sponsorInformation &&
          checkoutInfo.sponsorInformation.memberCommunicationPreferences) {
          const memberCommunicationPreferences = checkoutInfo.sponsorInformation.memberCommunicationPreferences;
          if (memberCommunicationPreferences) {
            this.rebindMemberPreferences(memberCommunicationPreferences);
          }
          if (checkoutInfo.sponsorInformation.notifyMeAboutUpdates) {
            this.ssComponentSettings.notifyMeCheckBoxControl.setValue(checkoutInfo.sponsorInformation.notifyMeAboutUpdates);
          }
        }
      });
  }

  /**
      *get member preferences and bind with Preferences Data
      *
      * @memberof CommunicationPreferencesComponent
      */
  getMemberCommunication(): void {
    const memberCommunicationPreferences = {
      email: false,
      phone: false
    };
    this._commonService.getMemberCommunicationPreferences(this.ssComponentSettings.userInfo.memberId).subscribe(
      (response: any) => {
        if (response) {
          if (response.memberPreferenceModels) {
            const email = response.memberPreferenceModels.
              find(item => item.preferenceId === ContactPreferenceType.Email &&
                +item.preferenceValue === CommunicationPreferenceValues.yes);
            const phone = response.memberPreferenceModels.
              find(item => item.preferenceId === ContactPreferenceType.Phone &&
                +item.preferenceValue === CommunicationPreferenceValues.yes);
            const notifyPreferences = response.memberPreferenceModels.
              find(item => item.preferenceId === ContactPreferenceType.NotifyMe &&
                +item.preferenceValue === CommunicationPreferenceValues.yes);
            if (email) {
              memberCommunicationPreferences.email = true;
            }
            if (phone) {
              memberCommunicationPreferences.phone = true;
            }
            this.rebindMemberPreferences(memberCommunicationPreferences);
            if (notifyPreferences) {
              this.ssComponentSettings.notifyMeCheckBoxControl.setValue(true);
            }
          }
        }
      });
  }


  /**
   *  This method used for get default sponsor
   *  getDefaultSponsor
   * @memberof SponsorSelectionComponentNew
   */
  getDefaultSponsor(): void {
    this.ssComponentSettings.isRepSiteSponsor = false;
    this.ssComponentSettings.isLoggedInSponsorInfo = true;
    this.ssComponentSettings.sponsorWizard = this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor;
    this.searchSponsorWizardByFboId(this.ssComponentSettings.userInfo.sponsorId);
  }

  /**
   * @description binding member preferences
   * @date 2018-10-30
   * @param {MemberCommunicationPreference} memberCommunicationPreferences
   * @memberof SponsorSelectionComponentNew
   */
  rebindMemberPreferences(memberCommunicationPreferences: MemberCommunicationPreference): void {
    if (memberCommunicationPreferences.email) {
      this.ssComponentSettings.contactSponsorEmail = memberCommunicationPreferences.email;
      this.ssComponentSettings.isContactSponsorSelected = true;
    }
    if (memberCommunicationPreferences.phone) {
      this.ssComponentSettings.contactSponsorPhone = memberCommunicationPreferences.phone;
      this.ssComponentSettings.isContactSponsorSelected = true;
    }
    this.ssComponentSettings.memberCommunicationPreferences = {
      email: this.ssComponentSettings.contactSponsorEmail,
      phone: false
    };
  }
  /**
  * @description this method
  * is used to set default country and zipCode
  * based on mailing address
  * @date 2018-07-20
  * @memberof SponserSelectionComponent
  */
  setSuggestSponsorPreference(): void {
    this._checkoutMessageService.getSponsorPreference()
      .subscribe((pInfoComponentSettings: PersonalInfoComponentSettings) => {
        if (pInfoComponentSettings && pInfoComponentSettings.liveFormAddress) {
          this.ssComponentSettings.selectedZipCode = pInfoComponentSettings.liveFormAddress.zip;
          this.ssComponentSettings.selectedCity = pInfoComponentSettings.liveFormAddress.city;
          this.ssComponentSettings.city = '';
          this.ssComponentSettings.setSuggestZipCode = this.ssComponentSettings.selectedZipCode;
          this.ssComponentSettings.addressLine1 = pInfoComponentSettings.liveFormAddress.addressLine1;
          this.buildSuggestSponsorForm();
          if (pInfoComponentSettings.formSubmitted) {
            this.setSponsorInformation();
          }
        }
      });
  }

  /** set selected sponsor from search suggestion to enrollement process
  */
  setSponsorInformation(): void {
    if (!this.selectedSponsor) {
      this.ssComponentSettings.isSponsorSelected = false;
      this.ssComponentSettings.sponsorNotFound = false;
      this.ssComponentSettings.searchBySponsorError = false;
      this.ssComponentSettings.noSponsorFound = false;
      this.ssComponentSettings.cityOrZipcodeerrMsg = false;
    } else {
      this.ssComponentSettings.isSponsorSelected = true;
      this.ssComponentSettings.isPersonalInformationSelected = true;
      this.ssComponentSettings.showAuthorizedFBO = true;
      this.ssComponentSettings.showSponserInfo = true;
      this.selectedSponsor.memberMetadataModels = this.ssComponentSettings.memberMetadataModels;
      this.selectedSponsor.memberCommunicationPreferences = this.ssComponentSettings.memberCommunicationPreferences;
      this.selectedSponsor.sponsorAssignedOptionId = this.ssComponentSettings.sponsorAssignedOptionId;
      this.selectedSponsor.notifyMeAboutUpdates = this.ssComponentSettings.notifyMeCheckBoxControl.value;
      this.selectedSponsorInfo.emit(this.selectedSponsor);
    }
  }


  /**
   * @description Notify updates
   * @date 2019-02-01
   * @memberof SponsorSelectionComponentNew
   */
  notifyUpdates(): void {
    this.prepareMemberCommunicationPreferences();
  }

  /**
  * setSponsorWizard method used to check or uncheck sponsor search options based on selected value
  * @param  {string} selectedSponsor
  * @returns void
  */
  setSponsorWizard(selectedSponsor: SponsorWizardSearchType, removeDefaultSponsor?: boolean): void {
    let filteredSponsorOption = [];
    if (removeDefaultSponsor) {
      this._cacheService.remove(CacheKey.ShareFBOID);
      this._cacheService.removeCookieValue(CacheKey.fboId);
    }
    this.ssComponentSettings.isFirstNameError = false;
    this.ssComponentSettings.isLastNameError = false;
    this.ssComponentSettings.sponsorWizard = selectedSponsor;
    if (selectedSponsor === this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor) {
      filteredSponsorOption = this.ssComponentSettings.sponsorSearchOptions
        .filter(x => x.id === this.ssComponentSettings.sponsorSearchOptionType.SearchByIKnowSponsor);
      const sponsorFieldByName = this.ssComponentSettings.sponsorSearchOptions
        .filter(x => x.id === this.ssComponentSettings.sponsorSearchOptionType.SearchByFBOName);
      this.ssComponentSettings.sponsorFields = filteredSponsorOption[0].sponsorSearchValues
        .concat(sponsorFieldByName[0].sponsorSearchValues);

    } else {
      filteredSponsorOption = this.ssComponentSettings
        .sponsorSearchOptions.filter(x => x.id
          === this.ssComponentSettings.sponsorSearchOptionType.SearchByIDontHaveSponsor);
      this.ssComponentSettings.sponsorFields = filteredSponsorOption[0].sponsorSearchValues;
    }
  }

  /**
   * @description
   * @date 2018-08-17
   * @param {SponsorWizardSearchType} selectedSponsor
   * @memberof SponsorSelectionComponentNew
   */
  resetVariable(selectedSponsor: SponsorWizardSearchType): void {
    this.ssComponentSettings.noSponsorFound = false;
    this.ssComponentSettings.contactSponsor = true;
    this.ssComponentSettings.searchBySuggestSponsors = null;
    this.ssComponentSettings.searchByIDOrNameSponsors = null;
    this.ssComponentSettings.cityOrZipcodeerrMsg = false;
    this.selectedSponsor = null;
    this.selectedSponsorInfo.emit(this.selectedSponsor);
    if (selectedSponsor === this.ssComponentSettings.sponsorSearchWizardType.SearchByIKnowSponsor) {
      this.ssComponentSettings.firstName = '';
      this.ssComponentSettings.lastName = '';
      this.ssComponentSettings.referringFboId = '';
      this.ssComponentSettings.selectedSponsorCountry = this.ssComponentSettings.browserCountry ?
        this.ssComponentSettings.browserCountry.countryId
        : this.ssComponentSettings.countries[0] ? this.ssComponentSettings.countries[0].countryId : 0;
      this.ssComponentSettings.selectedSponsorState = 0;
      this.ssComponentSettings.searchBySponsorError = false;
      this.disableFboIdOrName();
    } else if (selectedSponsor === this.ssComponentSettings.sponsorSearchWizardType.SearchByIDontHaveSponsor) {
      this.ssComponentSettings.city = '';
      this.ssComponentSettings.setSuggestZipCode = this.ssComponentSettings.selectedZipCode;
      this.buildSuggestSponsorForm();
    }
    this.setSelectedSponsorInformation();
  }

  // HardCoded Contact Sponsor Options...
  getContactSponsorOptions(): void {
    this.ssComponentSettings.contactSponsorOptions = [
      {
        id: 22,
        criteria: 'Email',
        property: 'Email'
      },
      {
        id: 23,
        criteria: 'Phone',
        property: 'Phone'
      }
    ];
  }

  /**
   * Check whether Email/Phone is selected
   * validateContactSponsor
   * @memberof SponsorSelectionComponentNew
   */
  validateContactSponsor(): void {
    if (this.ssComponentSettings.contactSponsorEmail || this.ssComponentSettings.contactSponsorPhone) {
      this.ssComponentSettings.noCantactSponsor = false;
      this.ssComponentSettings.isContactSponsorSelected = true;
    } else {
      this.ssComponentSettings.noCantactSponsor = false;
      this.ssComponentSettings.isContactSponsorSelected = false;
    }
    this.prepareMemberCommunicationPreferences();
  }

  checkContactSponsor(): void {
    // if (!this.ssComponentSettings.isContactSponsorSelected) {
    //   this.ssComponentSettings.noCantactSponsor = false;
    //   this.ssComponentSettings.contactSponsorEmail = false;
    //   this.ssComponentSettings.contactSponsorPhone = false;
    // } else if (!this.ssComponentSettings.contactSponsorEmail && !this.ssComponentSettings.contactSponsorPhone) {
    //   this.ssComponentSettings.noCantactSponsor = true;
    // }
    this.prepareMemberCommunicationPreferences();
  }

  /**
   *  Preparing member communication preference object
   *  prepareMemberCommunicationPreferences()
   * @memberof SponsorSelectionComponentNew
   */
  prepareMemberCommunicationPreferences(): void {
    this.ssComponentSettings.memberCommunicationPreferences = {
      email: this.ssComponentSettings.isContactSponsorSelected,
      phone: this.ssComponentSettings.contactSponsorPhone
    };
    if (this.selectedSponsor) {
      this.selectedSponsor.memberMetadataModels = this.ssComponentSettings.memberMetadataModels;
      this.selectedSponsor.memberCommunicationPreferences = this.ssComponentSettings.memberCommunicationPreferences;
      this.selectedSponsor.notifyMeAboutUpdates = this.ssComponentSettings.notifyMeCheckBoxControl.value;
      this.selectedSponsor.sponsorAssignedOptionId = this.ssComponentSettings.sponsorAssignedOptionId;
      this.selectedSponsorInfo.emit(this.selectedSponsor);
    }
  }

  /**
   * @description On Country change
   * @param {number} event
   * @param {number} index
   * @memberof SponsorSelectionComponentNew
   */
  onCountryChange(event: number, index: number): void {
    if (event) {
      const countryId = event;
      this.ssComponentSettings.selectedSponsorState = 0;
      this.getStatesLookup(countryId, false);
    }
  }

  /**
   * @description get countries lookup
   * @memberof SponsorSelectionComponentNew
   */
  getCountriesLookup(): void {
    let countries;
    if (this._cacheService.get(CacheKey.Countries)) {
      countries = this._cacheService.get(CacheKey.Countries);
      this.getFilteredCountries(countries);
    } else {
      this._commonService.getCountries().subscribe((res: Country[]) => {
        if (res && res.length > 0) {
          countries = res;
          this._cacheService.set(CacheKey.Countries, countries);
          this.getFilteredCountries(countries);
        }
      });
    }
  }

  /**
   * Grouping All Titan Countries and Non titan Countries
   * getFilteredCountries
   * @param {Country[]} countries
   * @memberof SponsorSelectionComponentNew
   */
  getFilteredCountries(countries: Country[]) {
    this.ssComponentSettings.countries = countries.filter((x: Country) => x.territory === false);
    this.ssComponentSettings.filteredTitanCountries = this.ssComponentSettings.countries.filter(x => x.titanPlatformEnabled === true);
    this.ssComponentSettings.filteredNonTitanCountries = this.ssComponentSettings.countries.filter(x => x.titanPlatformEnabled === false);
    this.ssComponentSettings.browserCountry = this.ssComponentSettings.countries.find((x: Country) =>
      (x.isocodeThree).toLowerCase() === this.ssComponentSettings.isoCountryCode.toLowerCase());
    this.ssComponentSettings.selectedSponsorCountry = this.ssComponentSettings.browserCountry.countryId;
    const country: Country = this.ssComponentSettings.countries.find((x: Country) =>
      (x.countryId) === +this.ssComponentSettings.selectedSponsorCountry);
    if (country) {
      this.ssComponentSettings.selectedCountryISO = country.isocodeThree;
    }
    // Get states By Country
    this.getStatesLookup(country.countryId, true);
  }

  /**
   *  Get zipcode patterns
   *  getZipCodePatterns
   * @memberof SponsorSelectionComponentNew
   */
  getZipCodePatterns() {
    this._commonService.getZipCodePatterns().subscribe((response: any) => {
      this.ssComponentSettings.zipCodePatterns = response;
      const pattern = this.ssComponentSettings.zipCodePatterns.filter(x => x.isoCodeThree
        === this.ssComponentSettings.selectedCountryISO)[0];
      this.ssComponentSettings.zipPattern = pattern ? pattern.zipPattern : null;
    });
  }

  /**
  * set selected sponsor information
  * @memberof SponsorSelectionComponentNew
  */
  setSelectedSponsorInformation(): void {
    const sponsorWizard = this.selectedSponsor ? this.ssComponentSettings.sponsorWizard : '';
    const rebindSponsor = {
      sponsorWizardType: sponsorWizard,
      sponsorId: this.ssComponentSettings.referringFboId,
      firstName: this.ssComponentSettings.firstName ? this.ssComponentSettings.firstName : '',
      lastName: this.ssComponentSettings.lastName ? this.ssComponentSettings.lastName : '',
      state: this.ssComponentSettings.selectedSponsorState ? this.ssComponentSettings.selectedSponsorState : 0,
      country: this.ssComponentSettings.selectedSponsorCountry ? this.ssComponentSettings.selectedSponsorCountry : '',
      city: this.ssComponentSettings.suggestSponsorForm ? this.ssComponentSettings.suggestSponsorForm.controls['sponsorCity'].value : '',
      zipCode: this.ssComponentSettings.suggestSponsorForm ? this.ssComponentSettings.
        suggestSponsorForm.controls['sponsorZipcode'].value : '',
      language: this.ssComponentSettings.suggestSponsorForm ? this.ssComponentSettings.
        suggestSponsorForm.controls['sponsorLanguage'].value : '',
      isDefaultSponsorSelected: this.ssComponentSettings.isLoggedInSponsorInfo
    };
    this._cacheService.set(CacheKey.RebindSponsor, rebindSponsor);
  }

  /**
  *  Getting States By country
  *  getStatesLookup
  * @param {number} countryId
  * @memberof SponsorSelectionComponentNew
  */
  getStatesLookup(countryId: number, reloadSponsorConfig: boolean): void {
    const country: Country = this.ssComponentSettings.filteredTitanCountries.find((x: Country) =>
      (x.countryId) === +countryId);
    if (country) {
      this._commonService.getStoreByCountryCode(country.isocodeThree).subscribe((res: any) => {
        const storeInfo = res;
        storeInfo.storeCountryCode = country.isocodeThree;
        if (storeInfo.storeCountryCode === storeInfo.homeIsocodeThree) {
          this._commonService.getStatesByCountry(countryId).subscribe((states: State[]) => {
            this.ssComponentSettings.states = states;
            if (reloadSponsorConfig) {
              this.loadSponsorConfigInfo();
            }
          });
          this.ssComponentSettings.showStates = true;
        } else {
          this.ssComponentSettings.showStates = false;
        }
      });
    } else {
      this.ssComponentSettings.showStates = false;
    }
  }

  /**
  * @description this method will load config info based on
  * state and countris
  * @date 2018-09-11
  * @private
  * @memberof SponsorSelectionComponentNew
  */
  private loadSponsorConfigInfo(): void {
    // Get Languages By Country
    this.getLanguagesLookup(this.ssComponentSettings.selectedCountryISO);
    this.getZipCodePatterns();
    this.loadReferralFBOID();
    this.setSuggestSponsorPreference();
    this.getSponsorEligibility();
  }


  /**
   * Getting Languages by Country
   * getLanguagesLookup
   * @param {string} selectedCountryISO
   * @memberof SponsorSelectionComponentNew
   */
  getLanguagesLookup(selectedCountryISO: string): void {
    this._commonService.getStoreByCountryCode(selectedCountryISO).subscribe((res: any) => {
      this.ssComponentSettings.setLanguagesByCountry = res.languages;
      this.ssComponentSettings.setSuggestLanguage = this.ssComponentSettings.setLanguagesByCountry.find(x => x.cultureName.toUpperCase()
        === this.ssComponentSettings.languageCode.toUpperCase()).languageName;
      this.buildSuggestSponsorForm();
    });
  }

  /**
* Suggest Sponsor Form
* @returns void
*/
  buildSuggestSponsorForm(): void {
    this.ssComponentSettings.suggestSponsorForm = this._formBuilder.group(
      {
        sponsorCity: [this.ssComponentSettings.city ? this.ssComponentSettings.city : ''],
        sponsorZipcode: [this.ssComponentSettings.setSuggestZipCode ? this.ssComponentSettings.setSuggestZipCode : '', []],
        sponsorLanguage: [this.ssComponentSettings.setSuggestLanguage ? this.ssComponentSettings.setSuggestLanguage : '', []],
      });
  }

  /**
  * Mark all the elements as touched to show validation messages
  * @param  {FormGroup} form
  * @returns void
  */
  markControlsAsTouched(form: FormGroup): void {
    if (form) {
      Object.keys(form.controls).forEach(function (key) {
        form.controls[key].markAsTouched();
      });
    }
  }

  /**
  * @description
  * @date 2018-12-12
  * @memberof SponsorSelectionComponentNew
  */
  getSponsorEligibility() {
    this._checkoutMessageService.getSponsorEligibility().subscribe((isEligible: boolean) => {
      this.ssComponentSettings.isSelectedSponsorEligible = isEligible;
    });
  }

  get sponsorZipcode() {
    return this.ssComponentSettings.suggestSponsorForm.get('sponsorZipcode');
  }

  /**
  * trim text elment text
  * @param  {FormGroup} form
  * @returns void
  */
  trimValue(event) {
    const value = event.target.value;
    if (value) {
      event.target.value = value.trim().length === 0 ? value.trim() : value;
    }
  }

  showFocus(e: any) {
    // e.currentTarget.nextElementSibling.nextElementSibling.style.outline = 'auto 2px #72a0ec';
  }
  removeFocus(e: any) {
    // e.currentTarget.nextElementSibling.nextElementSibling.style.outline = 'none';
  }
}
