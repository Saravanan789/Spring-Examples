export interface TaxValidationMessage {
    isDisablePlaceOrderBtn: boolean;
    validations: string;
    errorId?: string;
}
