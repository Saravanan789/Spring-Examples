export interface ValidationDetail {
    code: string;
    field: string;
    message: string;
}
