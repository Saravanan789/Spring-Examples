import { CreditCardModel } from './creditcard-model.interface';
import { CompleteRedirectRequest } from './complete-redirect-request.interface';
import { PaymentEcheck } from '.';

export interface OrderPayment {
    paymentAmount: number;
    memberPaymentMethodId: number;
    paymentStatusId?: number;
    creditCardModel: CreditCardModel;
    paymentECheck?: PaymentEcheck;
    completeRedirectRequestModel?: CompleteRedirectRequest;
    redirect?: boolean;
}
