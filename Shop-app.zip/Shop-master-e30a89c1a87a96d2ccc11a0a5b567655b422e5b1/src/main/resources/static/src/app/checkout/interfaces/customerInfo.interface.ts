export interface CustomerInfo {
  firstName: string;
  lastName: string;
  emailAddress?: string;
  customerId: string;
  surNamePrefix?: string;
  faxNumber?: string;
  phoneNumber: string;
}
