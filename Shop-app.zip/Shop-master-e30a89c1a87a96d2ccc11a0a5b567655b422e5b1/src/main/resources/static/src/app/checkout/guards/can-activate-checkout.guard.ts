import { CommonService } from '../../shared/services/common.service';
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Cart } from '../../shared/models/cart.model';

@Injectable()
export class CanActivateCheckoutGuard implements CanActivate {
    isoCountryCode = '';
    constructor(private router: Router,
        private _cacheService: CacheService) {
        this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    }

    /**
     * Checkout page Guard
     * @returns boolean
     */
    canActivate(): boolean {
        const cartSessionInfo: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        const isAutoshipEnabled: boolean = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        const autoshipInfo = this._cacheService.get(CacheKey.AutoshipCart);
        const cartSesstionGUID: any = this._cacheService.getCookieValue(CacheKey.CartSessionGuid);
        const hasCartItems = this._cacheService.getCookieValue(CacheKey.hasCartItems);
        const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        // allow user, If user has cartItems
        if ((cartSessionInfo && cartSessionInfo.items && cartSessionInfo.items.length > 0)
        || (isAutoshipEnabled && autoshipInfo && autoshipInfo.items && autoshipInfo.items.length > 0)
            || (this._cacheService.getSessionValue(CacheKey.RepeatWebOrderNumber)
                && this._cacheService.get(CacheKey.UserInfo)) || (cartSesstionGUID) || hasCartItems) {
            return true;
        } else {
            // If no CartItems, Redirect to Shop page
            this.router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/' + languageCode.toLowerCase() + '/products');
        }
        // default
        return true;
    }
}
