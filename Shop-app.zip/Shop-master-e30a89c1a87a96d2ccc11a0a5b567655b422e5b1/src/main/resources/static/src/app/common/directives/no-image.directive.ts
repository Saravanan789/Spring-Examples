import { Directive, ElementRef, Input } from '@angular/core';
import { environment } from '../../../environments/environment';


// tslint:disable-next-line:directive-selector
@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[err-img]',
    // tslint:disable-next-line:use-host-property-decorator
    host: { '(error)': 'onError($event)' }
})
export class NoImageDirective {
    // @Input('err-img')
    // fallbackImageUrl: string;
    constructor(private elementRef: ElementRef) {
    }
    /**
     * Fallback Image will be shown, when the image is broken
     * @param  {any} event
     * @returns void
     */
    onError(event: any): void {
        this.elementRef.nativeElement.src = environment.uiTemplateBaseUrl + '/images/no_image.png';
        // Add err-img class to an element
        this.elementRef.nativeElement.classList.add('err-img');
    }
}
