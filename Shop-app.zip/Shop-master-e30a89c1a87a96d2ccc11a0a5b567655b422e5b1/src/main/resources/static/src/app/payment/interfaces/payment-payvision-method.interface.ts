export interface PayvisionPaymentMethod {
  expiryYear: string;
  countryCode: string;
  type: string;
  cardType: string;
  maskedCardNumber: string;
  name: string;
  expiryMonth: string;
  billingAddressRequired: boolean;
}
