export enum ShippingOrderType {
    Personal = 17,
    AutoShip = 18,
    DropShip = 19
}
