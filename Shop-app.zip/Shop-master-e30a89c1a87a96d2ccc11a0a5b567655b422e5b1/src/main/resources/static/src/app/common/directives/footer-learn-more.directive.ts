import { Directive, HostListener, EventEmitter, Output } from '@angular/core';
import { DynamicRoute } from '../interfaces';

@Directive({
    selector: '[appFooterLearnMore]'
})
export class FooterLearnMoreDirective {
    @Output() isNavClicked: EventEmitter<DynamicRoute> = new EventEmitter<DynamicRoute>();
    constructor() {
    }
    @HostListener('click', ['$event', '$event.target']) onListenerTriggered($event: any, element: HTMLElement): void {
        if (element.attributes && element.nodeName === 'A') {
            // Prevent href from navigating and disabling page reload for Hotspot images
            $event.preventDefault();
            if ($event.target.attributes.href && $event.target.attributes.href.value) {
                this.isNavClicked.emit({
                    route: $event.target.attributes.href.value,
                    target: $event.target.attributes.target.value || '_self'
                });
            }
        }
    }
}
