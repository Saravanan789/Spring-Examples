import { TranslateService } from '@ngx-translate/core';
import { Cart } from '../../shared/models/cart.model';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { CartService } from '../../shared/services/cart.service';
import { ProductType } from '../enums/product-types.enum';
import { Options } from '../interfaces/options.interface';
import * as _ from 'lodash';

import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  HostListener,
  EventEmitter,
  Output
} from '@angular/core';
import { CacheService } from '../../shared/services/cache.service';
import { Router, NavigationEnd } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ImageType } from '../enums/image-type.enum';
import { ProductService } from '../services/product.service';
import { Product } from '../interfaces/product.interface';
import { CommonService } from '../../shared/services/common.service';
import { Quickview } from '../interfaces/product-quickview.interface';
import { ProductMessageService } from '../services/product-message.service';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { AppMessageService } from '../../app-message.service';
import { Item } from '../../shared/models/item.model';
import { Subscription } from 'rxjs/Subscription';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationService } from '../../shared/services/notification.service';
import { NotificationType } from '../../common/enums/notification-type.enum';
import { CardType } from '../../shared/enums/card-types.enum';
import { QuickviewComponent } from './quickview.component';
import { Member } from '../../shared/interfaces/member.interface';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ProductCache } from '../interfaces/product-cache.interface';
import { RowStatus } from '../../common/enums';
import { Autoship } from '../../checkout/interfaces';
import { ProductCacheService } from '../services/product-cache.service';
import { ActiveSessionService } from '../../shared/services';
import { MemberLevel } from '../../shared/enums';
import { TranslateParam } from '../../common/interfaces';

@Component({
  selector: 'app-product-list',
  templateUrl: '../templates/template3/views/product-list.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/product-list.component.less'
  ]
})

export class ProductListComponent implements OnInit, OnDestroy {
  productsCount: number;
  productsOnDisplayCount: number;
  isSearchResults: boolean;
  isPersonalPurchaseFlow = false;
  @Input() isSideNavCollapsed: boolean;
  @Output() productSearchResult = new EventEmitter<number>();
  personalPurchaseFlow: string;
  purchaseFlows: any[] = [];
  store: StoreConfig;
  cartItems: any[];
  products: Product[] = [];
  errorMessages: any = [];
  quickViewItem: Quickview;
  options: Options[];
  txt_quantity = 1;
  quantity = 1;
  disableMinus = false;
  disablePlus = false;
  public isModalShown = false;
  swiperInit = false;
  languageCode: string;
  storeId: number;
  selectedCurrency = 'USD';
  imageTypes = ImageType;
  catalogId = 1;
  isLoggedIn;
  blogCardsContent;
  sortTypes: any = [
    {
      key: 'FEATURED',
      value: 'Featured Products'
    },
    {
      key: 'PRICELOWHIGH',
      value: 'Price: Low to High'
    },
    {
      key: 'PRICEHIGHLOW',
      value: 'Price: High to Low'
    },
    {
      key: 'AVERAGERATINGS',
      value: 'Average Ratings'
    }
  ];

  pageSize = 12;
  pageNumber = 1;
  productCategoryId = 0;
  productsScrollDisabled = false;
  noProductsFound = false;
  productsScrollDistance = 3;
  productsScrollThrottle = 500;
  showCategoryName: boolean;
  categoryName: string;
  categoryId: number;
  productType = ProductType;
  sortTypeValue: string = this.sortTypes[0].key;
  selectedFilter: any = {};
  showOptions = false;
  isHeaderSearchEnabled = false;
  productSearch: string;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  purchaseFlow: PurchaseFlow;
  productsByCategorySubscription: Subscription;
  defaultProductsSubscription: Subscription;
  wishListSubscription: Subscription;
  catalogs: any;
  makeFixed = false;
  catalogSelected = 0;
  enrollSession: string;
  isoCountryCode: string;
  userLoggedIn: Member;
  quickViewFocusOut = true;
  s3BucketUrl = environment.cdnURL;
  totalRecordCount = 0;
  categoryCardContent;
  isAutoshipEnabled: boolean;
  categoryTreeOpenIndex: number;
  bsModalRef: BsModalRef;
  sortSearchProducts: boolean;
  isBackNavigation = false;
  ingredientsList = '';
  certificatesList = '';
  autoshipPreference: Autoship;
  isEnableWishList: boolean;
  scrollTimer: any;
  loadingProducts: boolean;
  translateParams: TranslateParam;

  constructor(
    private _cacheService: CacheService,
    private _productService: ProductService,
    private _router: Router,
    private _commonService: CommonService,
    private _cartService: CartService,
    private modalService: BsModalService,
    private _appMessageService: AppMessageService,
    private _productMessageService: ProductMessageService,
    private _configurationService: ConfigurationService,
    private _translatePipe: TranslateService,
    public _sanitizer: DomSanitizer,
    private _notificationService: NotificationService,
    private _productCacheService: ProductCacheService,
    private _activeSessionService: ActiveSessionService
  ) {

  }

  ngOnInit() {
    if (environment.dataLayer && environment.dataLayer.length > 0) {
      environment.dataLayer[0].pageCategory = 'shop-products';
    }
    this._router.events.subscribe((event) => {
      const isBackNavigation = this._productCacheService.getDetailbackNavigation();
      if (event instanceof NavigationEnd && isBackNavigation) {
        const scrollPosition = this._productCacheService.getScrollPosition();
        this._commonService.scrollByValue(0, scrollPosition, 0);
      }
    });
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    this.personalPurchaseFlow = this.isAutoshipEnabled ? PurchaseFlow.AUTOSHIP : PurchaseFlow.PERSONAL;
    this.getStoreData();
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._commonService.getLanguageCode();
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.purchaseFlow = this._commonService.getPurchaseFlowType();
    this.isLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    if (this.categoryId && this.categoryId > 0) {
      this.getProductsByCategoryId(this.categoryId);
    }
    this.getCategoryDetail();
    this.loadDefaultProductsEvent();
    this.getWishListSubject();
    this.getCategoryTreeSubject();
    this.getMemberAutoshipItems();
  }

  /**
     * Load Products By catalog Id
     * @param  {number} catalogId
     * @param  {number} pageSize?
     * @param  {boolean} isSort?
     * @returns void
     */
  getProductsByCatalogId(catalogId: number, reload: boolean = false, pageSize?: number, isSort?: boolean): void {
    if (this.storeId && this.catalogId) {
      pageSize = pageSize ? pageSize : this.pageSize;
      this.isSearchResults = false;
      this._productService.getProductsByCatalogId(this.storeId, this.catalogId, this.languageCode, pageSize, this.pageNumber,
        this.sortTypeValue)
        .subscribe((response: any) => {
          if (response.body) {
            if (reload) {
              this.getCardsContentByCategoryOrCatalog(response, reload, pageSize, isSort);
            } else {
              this.totalRecordCount = response.header._headers.get('x-total-count') ? +response.header._headers.get('x-total-count') : 0;
              this.noProductsFound = false;
              this.products = reload ? response.body : this.products.concat(response.body);
              this.products.forEach(item => {
                item.commissionableVolume = !item.literature ? item.commissionableVolume : 0;
              });
              this.productsOnDisplayCount = this.products.length;
              if (isSort) {
                this.pageNumber = pageSize / this.pageSize;
              }
              this.loadWishListProducts();
            }
          } else {
            this.productsScrollDisabled = true;
          }
        }, (error: any) => {
          if (reload) {
            this.products = [];
            this.noProductsFound = true;
          }
          this.translateParams = this._commonService.handleError(error);
        }, () => {
          // complete block
          this.loadingProducts = false;
        });
    }
  }

  //#endregion Custom Catalogs

  /**
   * get category tree open index subscription
   */
  getCategoryTreeSubject() {
    this._appMessageService.getCategoryTreeOpenIndex().subscribe((index) => {
      this.categoryTreeOpenIndex = index;
    });
  }

  public sanitizeImage(image: string): any {
    image = this.s3BucketUrl + image;
    return this._sanitizer.bypassSecurityTrustStyle(`url(${image})`);
  }

  /**
   *  Loads Default Products Search from header
   * @returns void
   */
  loadDefaultProductsEvent(): void {
    this.defaultProductsSubscription = this._productMessageService.getLoadDefaultProducts()
      .subscribe((productSearch: any, isbackNavigation?: boolean) => {
        this.categorySearchProducts(productSearch);
        window.history.pushState(null, null, '/' + this.isoCountryCode.toLowerCase() + '/' +
          this.languageCode.toLowerCase() + '/products' + '?search=' + productSearch.searchValue);
      });
  }

  /**
   * @param  {any} productSearch
   * @returns void
   */
  private categorySearchProducts(productSearch: any): void {
    const category = productSearch.category;
    this.productSearch = productSearch;
    this.isHeaderSearchEnabled = true;
    this.pageNumber = 1;
    this.products = [];
    this.productsScrollDisabled = false;
    this.catalogSelected = -1;
    this.totalRecordCount = 0;
    this.productsCount = 0;
    if (category && category.id > 0) {
      this.showCategoryName = true;
      this.categoryName = category.categoryName;
    } else {
      this.showCategoryName = false;
    }
    this.loadHeaderSearchProducts(productSearch, true);
  }

  // Load Products on Header Search
  loadHeaderSearchProducts(productSearch: any, reload: boolean = false, pageSize?: number, isSort?: boolean) {
    const category = productSearch.category;
    const productCategoryId = category && category.productCategoryId ? category.productCategoryId : 0;
    if (this.storeId) {
      this._productService
        .searchProductsbyCategory(this.storeId, productCategoryId, productSearch.searchValue,
          this.pageSize, this.pageNumber, this.sortTypeValue, this.languageCode)
        .subscribe((products: any) => {
          if (products.body) {
            this.isSearchResults = false;
            this.noProductsFound = false;
            this.productCategoryId = productCategoryId;
            if (!isSort && (this.totalRecordCount === 0 || this.pageNumber === 1)) {
              this.totalRecordCount = products.header._headers.get('x-total-count') ? +products.header._headers.get('x-total-count') : 0;
            }
            if (this.isHeaderSearchEnabled) {
              this.productSearchResult.emit(this.totalRecordCount);
              if (products.body) {
                this.products = reload ? products.body : this.products.concat(products.body);
                this.products.forEach(x => {
                  if (!(x.backOrderAllowed || (x.manageStock && x.stockQuantity > 0))) {
                    x.productQuantity = x.productQuantity || 0;
                  } else {
                    x.productQuantity = x.productQuantity || 1;
                  }
                  x.disableDecrement = x.disableDecrement || true;
                  if (ProductType.Variable === x.productTypeMasterId) {
                    this.showOptions = true;
                  } else {
                    this.showOptions = false;
                  }
                });
                if (isSort) {
                  this.pageNumber = pageSize / this.pageSize;
                }
              } else {
                this.productsScrollDisabled = true;
              }
            }
            this.loadWishListProducts();
            this._cacheService.removeCookieValue(CacheKey.HeaderSearch);
          } else {
            if (this.pageNumber === 1) {
              this.noProductsFound = true;
              this.productSearchResult.emit(0);
              this._cacheService.removeCookieValue(CacheKey.HeaderSearch);
            }
          }
        }, error => {
          if (error) {
            this.noProductsFound = true;
            this.productSearchResult.emit(0);
            this._cacheService.removeCookieValue(CacheKey.HeaderSearch);
            this.translateParams = this._commonService.handleError(error);
          }
        }, () => {
          // complete block
          this.loadingProducts = false;
        });
    }
  }


  /**
  * To add an item
  * @param  {Product} product
  */
  addToWishList(product: Product): void {
    // TODO amruth - need to move text to s3 and translate
    if (!this.userLoggedIn) {
      return;
    }
    if (this.userLoggedIn && product.options && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      product.wishListItem = !product.wishListItem ? true : false;
      product.productQuantity = this.quantity;
      const item: Item = this._cartService.convertProductToItemMappper(product);
      let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
      if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length >= 0 && wishListCart.sessionGuid) {
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .updateCart([item], CartTypes.WishlistCart, wishListCart)
          .subscribe((response: Cart) => {
            if (response) {
              //  this._commonService.createNotification('', itemAddedNotification.value, 'success');
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      } else if (product.wishListItem) {
        this._cartService
          .saveCart([item], CartTypes.WishlistCart)
          .subscribe((response: Cart) => {
            if (response) {
              //    this._commonService.createNotification('', itemAddedNotification.value, 'success');
              wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
              this._cacheService.set(CacheKey.WishListSession, wishListCart);
              this._appMessageService.setWishListItems();
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      } else if (!product.wishListItem) {
        const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
        wishListCart.items = _.remove(wishListCart.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .removeCartItem(wishListCart.sessionGuid, cartItem.id)
          .subscribe(response => {
            // this._commonService.createNotification('', itemDeletedNotification.value, 'success');
            wishListCart = new Cart(wishListCart, this.store);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      }
    }
  }

  /**
   * @returns void
   */
  getWishListSubject(): void {
    this.wishListSubscription = this._appMessageService.getWishListItems().subscribe(response => {
      this.loadWishListProducts();
    });
  }

  /**
   * load wishlist
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      this.products.forEach(x => {
        x.productQuantity = x.productQuantity || 1;
        x.disableDecrement = x.disableDecrement || true;
        wishListCart.items.forEach(y => {
          if (y.productId === x.id) {
            x.wishListItem = true;
          }
        });
      });
    } else {
      this.products.forEach(x => {
        if (!(x.backOrderAllowed || (x.manageStock && x.stockQuantity > 0))) {
          x.productQuantity = 0;
        } else {
          x.productQuantity = x.productQuantity || 1;
        }
        x.disableDecrement = x.disableDecrement || true;
        if (ProductType.Variable === x.productTypeMasterId) {
          this.showOptions = true;
        } else {
          this.showOptions = false;
        }
        x.wishListItem = false;
      });
    }
  }

  /**
  * this is for getting category name
  * @returns void
  */
  getCategoryDetail(): void {
    this.productsByCategorySubscription = this._productMessageService.getProductsByCategory()
      .subscribe((response: any) => {
        // On each Category Click goto top of the Body.
        // setTimeout(() => {
        this._commonService.scrollByValue(0, 0, 500);
        // }, 0);
        if (response && response.isSearch) {
          this.categorySearchProducts(response);
        } else {
          this.isHeaderSearchEnabled = false;
          this.loadProductsByCatalogOrCategoryId(response);
        }
      });
  }

  /**
   * load product by catgory or catelog id
   * @param  {any} selectedCategory
   * @returns void
   */
  loadProductsByCatalogOrCategoryId(selectedCategory: any): void {
    if (selectedCategory && selectedCategory.productCategoryId) {
      this.pageNumber = 1;
      this.productsScrollDisabled = false;
      // this.products = [];
      this.categoryName = selectedCategory.categoryName;
      this.showCategoryName = true;
      if (selectedCategory.isEnableHeader !== undefined) {
        this.isHeaderSearchEnabled = selectedCategory.isEnableHeader;
      }
      // this._productMessageService.setCardsSubject(selectedCategory);
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      this.fetchProductFilters();
      if (!this.isHeaderSearchEnabled && selectedCategory.productCategoryId && !selectedCategory.isCustomCatalog) {
        this.productCategoryId = selectedCategory.productCategoryId;
        this.catalogId = 0;
        this.getProductsByCategoryId(selectedCategory.productCategoryId, true);
      } else {
        this.productCategoryId = 0;
        this.catalogId = selectedCategory.productCategoryId;
        this.getProductsByCatalogId(this.catalogId, true);
      }
    }
  }

  /**
   * @description
   * @date 2018-09-03
   * @memberof ProductListComponent
   */
  fetchProductFilters(): void {
    const selectedProductFilters = this._cacheService.get(CacheKey.SelectedProductFilters);
    if (selectedProductFilters) {
      this.ingredientsList = selectedProductFilters.ingredientsList.toString();
      this.certificatesList = selectedProductFilters.certificatesList.toString();
    }
  }

  /**
  * to get products by category id
  * @param  {number} categoryId
  */
  getProductsByCategoryId(categoryId: number, reload: boolean = false, pageSize?: number, isSort?: boolean): void {
    pageSize = pageSize ? pageSize : this.pageSize;
    this.catalogSelected = -1;
    this.isSearchResults = false;
    if (this.storeId && categoryId) {
      this._productService
        .getProductByCategoryId(categoryId, this.storeId, this.languageCode,
          pageSize, this.pageNumber, this.sortTypeValue)
        .subscribe((response: any) => {
          if (response && response.body) {
            if (reload) {
              this.getCardsContentByCategoryOrCatalog(response, reload, pageSize, isSort);
            } else {
              this.totalRecordCount = response.header._headers.get('x-total-count') ? +response.header._headers.get('x-total-count') : 0;
              this.noProductsFound = false;
              this.products = reload ? response.body : this.products.concat(response.body);
              this.productsOnDisplayCount = this.products.length;
              if (isSort) {
                this.pageNumber = pageSize / this.pageSize;
              }
              this.loadWishListProducts();
            }
          } else {
            this.productsScrollDisabled = true;
          }
        }, error => {
          if (reload) {
            this.products = [];
            this.noProductsFound = true;
          }
        }, () => {
          // complete block
          this.loadingProducts = false;
        });
    }
  }

  /**
   * Merge Cards array into Products array
   * mergeCardToProductList()
   */
  mergeCardToProductList(): void {
    const selectedCategory = this._cacheService.get(CacheKey.SelectedCategoryState);
    // Retreive only Blog cards from cards array
    if (selectedCategory.cards && selectedCategory.cards.length > 0) {
      const blogCards = selectedCategory.cards.filter((item) => {
        if (item.type.toLowerCase() === CardType.Blog.toLowerCase()) {
          return item;
        }
      });
      this.blogCardsContent = _.orderBy(blogCards, ['sortOrder'], ['asc']);
      // When products are less than 3 and there is some blog cards from CMS, display first blog card
      // Based on parameter 'isCardContent', Products/blogs are rendered in UI
      if (this.products.length < 3 && this.blogCardsContent.length > 0 && this.blogCardsContent[0]) {
        const idx = this.products.length;
        this.products.splice(idx, 0, this.blogCardsContent[0]);
        this.products[idx]['isCardContent'] = true;
      } else if (this.products.length >= 3 && this.blogCardsContent.length > 0) {
        let i = 0;
        let totalLength = this.products.length;
        for (let x = 0; x < totalLength; x++) {
          this.products[x]['isCardContent'] = false;
          // Display Blog cards in Position 3, 7, and 11
          if ((((x + 1) === 3) || ((x + 1) === 7) || ((x + 1) === 11)) && this.blogCardsContent[i]) {
            this.products.splice(x, 0, this.blogCardsContent[i]);
            this.products[x]['isCardContent'] = true;
            totalLength = this.products.length;
            i = i + 1;
          }
        }
      }
    }
  }

  /**
   * Get cards content from CMS By Category/Catalog
   * getCardsContentByCategoryOrCatalog()
   * @param  {} {constselectedCategory=this._cacheService.get(CacheKey.SelectedCategoryState
   * @param  {} ;this._productService.getCardsContentByCategoryAndCustomCatalog(selectedCategory.isCustomCatalog
   * @param  {} selectedCategory.productCategoryId
   * @param  {any} .subscribe((res
   */
  getCardsContentByCategoryOrCatalog(response: any, reload: boolean = false, pageSize?: number, isSort?: boolean): void {
    const selectedCategory = this._cacheService.get(CacheKey.SelectedCategoryState);
    this._productService
      .getCardsContentByCategoryOrCatalog(selectedCategory.isCustomCatalog, selectedCategory.productCategoryId).subscribe(
        (res: any) => {
          this.totalRecordCount = response.header._headers.get('x-total-count') ? +response.header._headers.get('x-total-count') : 0;
          this.noProductsFound = false;
          if (res && (res.category || res.customCatalog)) {
            const cardItems = selectedCategory.isCustomCatalog ? res.customCatalog : res.category;
            selectedCategory.cards = cardItems.cards;
            this._productMessageService.setCardsSubject(cardItems);
            if (selectedCategory.cards) {
              this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
              setTimeout(() => {
                this.mergeCardToProductList();
              }, 100);
            }
          }
          this.products = reload ? response.body : this.products.concat(response.body);
          this.products.forEach(item => {
            item.commissionableVolume = !item.literature ? item.commissionableVolume : 0;
          });
          this.productsOnDisplayCount = this.products.length;
          if (isSort) {
            this.pageNumber = pageSize / this.pageSize;
          }
          this.loadWishListProducts();
        }, error => {
          this.totalRecordCount = response.header._headers.get('x-total-count') ? +response.header._headers.get('x-total-count') : 0;
          this.noProductsFound = false;
          this.products = reload ? response.body : this.products.concat(response.body);
          this.productsOnDisplayCount = this.products.length;
          if (isSort) {
            this.pageNumber = pageSize / this.pageSize;
          }
          this.loadWishListProducts();
        });
  }
  /**
   * get products on load scroll
   * @returns void
   */
  loadProductsOnScroll(): void {
    this.loadingProducts = true;
    this.pageNumber++;
    if (this.isHeaderSearchEnabled) {
      if (this.sortSearchProducts) {
        this.loadHeaderSearchProducts(this.productSearch, true, this.pageSize, true);
      } else {
        this.loadHeaderSearchProducts(this.productSearch);
      }
      return;
    }
    if (this.productCategoryId > 0) {
      this.getProductsByCategoryId(this.productCategoryId);
    } else {
      // this.getFeaturedProducts();
      this.getProductsByCatalogId(this.catalogId);
    }
  }

  /**
   * Show Modal popup
   * @param product
   */
  showModalPopup(product: Product) {
    const initialState = {
      productDetails: product
    };
    this.bsModalRef = this.modalService.show(QuickviewComponent, { class: 'modal-lg modal-dialog-centered', initialState });
    this.bsModalRef.content.product = product;
  }


  /**
   * Discount price Calculation for Price
   * @param  {number} price
   * @param  {number} discount
   */
  discountPriceCalc(retailPrice: number, applicablePrice: number) {
    return this._productService.discountPriceCalc(retailPrice, applicablePrice);
  }

  ngOnDestroy(): void {
    // unsubscribe to avoid memory leaks
    this.productsByCategorySubscription.unsubscribe();
    this.defaultProductsSubscription.unsubscribe();
    if (this.wishListSubscription) {
      this.wishListSubscription.unsubscribe();
    }
  }

  /**
  * verifying whether the product is shippable to the selected shipping address or not
  * @returns Address
  */
  getShippingRestrictedProducts(itemNumber: string): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (userDefaultAddressDetails && itemNumber) {
      const getShippingRestrictedProductsData = this._commonService.getShippingRestrictedProducts(itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            this._notificationService.createNotification('', response.productModels[0].errorDescription, NotificationType.ERROR);
            // this.shippingRestrictedProductError = response.productModels[0].errorDescription;
            // this.itemNo = response.productModels[0].itemNumber;
          }
        });
    }
  }

  /**
   * show cart / Product detail based on variant.
   */
  addToCart(product: Product, cartType: number): void {
    if (product && product.options.length === 0) {
      if (!product.addingToCart) {
        //  product['productQuantity'] = this.quantity;
        this.getShippingRestrictedProducts(product.itemNumber);
        this.manageShoppingCart(product, cartType);
      }
    } else if (product.productTypeMasterId === this.productType.Variable && product.options.length > 0) {
      this.showModalPopup(product);
    } else {
      this._router.navigate(['/', this.isoCountryCode, 'products', product.slug]);
    }
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(product: Product, cartType: CartTypes) {
    // quickview.Item added to cart
    // const itemAddedNotification: any = this._translatePipe.get('Item added to bag');
    // const itemUpdatedNotification: any = this._translatePipe.get('Item updated to bag');
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    const item: Item = this._cartService.convertProductToItemMappper(product, cartSessionInfo);
    if (cartSessionInfo) {
      const cartItem = cartSessionInfo.items.filter(x => x.productId === item.productId)[0];
      if (cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get
            ('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > product.stockQuantity && product.manageStock && !product.backOrderAllowed) {
          item.quantity = cartItem.quantity;
          product.errorMessage = true;
          setTimeout(() => {
            product.errorMessage = false;
          }, 2000);
          this.outofStockNotification(product);
          return;
        }
      }
    }
    // product is going to add in the cart
    product.addingToCart = true;
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      product.addingToCart = false;
      setTimeout(() => {
        this._appMessageService.setMiniCart(cartSession);
        this._appMessageService.showMiniCartView(product.id);
        this._commonService.focusTargetElement('minicart-shop-msg');
      }, 0);
    } else if (cartSessionInfo) {
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }

  /**
  * to update product quantity
  */
  updateQuantity(prod: Product | any) {
    const qty = parseInt(prod.productQuantity, 10);
    if (qty > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = prod.stockQuantity;
      this.outofStockNotification(prod);
    } else {
      prod.productQuantity = qty || null;
    }
    prod.disableDecrement = prod.productQuantity > 1 ? false : true;
  }

  /**
   * Increment the product Quantity
   * @returns void
   */
  incrementQuantity(prod): void {
    prod.productQuantity = ++prod.productQuantity;
    prod.disableDecrement = false;
    if (prod.productQuantity > prod.stockQuantity && !prod.backOrderAllowed) {
      prod.errorMessage = true;
      setTimeout(() => {
        prod.errorMessage = false;
      }, 2000);
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
      this.outofStockNotification(prod);
    }
  }

  outofStockNotification(product: Product) {
    // const cartStockErrorForItem: any = this._translatePipe.get('stockError.No Stock Available for Item Number');
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">' +
      product.stockQuantity + '</span>', NotificationType.ERROR);
  }

  /**
   * Decrement the product Quantity
   * @returns void
   */
  decrementQuantity(prod): void {
    if (prod.productQuantity > 1) {
      prod.productQuantity = parseInt(prod.productQuantity, 10) - 1;
    }
    if (prod.productQuantity === 1) {
      prod.disableDecrement = true;
    }
  }

  focusoutQuickView(index) {
    this.quickViewFocusOut = true;
  }

  /**
   * switch to next category if all products are focused for screen readers
   * @param {number} index
   */
  tabNextCategory(index: number) {
    if ((this.products.length - 1) === index) {
      const categoryTree = this._cacheService.get(CacheKey.CategoriesTree);
      this.categoryTreeOpenIndex = (this.categoryTreeOpenIndex === (categoryTree.length - 1)) ? -1 : this.categoryTreeOpenIndex;
      const categoryTreeId = 'category-' + (this.categoryTreeOpenIndex + 1);
      this.tabFocus(categoryTreeId);
    }
  }

  /**
  * ADA Compliance
  * focus element by Id
  * @param {string} elementId
  * @param {any} event
  * @param {number} timeInterval
  * @returns void
  */
  tabFocus(elementId: string, event?: any, timeInterval?: number) {
    if (timeInterval) {
      setTimeout(() => {
        this._commonService.focusTargetElement(elementId);
      }, timeInterval);
    } else {
      this._commonService.focusTargetElement(elementId);
    }
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event: any) {
    const windowScrollTop = (document.documentElement.scrollTop || document.body.scrollTop);
    const bodyContent: any = document.querySelector('.body-content');
    const headerSection: any = document.querySelector('.navbar-fixed-top');
    if (headerSection && windowScrollTop > (bodyContent.offsetTop - headerSection.scrollHeight)) {
      this.makeFixed = true;
    } else {
      this.makeFixed = false;
    }
  }

  /**
   * @returns void
   */
  getStoreData(): void {
    const storeConfig: StoreConfig = this._configurationService.getStoreData();
    if (storeConfig) {
      this.store = storeConfig;
      this.storeId = this.store.id;
      this.isEnableWishList = this.store.enableWishlist;
      this.purchaseFlows = storeConfig.purchaseFlows;
      this.hasPurchaseFlow();
      this.shippingNotification(storeConfig);
    }
  }

  /**
   * @description
   * Display notification for Shipping in case of Participating Country
   * @date 2018-08-30
   * @param {StoreConfig} storeConfig
   * @memberof ProductListComponent
   */
  shippingNotification(storeConfig: StoreConfig): void {
    let canShowNotification;
    if (this._cacheService.get(CacheKey.CanShowNotification)) {
      canShowNotification = JSON.parse(this._cacheService.get(CacheKey.CanShowNotification));
    } else {
      canShowNotification = true;
    }
    if (canShowNotification && storeConfig.homeCountryId !== storeConfig.countryId) {
      const message: any = this._translatePipe.get('common.shipping notification description');
      this._notificationService.createNotification('', message.value, NotificationType.WARN, 30000000, true);
    }
  }

  hasPurchaseFlow(): void {
    if (this.purchaseFlows && this.purchaseFlows.length > 0 && (this.store.purchaseFlows !== null && this.store.purchaseFlows.length > 0)) {
      this.purchaseFlows.forEach(flow => {
        this.store.purchaseFlows.forEach((storeFlow: any) => {
          if (flow.id === storeFlow.id && flow.name === this.personalPurchaseFlow) {
            this.isPersonalPurchaseFlow = true;
          }
        });
      });
    }
  }

  /**
   * redirect to sso login url
   * @param  {boolean} isLogin
   * @returns void
  */
  gotoLogin(isLogin: boolean, product: Product): void {
    this._cacheService.set(CacheKey.RedirectToFavourites, true);
    this._cacheService.set(CacheKey.WishListProduct, product);
    this._commonService.navigateToLogin(false);
  }

  /**
   * @param  {Product} product
   * @returns void
   */
  navigateToProductDetail(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = product.categories[0];
    }
    if (selectedCategory && selectedCategory.slug) {
      this._router.navigate
        (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() +
          '/products/' + selectedCategory.slug + '/' + product.slug]);
    } else {
      this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' +
        this.languageCode.toLowerCase() + '/products/' + product.slug]);
    }
  }

  prepareProductCacheData(): ProductCache {
    return {
      data: this.products,
      scrollPosition: window.scrollY || window.pageYOffset,
      pageNumber: this.pageNumber
    };
  }

  /**
   * Trackby will change the DOM
   *  for only added or removed element(not entire DOM Collection)
   * @param  {number} index
   * @returns number
   */
  trackItem(index: number, item: any): number {
    return item;
  }

  /**
   * @ADA
   * focus previous category from current opened category tree index
   * @param {string} elementId
   * @return void
   */
  tabPreviousCategory(elementId: string): void {
    let previouCategoryTree = this.categoryTreeOpenIndex ? (this.categoryTreeOpenIndex + 1).toString() : '0';
    previouCategoryTree = elementId + previouCategoryTree;
    this.tabFocus(previouCategoryTree);
  }

  /**
   * @ADA
   * tab focus to sort by ddl
   * @param {number} index
   * @returns void
   */
  tabToSortOptions(index: number): void {
    if (index === 0) {
      this.tabFocus('sort-by-label');
    }
  }

  /**
 *Clear Autoship Cart
 *
 * @memberof CartComponent
 */
  clearAutoshipCart() {
    const autoshipSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
    this._cacheService.removeCookieValue(CacheKey.IsAutoshipEnabled);
    if (autoshipSession && autoshipSession.items && autoshipSession.items.length > 0) {
      this._cartService.removeCart(autoshipSession.sessionGuid).subscribe(response => {
        this._cacheService.remove(CacheKey.AutoshipCart);
        this.navigateToAccountPortal();
      });
    } else {
      this.navigateToAccountPortal();
    }
  }

  /**
  * @description
  * @date 2018-10-03
  * @param {string} route
  * @memberof ProductComponent
  */
  navigateToPortal(route: string): void {
    if (route) {
      window.location.href = route;
    }
  }

  /**
   * Navigate back to Account Portal on cancel autoship
   * @returns void
   */
  navigateToAccountPortal(): void {
    window.location.href = environment.accountSiteURL + '/' + this.isoCountryCode + '/' + this.languageCode +
      '/account/my-profile';
  }

  /**
   * @description get Exisitng Autoship items
   * @date 2018-10-22
   * @memberof ProductListComponent
   */
  getMemberAutoshipItems(): void {
    const autoshipId = this._cacheService.getCookieValue(CacheKey.AutoshipId);
    const autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
    if (this.isAutoshipEnabled && autoshipCart) {
      this._appMessageService.setMiniCart(autoshipCart);
    } else if (this.isAutoshipEnabled && autoshipId) {
      this.getAutoshipProfileDetails();
    }
  }

  /**
   * @description get Autoship Profile Details
   * @date 2018-10-21
   * @memberof ProductListComponent
   */
  getAutoshipProfileDetails(): void {
    this._commonService
      .getAutoShipByMemberId(this.userLoggedIn.memberId)
      .subscribe((res) => {
        if (res && res[0].body && res[0].body.length > 0) {
          const autoshipPreferences = res[0].body;
          const autoship = autoshipPreferences.find((x) => x.rowStateId === RowStatus.Active);
          this.autoshipPreference = JSON.parse(JSON.stringify(autoship));
          if (this.autoshipPreference && this.autoshipPreference.autoshipProducts) {
            const cartSession = {
              sessionInfo: res,
              reloadMemberCart: true
            };
            this.getAutoshipProducts(this.autoshipPreference);
          }
        } else {
          this._cacheService.remove(CacheKey.AutoshipDetails);
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
  }

  /**
   * @description get Autoship products
   * @date 2018-10-22
   * @param {Autoship} autoshipPreference
   * @memberof ProductListComponent
   */
  getAutoshipProducts(autoshipPreference: Autoship): void {
    const productIds = [];
    if (this.storeId && autoshipPreference.autoshipProducts) {
      autoshipPreference.autoshipProducts.forEach((item) => productIds.push(item.productId));
      this._commonService.getProductsByIds(productIds, this.languageCode, this.storeId).subscribe((response) => {
        if (response) {
          const autoShipProducts: Item[] = [];
          response.forEach((product, index) => {
            const autoshipProdItem = autoshipPreference.autoshipProducts.find(x => x.productId === product.id);
            product.productQuantity = autoshipProdItem && autoshipProdItem.quantity ?
              autoshipProdItem.quantity : 1;
            const item: Item = this._cartService.convertProductToItemMappper(product);
            autoShipProducts.push(item);
          });
          const cartResponse = {
            items: autoShipProducts
          };
          const autoshipCart = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
          this._cacheService.set(CacheKey.AutoshipCart, autoshipCart);
          this._appMessageService.setMiniCart('');
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }
}
