import { PriceType } from '../../shared/enums/price-type.enum';
import { MemberType } from '../../shared/enums/member-type.enum';
import { ShippingOrderType } from '../enums/shipping-order-type.enum';
import { ShippingProductModel } from './shipping-product.interface';
import { Address } from '../../common/interfaces';

export interface ShippingOptionsRequest {
  productModels: ShippingProductModel[];
  languageCode: string;
  orderSourceId: number;
  storeId: number;
  memberTypeId: MemberType;
  memberLevelId: number;
  orderSubTotal: number;
  orderCaseCredits: number;
  purchaseFlowId: number;
  fromAddress: Address;
  toAddress: Address;
  orderSource?: string;
  requestID: number;
  orderTypeId?: ShippingOrderType;
  shippingTypeId: number;
  priceTypeId: PriceType;
  orderDate?: string;
  storeHomeCountryCode: string;
}
