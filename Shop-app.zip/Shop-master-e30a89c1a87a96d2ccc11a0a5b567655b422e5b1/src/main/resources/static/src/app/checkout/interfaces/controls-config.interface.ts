export interface ControlsConfig {
    [key: string]: any;
}
