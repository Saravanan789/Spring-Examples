export interface DynamicRoute {
    route: string;
    target: string;
}
