import { ShippingMethod } from './shipping-method.interface';

export interface ShippingMethodInformation {
    shippingMethod: ShippingMethod;
}
