export interface ChildImage {
    id: number;
    type: string;
    url: string;
    parentId: number;
    sortOrder: number;
}
