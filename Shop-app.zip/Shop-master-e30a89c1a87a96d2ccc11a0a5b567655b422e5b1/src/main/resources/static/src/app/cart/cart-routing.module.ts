import { CartComponent } from './components/cart.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CanActivateCartGuard } from '../shared/guards/can-activate-cart.guard';
const cartModuleRoutes: Routes = [
  { path: '', component: CartComponent, canActivate: [CanActivateCartGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(cartModuleRoutes)],
  exports: [RouterModule]
})
export class CartRoutingModule { }
