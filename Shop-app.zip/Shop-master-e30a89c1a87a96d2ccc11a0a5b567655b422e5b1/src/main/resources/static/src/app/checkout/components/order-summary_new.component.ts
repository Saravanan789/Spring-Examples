import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { OrderSummaryComponentSettings } from '../component-settings';
import {
    CartService, CommonService,
    CacheService, ConfigurationService, DataShareService, ActiveSessionService
} from '../../shared/services';
import { Router, ActivatedRoute } from '@angular/router';
import { OrderService, ShippingMethodService, AutoshipService } from '../services';
import { AppMessageService } from '../../app-message.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { StoreConfig, Country, State, MemberMetaData } from '../../shared/interfaces';
import { CheckoutInformation, EnrollSession, Order, PickupLoaction, Autoship } from '../interfaces';
import { MemberType, CartTypes } from '../../shared/enums';
import { Cart } from '../../shared/models';
import { environment } from '../../../environments/environment';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Product } from '../../products/interfaces/product.interface';
import { Member } from '../../shared/interfaces/member.interface';
import { LoaderService } from '../../shared/services/loader.service';
import { AddressService } from '../../common/services/address.service';
import { MemberMetaDataEnum } from '../../common/enums';
import { DocumentService } from '../../shared/services/documents.service';
import { TaxType } from '../enums';
import { WholesaleQualifiedResponse } from '../../checkout/interfaces';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { SSO } from '../../sso/sso.constants';

/**
 * @description this component will used display order confirmation
 *  or ordered item details and prices
 * @date 2018-08-04
 * @export
 * @class OrderSummaryNewComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-order-summary',
    templateUrl:
        '../templates/template3/views/order-summary_new.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/order-summary_new.component.less'
    ]
})

export class OrderSummaryNewComponent implements OnInit, OnDestroy {

    osComponentSettings: OrderSummaryComponentSettings = new OrderSummaryComponentSettings();
    @ViewChild('logoutModal') public logoutModal: AppModalDirective;
    constructor(
        private _commonService: CommonService,
        private _cacheService: CacheService,
        private _orderService: OrderService,
        private _router: Router,
        private _activatedRoute: ActivatedRoute,
        private _cartService: CartService,
        private _configurationService: ConfigurationService,
        private _appMessageService: AppMessageService,
        private _loaderService: LoaderService,
        private _shippingService: ShippingMethodService,
        private _documentService: DocumentService,
        private _addressService: AddressService,
        private _dataService: DataShareService,
        private _autoshipService: AutoshipService,
        private _activeSessionService: ActiveSessionService
    ) { }

    ngOnInit(): void {
        document.getElementById('mainContent').focus();
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof OrderSummaryNewComponent
     */
    loadDefaultSettings() {
        if (environment.dataLayer && environment.dataLayer.length > 0) {
            environment.dataLayer[0].pageCategory = 'shop-order-summary';
        }
        this.getCountriesLookup();
        this.osComponentSettings.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        this.osComponentSettings.autoshipDate = this._cacheService.get(CacheKey.AutoshipDate);
        this.osComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.osComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.subscribeRouteParams();
        this.updateUserInfoInOptInFlow();
        this.loadMemberType();
        this.getStoreData();
        this.loadCheckoutInformation();
        if (this.osComponentSettings.isAutoshipEnabled) {
            this.placeAutoshipOrder();
        } else {
            this.getAutoshipCart();
        }
        this.getOrderOrEnrollInformation();
        this.getCartSessionInfo();
        this.memeberUpgradeLogout();
        this._loaderService.stop();
    }

    /**
     * @description logout while enrolling for retail user
     * @date 2019-04-24
     * @memberof OrderSummaryNewComponent
     */
    memeberUpgradeLogout(): void {
        this._appMessageService.getMemberUpgradeNotification()
            .subscribe((response) => {
                if (response) {
                    this.logoutModal.show();
                }
            });
    }

    /**
     * @description Get Countries
     * @date 2018-07-19
     * @private
     * @memberof CheckoutNewComponent
     */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.osComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
        } else {
            this._commonService.getCountries().subscribe((res: Country[]) => {
                if (res && res.length > 0) {
                    this.osComponentSettings.countries = res;
                }
            });
        }
    }

    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof CheckoutNewComponent
     */
    private getStatesLookup(countryId: number) {
        if (countryId) {
            this._commonService.getStatesByCountry(countryId).subscribe((res: State[]) => {
                this.osComponentSettings.states = res;
                if (this.osComponentSettings.autoshipShippingAddressDetails) {
                    this.osComponentSettings.autoshipShippingAddressDetails.state = this.osComponentSettings.states
                        .find((x: State) => x.id === this.osComponentSettings.autoshipShippingAddressDetails.stateId).stateCode;
                }
            }, (err: any) => {
            });
        }
    }

    /**
     * @description this method will be used to
     * get params of weborderid and memberid
     * from route while navigating to ordersummary
     * @date 2018-08-06
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private subscribeRouteParams(): void {
        this._activatedRoute.params.subscribe(params => {
            this.osComponentSettings.webOrderId = params['webOrderId']; // (+) converts string 'id' to a number
        });
        this._activatedRoute.params.subscribe(params => {
            this.osComponentSettings.memberId = params['memberId']; // (+) converts string 'id' to a number
        });
    }

    /**
     * @description this method For updating the Member Level
     * while we are in OPT-IN Flow
     * @date 2018-08-06
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private updateUserInfoInOptInFlow(): void {
        if (this.osComponentSettings.userInfo && this.osComponentSettings.userInfo.memberId
            && this.osComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER) {
            this._commonService.getUserInfo(this.osComponentSettings.userInfo.memberId)
                .subscribe((response: Member) => {
                    this._cacheService.set(CacheKey.UserInfo, response);
                    this._appMessageService.setUpdatedUserInfo(response);
                });
        }
    }

    /**
    * @description this method retives
    * store information from cache service
    * @date 2018-07-19
    * @memberof OrderSummaryNewComponent
    */
    private getStoreData(): void {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.osComponentSettings.store = result;
            this.validateSkippedCount();
        }
        this.osComponentSettings.phoneNumberFormat =
            this._commonService.getPhoneNumberFormatByCountryCode(this.osComponentSettings.isoCountryCode);
    }

    /**
     * @description this method
     * @date 2019-04-05
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private getWholsesaleQualifiedDetails(): void {
        if (this.osComponentSettings.userInfo && this.osComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
            && !this.osComponentSettings.userInfo.wholesaleQualified) {
            this._commonService
                .getWholsesaleQualifiedDetails(this.osComponentSettings.userInfo.distributorId,
                    this.osComponentSettings.store.operatingCountry)
                .subscribe((response: WholesaleQualifiedResponse) => {
                    if (response && response.wholesaleQualified) {
                        this._cacheService.setCookieValue(CacheKey.FPCWholesaleQualified, response.wholesaleQualified);
                        this.osComponentSettings.userInfo.wholesaleQualified = response.wholesaleQualified;
                        this._cacheService.set(CacheKey.UserInfo, this.osComponentSettings.userInfo);
                    }
                });
        }
    }

    /**
     * Steps for Update Skip Count - FPC to FBO upgrade flow
     * validateSkippedCount
     * @memberof OrderSummaryNewComponent
     */
    validateSkippedCount(): void {
        this.osComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        const skipCountIncreasedCacheKey = this._cacheService.get(CacheKey.SkipCountIncreased);
        const skipCountIncreased = skipCountIncreasedCacheKey ? JSON.parse(skipCountIncreasedCacheKey) : false;
        if (this.osComponentSettings.userInfo && this.osComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
            && !skipCountIncreased) {
            let memberSkipCount = this.getMemberSkipCount();
            memberSkipCount = memberSkipCount + 1;
            this.updateSkipCount(this.osComponentSettings.userInfo.memberId, memberSkipCount);
        }
    }

    /**
    * This method used for getting updated member skipped count
    * getMemberSkipCount
    * @returns
    * @memberof CartComponent
    */
    getMemberSkipCount() {
        const memberMetaData: MemberMetaData = this.osComponentSettings.userInfo.memberMetaData
            .find(x => x.customKey === MemberMetaDataEnum.UPGRADESKIPPEDCOUNT);
        let memberSkippedCount = 0;
        if (memberMetaData && memberMetaData.customValue) {
            memberSkippedCount = Number(memberMetaData.customValue);
        }
        return memberSkippedCount;
    }

    /**
    * This method used for updating skip count
    * updateSkipCount
    * @memberof CartComponent
    */
    updateSkipCount(memberId: number, memberSkippedCount: number): void {
        this._cartService.updateMemberSkipCount(memberId, memberSkippedCount).subscribe(response => {
            if (response && response.isSuccess) {
                this._cacheService.set(CacheKey.SkipCountIncreased, JSON.stringify(true));
                this._cacheService.set(CacheKey.MemberOptinCount, memberSkippedCount);
            }
        });
    }

    /**
     * @description place Autoship Order
     * @date 2018-10-17
     * @memberof OrderSummaryNewComponent
     */
    placeAutoshipOrder(): void {
        const autoshipRequest = this._cacheService.get(CacheKey.AutoshipDetails);
        if (autoshipRequest && autoshipRequest.id) {
            this._autoshipService.updateAutoShipProfileById(autoshipRequest).subscribe((response: Autoship) => {
                if (response) {
                    this._cacheService.set(CacheKey.AutoshipDetails, autoshipRequest);
                    this.getAutoshipCart();
                }
            });
        } else {
            this._autoshipService.createAutoshipProfile(autoshipRequest).subscribe((response: Autoship) => {
                if (response) {
                    this._cacheService.set(CacheKey.AutoshipDetails, autoshipRequest);
                    this.getAutoshipCart();
                }
            });
        }
    }
    /**
     * @description this method will load autoship cart items
     * @date 2018-08-06
     * @memberof OrderSummaryNewComponent
     */
    getAutoshipCart(): void {
        this.osComponentSettings.autoshipCart = this._cacheService.get(CacheKey.AutoshipCart);
        this.osComponentSettings.autoshipDetails = this._cacheService.get(CacheKey.AutoshipDetails);
        const intialAutoshipDetails = this._cacheService.get(CacheKey.InitialAutoshipDetails);
        if (this.osComponentSettings.autoshipDetails) {
            this.getAutoshipShippingMethodDetails(this.osComponentSettings.autoshipDetails);
            this.getAutoshipShippingAddressDetails(this.osComponentSettings.autoshipDetails);
            this._cacheService.remove(CacheKey.AutoshipDetails);
        } else if (intialAutoshipDetails && intialAutoshipDetails.shippingMethodInfo && intialAutoshipDetails.shippingAddress) {
            this.osComponentSettings.autoshipShippingMethodDetails = intialAutoshipDetails.shippingMethodInfo;
            this.osComponentSettings.autoshipShippingAddressDetails = intialAutoshipDetails.shippingAddress;
        }
        this._cacheService.remove(CacheKey.AutoshipDate);
        this._cacheService.remove(CacheKey.AutoshipCart);
        this._cacheService.remove(CacheKey.InitialAutoshipDetails);
    }

    /**
     * @description get Autoship shipping method details
     * @date 2018-09-07
     * @private
     * @param {Autoship} autoship
     * @memberof OrderSummaryNewComponent
     */
    private getAutoshipShippingMethodDetails(autoship: Autoship): void {
        if (autoship && autoship.autoshipShippingInformations &&
            autoship.autoshipShippingInformations.length > 0 &&
            autoship.autoshipShippingInformations[0].shipMethodId) {
            this._shippingService.getShippinMethodDetailsById(this.osComponentSettings.store.id,
                autoship.autoshipShippingInformations[0].shipMethodId)
                .subscribe(response => {
                    if (response) {
                        this.osComponentSettings.autoshipShippingMethodDetails = response;
                    }
                });
        }
    }

    /**
     * @description Autoship Shipping Address Details
     * @date 2018-09-17
     * @private
     * @param {Autoship} autoship
     * @memberof OrderSummaryNewComponent
     */
    private getAutoshipShippingAddressDetails(autoship: Autoship): void {
        if (autoship && autoship.autoshipShippingInformations &&
            autoship.autoshipShippingInformations.length > 0 &&
            autoship.autoshipShippingInformations[0].shippingAddressId) {
            this._addressService.getAddressDetailsById(autoship.autoshipShippingInformations[0].shippingAddressId)
                .subscribe(response => {
                    if (response) {
                        this.osComponentSettings.autoshipShippingAddressDetails = response[0];
                        this.osComponentSettings.autoshipShippingAddressDetails.country =
                            this.osComponentSettings.countries.find((x: Country) => x.countryId ===
                                this.osComponentSettings.autoshipShippingAddressDetails.countryId).isocodeThree;
                        this.getStatesLookup(this.osComponentSettings.autoshipShippingAddressDetails.countryId);
                    }
                });
        }
    }

    /**
     * @description this method will load member type
     * or logeed in member information
     * @date 2018-07-25
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private loadMemberType(): void {
        this.osComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.osComponentSettings.registerMemberType = this.osComponentSettings.userInfo
            && this.osComponentSettings.userInfo.memberTypeId
            ? this.osComponentSettings.userInfo.memberTypeId : this._cacheService.get(CacheKey.RegisterMemberType);
        this.osComponentSettings.memberTitleId = this._activeSessionService.getMemberTitleId();
        this.osComponentSettings.purchaseFlow = this._commonService.getPurchaseFlowType();
    }

    /**
    * @description this method is used
    * load stored information while refreshing the page
    * @date 2018-07-21
    * @memberof OrderSummaryNewComponent
    */
    private loadCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation) {
            this.osComponentSettings.shippingInformation = checkoutInformation.shippingInformation;
            this.osComponentSettings.paymentInformation = checkoutInformation.paymentInformation;
            this.osComponentSettings.shippingMethodInformation = checkoutInformation.shippingMethodInformation;
            this.osComponentSettings.personalInformation = checkoutInformation.personalInformation;
            this.osComponentSettings.sponsorInformation = checkoutInformation.sponsorInformation;
            if (this.osComponentSettings.shippingMethodInformation
                && this.osComponentSettings.shippingMethodInformation.shippingMethod) {
                this.osComponentSettings.deliveryOptionType = this.osComponentSettings.shippingInformation.deliveryOptionType;
                this.osComponentSettings.shippingMethod = this.osComponentSettings.shippingMethodInformation.shippingMethod;
            }
            if (checkoutInformation.shippingInformation
                && checkoutInformation.shippingInformation.shippingAddress) {
                this.osComponentSettings.shippingAddress = checkoutInformation.shippingInformation.shippingAddress;
            }
        } else {
            this.continueShopping();
        }
        this.getWholsesaleQualifiedDetails();
        this.removeUnusedInformation();
    }

    /**
    * @description this method will triggrer when laoding of
    * cart items done from service
    * @date 2018-08-01
    * @private
    * @memberof ShippingMethodsNewComponent
    */
    private getCartSessionInfo(): void {
        this.osComponentSettings.cartSubscription = this._appMessageService
            .getCartItemsChanges()
            .subscribe((response) => {
                this.getCartItems();
            });
    }

    /**
     * @description this method help us load
     * information of created order or retail user info
     * based on weborderid or memberid
     * @date 2018-08-06
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private getOrderOrEnrollInformation(): void {
        if (this.osComponentSettings.webOrderId && !this.osComponentSettings.isAutoshipEnabled) {
            this.getOrderInformation();
        }
        // for retail user
        if (this.osComponentSettings.memberId && !this.osComponentSettings.isAutoshipEnabled) {
            this.getEnrollDetails();
        }
    }

    /**
     * @description this method help to load order information
     * by weborder id
     * @date 2018-08-06
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private getOrderInformation(): void {
        this._orderService.getOrderDetailsById(this.osComponentSettings.webOrderId)
            .subscribe((response: Order) => {
                this.osComponentSettings.orderDetails = response;
                if (this.osComponentSettings.orderDetails && this.osComponentSettings.orderDetails.taxMetaData
                    && this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                    && this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges.length) {
                    const gst = this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                        .find(tax => tax.taxChargeType === TaxType.GST_TAX);
                    const pst = this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                        .find(tax => tax.taxChargeType === TaxType.PST_TAX);
                    this.osComponentSettings.gstTax = gst ? gst.taxAmount : 0;
                    this.osComponentSettings.pstTax = pst ? pst.taxAmount : 0;
                }
                this.getTranslationValues(this.osComponentSettings.orderDetails.webOrderId);
                this.getCartItems();
            });
    }

    /**
     * @description this method help to get order information
     * @date 2018-08-06
     * @memberof OrderSummaryNewComponent
     */
    private getEnrollDetails(): void {
        const enrollSessionGuid: string = this._cacheService.get(CacheKey.EnrollSessionGuid);
        if (enrollSessionGuid) {
            this._commonService.getDetailsByEnrollSessionGuid(enrollSessionGuid)
                .subscribe((response: EnrollSession) => {
                    if (response) {
                        this.osComponentSettings.orderDetails = response.enrollInfo.orderInfo;
                        if (this.osComponentSettings.orderDetails && this.osComponentSettings.orderDetails.taxMetaData
                            && this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                            && this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges.length) {
                            const gst = this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                                .find(tax => tax.taxChargeType === TaxType.GST_TAX);
                            const pst = this.osComponentSettings.orderDetails.taxMetaData.orderTaxCharges
                                .find(tax => tax.taxChargeType === TaxType.PST_TAX);
                            this.osComponentSettings.gstTax = gst ? gst.taxAmount : 0;
                            this.osComponentSettings.pstTax = pst ? pst.taxAmount : 0;
                        }
                        this._cacheService.remove(CacheKey.ShareFBOID);
                        this._cacheService.removeCookieValue(CacheKey.fboId);
                        if (this.osComponentSettings.orderDetails.webOrderId) {
                            this.getTranslationValues(this.osComponentSettings.orderDetails.webOrderId);
                        }
                    }
                    this.getCartItems();
                });
        }
    }

    /**
     * @description this method will load shopping cart items
     * @date 2018-08-06
     * @memberof OrderSummaryNewComponent
     */
    getCartItems(): void {
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        if (cartSession && cartSession.items && cartSession.items.length > 0) {
            this.osComponentSettings.shoppingCart = new Cart(cartSession, this.osComponentSettings.store);
            this.osComponentSettings.productId = this.osComponentSettings.shoppingCart
                && this.osComponentSettings.shoppingCart.items ?
                this.osComponentSettings.shoppingCart.items[0].productId : null;
            // this.acknowledgePaymentDocuments();
            this._cacheService.remove(CacheKey.FBOTerms);
            this.clearCartItems();
        }
    }

    /**
    * @description
    * @date 2018-09-19
    * @param {number} memberTypeId
    * @returns {*}
    * @memberof OrderSummaryNewComponent
    */
    acknowledgePaymentDocuments(): void {
        const documents = this._cacheService.get(CacheKey.FBOTerms);
        if (documents && documents.paymentPolicies
            && documents.paymentPolicies && this.getMemberID()) {
            this._documentService.updateAcknowledgedDocuments(
                documents.paymentPolicies, this.osComponentSettings.registerMemberType, this.getMemberID()).subscribe();
        }
        this._cacheService.remove(CacheKey.FBOTerms);
    }

    /**
     * @description this mehtod will check and return memebrid
     * @date 2018-08-14
     * @private
     * @param {EnrollInfo} enrollInformation
     * @returns {number}
     * @memberof CheckoutNewComponent
     */
    private getMemberID(): number {
        let memberId: number;
        if (this.osComponentSettings.checkoutInformation && this.osComponentSettings.checkoutInformation.retuningGuestUser) {
            memberId = this.osComponentSettings.checkoutInformation.retuningGuestUser.memberId;
        } else if (this.osComponentSettings.checkoutInformation && this.osComponentSettings.checkoutInformation.guestToRetailUser) {
            memberId = this.osComponentSettings.checkoutInformation.guestToRetailUser.memberId;
        } else if (this.osComponentSettings.userInfo) {
            memberId = this.osComponentSettings.userInfo.memberId;
        } else if (this.osComponentSettings.memberId) {
            memberId = this.osComponentSettings.memberId;
        }
        return memberId;
    }

    /**
     * @description this method will clear cart items
     * @date 2018-08-06
     * @memberof OrderSummaryNewComponent
     */
    clearCartItems(): void {
        this._cacheService.remove(CacheKey.CheckoutInformation);
        this._cacheService.remove(CacheKey.CardTokenDetails);
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        const autoshipSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
        if (cartSession && cartSession.items && cartSession.items.length > 0 && !this.osComponentSettings.cartStatus.clearCart) {
            this.osComponentSettings.cartStatus.clearCart = true;
            this.clearCartSeesion(cartSession.sessionGuid, CartTypes.OrderCart);
        }
        if (autoshipSession && autoshipSession.items && autoshipSession.items.length > 0
            && !this.osComponentSettings.cartStatus.clearAutoshipCart) {
            this.osComponentSettings.cartStatus.clearAutoshipCart = true;
            this.clearCartSeesion(autoshipSession.sessionGuid, CartTypes.AutoshipCart);
        }
    }

    /**
     * Clear Cart session
     * @param sessionGuid
     */
    private clearCartSeesion(sessionGuid: string, cartType: number) {
        this.osComponentSettings.clearCartInProgress = true;
        this._cartService.removeCart(sessionGuid)
            .subscribe(response => {
                this.removeCartInfo(cartType);
                setTimeout(() => {
                    this.removeCartInfo(cartType);
                }, 2000);
            }, error => {
                this.removeCartInfo(cartType);
            });
    }

    /**
     * @description this method will remove session
     * @date 2018-08-06
     * @private
     * @param {string} sessionGuid
     * @param {number} cartType
     * @memberof OrderSummaryNewComponent
     */
    private removeCartInfo(cartType: number): void {
        if (cartType === CartTypes.AutoshipCart) {
            this._cacheService.remove(CacheKey.AutoshipCart);
            this.osComponentSettings.cartStatus.clearAutoshipCart = false;
        } else {
            this._cacheService.remove(CacheKey.CartSessionInfo);
            this._cacheService.remove(CacheKey.IsFPCOptInEligible);
            this._cacheService.remove(CacheKey.hasCartItems);
            this._cacheService.setCookieValue(CacheKey.ClearCart, 'true');
            this._cacheService.removeCookieValue(CacheKey.CartSessionGuid);
            this.osComponentSettings.cartStatus.clearCart = false;
        }
        const cartSession = {
            sessionInfo: null,
            reloadMemberCart: false
        };
        this._appMessageService.setMiniCart(cartSession);
        this.osComponentSettings.clearCartInProgress = false;
    }


    /**
     * to get dynamic translation values
     */
    getTranslationValues(webOrderId: string) {
        let sponsorName = '';
        if (this.osComponentSettings.sponsorInformation
            && this.osComponentSettings.sponsorInformation.sponsorName) {
            sponsorName = this.osComponentSettings.sponsorInformation.sponsorName;
        }
        this.osComponentSettings.translationValues = {
            webOrderId: webOrderId,
            sponsorName: sponsorName,
            savedPrice: this.osComponentSettings.shoppingCart ? this.osComponentSettings.shoppingCart.savedPrice : 0,
        };
    }


    /**
    * from retail user navigate to corporate
    */
    redirectToCorporate() {
        const shoppingCart: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        if (shoppingCart && shoppingCart.sessionGuid) {
            this._cacheService.setCookieValue(CacheKey.CartSessionGuid, shoppingCart.sessionGuid);
        }
        window.location.href = environment.corporateSiteUrl;
    }

    /**
     * Navigate to the my account
     */
    reddirectToAccount() {
        window.location.href = environment.accountSiteURL;
    }

    /**
    * loaction langitude url
    * @returns string
    */
    getLocationMap(pickUplocation: PickupLoaction): string {
        if (pickUplocation && pickUplocation.latitude && pickUplocation.longitude) {
            return ApiUrlConstants.googleMapsUrl + pickUplocation.latitude +
                ',' + pickUplocation.longitude;
        } else {
            return null;
        }
    }


    /**
     * @description this method will navigate to shopping page
     * @date 2018-08-06
     * @memberof OrderSummaryNewComponent
     */
    continueShopping() {
        this._cacheService.remove(CacheKey.GuestUser);
        this._cacheService.remove(CacheKey.RegisterMemberType);
        this.clearCartItems();
        this._cacheService.remove(CacheKey.CheckoutInformation);
        this._cacheService.removeCookieValue(CacheKey.IsAutoshipEnabled);
        this._cacheService.remove(CacheKey.CartSessionInfo);
        const cartSessionInfo = {
            sessionInfo: '',
            reloadMemberCart: true
        };
        const fpcCachekeKey = this._cacheService.get(CacheKey.FPCOptIn);
        const isFPCOptIn = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
        if (window.location.pathname.indexOf('ordersummary') > -1 && isFPCOptIn) {
            this._appMessageService.setMemberUpgradeNotification(true);
        } else {
            this._appMessageService.setMiniCart(cartSessionInfo);
            this._router.navigate([this.osComponentSettings.isoCountryCode.toLowerCase() +
                '/' + this.osComponentSettings.languageCode.toLowerCase() + '/products']);
        }
    }

    /**
     * this method will navigate to product detail page
    * @param  {Product} product
    * @returns void
    */
    navigateToProductDetail(product: Product): void {
        let selectedCategory;
        if (product.categories) {
            selectedCategory = product.categories[0];
        }
        if (product.parentProductSlug) {
            product.slug = product.parentProductSlug;
            this._dataService.variableProductOption = product.selectedOption;
        }
        if (selectedCategory && selectedCategory.slug) {
            this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
            this._router.navigate([this.osComponentSettings.isoCountryCode.toLowerCase() + '/' +
                this.osComponentSettings.languageCode.toLowerCase() + '/products/' + selectedCategory.slug + '/' + product.slug]);
        } else {
            this._router.navigate([this.osComponentSettings.isoCountryCode.toLowerCase() +
                '/' + this.osComponentSettings.languageCode.toLowerCase() + '/products/' + product.slug]);
        }
    }


    /**
     * Print order summary
     */
    printOrderSummary() {
        window.print();
    }

    /**
     * @description this method helps to remove
     * unused inforamtion once we are done with order creation
     * @date 2018-08-06
     * @private
     * @memberof OrderSummaryNewComponent
     */
    private removeUnusedInformation(): void {
        this._cacheService.removeSessionValue(CacheKey.RepeatWebOrderNumber);
        this._cacheService.removeSessionValue(CacheKey.RepeatOrderLoaded);
        this._cacheService.removeSessionValue(CacheKey.RepSiteReferralId);
        this._cacheService.removeCookieValue(CacheKey.IsAutoshipEnabled);
        this._cacheService.remove(CacheKey.CheckoutInformation);
    }

    ngOnDestroy(): void {
        if (this.osComponentSettings.cartSubscription) {
            this.osComponentSettings.cartSubscription.unsubscribe();
        }
    }


    /**
     * @description this method will navigate user to the account dashboard
     * @date 2018-08-17
     * @memberof OrderSummaryNewComponent
     * @returns void
     */
    goToYourDashboard(): void {
        const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
        const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        if (userInfo) {
            let accountUrl = environment.accountSiteURL + '/' + this.osComponentSettings.isoCountryCode.toLowerCase() + '/' +
                languageCode.toLowerCase();
            accountUrl = userInfo.memberTypeId === MemberType.DISTRIBUTOR ?
                accountUrl + '/account/dashboard' : accountUrl + '/account/my-profile';
            const memberOptinCount = this._cacheService.get(CacheKey.MemberOptinCount);
            if (memberOptinCount) {
                accountUrl = accountUrl + '?MemberOptinCount=' + memberOptinCount;
            }
            const fpcCachekeKey = this._cacheService.get(CacheKey.FPCOptIn);
            const isFPCOptIn = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
            if (window.location.pathname.indexOf('ordersummary') > -1 && isFPCOptIn) {
                this._appMessageService.setMemberUpgradeNotification(true);
            } else {
                window.location.href = accountUrl;
            }
        } else {
            this._commonService.navigateToLogin(false, true);
        }
    }

    /**
 * @description Go to myaccount Autoship Profile
 * @date 2018-09-17
 * @memberof OrderSummaryNewComponent
 */
    navigateAutoshipProfile(): void {
        if (this.osComponentSettings.userInfo) {
            const accountUrl = environment.accountSiteURL + '/' + this.osComponentSettings.isoCountryCode.toLowerCase() + '/' +
                this.osComponentSettings.languageCode.toLowerCase() +
                '/account/autoship-preferences';
            const fpcCachekeKey = this._cacheService.get(CacheKey.FPCOptIn);
            const isFPCOptIn = fpcCachekeKey ? JSON.parse(fpcCachekeKey) : false;
            if (window.location.pathname.indexOf('ordersummary') > -1 && isFPCOptIn) {
                this._appMessageService.setMemberUpgradeNotification(true);
            } else {
                window.location.href = accountUrl;
            }
        } else {
            this._commonService.navigateToLogin(false, true);
        }
    }

    /**
 * @description logout from system
 * @memberof AppHeaderComponent
 */
    logout(): void {
        // clear keycloak cache
        if (this.osComponentSettings.userInfo && this.osComponentSettings.userInfo.distributorId) {
            this._commonService.clearKeyCloakCache(this.osComponentSettings.userInfo.distributorId)
                .subscribe((response: any) => {
                    if (response) {
                        this.logOutSettings();
                    }
                }, error => {
                    this.logOutSettings();
                });
        } else {
            this.logOutSettings();
        }
    }

    /**
     * @description This method used for logout from syatem
     * logOutSettings
     * @memberof AppHeaderComponent
     */
    logOutSettings(): void {
        this._cacheService.remove(CacheKey.CheckoutInformation);
        this._cacheService.remove(CacheKey.hasCartItems);
        this.osComponentSettings.cookieService.set(CacheKey.ClearCart, 'true', null, environment.cookiePath, environment.cookieDomain);
        this._cacheService.remove(CacheKey.CheckoutStep);
        this._cacheService.remove(CacheKey.RecentlyViewedProducts);
        this._cacheService.remove(CacheKey.OrderRules);
        this._cacheService.remove(CacheKey.QuickOrderList);
        this._cacheService.removeSessionValue(CacheKey.RepeatWebOrderNumber);
        this._cacheService.remove(CacheKey.WishListSession);
        this._cacheService.remove(CacheKey.CartSessionInfo);
        this._cacheService.remove(CacheKey.UserDefaultAddress);
        this._cacheService.remove(CacheKey.AutoshipCart);
        this._cacheService.remove(CacheKey.AutoshipDetails);
        this._cacheService.remove(CacheKey.RegisterMemberType);
        this._cacheService.removeCookieValue(CacheKey.IsAutoshipEnabled);
        this._cacheService.remove(CacheKey.MyActionCenterModalDisplayed);
        this._cacheService.remove(CacheKey.IgnoreOptInSkipCount);
        this._cacheService.remove(CacheKey.MemberOptinCount);
        this._cacheService.remove(CacheKey.SkipCountIncreased);
        this._cacheService.setCookieValue(CacheKey.IsUserLogout, true);
        if (this._cacheService.get(CacheKey.GuestUser)
            || this._cacheService.get(CacheKey.RegisterMemberType)) {
            this._cacheService.remove(CacheKey.GuestUser);
            this._cacheService.remove(CacheKey.RegisterMemberType);
            this._router.navigate([this.osComponentSettings.isoCountryCode.toLowerCase()
                + '/' + this.osComponentSettings.languageCode.toLowerCase() + '/products']);
        } else {
            this._cacheService.remove(CacheKey.SSOToken);
            this._cacheService.remove(CacheKey.Refresh_token);
            this._cacheService.remove(CacheKey.UserInfo);
            this._cacheService.remove(CacheKey.CartSessionInfo);
            this._cacheService.remove(CacheKey.AutoshipCart);
            this._cacheService.remove(CacheKey.RecentlyViewedProducts);
            this._cacheService.removeCookieValue(CacheKey.CartSessionGuid);
            this._cacheService.removeCookieValue(CacheKey.IsAutoshipEnabled);
            this._cacheService.removeCookieValue(CacheKey.HideFPCOptInMessage);
            if (this._router.url.split('/').indexOf('ordersummary') > -1 ||
                this._router.url.split('/').indexOf('checkout') > -1) {
                this._cacheService.set(CacheKey.Nav_path, '/' + this.osComponentSettings.isoCountryCode.toLowerCase() + '/'
                    + this.osComponentSettings.languageCode.toLowerCase() + '/products');
            }
            if (localStorage.getItem('Impersonation') === 'true') {
                localStorage.removeItem('Impersonation');
            }
            localStorage.clear();
            if (SSO.isRemoveObsoleteCookie()) {
                localStorage.removeItem(SSO.ACCESS_TOKEN);
                localStorage.removeItem(SSO.REFRESH_TOKEN);
                localStorage.removeItem(SSO.LOCAL_MEMBER_SESSION_ID);
                localStorage.removeItem(SSO.IS_NEW_TOKEN);
                this.osComponentSettings.cookieService.delete(SSO.MEMBER_SESSIONID, environment.cookiePath, environment.cookieDomain);
            } else {
                this.osComponentSettings.cookieService.delete(SSO.ACCESS_TOKEN, environment.cookiePath, environment.cookieDomain);
                this.osComponentSettings.cookieService.delete(SSO.REFRESH_TOKEN, environment.cookiePath, environment.cookieDomain);
            }
            this.osComponentSettings.cookieService.delete(SSO.NONCE, environment.cookiePath, environment.cookieDomain);
            this.osComponentSettings.cookieService.delete(SSO.MEMBER_ID, environment.cookiePath, environment.cookieDomain);
            this.osComponentSettings.cookieService.delete(CacheKey.FPCWholesaleQualified, environment.cookiePath, environment.cookieDomain);
            window.location.href = SSO.getSSOLogoutUrl(environment.corporateSiteUrl);
        }
    }
}
