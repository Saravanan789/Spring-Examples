import { Pipe, PipeTransform } from '@angular/core';
import 'intl';
import 'intl/locale-data/jsonp/en.js';

@Pipe({
  name: 'fieldFilter'
})
export class FieldFilterPipe implements PipeTransform {
    transform(arr: any[], field: string, value: string): any[] {
        if (!arr) {
            return [];
        }
        return arr.filter(it => it[field] === value);
    }
}
