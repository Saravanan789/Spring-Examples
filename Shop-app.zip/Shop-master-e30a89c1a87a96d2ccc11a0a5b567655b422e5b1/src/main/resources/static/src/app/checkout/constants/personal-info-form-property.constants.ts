export enum PersonalInfoFormConstants {
    EMAIL = 'email',
    FIRSTNAME = 'firstName',
    LASTNAME = 'lastName',
    PASSWORD = 'pass_word',
    CONFIRM_PASSWORD = 'confirmPassword',
    MIDDLENAME = 'middleName',
    PHONENUMBER = 'phoneNumber',
    MINLENGTH = 'minLength',
    MAXLENGTH = 'maxLength',
    PATTERN = 'pattern'
}
