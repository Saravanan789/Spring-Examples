import { PaymentComponentSettings } from './payment.model';

export class WorldpayXMLPaypalComponentSettings extends PaymentComponentSettings {

}
