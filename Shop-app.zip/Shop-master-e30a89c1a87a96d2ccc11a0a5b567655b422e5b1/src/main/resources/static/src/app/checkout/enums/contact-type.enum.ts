export enum ContactType {
    PHONE = 'PHONE',
    ALT_PHONE = 'ALT_PHONE',
    EMAIL = 'EMAIL',
    ALT_EMAIL = 'ALT_EMAIL',
    HOME_PHONE_NO = 'HOME_PHONE_NO',
    WORK_PHONE_NO = 'WORK_PHONE_NO',
    MOBILE = 'MOBILE'
}
