import { CommonService } from '../../shared/services/common.service';
import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Member } from '../../shared/interfaces/member.interface';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Product } from '../../products/interfaces/product.interface';
import { MemberLevel } from '../../shared/enums';

@Component({
    selector: 'app-price-popover',
    templateUrl:
        '../templates/template3/views/price-popover.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/price-popover.component.less'
    ],
    encapsulation: ViewEncapsulation.None
})
export class PricePopoverComponent implements OnInit {
    @Input() product: Product;
    @Input() memberTitleId: MemberLevel;
    memberTitle = MemberLevel;
    discountPercenatge = 0;
    userInfo: Member;
    translationValues: any;
    wholesaleQualified: boolean;
    @Input() container = 'body';
    @Input() customClass = '';
    constructor(private _commonService: CommonService, private _cacheService: CacheService) {

    }

    ngOnInit() {
        this.userInfo = this._cacheService.get(CacheKey.UserInfo);
        if (this.userInfo && this.userInfo.memberTitle) {
            this.translationValues = {
                memberTitle: this.userInfo.memberTitle.toLowerCase()
            };
            this.memberTitleId = this.userInfo.memberTitleId;
            this.wholesaleQualified = this.userInfo.wholesaleQualified ? true : false;
        }
        if (!this.memberTitleId) {
            this.memberTitleId = MemberLevel.RETAIL;
        }
        this.discountPercenatge = this._commonService.getDiscountPerc(this.memberTitleId, this.wholesaleQualified);
        this.customClass += ' price-popover';
    }

    /**
     * @description method to get total savings
     * @param {Product} product
     * @returns {number}
     * @memberof PricePopoverComponent
     */
    getTotalSavings(product: Product): number {
        return this._commonService.totalSavingsCalc(product, this.memberTitleId, this.wholesaleQualified);
    }


    /**
     * @param {*} popTemplate
     * @param {*} showhide
     * @memberof PricePopoverComponent
     */
    focusPopOver(popTemplate: any, showhide: any) {
        if (showhide) {
            document.getElementById('popTemplate').focus();
        }

    }
}
