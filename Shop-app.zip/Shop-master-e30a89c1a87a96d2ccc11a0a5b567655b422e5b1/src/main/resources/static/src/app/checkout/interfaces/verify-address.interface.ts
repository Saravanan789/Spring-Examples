export interface VerifyAddress {
  id?: number;
  state: string;
  country: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  addressLine4: string;
  postalCode: string;
  city: string;
  name: string;
  countryCode: string;
}
