import { CartRoutingModule } from './cart-routing.module';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CartModuleConstants } from './cart-module.constants';
import { AppCommonModule } from '../common/app-common.module';
import { ModalModule, PopoverModule, TypeaheadModule } from 'ngx-bootstrap';
import { CanActivateCartGuard } from '../shared/guards/can-activate-cart.guard';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { ShippingMethodService } from '../checkout/services';

@NgModule({
  imports: [
    AppCommonModule, PopoverModule.forRoot(),
    CartRoutingModule,
    ModalModule.forRoot(),
    TypeaheadModule.forRoot(),
    NguiAutoCompleteModule
  ],
  declarations: CartModuleConstants.MODULE_COMPONENTS,
  providers: [
    CanActivateCartGuard, ShippingMethodService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: CartModuleConstants.MODULE_COMPONENTS
})
export class CartModule { }
