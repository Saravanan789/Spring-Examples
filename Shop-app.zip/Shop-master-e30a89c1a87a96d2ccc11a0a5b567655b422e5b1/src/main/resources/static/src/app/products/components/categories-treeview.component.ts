import { ProductService } from '../services/product.service';
import { Subscription } from 'rxjs/Subscription';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonService } from '../../shared/services/common.service';
import { ProductMessageService } from '../services/product-message.service';
import { CacheService } from '../../shared/services/cache.service';
import { AppMessageService } from '../../app-message.service';
import { Location } from '@angular/common';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { PlatformLocation } from '@angular/common';
import { Meta, Title } from '@angular/platform-browser';
import { MetaTagConstants } from '../../shared/constants/meta-tag.constants';

@Component({
  selector: 'app-tree-view,[tree-view]',
  templateUrl:
    '../templates/template3/views/categories-treeview.component.html',
  encapsulation: ViewEncapsulation.None
})
export class TreeViewComponent implements OnInit {
  categoryId: number;
  @Input() treeData: any[];
  isNavCollapsed: boolean;
  @Input() level: number;
  @Input() node: any = {};
  isCategoryBackNavigation = false;
  config = {
    wheelSpeed: 2,
    useBothWheelAxes: true,
    scrollYMarginOffset: 2
  };
  sideNavSubscription: Subscription;
  categorySlug: string;
  searchValue: any;

  constructor(
    private _productMessageService: ProductMessageService,
    private _appMessageService: AppMessageService,
    private _cacheService: CacheService,
    private _productService: ProductService,
    private _commonService: CommonService,
    private meta: Meta,
    private title: Title) { }

  ngOnInit() {
    this._productMessageService.getProductsByCategory().subscribe((category: any) => {
      if (category) {
        this.setSelectedCategory(category);
      }
    });
  }

  /**
   * To retain search criteria on browser back Navigation
   * @returns boolean
   */
  getSearchProdcuts(): boolean {
    this.searchValue = this._commonService.getParamValueFromUrl('search');
    if (!this.searchValue && this._cacheService.getCookieValue(CacheKey.HeaderSearch)) {
      const headerSearch = JSON.parse(this._cacheService.getCookieValue(CacheKey.HeaderSearch));
      this.searchValue = headerSearch.searchValue;
    }
    if (this.searchValue) {
      this.node.isOpen = false;
      const headerSearch = {
        category: '',
        searchValue: this.searchValue
      };
      this._cacheService.setCookieValue(CacheKey.HeaderSearch, JSON.stringify(headerSearch));
      this._productMessageService.setLoadDefaultProducts(headerSearch);
      return true;
    }
  }


  /**
  * to hide side nav menu
  */
  sideNavClose() {
    this.isNavCollapsed = false;
    this._productService.sideNavClose(false);
  }

  /**
   * to focus back to product categories expansion
   * in order to avoid background navigation while keyboard access
   */
  focusBackToProductCategories() {
    document.getElementById('productCategoriesMenu').focus();
  }

  /**
     * to toggle tree view and to emit the selected category
     * @param  {any} item
     * @param {boolean} isTabbed
     * @returns void
     */
  categoryTreeOpen(item: any, isTabbed?: boolean): void {
    this._cacheService.removeCookieValue(CacheKey.HeaderSearch);
    this.categoryId = item.id;
    const countryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this._appMessageService.setShowProductBanner(false);
    const treeIdx = this.treeData.findIndex(x => x.productCategoryId === item.productCategoryId);
    this._appMessageService.setCategoryTreeOpenIndex(treeIdx);
    item.isOpen = !item.isOpen;
    item['isEnableHeader'] = false;
    if (item && item.meta) {
      const metaTitle = item.meta.title || MetaTagConstants.metaTitle;
      const description = item.meta.description || MetaTagConstants.metaDescription;
      this.title.setTitle(metaTitle);
      this.meta.updateTag({ name: 'description', content: description });
    }
    this.setSelectedCategory(item);
    if (item.slug) {
      window.history.pushState(null, null, countryCode.toLowerCase() + '/' + languageCode.toLowerCase() + '/' + item.slug);
    } else {
      window.history.pushState(null, null, countryCode.toLowerCase() + '/' + languageCode.toLowerCase() + '/products');
    }
    this._productMessageService.setProductsByCategory(item);
    this._appMessageService.setHeaderDataReset();
    if (isTabbed) {
      this._commonService.focusTargetElement('sort-by-label');
    }
  }

  setSelectedCategory(item: any): void {
    this.treeData = this.treeData.map(x => {
      if (x.productCategoryId === item.productCategoryId
        && (x.isCustomCatalog === item.isCustomCatalog)) {
        x.isOpen = true;
      } else {
        x.isOpen = false;
      }
      return x;
    });
  }
}
