import { ContactTypeValue, ContactType } from '../enums';

export interface MemberContact {
    id?: number;
    value: string;
    contactType?: ContactType;
    contactTypeID?: number;
}
