export enum AddressType {
    SHIPPING = 40,
    BILLING = 50,
    MAILING = 49,
    PICKUP = 51
}

export enum AddressOptions {
    SHIPPING = 'Shipping',
    ORIGINALADDRESS = 'originalAddress',
    SUGGESTEDADDRESS = 'suggestedAddress'
}

export enum AddressSchemaFormFrameworkType {
    BOOTSTRAP4 = 'bootstrap-4'
}
