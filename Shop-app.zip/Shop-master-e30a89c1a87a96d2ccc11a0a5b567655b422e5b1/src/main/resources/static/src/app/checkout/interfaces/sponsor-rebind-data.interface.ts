import { SponsorWizardSearchType } from '../enums';

export interface RebindSponsorData {
    sponsorWizardType: SponsorWizardSearchType;
    sponsorId: string;
    firstName: string;
    lastName: string;
    state: number;
    country: number;
    city: string;
    zipCode: string;
    language: string;
    isDefaultSponsorSelected?: boolean;
}
