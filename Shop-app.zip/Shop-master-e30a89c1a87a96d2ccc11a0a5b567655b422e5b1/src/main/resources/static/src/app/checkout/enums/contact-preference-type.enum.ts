export enum ContactPreferenceType {
    Email = 20,
    Phone = 21,
    NotifyMe = 22
}
