import { Address } from '../../common/interfaces';

export interface PayvisionSavedCard {
    cardToken: string;
    expiryMonth: string;
    expiryYear: string;
    nameOnTheCard: string;
    cardType: string;
    maskedCard: string;
    customerId: string;
    defaultCard: boolean;
    id: number;
    billingAddress: Address;
    billingAddressId: number;
    token: string;
}
