export enum ShippingMemberType {
    DISTRIBUTOR = 4,
    RETAIL = 6
}
