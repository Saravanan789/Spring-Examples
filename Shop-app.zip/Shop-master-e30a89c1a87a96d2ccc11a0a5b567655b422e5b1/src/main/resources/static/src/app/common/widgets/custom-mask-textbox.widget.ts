import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';

import { Http } from '@angular/http';
import { JsonSchemaFormService } from 'angular4-json-schema-form-updated';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Subscription } from 'rxjs/Subscription';
import { Member } from '../../shared/interfaces';
import { ConfigurationService } from '../../shared/services';

@Component({
    // tslint:disable-next-line:component-selector
    selector: 'custom-mask-widget',
    template: `
    <!-- [class]="options?.htmlClass || ''"-->
    <div [class.floatLabelContainer]="true">
      <label *ngIf="options?.title"
        [attr.for]="'control' + layoutNode?._id"
        [class]="options?.labelHtmlClass || ''"
        [style.display]="options?.notitle ? 'none' : ''"
        [innerHTML]="options?.title"></label>
      <input float-label
        [dropSpecialCharacters]="false" [mask]="options?.maskFormat"
        [formControl]="formControl"
        [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
        [attr.list]="'control' + layoutNode?._id + 'Autocomplete'"
        [attr.maxlength]="options?.maxLength"
        [attr.minlength]="options?.minLength"
        [attr.pattern]="options?.pattern"
        [attr.placeholder]="options?.placeholder"
        [attr.required]="options?.required"
        [class]="options?.fieldHtmlClass || ''"
        [disabled]="controlDisabled"
        [id]="'control' + layoutNode?._id"
        [name]="controlName"
        [readonly]="options?.readonly ? 'readonly' : null"
        [type]="options?.widgetType"
        [value]="controlValue"
        (input)="updateValue($event)"
        (keyup)="removeError()">
        <datalist *ngIf="options?.typeahead?.source"
          [id]="'control' + layoutNode?._id + 'Autocomplete'">
          <option *ngFor="let word of options?.typeahead?.source" [value]="word">
        </datalist>
        <!-- Email verification spinner block start -->
        <span *ngIf="layoutNode?.name==='email' && isShowLoader" tabindex="0" class="personal-info--email-info">
        <i class="fa fa-spinner"></i></span>
        <!-- Email verification spinner block end -->
    </div>
    <span *ngIf="customMessage" [class]="'error custom-error'">{{customMessage}}</span>`,
})
export class CustomMaskTextboxComponent implements OnInit {
    formControl: AbstractControl;
    controlName: string;
    controlValue: string;
    controlDisabled = false;
    boundControl = false;
    customMessage: any;
    options: any;
    selectSubscription: Subscription;
    optionsGetUrl: any;
    validateUrl: any;
    storeId: any;
    isoCountryCode: string;
    enrollCountryCode: string;
    autoCompleteList: string[] = [];
    userInfo: Member;
    isShowLoader = false;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(
        private jsf: JsonSchemaFormService, private _http: Http,
        private chRef: ChangeDetectorRef, private _cacheService: CacheService,
        private _configurationService: ConfigurationService
    ) { }

    ngOnInit() {
        this.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.storeId = this._cacheService.get(CacheKey.StoreConfiguration).id;
        this.options = this.layoutNode.options || {};
        if (this.options) {
            this.options.widgetType = this.options.widgetType || 'text';
            this.jsf.initializeControl(this);
        }
    }

    /**
     * @returns void
     */
    removeError(): void {
        sessionStorage.removeItem('customError-' + this.controlName);
    }

    /**
     * @param  {any} event
     */
    updateValue(event: any) {
        this.jsf.updateValue(this, event.target.value);
    }
}
