export interface DeliveryOptionTypeResponse {
    id: number;
    optionValue: string;
}
