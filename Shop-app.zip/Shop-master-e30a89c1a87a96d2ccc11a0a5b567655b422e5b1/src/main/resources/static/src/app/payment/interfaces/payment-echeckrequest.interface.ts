import { Address } from '../../common/interfaces';

/**
 * This is for validating echeck request
 *
 * @export
 * @interface PaymentEcheckRequest
 */
export interface PaymentEcheckRequest {
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    accountType: string;
    mecTransactionID: string;
    nameOnBankAccount: string;
    customMessage: string;
    reusable: boolean;
    defaultEcheck: boolean;
    eCheckID: number;
    addressOne?: string;
    addressTwo?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
    name?: string;
    email: string;
    phone: string;
}

/**
 * save personal check request object.
 */
export interface PersonalCheck {
    id: number;
    billingAddressId: number;
    billingAddress: Address;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    accountType: string;
    nameOnBankAccount: string;
    customMessage: string;
    reusable: boolean;
    defaultECheck: boolean;
    customerId: number;
    billingAddressRequired: boolean;
    storeId: number;
    referenceId?: string;
    email: string;
    phone: string;
}
