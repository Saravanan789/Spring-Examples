import { PaymentProcessor, PaymentStatus } from '../enums';

export interface PaymentFailResponse {
    errorCode: string;
    errorMessage: string;
    paymentStatus: PaymentStatus;
    paymentProcessor: string;
    displayRetryBtn: boolean;
}
