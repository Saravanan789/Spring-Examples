import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CreditCardDirectivesModule } from 'angular-cc-library';
import { AppCommonModule } from '../common/app-common.module';
import { ModalModule, BsDropdownModule, TabsModule, TypeaheadModule } from 'ngx-bootstrap';
import { PaymentRoutingModule } from './payment-routing.module';
import { PaymentModuleConstants } from './payment-module.constants';
import { PaymentService, PayvisionService, EcheckService, WorldpayXMLService, PaymentMessageService } from './services';

@NgModule({
    imports: [
        AppCommonModule,
        CreditCardDirectivesModule,
        ModalModule,
        PaymentRoutingModule,
        BsDropdownModule.forRoot(),
        TabsModule.forRoot(),
        TypeaheadModule.forRoot()
    ],
    declarations: [PaymentModuleConstants.MODULE_COMPONENTS],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [PaymentService, PayvisionService, EcheckService, WorldpayXMLService, PaymentMessageService],
})
export class PaymentModule { }
