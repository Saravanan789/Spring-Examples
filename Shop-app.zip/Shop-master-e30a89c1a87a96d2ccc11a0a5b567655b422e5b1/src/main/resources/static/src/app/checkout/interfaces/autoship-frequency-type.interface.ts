export interface AutoshipFrequencyType {
    id: number;
    rowStateId: number;
    name: string;
    description: string;
}
