import { ContactTypeValue } from '../enums';

export class ContactTypeConstants {
    public static phoneTypes = [
        { value: ContactTypeValue.PHONE, name: 'Phone' },
        { value: ContactTypeValue.MOBILE, name: 'Mobile' }
    ];
}
