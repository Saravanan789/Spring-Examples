export interface Categories {
  id: number;
  storeId: number;
  productCategoryId: number;
  productCategoryGroupId: number;
  parentCategoryConfigId: number;
  categoryName: string;
  isOpen?: boolean;
  slug: string;
  subCategory: Categories[];
  isCustomCatalog: boolean;
  description: string;
}
