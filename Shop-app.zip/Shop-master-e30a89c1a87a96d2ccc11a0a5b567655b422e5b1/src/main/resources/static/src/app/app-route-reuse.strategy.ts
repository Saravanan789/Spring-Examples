import { RouteReuseStrategy, DetachedRouteHandle, ActivatedRouteSnapshot } from '@angular/router';
import { ProductCacheService } from './products/services/product-cache.service';
import { Inject, Injectable } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { ComponentNames } from './shared/constants/component-names.constants';

@Injectable()
export class AppRouteReuseStrategy extends RouteReuseStrategy {
    componentsToCache: string[] = [ComponentNames.PRODUCT_COMPONENT];
    snapshots: { [key: string]: DetachedRouteHandle } = {};

    private isBrowserBack: boolean;
    constructor(private _productCacheService: ProductCacheService,
        private platformLocation: PlatformLocation) {
        super();
        // To notify broswer back button pressed
        this.platformLocation.onPopState((event: any) => {
            event.stopImmediatePropagation();
            this.isBrowserBack = true;
        });
    }
    /**
     * It will be triggered, when we navigate to other route
     * @param {ActivatedRouteSnapshot} route
     * @returns {boolean}
     * @memberof AppRouteReuseStrategy
     */
    shouldDetach(route: ActivatedRouteSnapshot): boolean {
        const component: any = route.data;
        // resetting the back notification
        if (component && component.name !== ComponentNames.PRODUCT_DETAIL_COMPONENT) {
            this.isBrowserBack = false;
            this._productCacheService.setDetailbackNavigation(false);
        }
        // store then scroll position while navigating from product list
        if (component && this.componentsToCache.indexOf(component.name) > -1) {
            this._productCacheService.setScrollPosition();
            return true;
        }
        const handler: any = this.snapshots[ComponentNames.PRODUCT_COMPONENT];
        // Destroys the product component when we create a new Product component
        if (component && component.name === ComponentNames.PRODUCT_DETAIL_COMPONENT
            && handler && handler.componentRef && !this.isBrowserBack) {
            this.snapshots[ComponentNames.PRODUCT_COMPONENT] = null;
            handler.componentRef.destroy();
            return false;
        } else if (component && component.name !== ComponentNames.PRODUCT_DETAIL_COMPONENT
            && component.name !== ComponentNames.PRODUCT_COMPONENT
            && handler && handler.componentRef) {
            this.snapshots[ComponentNames.PRODUCT_COMPONENT] = null;
            handler.componentRef.destroy();
        }
        return false;
    }
    /**
     *
     * To store detached routes(only called when should detach returns true)
     * @param {ActivatedRouteSnapshot} route
     * @param {DetachedRouteHandle} handle
     * @memberof AppRouteReuseStrategy
     */
    store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
        const component: any = route.data;
        // Stores the detached route
        if (component && component.name === ComponentNames.PRODUCT_COMPONENT) {
            this.snapshots[ComponentNames.PRODUCT_COMPONENT] = handle;
        }
    }
    /**
     * Called when the route is going to active
     * place where we can check the saved routes exists or not
     * @param {ActivatedRouteSnapshot} route
     * @returns {boolean}
     * @memberof AppRouteReuseStrategy
     */
    shouldAttach(route: ActivatedRouteSnapshot): boolean {
        const component: any = route.data;
        // Checks whether is product component and only through browser back navigation
        if (component && component.name === ComponentNames.PRODUCT_COMPONENT && this.isBrowserBack) {
            return !!this.snapshots[ComponentNames.PRODUCT_COMPONENT];
        }
        return false;
    }
    /**
     * called when the shouldReuseRoute returns false
     * To send the stored routes to Router to show saved route instead of recreating it
     * if returns null new route component will be created
     * @param {ActivatedRouteSnapshot} route
     * @returns {DetachedRouteHandle}
     * @memberof AppRouteReuseStrategy
     */
    retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle {
        const component: any = route.data;
        // sends the saved route to Router
        if (component && component.name === ComponentNames.PRODUCT_COMPONENT && this.isBrowserBack) {
            return this.snapshots[ComponentNames.PRODUCT_COMPONENT];
        }
        return null;
    }
    /**
     * This is called first and decides whether to reuse the current route or not
     * if returns true the current route will be reused
     * if returns false then it will retrive the stored routes
     * @param {ActivatedRouteSnapshot} prevRoute
     * @param {ActivatedRouteSnapshot} nextRoute
     * @returns {boolean}
     * @memberof AppRouteReuseStrategy
     */
    shouldReuseRoute(prevRoute: ActivatedRouteSnapshot, nextRoute: ActivatedRouteSnapshot): boolean {
        if (prevRoute.routeConfig && nextRoute.routeConfig && prevRoute.routeConfig.data && nextRoute.routeConfig.data) {
            if (prevRoute.routeConfig.data.name === ComponentNames.PRODUCT_DETAIL_COMPONENT
                && nextRoute.routeConfig.data.name === ComponentNames.PRODUCT_COMPONENT
                && this.isBrowserBack) {
                this._productCacheService.setDetailbackNavigation(true);
            } else if (prevRoute.routeConfig.data.name === ComponentNames.PRODUCT_COMPONENT
                && nextRoute.routeConfig.data.name === ComponentNames.PRODUCT_COMPONENT) {
                this._productCacheService.setDetailbackNavigation(false);
            }
        }
        return prevRoute.routeConfig === nextRoute.routeConfig;
    }
}
