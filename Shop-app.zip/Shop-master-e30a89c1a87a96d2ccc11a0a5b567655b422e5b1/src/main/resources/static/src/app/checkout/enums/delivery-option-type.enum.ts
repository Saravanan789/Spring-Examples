export enum DeliveryOptionType {
    Delivery = 'Delivery',
    Pickup = 'Pickup'
}
