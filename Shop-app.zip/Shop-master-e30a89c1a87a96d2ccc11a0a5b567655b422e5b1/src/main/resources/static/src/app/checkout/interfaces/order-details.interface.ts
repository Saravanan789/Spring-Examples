import { PaymentLineItem } from '../../payment/interfaces';

export interface OrderDetails {
  orderId: number;
  lineItems: PaymentLineItem;
}

