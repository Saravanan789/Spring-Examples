export enum ProductReviewSuccessNotification {
    ReviewAfterApproval = 'Thank you! Your review has been received.',
    ReviewBeforeApproval = 'Thank you! Your review has been received and, if approved, will be posted soon.',
}
