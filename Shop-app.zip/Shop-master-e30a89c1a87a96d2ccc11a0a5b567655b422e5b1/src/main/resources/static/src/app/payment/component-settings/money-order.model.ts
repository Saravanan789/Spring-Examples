import { PaymentComponentSettings } from './payment.model';
import { Address } from '../../common/interfaces';
import { PaymentInformation } from '../../checkout/interfaces';

export class MoneyOrderComponentSettings extends PaymentComponentSettings {
    shippingAddress: Address;
    viewBillingAddress: boolean;
    shippingAsBilling: boolean;
    billingAddress: Address;
    paymentInformation: PaymentInformation;
    moneyOrderBillingSchemaUrl: string;
}
