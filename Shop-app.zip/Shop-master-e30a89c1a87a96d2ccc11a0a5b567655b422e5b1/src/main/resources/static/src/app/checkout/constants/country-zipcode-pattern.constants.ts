export class CountryZipCodePattern {

  static USA = '';
  static CAN = '';
  static GBR = '';
  static LUX = '';
  static NLD = '';
  static BEL = '';

  /**
   * checks with  particular country zip code pattern
   * @param countryCode
   */
  static getCountryZipCodePattern(countryCode: string): string {
    let pattern = '';
    switch (countryCode.toUpperCase()) {
      case 'USA':
        pattern = '^[0-9]{5}(-[0-9]{4})?$';
        break;
      case 'CAN':
        pattern = '^[ABCEGHJKLMNPRSTVXY]{1}[0-9]{1}[A-Z]{1} *[0-9]{1}[A-Z]{1}[0-9]{1}$';
        break;
      case 'GRB':
        pattern = '[A-Z]{1,2}[0-9R][0-9A-Z]? (?:(?![CIKMOV])[0-9][a-zA-Z]{2})';
        break;
      case 'LUX':
        pattern = '^((1|2|4|9)[0-9][0-9][0-9]|(3)[2-9][0-9][0-9]|(5)' +
        '[2-9][0-9][0-9]|(6)[1-9][0-9][0-9]|(7)[2-7][0-9][0-9]|(8)[0-8][0-9][0-9])$';
        break;
      case 'NLD':
        pattern = '^(?:NL-)?(?:[1-9]\\d{3}?(?:[A-EGHJ-NPRTVWXZ][A-EGHJ-NPRSTVWXZ]|S[BCEGHJ-NPRTVWXZ])?)$';
        break;
      case 'BEL':
        pattern = '^(?:(?:[1-9])(?:\\d{3}))$';
        break;
      default:
        pattern = '^[0-9]{5}(-[0-9]{4})?$';
    }
    return pattern;
  }
}
