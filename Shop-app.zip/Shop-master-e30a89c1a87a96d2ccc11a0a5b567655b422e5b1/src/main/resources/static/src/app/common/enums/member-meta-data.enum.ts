export enum MemberMetaDataEnum {
    UPGRADESKIPPEDCOUNT = 'UpgradeSkippedCount'
}
