import { PaymentRegistrationResponse } from '../../payment/interfaces';

export interface PayvisionInformation {
    payvisionRegistrationResponse: PaymentRegistrationResponse;
}
