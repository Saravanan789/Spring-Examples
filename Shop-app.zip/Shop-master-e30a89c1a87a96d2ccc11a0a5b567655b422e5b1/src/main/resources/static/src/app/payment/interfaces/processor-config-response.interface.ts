import { PaymentProcessorConfig } from './payment-processor-config.interface';

export interface ProcessorConfigResponse {
    paymentMethodModels: PaymentProcessorConfig;
}
