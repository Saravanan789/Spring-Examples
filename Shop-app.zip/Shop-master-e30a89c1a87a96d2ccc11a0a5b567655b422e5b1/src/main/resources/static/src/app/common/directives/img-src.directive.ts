import { Directive, ElementRef, Input, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';

// tslint:disable-next-line:directive-selector
@Directive({ selector: '[imgSrc]' })
export class ImgSrcDirective implements OnInit {
  @Input() imgSrc: string;
  elem: ElementRef;

  constructor(el: ElementRef) {
    this.elem = el;
  }

  ngOnInit() {
    if (environment.production) {
      this.elem.nativeElement.src =
        environment.uiTemplateBaseUrl + this.imgSrc;
    } else {
      this.elem.nativeElement.src = environment.uiTemplateBaseUrl + this.imgSrc;
    }
  }
}
