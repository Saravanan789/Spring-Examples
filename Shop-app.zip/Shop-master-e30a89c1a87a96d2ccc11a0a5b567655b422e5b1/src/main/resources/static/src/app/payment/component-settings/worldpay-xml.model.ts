import { PaymentComponentSettings } from './payment.model';

export class WorldpayXMLComponentSettings extends PaymentComponentSettings {

}
