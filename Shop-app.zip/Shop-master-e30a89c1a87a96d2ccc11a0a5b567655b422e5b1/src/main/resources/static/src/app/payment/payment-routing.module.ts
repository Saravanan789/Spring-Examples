import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymentComponent, PaymentStatusComponent } from './components';

const routes: Routes = [
    { path: '', component: PaymentComponent },
    { path: ':paymentProcessor/:paymentStatus', component: PaymentStatusComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PaymentRoutingModule { }

