import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { PaymentMethodTypes } from '../enums/payment-method-types.enum';
import { StorePaymentMethod, PaymentProcessorConfig, PayvisionSavedCard, PaymentFailResponse } from '../interfaces';
import { CheckoutInformation, WorldPayRedirectUrl, PaymentInformation } from '../../checkout/interfaces';
import { FormGroup } from '@angular/forms';
import { PaymentProcessor } from '../enums';
import { Cart } from '../../shared/models';
import { Subscription } from 'rxjs/Subscription';
import { DocumentLibrary } from '../interfaces/document-library.interface';

export class PaymentComponentSettings extends BaseSettings {
    storePaymentMethods: StorePaymentMethod[];
    paymentMethodTypes = PaymentMethodTypes;
    selectedPaymentMethodType: PaymentMethodTypes;
    checkoutInformation: CheckoutInformation;
    paymentMethodTypeForm: FormGroup;
    paymentProcessorConfig: PaymentProcessorConfig;
    selectedPaymentMethod: StorePaymentMethod;
    processorTypes = PaymentProcessor;
    isoTwoletterCountryCode: string;
    enablePaymentOptions = false;
    errorMessage: string;
    enablePlaceOrder = true;
    shoppingCart: Cart;
    shoppingCartSubscription: Subscription;
    reCreateOrderSubscription: Subscription;
    placeOrderTAndC: DocumentLibrary[];
    isAutoshipEnabled: boolean;
    savedCards: PayvisionSavedCard[];
    paymentWithSavedCard: boolean;
    worldpayFormLoaded: boolean;
    selectedPayvisionSavedCard: PayvisionSavedCard;
    savedPayvisionCardForm: FormGroup;
    paymentInformation: PaymentInformation;
    paymentFailResponse: PaymentFailResponse;
    paymentFailPaymentMethod: StorePaymentMethod;
    isInitialize = true;
}
