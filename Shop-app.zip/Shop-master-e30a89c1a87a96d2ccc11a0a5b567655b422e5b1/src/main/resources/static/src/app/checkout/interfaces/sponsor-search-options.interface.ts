import { SponsorSearchValue } from './sponsor-search-value.interface';

export interface SponsorSearchOptions {
    id: number;
    option: string;
    autoAssign: boolean;
    sponsorSearchValues: SponsorSearchValue[];
}
