import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import { HostListener, ElementRef, ChangeDetectorRef, Directive, Input } from '@angular/core';
import { debug } from 'util';
import { DateConstants } from '../../checkout/constants';
// tslint:disable-next-line:directive-selector
@Directive({ selector: '[DateFormat]' })
export class DateFormatDirective {
    findNumber = '^[0-9]*$';
    findCharacter = '([A-z]*\\s)*';
    constructor(private el: ElementRef, private _chRef: ChangeDetectorRef) {

    }

    @HostListener('keypress', ['$event']) onkeypress(event: any) {
        const e = <KeyboardEvent>event;
        const value = event.target.value;

        if (value.length === 2 && value[1] !== '-' && e.key !== '-' && e.key !== 'Backspace') {
            this.el.nativeElement.value = value + '-';
        } else if (value.length === 2 && value[1] === '-') {
            this.el.nativeElement.value = '0' + value[0] + value[1];
        }
        if (value.length === 5 && (new RegExp(this.findNumber).test(value[4]))
            && value[4] !== '-' && e.key !== '-' && e.key !== 'Backspace') {
            this.el.nativeElement.value = value + '-';
        } else if (value.length === 5 && value[4] === '-') {
            this.el.nativeElement.value = value[0] + value[1] + value[2] + '0' + value[3] + value[4];
        } else if (value.length === 6 && (new RegExp(this.findCharacter).test(value[4]))
            && !(new RegExp('-').test(value[5])) && e.key !== '-' && e.key !== 'Backspace') {
            this.el.nativeElement.value = value + '-';
        }
        return;
    }

    @HostListener('input', ['$event']) onKeyUp(event: any) {
        const e = <KeyboardEvent>event;
        const value = event.target.value;
        const characterCheck = /[a-zA-z]/;
        // tslint:disable-next-line:max-line-length
        const datepattern = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]|(?:Jan|Mar|May|Jul|Aug|Oct|Dec|jan|mar|may|jul|aug|oct|dec|JAN|MAR|MAY|JUL|AUG|OCT|DEC)))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2]|(?:Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)(?:0?2|(?:Feb|feb|FEB))\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9]|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|jan|feb|mar|apr|may|jun|jul|aug|sep|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP))|(?:1[0-2]|(?:Oct|Nov|Dec|oct|nov|dec|OCT|NOV|DEC)))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;
        if (!(new RegExp(datepattern).test(value))) {
            return { 'dateValidation': true };
        } else if (value && value.length === 10 && !(characterCheck.test(value[3]))) {
            const date = value[3] + value[4] + value[2] + value[0] + value[1] + value[5] + value[6] + value[7] + value[8] + value[9];
            const formattedDate = moment(date, DateConstants.MMDDFormat).format(DateConstants.DateFormat);
            if (formattedDate === DateConstants.InvalidDate) {
                this.el.nativeElement.value = value;
            } else {
                this.el.nativeElement.value = formattedDate;
            }
        }
    }
}
