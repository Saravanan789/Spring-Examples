import { CurrencyPipe } from './pipes/currency-format.pipe';
import { ChildImageFilterPipe } from './pipes/child-image-filter.pipe';
import { HttpService } from './utils/http.service';
import { BrowserXhr, Http, HttpModule, RequestOptions, XHRBackend } from '@angular/http';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SwiperConfigInterface, SwiperModule, SWIPER_CONFIG } from 'ngx-swiper-wrapper';
import { PopoverModule, RatingModule, TooltipModule } from 'ngx-bootstrap';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AppTranslationModule } from '../translations/app-translations.module';
import { JsonSchemaFormModule } from 'angular4-json-schema-form-updated';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { ShareButtonsModule } from 'ngx-sharebuttons';
import { Ng2DeviceDetectorModule } from 'ng2-device-detector';
import { AppCommonModuleConstants } from './app-common.module.constants';
import { TranslateKey } from './pipes/translate-key.pipe';
import { OwlDateTimeModule, OWL_DATE_TIME_LOCALE, OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';
import { OwlMomentDateTimeModule } from 'ng-pick-datetime-moment';
import { AddressService } from './services/address.service';
import { AppSectionSpinnerService } from './services/section-spinner.service';
import { CustomMaskTextboxComponent, CustomSelectWidgetComponent } from './widgets';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { LogoutGuard } from './components';

export const MY_MOMENT_FORMATS = {
  parseInput: 'MMM YYYY',
  fullPickerInput: 'l LT',
  datePickerInput: 'DD-MMM-YYYY',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY',
};
const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
  direction: 'horizontal',
  slidesPerView: 'auto',
  keyboard: true,
};

export function httpServiceFactory(backend: XHRBackend, defaultOptions: RequestOptions) {
  return new HttpService(backend, defaultOptions);
}


@NgModule({
  imports: [
    HttpModule,
    CommonModule,
    SwiperModule,
    FormsModule,
    ReactiveFormsModule,
    AppTranslationModule,
    // TranslationModule.forRoot( {
    //   cdnURLCacheKey: CacheKey.cdnURLCacheKey,
    //   countryCode : 'USA',
    //   countryCodeCacheKey: CacheKey.countryCode
    // }),
    RouterModule,
    InfiniteScrollModule,
    JsonSchemaFormModule,
    HttpClientModule,
    HttpClientJsonpModule, RatingModule,
    ShareButtonsModule.forRoot(), ModalModule.forRoot(),
    Ng2DeviceDetectorModule.forRoot(), PopoverModule.forRoot(),
    TooltipModule.forRoot(),
    OwlDateTimeModule, OwlMomentDateTimeModule,
    NgxMaskModule.forRoot(),
  ],
  declarations: AppCommonModuleConstants.MODULE_COMPONENTS,
  providers: [LogoutGuard, {
    provide: SWIPER_CONFIG,
    useValue: DEFAULT_SWIPER_CONFIG
  }, {
      provide: Http,
      useFactory: httpServiceFactory,
      deps: [XHRBackend, RequestOptions]
    },
    { provide: OWL_DATE_TIME_LOCALE, useValue: 'en' },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_MOMENT_FORMATS },
    ChildImageFilterPipe, CurrencyPipe, TranslateKey,
    AddressService, AppSectionSpinnerService, MaskPipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [
    HttpModule,
    SwiperModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppTranslationModule,
    // TranslationModule,
    RouterModule,
    InfiniteScrollModule,
    JsonSchemaFormModule,
    HttpClientModule,
    HttpClientJsonpModule,
    ShareButtonsModule, RatingModule, TooltipModule, PopoverModule,
    Ng2DeviceDetectorModule, AppCommonModuleConstants.MODULE_COMPONENTS,
    OwlDateTimeModule, OwlMomentDateTimeModule,
    NgxMaskModule
  ],
  entryComponents: [CustomSelectWidgetComponent, CustomMaskTextboxComponent]
})
export class AppCommonModule { }
