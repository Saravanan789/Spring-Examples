export enum ContactTypeValue {
    MOBILE = 117,
    PHONE = 43,
    EMAIL = 47
}
