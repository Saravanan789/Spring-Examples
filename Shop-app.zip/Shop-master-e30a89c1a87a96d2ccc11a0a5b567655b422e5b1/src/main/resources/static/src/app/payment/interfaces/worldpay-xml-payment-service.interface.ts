export interface WorldpayXMLPaymentService {
    submit: WorldpayXMLPaymentServiceSubmit;
}

export interface WorldpayXMLPaymentServiceSubmit {
    order: WorldpayXMLPaymentServiceOrder;
}

export interface WorldpayXMLPaymentServiceOrder {
    orderCode?: string;
    description: string;
    amount: WorldpayXMLPaymentServiceOrderAmount;
    paymentMethodMask: WorldpayXMLPaymentMethodMask;
    shopper: WorldpayXMLPaymentMethodShopper;
}

export interface WorldpayXMLPaymentServiceOrderAmount {
    currencyCode: string;
    exponent: number;
}

export interface WorldpayXMLPaymentMethodMask {
    include: XMLPaymentMethodMask;
}

export interface XMLPaymentMethodMask {
    code: string;
}

export interface WorldpayXMLPaymentMethodShopper {
    shopperEmailAddress: string;
}
