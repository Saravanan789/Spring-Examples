import { TaxCart } from './tax-cart.interface';
import { Address } from '../../common/interfaces';

export interface TaxRequest {
  orderID: number;
  memberID: number;
  shopingCart: TaxCart;
  fromAddress: Address;
  toAddress: Address;
  memberNumber: string;
  orderNumber: number;
  storeID: number;
  priceTierName?: string;
  currencyCode: string;
  countryCode: string;
  orderTypeId: number;
  deliveryTypeId: number;
  orderSource: string;
  memberLevelId: number;
  wholesaleQualified?: boolean;
  conversionRate: number;
}
