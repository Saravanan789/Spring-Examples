export interface PaymentCallBackUrl {
    id?: number;
    orderId?: number;
    webOrderId?: string;
    checkoutId?: string;
    successUrl: string;
    failureUrl: string;
    cancelledUrl: string;
}

