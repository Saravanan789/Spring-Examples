import { ShippingMethod } from './shipping-method.interface';
import { RestrictedProduct } from './restricted-product.interface';

export interface ShippingOptionsResponse {
  importFeeEnabled: boolean;
  languageCode: string;
  rateResponseId: number;
  shippingMethods: ShippingMethod[];
  success: boolean;
  validations: any;
  productModels: RestrictedProduct[];
  distributionCenterName?: string;
}
