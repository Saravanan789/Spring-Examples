export interface ProductShippingRestriction {
    productModelResponse: boolean;
    shippingResponse: boolean;
    itemNumbers: any[];
    itemNo: string;
    productError: string;
}
