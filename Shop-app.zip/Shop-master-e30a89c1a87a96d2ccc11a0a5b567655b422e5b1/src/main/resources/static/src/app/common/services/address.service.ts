import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Address } from '../interfaces';

@Injectable()
export class AddressService {
    // private _schemaForm = environment.uiTemplateBaseUrl + '/test/schema-forms/';
   private _schemaForm = environment.cdnURL + '/portals/shop/template1/schema-forms/';
    constructor(
        private _http: Http,
        private _httpClient: HttpClient
    ) { }

    /**
     * @param  {any} address
     * @returns Observable
     */
    getSuggestedAddress(address: Address): Observable<Address> {
        return this._http
            .post(ApiUrlConstants.addressApiUrl + '/verify-address', address)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * to get saved addresses
     * @param  {number} memnerId
     */
    getSavedAddress(memberId: number, countryId?: number, addressTypeId?: number): Observable<Address[]> {
        let requestUrl = ApiUrlConstants.accountApiUrl + '/members/' + memberId + '/addresses';
        if (countryId) {
            requestUrl = requestUrl + '?countryId=' + countryId;
        }
        if (addressTypeId) {
            const operator = countryId ? '&' : '?';
            requestUrl = requestUrl + operator + 'addressTypeId=' + addressTypeId;
        }
        return this._http
            .get(requestUrl)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * save verifiedAddress
     * @param  {any} verifiedAddress
     * @returns Observable
     */
    saveVerifiedAddress(verifiedAddress: Address): Observable<any> {
        return this._http
            .post(ApiUrlConstants.accountApiUrl + '/members/' + verifiedAddress.memberId + '/addresses', verifiedAddress)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * update Saved Addresses based on memebr id
     * @param  {ShippingAddress} verifiedAddress
     * @param  {number} savedAddressId
     * @returns Observable
     */
    updateVerifiedAddress(verifiedAddress: Address, memberAddressId: number): Observable<any> {
        return this._http
            .put(ApiUrlConstants.accountApiUrl + '/members/' + verifiedAddress.memberId + '/addresses/' + memberAddressId, verifiedAddress)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * delete Saved Addresses based on memebr id
     * @param  {number} memberId
     * @param  {number} savedAddressId
     * @param  {number} loggedinUserId
     * @returns Observable
     */
    deleteVerifiedAddress(memberId: number, savedAddressId: number, loggedinUserId: number): Observable<any> {
        return this._http
            .delete(ApiUrlConstants.accountApiUrl + '/members/' + memberId +
                '/addresses/' + savedAddressId + '?loggedinUserId=' + loggedinUserId)
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description get address details by address id
     * @date 2018-09-17
     * @param {number} addressId
     * @returns {Observable<Address>}
     * @memberof AddressService
     */
    getAddressDetailsById(addressId: number): Observable<Address[]>  {
        const  url  =  ApiUrlConstants.accountApiUrl  +  '/members/addresses/' + addressId;
        return  this._http
            .get(url)
            .map((res:  Response)  =>  res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @returns Observable
     */
    getJsonFormSchema(schemaUrl: string): Observable<any> {
        return this._httpClient
            .get(this._schemaForm + schemaUrl + '?timeStamp=' + new Date().getTime(), { responseType: 'text' })
            .catch(this.handleErrorObservable);
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error.message || error);
    }
}
