export class CountryPhoneNumberFormats {
    public static formats: CountryPhoneNumberFormat[] = [
        { countryCode: 'usa', phoneNumberMaskFormat: '(000) 000-0000' },
        { countryCode: 'can', phoneNumberMaskFormat: '(000) 000-0000' }
    ];
}

interface CountryPhoneNumberFormat {
    countryCode: string;
    phoneNumberMaskFormat: string;
}
