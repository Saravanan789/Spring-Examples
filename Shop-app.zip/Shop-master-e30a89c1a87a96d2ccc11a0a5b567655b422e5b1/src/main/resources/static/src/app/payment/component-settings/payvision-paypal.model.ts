import { PaymentComponentSettings } from './payment.model';

export class PayvisionPaypalComponentSettings extends PaymentComponentSettings {

}
