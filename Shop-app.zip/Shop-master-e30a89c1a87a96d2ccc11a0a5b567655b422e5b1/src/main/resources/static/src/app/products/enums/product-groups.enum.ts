export enum ProductGroup {
    RelatedProudcts = 1,
    YouMayAlsoLike = 2
}
