export enum ShippingMemberTitle {
    NOVUS = 20,
    ASSISTANTMANAGER = 21,
    SUPERVISOR = 22
}
