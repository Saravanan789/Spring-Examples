import { SponsorInformation } from './sponsor-information.interface';
import { ShippingInformation } from './shipping-information.interface';
import { ShippingMethodInformation } from './shipping-method-information.interface';
import { OrderResponse } from './order-response.interface';
import { PersonalInformation } from './personal-information.interface';
import { PaymentInformation } from './payment-information.interface';
import { Member } from '../../shared/interfaces';
import { Order } from './order.interface';
import { EnrollInfo } from './enroll-info.interface';
import { Address } from '../../common/interfaces';

export interface CheckoutInformation {
    personalInformation: PersonalInformation;
    sponsorInformation: SponsorInformation;
    shippingInformation: ShippingInformation;
    paymentInformation: PaymentInformation;
    shippingMethodInformation: ShippingMethodInformation;
    mailingAddress?: Address;
    orderResponse: OrderResponse;
    orderDetails?: Order;
    enrollInformation?: EnrollInfo;
    retuningGuestUser?: Member;
    guestToRetailUser?: Member;
    autoshipShippingMethodInformation: ShippingMethodInformation;
}
