export enum PaymentMethodTypes {
    Credit_Card = 'Credit_Card',
    eCheck = 'eCheck',
    Money_order = 'Money_Order',
    Cash = 'Cash',
    Ideal = 'Ideal',
    PayPal = 'PayPal',
    // tslint:disable-next-line:quotemark
    None = "None"
}
