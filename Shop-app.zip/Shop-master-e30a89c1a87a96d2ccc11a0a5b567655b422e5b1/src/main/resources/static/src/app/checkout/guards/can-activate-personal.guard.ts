import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { MemberType } from '../../shared/enums';
import { CacheService } from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';

@Injectable()
export class CanActivatePersonalGuard implements CanActivate {
    constructor(
        private _router: Router,
        private _cacheService: CacheService) { }

    /**
     * Checkout page Guard
     * @returns boolean
     */
    canActivate(): boolean {
        const languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        const isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        const registerMemberType: MemberType = this._cacheService.get(CacheKey.RegisterMemberType);
        const fpcOptin = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        // allow user, If user is retail
        if ((registerMemberType === MemberType.RETAILCUSTOMER
            && !this._cacheService.get(CacheKey.UserInfo))
            || (this._cacheService.get(CacheKey.UserInfo) && fpcOptin)) {
            return true;
        } else {
            this._router.navigateByUrl('/' + isoCountryCode.toLowerCase() + '/'
                + languageCode.toLowerCase() + '/products');
        }
    }
}
