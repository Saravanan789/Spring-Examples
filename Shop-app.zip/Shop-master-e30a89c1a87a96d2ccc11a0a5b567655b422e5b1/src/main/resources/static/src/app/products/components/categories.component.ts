import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { DataShareService } from '../../shared/services/data.service';
import {
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewEncapsulation,
  HostListener
} from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { ProductService } from '../services/product.service';
import { CommonService } from '../../shared/services/common.service';
import { Categories } from '../interfaces/categories.interface';
import { ProductMessageService } from '../services/product-message.service';
import { ConfigurationService } from '../../shared/services/configuration.service';
import * as _ from 'lodash';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { AppMessageService } from '../../app-message.service';
import { MemberLevel } from '../../shared/enums';
import { ActiveSessionService } from '../../shared/services';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-categories',
  templateUrl: '../templates/template3/views/categories.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/categories.component.less'
  ],
  encapsulation: ViewEncapsulation.None
})
export class CategoriesComponent implements OnInit, OnDestroy {
  store: any;
  categoriesTree: Categories[];
  flatArray: Categories[];
  @Input() isNavCollapsed = true;
  sideNavSubscription: Subscription;
  categoriesAndCatalogsSubject: Subscription;
  sideNavCloseSubscription: Subscription;
  navScrollSubscription: Subscription;
  topNavbar: boolean;
  languageCode: string;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  purchaseFlow: PurchaseFlow;
  catalogs: any[];
  storeId: number;
  headerHeight: any;
  category: any;
  openCategory = false;
  categorySubscription: Subscription;
  searchValue: any;
  headerSearchValue = '';
  constructor(
    private _productService: ProductService,
    private _commonService: CommonService,
    private _productMessageService: ProductMessageService,
    private _configurationService: ConfigurationService,
    private _dataShareService: DataShareService,
    private _cacheService: CacheService,
    private _appMessageService: AppMessageService,
    private _activeSessionService: ActiveSessionService,
    private _route: ActivatedRoute
  ) {
    this.sideNavSubscription = _productService.sideNavOpen$.subscribe(
      status => {
        this.isNavCollapsed = status;
      }
    );
    this.navScrollSubscription = this._productMessageService.getNavScroll().subscribe((res: any) => {
      this.topNavbar = res;
    });
  }


  ngOnInit() {
    this._dataShareService.currentMessage.subscribe(message => {
      if (message) {
        this.headerHeight = message;
      } else {
        this.headerHeight = 139;
      }
    });
    this.subscribeCategory();
    this.getStoreData();
    this.languageCode = this._commonService.getLanguageCode();
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.purchaseFlow = this._commonService.getPurchaseFlowType();
    this.isMobileDevice();
    this.sideNavCloseSubSubscription();
    this._productService.sideNavClose(this.isNavCollapsed);
    this.getCategoriesAndCatalogsSubject();
    const categoriesTree: Categories[] = this._cacheService.get(CacheKey.CategoriesTree);
    if (categoriesTree && categoriesTree.length > 0) {
      this.setDefaultCategory(categoriesTree);
    }
    this.subscribeParams();
  }

  /**
   * Listen the product list component params
   * @memberof CategoriesComponent
   */
  subscribeParams(): void {
    this._route.params.subscribe((params) => {
      const categorySlug = params['slug'];
      const categoriesTree: Categories[] = this._cacheService.get(CacheKey.CategoriesTree);
      if (categoriesTree && categoriesTree.length > 0) {
        const category = categoriesTree.find(x => x.slug.toLowerCase() === categorySlug.toLowerCase());
        this._cacheService.set(CacheKey.SelectedCategoryState, category || categoriesTree[0]);
        this.setDefaultCategory(categoriesTree);
      }
    });
  }

  /** To Retain Search criteria on page refresh
   * @returns boolean
   */
  getSearchProdcuts(): boolean {
    this.searchValue = this._commonService.getParamValueFromUrl('search');
    if (!this.searchValue && this._cacheService.getCookieValue(CacheKey.HeaderSearch)) {
      const headerSearch = JSON.parse(this._cacheService.getCookieValue(CacheKey.HeaderSearch));
      this.searchValue = headerSearch.searchValue;
    }
    if (this.searchValue) {
      const headerSearch = {
        category: this.category,
        searchValue: this.searchValue
      };
      this._cacheService.setCookieValue(CacheKey.HeaderSearch, JSON.stringify(headerSearch));
      this._productMessageService.setLoadDefaultProducts(headerSearch);
      return true;
    }
  }


  subscribeCategory(): void {
    this._productMessageService.getProductsByCategory().subscribe((item: any) => {
      this.category = item;
    });
  }

  sideNavCloseSubSubscription() {
    this.sideNavCloseSubscription = this._productService.sideNavClose$.subscribe(
      status => {
        this.isNavCollapsed = status;
      });
  }

  private mergeCatalogsAndCategories(): any[] {
    return this.catalogs.map(function (x) {
      return {
        productCategoryId: x.id,
        id: x.id,
        parentCategoryConfigId: null,
        categoryName: x.name,
        storeId: x.storeId,
        isCustomCatalog: true,
        cards: x.cards,
        slug: x.slug,
        description: x.description
      };
    });
  }

  /**
   * to get all categories
   */
  getCategories(): void {
    const storeId: number = this.store.id;
    const groupId = 1;
    if (storeId) {
      this._commonService
        .getCategories(storeId, groupId, this.languageCode)
        .subscribe(response => {
          if (response && response.length > 0) {
            this.flatArray = response;
            this.getAllCatalogs();
          }
        }, error => {
        });
    }
  }

  /**
  * get all the Catalogs
  * @returns void
  */
  getAllCatalogs(): void {
    if (this.storeId) {
      this._productService.getCustomCatalogs(this.storeId).subscribe((catalogs: any) => {
        if (catalogs && catalogs.length > 0 && catalogs[0].id) {
          this.catalogs = catalogs;
          const mergeArray: any[] = this.mergeCatalogsAndCategories();
          this.setDefaultCategory(mergeArray);
        } else {
          this.setDefaultCategory([]);
        }
      }, error => {
        this.setDefaultCategory([]);
      });
    }
  }

  /**
   * @returns void
   */
  getCategoriesAndCatalogsSubject(): void {
    this.categoriesAndCatalogsSubject = this._appMessageService
      .getCategoriesAndCatalogsSubject().subscribe(res => {
        const categoriesTree: Categories[] = this._cacheService.get(CacheKey.CategoriesTree);
        this.setDefaultCategory(categoriesTree);
        const searchValue = this._commonService.getParamValueFromUrl('search');
        if (searchValue) {
          this.headerSearchValue = searchValue;
        }
      });
  }

  /**
   * @param  {any[]} arrProducts
   */
  private setDefaultCategory(arrProducts: Categories[]) {
    const categoriesTreeList = this.constructTreeFromFlatArray(arrProducts, null, null, null);
    let selectedCategoryState = this._cacheService.get(CacheKey.SelectedCategoryState);
    if (!(window.location.pathname.indexOf('/products') > -1)) {
      const categorySlug = window.location.pathname.split('/').length > 3 ?
        window.location.pathname.split('/')[3] : '';
      if (categorySlug && categoriesTreeList &&
        (selectedCategoryState && selectedCategoryState.slug
          && selectedCategoryState.slug.toLowerCase() !== categorySlug.toLowerCase())) {
        const category = categoriesTreeList.find(x => x.slug.toLowerCase() === categorySlug.toLowerCase());
        if (category) {
          this._cacheService.set(CacheKey.SelectedCategoryState, category);
          selectedCategoryState = category;
        }
      }
    }
    const categoryId = parseInt(this._commonService.getParamValueFromUrl('categoryId'), 10);
    const headerSearch = this.getSearchValue();
    if (categoryId) {
      selectedCategoryState = { productCategoryId: categoryId };
    }
    if (!headerSearch && !selectedCategoryState) {
      this._productMessageService.setProductsByCategory(categoriesTreeList[0]);
      this._appMessageService.setCategoryTreeOpenIndex(0);
      this.headerSearchValue = '';
    } else if (!headerSearch && selectedCategoryState && categoriesTreeList && categoriesTreeList.length > 0) {
      this.headerSearchValue = '';
      const selectedCategory: Categories = categoriesTreeList
        .find(x => x.productCategoryId === selectedCategoryState.productCategoryId
          && (x.isCustomCatalog === selectedCategoryState.isCustomCatalog));
      this.category = selectedCategory ? selectedCategory : categoriesTreeList[0];
      this._productMessageService.setProductsByCategory(this.category);
      const treeIdx = categoriesTreeList.findIndex(x => x.productCategoryId === this.category.productCategoryId);
      this._appMessageService.setCategoryTreeOpenIndex(treeIdx);
    } else if (headerSearch) {
      headerSearch.isSearch = true;
      this.headerSearchValue = headerSearch.searchValue;
      this._productMessageService.setProductsByCategory(headerSearch);
      const treeIdx = categoriesTreeList.findIndex(x => x.productCategoryId === this.category.productCategoryId);
      this._appMessageService.setCategoryTreeOpenIndex(treeIdx);
    }
    this.categoriesTree = categoriesTreeList.map(x => {
      if (this.category && x.productCategoryId === this.category.productCategoryId
        && x.isCustomCatalog === this.category.isCustomCatalog) {
        x.isOpen = true;
      } else {
        x.isOpen = false;
      }
      return x;
    });
  }

  getSearchValue(): any {
    const searchValue = this._commonService.getParamValueFromUrl('search');
    let headerSearch: any = null;
    if (searchValue) {
      headerSearch = { searchValue: searchValue };
    }
    let cookieValue = this._cacheService.getCookieValue(CacheKey.HeaderSearch);
    if (cookieValue && cookieValue.length > 0) {
      cookieValue = JSON.parse(cookieValue);
    }
    return headerSearch || cookieValue;
  }
  /**
   * to construct tree view object from flat array
   * @param  {any} list
   * @param  {any} idAttr
   * @param  {any} parentAttr
   * @param  {any} childrenAttr
   */
  constructTreeFromFlatArray(
    list: any,
    idAttr: any,
    parentAttr: any,
    childrenAttr: any
  ) {
    if (!idAttr) { idAttr = 'id'; }
    if (!parentAttr) { parentAttr = 'parentCategoryConfigId'; }
    if (!childrenAttr) { childrenAttr = 'subCategory'; }

    const treeList: any = [];
    const lookup = {};
    if (list) {
      list.forEach((obj: any) => {
        lookup[obj[idAttr]] = obj;
        obj[childrenAttr] = [];
      });
      list.forEach((obj: any) => {
        if (obj[parentAttr] != null) {
          if (lookup[obj[parentAttr]]) {
            lookup[obj[parentAttr]][childrenAttr].push(obj);
          }
        } else {
          treeList.push(obj);
        }
      });
    }
    return treeList;
  }

  /**
   * to hide side nav menu
   */
  sideNavClose() {
    this.isNavCollapsed = false;
    if (this._cacheService.getCookieValue(CacheKey.countryCode) === 'can') {
      document.getElementById('chooseCountry').focus();
    }
    this._productService.sideNavClose(false);
  }

  // Mobile device
  isMobileDevice(): void {
    const check = this._productService.isMobileDevice();
    if (check) {
      this.sideNavClose();
    }
  }

  getStoreData(): void {
    const result: StoreConfig = this._configurationService.getStoreData();
    if (result) {
      this.store = result;
      this.storeId = this.store.id;
    }
  }

  /**
   * prevent memory leak when component destroyed
   */
  ngOnDestroy() {
    if (this.sideNavCloseSubscription) {
      this.sideNavCloseSubscription.unsubscribe();
    }
    if (this.sideNavSubscription) {
      this.sideNavSubscription.unsubscribe();
    }
    if (this.navScrollSubscription) {
      this.navScrollSubscription.unsubscribe();
    }
    if (this.categoriesAndCatalogsSubject) {
      this.categoriesAndCatalogsSubject.unsubscribe();
    }
  }

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (this._cacheService.getCookieValue(CacheKey.countryCode) === 'can') {
      this.sideNavClose();
    }
  }
}
