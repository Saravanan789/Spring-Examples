import {
  CartSummaryComponent,
  SponsorSelectionComponentNew,
CheckoutNewComponent,
  PersonalInfoComponent,
  ShippingAddressNewComponent,
  ShippingMethodsNewComponent,
  GuestPersonalInfoComponent,
  OrderSummaryNewComponent
} from './components';
import { PatternValidatorDirective } from './directives/pattern.directive';

export class CheckoutModuleConstants {
  static MODULE_COMPONENTS = [
    PatternValidatorDirective,
    SponsorSelectionComponentNew,
    CartSummaryComponent,
    CheckoutNewComponent,
    PersonalInfoComponent,
    ShippingAddressNewComponent,
    ShippingMethodsNewComponent,
    GuestPersonalInfoComponent,
    OrderSummaryNewComponent
  ];
}
