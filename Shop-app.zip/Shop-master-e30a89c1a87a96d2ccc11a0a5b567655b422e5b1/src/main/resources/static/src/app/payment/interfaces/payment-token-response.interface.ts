import { Address } from '../../common/interfaces';
import { PayvisionPaymentMethod } from './payment-payvision-method.interface';


export interface PaymentTokenResponse {
    token: string;
    customerId: number;
    customerProfileID: string;
    paymentMethod: PayvisionPaymentMethod;
    reusable: boolean;
    billingAddress: Address;
    billingAddressId: string;
    countryCode: string;
    storeId: number;
    memberId: number;
    addressVerified?: boolean;
}
