export enum ShippingType {
    DELIVERY = 1,
    PICKUP = 2
}
