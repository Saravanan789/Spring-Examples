export class CheckoutConstants {
    public static PERSONALINFO_ROUTE = '/checkout/personalinfo';
    public static DEFAULT_SPONSORID = '001002575619';
}
