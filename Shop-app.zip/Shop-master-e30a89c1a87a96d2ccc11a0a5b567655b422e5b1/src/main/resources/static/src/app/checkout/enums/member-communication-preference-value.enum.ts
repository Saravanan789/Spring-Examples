export enum MemeberCommunicationPreferenceValue {
    YES = 37,
    NO = 38
}
