import { Address, AddressResponse } from '../interfaces';
import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { AddressSchemaFormFrameworkType, AddressOptions } from '../enums/address-type.enum';
import { JsonSchemaFormOptions } from '../interfaces/address-response.interface';
import { Subscription } from 'rxjs/Subscription';
import { Country, State } from '../../shared/interfaces';
import { CustomMaskTextboxComponent, CustomSelectWidgetComponent } from '../widgets';

export class AddressComponentSettings extends BaseSettings {
    address: Address;
    addressSubmitted: boolean;
    isoCountryCode: string;
    jsonFormObject: any;
    originalJsonFormObject: any;
    selectedFrameWork = AddressSchemaFormFrameworkType.BOOTSTRAP4;
    addressVerificationForm = false;
    responseCodes: AddressResponse[] = [];
    liveFormData: Address;
    interval: any;
    countries: Country[];
    states: State[];
    countryId: number;
    originalAddress: Address;
    suggestedAddress: Address;
    errorCodes: any;
    isModalOpen = false;
    jsonFormOptions: JsonSchemaFormOptions = {
        addSubmit: true, // Add a submit button if layout does not have one
        loadExternalAssets: false, // Load external css and JavaScript for frameworks
        debug: false,
        setSchemaDefaults: true,
        returnEmptyFields: false,
    };
    customWidgets = {
        'custom-select-widget': CustomSelectWidgetComponent,
        'custom-mask-widget': CustomMaskTextboxComponent
    };
    selectedAddressType = AddressOptions.SUGGESTEDADDRESS;
    submitAddressSubscription: Subscription;
    editSubscription: Subscription;
    showAddressVerification: boolean;
    displayMobileAddressVerification = false;
    templateCTX: any;
    displayAddressBlock = true;
    liveFormStatus: boolean;
    validationMessageInitialHide = true;
}
