export enum PaymentProcessor {
    WORLDPAYXML = 'WPAYXML',
    PAYVISION = 'PVISION',
    WPAY = 'WPAY',
}
