export interface PaymentRegistrationResponse {
    buildNumber: string;
    paymentType: string;
    timestamp: string;
    ndc: string;
    id: string;
    result: RegistrationResult;
    paymentStatus: string;
    paymentStatusId: string;
    status: boolean;
    paymentBrand: string;
    card: RegistrationCardDetails;
    paymentUrl: string;
    formUrl: string;
    paymentCallBackUrl: string;
    cardBrands: string;
}

export interface RegistrationResult {
    code: string;
    description: string;
}

export interface RegistrationCardDetails {
    bin: string;
    last4Digits: string;
    holder: string;
    expiryMonth: string;
    expiryYear: string;
}
