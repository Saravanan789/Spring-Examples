import { PayvisionRequestModel } from './payvision-request-model.interface';
import { Address } from '../../common/interfaces';
import { PaymentMethodTypes } from '../enums';
export interface PaymentRequest {
    token: string;
    orderDescription: string;
    amount: number;
    countryCode: string;
    currencyCode: string;
    storeId: number;
    paymentMethodType: PaymentMethodTypes;
    customerId: any;
    billingAddress: Address;
    paymentRequestModel: PayvisionRequestModel;
}
