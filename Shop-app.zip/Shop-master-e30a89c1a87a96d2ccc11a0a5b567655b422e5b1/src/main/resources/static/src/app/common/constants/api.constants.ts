import { environment } from '../../../environments/environment';
export class ApiUrlConstants {
    public static productApiUrl = environment.apiUrl + '/product/v1';
    public static orderApiUrl = environment.apiUrl + '/order/V1';
    public static paymentApiUrl = environment.apiUrl + '/payment/v1';
    public static taxApiUrl = environment.apiUrl + '/tax/taxservice/V1';
    public static shippingApiUrl = environment.apiUrl + '/shipping/V1';
    public static addressApiUrl = environment.apiUrl + '/address/V1';
    public static accountApiUrl = environment.apiUrl + '/account/V1';
    public static configurationApiUrl = environment.apiUrl + '/admin/V1/';
    public static cmsApiUrl = environment.apiUrl + '/content/v1';
    public static enrollSiteURL = environment.enrollSiteURL;
    public static googleMapsUrl = 'https://www.google.com/maps/place/';
    public static reBrandlyApiUrl = 'https://api.rebrandly.com/v1/';
    public static REBRANDLYAPIKEY = 'be359875aec44c0b93a3bb379e797bf7';
    public static reBrandlyDomainName = 'rebrand.ly';
}
