export enum ProductWeightMetric {
    KGS = 10,
    OUNCES = 11,
    LBS = 12,
    GRAMS = 13
}
