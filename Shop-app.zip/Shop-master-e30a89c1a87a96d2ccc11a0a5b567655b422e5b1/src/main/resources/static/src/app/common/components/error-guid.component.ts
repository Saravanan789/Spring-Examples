import { Input, Component, OnInit } from '@angular/core';
import { TranslateParam } from '../interfaces';

@Component({
    selector: 'app-error-guid',
    templateUrl: '../templates/template3/views/error-guid.component.html',
    styleUrls: [
      '../templates/template3/themes/default/less/error-guid.component.less'
    ]
})

export class ErrorGuidComponent implements OnInit {
    @Input() translateParams: TranslateParam;
    errorGuid: string;

    constructor() {
    }

    ngOnInit() {
        if (this.translateParams) {
            this.errorGuid = this.translateParams.errorGuid;
        }
    }
}
