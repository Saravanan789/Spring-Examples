import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CreditCardDirectivesModule } from 'angular-cc-library';
import { TabsModule, PopoverModule, TypeaheadModule, ModalModule, BsDropdownModule } from 'ngx-bootstrap';

import { CheckoutModuleConstants } from './checkout-module.constants';
import { AppCommonModule } from '../common/app-common.module';
import { CheckoutRoutingModule } from './checkout-routing.module';
import {
  CheckoutMessageService, OrderService,
  OrderTaxService,
  SponsorService,
  ShippingMethodService, EnrollService, AutoshipService
} from './services';

@NgModule({
  imports: [
    PopoverModule,
    AppCommonModule,
    CheckoutRoutingModule,
    CreditCardDirectivesModule,
    ModalModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    TypeaheadModule.forRoot()
  ],
  declarations: CheckoutModuleConstants.MODULE_COMPONENTS,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    OrderService,
    OrderTaxService,
    SponsorService,
    CheckoutMessageService,
    ShippingMethodService,
    EnrollService, AutoshipService
  ],
  exports: CheckoutModuleConstants.MODULE_COMPONENTS
})
export class CheckoutModule { }
