export enum OrderSourceType {
    Web = 34,
    Telephone = 35,
    POS = 36
}
