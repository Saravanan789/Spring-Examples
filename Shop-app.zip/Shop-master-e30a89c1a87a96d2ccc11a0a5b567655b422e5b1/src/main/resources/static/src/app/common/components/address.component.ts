import {
    ChangeDetectorRef,
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output,
    Renderer,
    ViewChild
} from '@angular/core';
import { CommonService } from '../../shared/services/common.service';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { AddressService } from '../services/address.service';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { AddressResponse } from '../interfaces/address-response.interface';
import { AddressOptions } from '../enums/address-type.enum';
import { AddressComponentSettings } from '../component-settings';
import { State, Country } from '../../shared/interfaces';
import { Ng2DeviceService } from 'ng2-device-detector';
import { AppMessageService } from '../../app-message.service';
import { TranslateService } from '@ngx-translate/core';
import { TranslateKey } from '../pipes/translate-key.pipe';
import { ConfigurationService } from '../../shared/services';
import { Address, VerifyAddressErrorCode, TranslateParam } from '../interfaces';
import { MaskPipe } from 'ngx-mask';
import { CheckoutInformation } from '../../checkout/interfaces';
import { CountrySuffixZipCodes } from '../constants/country-suffix-zipcodes';
import { ContactTypeValue } from '../../checkout/enums';
@Component({
    selector: 'app-address-new',
    templateUrl: '../templates/template3/views/address.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/address.component.less']
})

export class AddressNewComponent implements OnInit, OnDestroy {
    addressComponentSettings: AddressComponentSettings = new AddressComponentSettings();

    @ViewChild('addressModal') public addressModal: AppModalDirective;

    @Input() schemaUrl: string;
    @Input() preloadAddress: Address;
    @Input() skipAddressVerification: boolean;
    @Input() isInputChangeRequired: boolean;
    @Input() isAutoPopulate: boolean;

    @Output() addressSubmit = new EventEmitter<any>();
    // this is used to send info of displaying address verification
    // as of now we are using in personal information section
    @Output() addressVerificationInfo = new EventEmitter<boolean>();
    @Output() notifyInvalidAddress = new EventEmitter<boolean>();

    @Output() addressSubmitOnInputChange = new EventEmitter<any>();
    translateParams: TranslateParam;

    constructor(
        private _addressService: AddressService,
        private elementRef: ElementRef,
        private _renderer: Renderer,
        private _commonService: CommonService,
        private _cacheService: CacheService,
        private chRef: ChangeDetectorRef,
        private _appMessageService: AppMessageService,
        private _deviceService: Ng2DeviceService,
        private _translateService: TranslateService,
        private _translateKey: TranslateKey,
        private _configurationService: ConfigurationService,
        private _maskPipe: MaskPipe,
    ) { }

    ngOnInit() {
        this.addressComponentSettings.isoCountryCode = this._configurationService.getShippingCountryCode();
        this.addressComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.getJsonSchema();
        this.rebindForm();
        this.getCountriesLookup();
        this.submitAddress();
        this._commonService.getEmitter('newAddressForm').subscribe((response: any) => {
            this.reloadJsonObject();
        });
    }

    /**
     * @description new Address Schema Form
     * @date 2018-07-20
     * @private
     * @memberof AddressComponent
     */
    private reloadJsonObject(): void {
        this.addressComponentSettings.address = null;
        this.addressComponentSettings.jsonFormObject = {};
        this.addressComponentSettings.jsonFormObject.data = {};
        this.addressComponentSettings.jsonFormObject = this.getParsedSchemaFormJson(this.addressComponentSettings.originalJsonFormObject);
    }

    /**
     * @param {Address} data
     * @memberof AddressNewComponent
     */
    onChanges(data: Address) {
        this.addressComponentSettings.liveFormData = data;
    }

    /**
     * @description it will trigger when we
     * change any input value in form
     * @date 2018-08-02
     * @memberof AddressComponent
     */
    changeInputValue(event: any): void {
        this.addressComponentSettings.showAddressVerification = true;
        if (this.addressComponentSettings.addressSubmitted) {
            this.addressComponentSettings.addressSubmitted = false;
            this.addressSubmit.emit(this.addressComponentSettings);
        }
        if (this.isInputChangeRequired) {
            this.addressSubmitOnInputChange.emit(this.prepareNewAddress(this.addressComponentSettings.liveFormData));
        }
    }

    /**
     * @description method to get countries lookup
     * @memberof AddressNewComponent
     */
    getCountriesLookup() {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.addressComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            this.addressComponentSettings.countryId = this.addressComponentSettings.countries.filter((x: Country) => x.isocodeThree
                === this.addressComponentSettings.isoCountryCode.toUpperCase())[0].countryId;
            if (this.addressComponentSettings.countryId) {
                this.getAllStatesByCountry();
            }
        } else {
            this._commonService.getCountries().subscribe((res: Country[]) => {
                if (res && res.length > 0) {
                    this.addressComponentSettings.countries = res;
                    this._cacheService.set(CacheKey.Countries, this.addressComponentSettings.countries);
                    this.addressComponentSettings.countryId = this.addressComponentSettings.countries
                        .filter((x: Country) => x.isocodeThree === this.addressComponentSettings.isoCountryCode.toUpperCase())[0].countryId;
                    if (this.addressComponentSettings.countryId) {
                        this.getAllStatesByCountry();
                    }
                }
            });
        }
    }

    /**
     * @description get states by country
     * @memberof AddressNewComponent
     */
    getAllStatesByCountry() {
        const storedStates = this._cacheService.get(CacheKey.StatesByCountryId + '_' + this.addressComponentSettings.countryId);
        if (storedStates && storedStates.length > 0) {
            this.addressComponentSettings.states = storedStates;
        } else {
            if (this.addressComponentSettings.countryId) {
                this._commonService.getStatesByCountry(this.addressComponentSettings.countryId).subscribe((res: State[]) => {
                    this.addressComponentSettings.states = res;
                });
            }
        }
    }

    /**
     * @description to get the country specific schema json file
     * @returns void
     */
    getJsonSchema(address?: Address, isEdit?: boolean): void {
        this._addressService.getJsonFormSchema(this.schemaUrl)
            .subscribe((response: any) => {
                this.addressComponentSettings.jsonFormObject = this.getParsedSchemaFormJson(response);
                this.addressComponentSettings.originalJsonFormObject = response;
                this.addressComponentSettings.address = address || this.preloadAddress;
                if (this.addressComponentSettings.address) {
                    if (this.addressComponentSettings.address.phoneNumber && !this.addressComponentSettings.address.phone) {
                        this.addressComponentSettings.address.phone = this.addressComponentSettings.address.phoneNumber;
                    }
                    this.addressComponentSettings.address.phone = this.addressComponentSettings.address.phone ?
                        this.maskPhoneNumber(this.addressComponentSettings.address.phone) : '';
                    this.addressComponentSettings.jsonFormObject.data = this.addressComponentSettings.address;
                    if (this.addressComponentSettings.address.isInvalidAddress) {
                        this.addressComponentSettings.addressSubmitted = false;
                    } else {
                        this.addressComponentSettings.addressSubmitted = isEdit ? isEdit :
                        this.isAutoPopulate ? false : true;
                    }
                    this.isAutoPopulate = false;
                    this.addressComponentSettings.showAddressVerification = isEdit ? isEdit : false;
                }
                if (!this.addressComponentSettings.jsonFormObject.data
                    || (this.addressComponentSettings.jsonFormObject.data
                        && (!this.addressComponentSettings.jsonFormObject.data.state))) {
                    this.addressComponentSettings.jsonFormObject.data.state = '';
                }
                if (!this.addressComponentSettings.jsonFormObject.data
                    || (this.addressComponentSettings.jsonFormObject.data
                        && (!this.addressComponentSettings.jsonFormObject.data.state
                            || !this.addressComponentSettings.jsonFormObject.data.phoneType))) {
                    this.addressComponentSettings.jsonFormObject.data.phoneType = ContactTypeValue.MOBILE;
                }
                if (isEdit) {
                    this.getSchemaFormButton(isEdit);
                }
                this.findErrorElement();
            });
    }

    /**
     * get parsed json form object
     * @param  {any} jsonText
     * @returns any
     */
    getParsedSchemaFormJson(jsonText: any): any {
        let newFormObject: any = null;
        try {
            // Parse entered content as JSON
            newFormObject = JSON.parse(jsonText);
        } catch (jsonError) {
            try {
                // If entered content is not valid JSON,
                // parse as JavaScript instead to include functions
                newFormObject = null;
                /* tslint:disable */
                //eval('newFormObject = ' + jsonText);
                /* tslint:enable */

            } catch (javascriptError) {
                return;
            }
        }
        newFormObject = this.getTranslatedSchemaData(newFormObject);
        return newFormObject;
    }

    /** Schema Form Translation
    * @param  {any} jsonObject
    */
    getTranslatedSchemaData(jsonObject: any): any {
        // Translate Schema form fields..
        if (jsonObject && jsonObject.schema && jsonObject.schema.properties) {
            const jsonSchemaKeys = Object.keys(jsonObject.schema.properties);
            if (jsonSchemaKeys) {
                jsonSchemaKeys.forEach((obj: any) => {
                    // Translate Schema Form fields..
                    let translatedText = jsonObject.schema.properties[obj].placeholder || jsonObject.schema.properties[obj].selectText;
                    if (translatedText.endsWith('*')) {
                        translatedText = translatedText.slice(0, -1);
                    }
                    let translatedValue = this._translateService.get(
                        decodeURIComponent(encodeURIComponent('schemaform.' + translatedText)))['value'];
                    translatedValue = translatedValue ? translatedValue : translatedText;
                    if (jsonObject.schema.required) {
                        if (jsonObject.schema.required.indexOf(obj) > -1) {
                            translatedValue += '*';
                        }
                    }
                    translatedValue = this._translateKey.transform(translatedValue, false);
                    translatedValue = translatedValue ? translatedValue : translatedText;
                    if (jsonObject.schema.properties[obj].placeholder) {
                        jsonObject.schema.properties[obj].placeholder = translatedValue;
                    } else if (jsonObject.schema.properties[obj].selectText) {
                        jsonObject.schema.properties[obj].selectText = translatedValue;
                    }
                    // Unique Validation Message Translation
                    if (jsonObject.schema.properties[obj].uniqueValidationMessage) {
                        const errorTranslatedText = jsonObject.schema.properties[obj].uniqueValidationMessage;
                        let errorTranslatedValue = this._translateService.
                            get(decodeURIComponent(encodeURIComponent('schemaform.' + errorTranslatedText)))['value'];
                        errorTranslatedValue = this._translateKey.transform(errorTranslatedValue, false);
                        jsonObject.schema.properties[obj].uniqueValidationMessage = errorTranslatedValue ?
                            errorTranslatedValue : errorTranslatedText;
                    }
                    // Translate Validation messages..
                    if (jsonObject.schema.properties[obj].validationMessages) {
                        const validationMessagesKeys = Object.keys(jsonObject.schema.properties[obj].validationMessages);
                        validationMessagesKeys.forEach((validationObj) => {
                            if (validationObj) {
                                const errorTranslatedText = jsonObject.schema.properties[obj].validationMessages[validationObj];
                                if (errorTranslatedText) {
                                    let errorTranslatedValue = this._translateService.get(
                                        decodeURIComponent(encodeURIComponent('schemaform.' + errorTranslatedText)))['value'];
                                    errorTranslatedValue = errorTranslatedValue ? errorTranslatedValue : errorTranslatedText;
                                    errorTranslatedValue = this._translateKey.transform(errorTranslatedValue, false);
                                    jsonObject.schema.properties[obj].validationMessages[validationObj] = errorTranslatedValue ?
                                        errorTranslatedValue : errorTranslatedText;
                                }
                            }
                        });
                    }
                });
            }
        }
        // Translate Schema form Button Text..
        if (jsonObject && jsonObject.form) {
            const jsonObjectForm = jsonObject.form;
            for (let i = 0; i < jsonObjectForm.length; i++) {
                jsonObjectForm[i].items = this.searchButtonTitle(jsonObjectForm[i].items);
            }
        }
        return jsonObject;
    }

    /** Search Button text
     * @param  {any} items
     */
    searchButtonTitle(items: any) {
        items.forEach(element => {
            if (element.title) {
                const translatedText = element.title;
                let translatedValue = this._translateService.get(
                    decodeURIComponent(encodeURIComponent('schemaform.' + translatedText)))['value'];
                translatedValue = translatedValue ? translatedValue : translatedText;
                translatedValue = this._translateKey.transform(translatedValue, false);
                translatedValue = translatedValue ? translatedValue : translatedText;
                element.title = translatedValue;
            }
            if (element.items instanceof Array) {
                const item = element.items;
                this.searchButtonTitle(item);
            }
        });
        return items;
    }

    /**
     * @returns void
     */
    findErrorElement(): void {
        setTimeout(() => {
            this.addressComponentSettings.validationMessageInitialHide = false;
            if (document.getElementsByClassName('help-block').length > 0) {
                this.hideErrorElement(true);
            }
        }, 500);
    }

    /**
     * @param  {boolean} hide
     * @returns void
     */
    private hideErrorElement(hide: boolean): void {
        const elements = this.elementRef.nativeElement.getElementsByClassName('help-block');
        if (elements) {
            for (let i = 0; i < elements.length; i++) {
                if (hide) {
                    this._renderer.setElementClass(elements[i], 'hide', true);
                    this._renderer.setElementClass(elements[i], 'show', false);
                } else {
                    this._renderer.setElementClass(elements[i], 'show', true);
                    this._renderer.setElementClass(elements[i], 'hide', false);
                }
            }
        }
    }

    /**
     * to save address
     * and to emit the onsubmit output emmiter
     * @param  {any} address
     * @returns void
     */
    saveAddress(address: Address): void {
        if (address) {
            this.addressComponentSettings.address = address;
            //  Mapping the Shipping Address Id for Updating the Address in Enrollment Flow
            const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
            if (!this.addressComponentSettings.userInfo &&
                checkoutInformation && checkoutInformation.shippingInformation
                && checkoutInformation.shippingInformation.shippingAddress) {
                if (checkoutInformation.shippingInformation.shippingAddress) {
                    address.id = checkoutInformation.shippingInformation.shippingAddress.id;
                }
            }
            if (this.addressComponentSettings.showAddressVerification && !this.skipAddressVerification) {
                this.addressComponentSettings.showAddressVerification = false;
                this.addressComponentSettings.originalAddress = this.prepareNewAddress(address);
                this.getSuggestedAddress(this.addressComponentSettings.originalAddress);
            } else {
                this.processEnteredAddress(address);
            }
        } else {
            this.notifyInvalidAddress.emit(true);
            this.hideErrorElement(false);
        }
    }

    /**
     * @description get adderss
     * @param {Address} address
     * @returns {Address}
     * @memberof AddressNewComponent
     */
    prepareNewAddress(address: Address): Address {
        if (address) {
            let state: State;
            if (this.addressComponentSettings.states && this.addressComponentSettings.states.length > 0) {
                if (address.state) {
                    state = this.addressComponentSettings.states.find(x => x.stateCode.toUpperCase() === address.state.toUpperCase());
                }
                if (!state) {
                    state = this.addressComponentSettings.states[0];
                }
            }
            const mappedAddress: Address = {
                name: address.name,
                firstName: address.firstName,
                lastName: address.lastName,
                middleName: address.middleName,
                addressLine1: address.addressLine1,
                addressLine2: address.addressLine2,
                city: address.city,
                state: state ? state.stateCode : '',
                stateId: state ? state.id : 0,
                stateCode: state ? state.stateCode : '',
                zip: address.zip || address.postalCode,
                postalCode: address.zip || address.postalCode,
                countryId: Number(address.country) || this.addressComponentSettings.countryId,
                country: this.addressComponentSettings.isoCountryCode,
                countryCode: this.addressComponentSettings.isoCountryCode,
                addressVerified: address.addressVerified || address.validAddress,
                validAddress: address.validAddress,
                phone: address.phone ? address.phone : null,
                phoneNumber: address.phone ? address.phone : null,
                saveForFutureUse: address.saveForFutureUse,
                id: address.id,
                phoneType: address.phoneType,
                latitude: address.latitude,
                longitude: address.longitude
            };
            return mappedAddress;
        }
    }

    /**
    * @description to get the suggested address and perform specific actions
    * @returns void
    */
    getSuggestedAddress(addressRequestObj: Address): void {
        this.addressComponentSettings.responseCodes = [];
        addressRequestObj.zip = addressRequestObj.zip.toUpperCase();
        addressRequestObj.postalCode = addressRequestObj.zip.toUpperCase();
        this._addressService.getSuggestedAddress(addressRequestObj)
            .subscribe((verifyAddressResponse: Address) => {
                if (verifyAddressResponse) {
                    this.addressComponentSettings.errorCodes = null;
                    if (verifyAddressResponse.errorCodes && verifyAddressResponse.errorCodes.length > 0) {
                        verifyAddressResponse.errorCodes.forEach((code: VerifyAddressErrorCode) => {
                            const responseCode: AddressResponse = {
                                responseCode: code.errorCode,
                                responseDescription: code.validationMessage
                            };
                            this.addressComponentSettings.responseCodes.push(responseCode);
                        });
                        this.addressComponentSettings.errorCodes = verifyAddressResponse.errorCodes.filter((x: any) =>
                            x.messageRequired === true && x.propertyName !== 'Note').length;
                    }
                    if (this.addressComponentSettings.errorCodes) {
                        this.addressComponentSettings.addressVerificationForm = true;
                        this.populateSuggestedAddress(verifyAddressResponse);
                        this.loadDesktopOrMobileAddressVerification(true);
                    } else if (verifyAddressResponse.sameAsSuggestedAddress) {
                        this.addressComponentSettings.suggestedAddress = verifyAddressResponse;
                        this.addressComponentSettings.suggestedAddress.zip = verifyAddressResponse.postalCode;
                        this.addressComponentSettings.suggestedAddress.phone = this.addressComponentSettings.originalAddress.phone
                            ? this.addressComponentSettings.originalAddress.phone : null;
                        this.addressComponentSettings.selectedAddressType = AddressOptions.SUGGESTEDADDRESS;
                        this.selectAddress();
                    } else {
                        this.addressComponentSettings.originalAddress = addressRequestObj;
                        this.addressComponentSettings.originalAddress =
                            this.transformAddressZipCode(this.addressComponentSettings.originalAddress);
                        this.addressComponentSettings.addressVerificationForm = false;
                        this.addressComponentSettings.suggestedAddress = verifyAddressResponse;
                        this.addressComponentSettings.suggestedAddress.zip = verifyAddressResponse.postalCode;
                        this.addressComponentSettings.suggestedAddress.phone = this.addressComponentSettings.originalAddress.phone
                            ? this.addressComponentSettings.originalAddress.phone : null;
                        this.getSchemaFormButton(false);
                        this.loadDesktopOrMobileAddressVerification(true);
                    }
                }

            }, (error: any) => {
                this.translateParams = this._commonService.handleError(error);
            });
    }

    /**
     * @description method to populate suggested address
     * @param {Address} suggestedAddress
     * @memberof AddressNewComponent
     */
    populateSuggestedAddress(suggestedAddress: Address): void {
        if (suggestedAddress) {
            this.addressComponentSettings.addressVerificationForm = false;
            if (!this.chRef['destroyed']) {
                this.chRef.detectChanges();
            }
            if (suggestedAddress.errorCodes && suggestedAddress.errorCodes.length > 0) {
                this.addressComponentSettings.jsonFormObject = this.getCustomErrorMessages(suggestedAddress.errorCodes);
            }
            this.addressComponentSettings.jsonFormObject = this.getSchemaFormButton(true);
            this.addressComponentSettings.jsonFormObject.data =
                this.mapAddressToSchemaFields(this.addressComponentSettings.originalAddress);
        } else {
            this.addressComponentSettings.jsonFormObject.data = suggestedAddress;
        }
        this.addressComponentSettings.addressVerificationForm = true;
        this.addressComponentSettings.showAddressVerification = false;
        this.findErrorElement();
    }

    /**
     * once we click on verify button, show the 3 bttons and note block
     * and hide the verify button
     * @returns any
     */
    getSchemaFormButton(show: boolean): any {
        if (this.addressComponentSettings.jsonFormObject && this.addressComponentSettings.jsonFormObject.form) {
            const form: any = this.addressComponentSettings.jsonFormObject.form.filter((x: any) => x.type === 'div');
            const items: any = form[0].items;
            items.forEach((x: any) => {
                if (x && x.items.length > 0) {
                    x.items.forEach((y: any) => {
                        if (y.eventId === 'UseOriginalAddress') {
                            if (show) {
                                y.fieldHtmlClass = 'show';
                            } else {
                                y.fieldHtmlClass = 'hide';

                            }
                        }
                        if (y.eventId === 'VerifyAddress') {
                            if (show) {
                                y.fieldHtmlClass = 'show verify-address';
                            } else {
                                y.fieldHtmlClass = 'hide verify-address';

                            }
                        }
                    });
                }
            });
        }
        return this.addressComponentSettings.jsonFormObject;
    }

    /**
     * to get error messages
     * @param  {any} errorCode
     */
    getCustomErrorMessages(errorCode: any): any {
        if (this.addressComponentSettings.jsonFormObject && this.addressComponentSettings.jsonFormObject.form) {
            Object.keys(this.addressComponentSettings.jsonFormObject.schema.properties).forEach((x, y) => {
                const errorProperty: any = errorCode.filter((z: any) => z.propertyName.toUpperCase() === x.toUpperCase());
                const schemaProperty: any = this.addressComponentSettings.jsonFormObject.schema.properties[x];
                if (errorProperty.length > 0) {
                    schemaProperty.customErrorMessage = '';
                    errorProperty.forEach((error: any) => {
                        if (error.messageType === 'AddressCorrected') {
                            schemaProperty.customErrorMessage = '';
                            schemaProperty.htmlClass = 'color-green';
                        } else if (error.messageType === 'ErrorMessage') {
                            let translatedValue = this._translateService.get(
                                decodeURIComponent(encodeURIComponent('schemaform.' + error.validationMessage)))['value'];
                            translatedValue = translatedValue ? translatedValue : error.validationMessage;
                            translatedValue = this._translateKey.transform(translatedValue, false);
                            translatedValue = translatedValue ? translatedValue : error.validationMessage;
                            schemaProperty.customErrorMessage = schemaProperty.customErrorMessage !== ''
                                && schemaProperty.customErrorMessage !== undefined ?
                                '<div>' + schemaProperty.customErrorMessage + '</div><div>' + translatedValue + '</div>'
                                : translatedValue;
                            schemaProperty.htmlClass = 'color-yellow';
                        }
                    });
                } else {
                    schemaProperty.customErrorMessage = '';
                }
            });
        }
        return this.addressComponentSettings.jsonFormObject;
    }

    /**
    * @param  {any} address
    * @returns any
    */
    private mapAddressToSchemaFields(address: Address): Address {
        if (address) {
            const mapSchemaFields: Address = {
                firstName: address.firstName,
                middleName: address.middleName,
                lastName: address.lastName,
                name: address.name,
                addressLine1: address.addressLine1,
                addressLine2: address.addressLine2,
                city: address.city,
                state: address.state,
                zip: address.zip || address.postalCode,
                country: String(address.countryId),
                phone: address.phone ? address.phone : null,
                saveForFutureUse: address.saveForFutureUse,
                phoneType: address.phoneType
            };
            return mapSchemaFields;
        }

    }

    /**
     * Store the selected address type
     * @param selectedAddressType
     */
    setAddressType(selectedAddressType: AddressOptions) {
        this.addressComponentSettings.selectedAddressType = selectedAddressType;
    }

    /**
     * select Address
     */
    selectAddress() {
        if (this.addressComponentSettings.selectedAddressType === AddressOptions.ORIGINALADDRESS) {
            this.emitEnteredAddress(this.addressComponentSettings.originalAddress);
        } else if (this.addressComponentSettings.selectedAddressType === AddressOptions.SUGGESTEDADDRESS) {
            this.addressComponentSettings.suggestedAddress.name = this.addressComponentSettings.originalAddress.name;
            this.addressComponentSettings.suggestedAddress.firstName = this.addressComponentSettings.originalAddress.firstName;
            this.addressComponentSettings.suggestedAddress.middleName = this.addressComponentSettings.originalAddress.middleName;
            this.addressComponentSettings.suggestedAddress.lastName = this.addressComponentSettings.originalAddress.lastName;
            this.addressComponentSettings.suggestedAddress.phoneType = this.addressComponentSettings.originalAddress.phoneType;
            this.addressComponentSettings.suggestedAddress.saveForFutureUse = this.addressComponentSettings
                .originalAddress.saveForFutureUse;
            if (this.addressComponentSettings.originalAddress && this.addressComponentSettings.originalAddress.id) {
                this.addressComponentSettings.suggestedAddress.id = this.addressComponentSettings.originalAddress.id;
            }
            this.emitEnteredAddress(this.addressComponentSettings.suggestedAddress);
        }
        this.loadDesktopOrMobileAddressVerification(false);
        this.getSchemaFormButton(false);
    }

    /**
     * @description this method is used
     * emit entered address from child to parent
     * component
     * @date 2018-07-20
     * @memberof AddressComponent
     */
    emitEnteredAddress(address: Address): void {
        this.addressComponentSettings.addressSubmitted = true;
        this.addressComponentSettings.address = this.prepareNewAddress(address);
        this.addressSubmit.emit(this.addressComponentSettings);
    }

    /**
     * to perform actions on click of each button
     * @param  {any} event
     * @returns void
     */
    verifyButtonSubmit(event: any): void {
        if (event.eventId === 'UseOriginalAddress' && this.addressComponentSettings.liveFormStatus) {
            this.processEnteredAddress(this.addressComponentSettings.liveFormData);
        } else {
            this.hideErrorElement(false);
        }
    }

    /**
     * @description this method ued to
     * emit address from child to parent
     * component while
     * @date 2018-07-23
     * @param {Address} address
     * @memberof AddressComponent
     */
    processEnteredAddress(address: Address): void {
        this.addressComponentSettings.addressVerificationForm = false;
        this.addressComponentSettings.jsonFormObject = this.getSchemaFormButton(false);
        this.hideErrorElement(true);
        const existingAddress: Address = this.prepareNewAddress(address);
        this.emitEnteredAddress(existingAddress);
        this.loadDesktopOrMobileAddressVerification(false);
        this.getSchemaFormButton(false);
    }

    /**
     * @returns void
     */
    onHidden(): void {
        this.getSchemaFormButton(false);
    }

    /**
    * re bind form when we click on change address
    * @returns void
    */
    rebindForm(): void {
        this.addressComponentSettings.editSubscription = this._commonService.getEmitter('editAddress')
            .subscribe((response: any) => {
                this.getJsonSchema(response);
                this.addressComponentSettings.jsonFormObject.data = response;
                if (response && !response.isSavedAddress) {
                    if (!this.chRef['destroyed']) {
                        this.chRef.detectChanges();
                    }
                    this.addressComponentSettings.addressVerificationForm = true;
                    this.loadDesktopOrMobileAddressVerification(true);
                }
            });
    }

    /**
     * @description this method will be used
     * to load address verification based on mobile or desktop devices
     * @date 2018-08-02
     * @private
     * @memberof AddressComponent
     */
    private loadDesktopOrMobileAddressVerification(displayVerification: boolean): void {
        this.addressComponentSettings.displayAddressBlock = displayVerification;
        this.addressComponentSettings.templateCTX = { addressComponentSettings: this.addressComponentSettings };
        if (this._deviceService.isMobile()) {
            this.addressComponentSettings.displayMobileAddressVerification = displayVerification;
            this.addressVerificationInfo.emit(displayVerification);
            if (!displayVerification) {
                this.addressComponentSettings.jsonFormObject =
                    this.getParsedSchemaFormJson(this.addressComponentSettings.originalJsonFormObject);
                this.addressComponentSettings.jsonFormObject.data = this.addressComponentSettings.address;
            }
        } else {
            this.addressComponentSettings.displayMobileAddressVerification = false;
            if (displayVerification) {
                if (!this.addressComponentSettings.isModalOpen) {
                    this.addressComponentSettings.isModalOpen = true;
                    this.addressModal.show();
                }
            } else {
                this.addressComponentSettings.isModalOpen = false;
                this.addressComponentSettings.jsonFormObject.data = this.addressComponentSettings.address;
                this.addressModal.hide();
            }
        }
        if (!this.addressComponentSettings.displayAddressBlock) {
            setTimeout(() => {
                this.addressComponentSettings.displayAddressBlock = true;
            }, 100);
        }
    }

    /**
     *Edit the Address
     * @param {Address} originalAddress
     * @memberof AddressComponent
     */
    editAddress(originalAddress: Address) {
        this.addressComponentSettings.addressVerificationForm = true;
        this.addressComponentSettings.addressSubmitted = false;
        this.getJsonSchema(originalAddress, true);
        this.addressComponentSettings.jsonFormObject.data = originalAddress;
        this.addressComponentSettings.showAddressVerification = true;
    }

    /**
     * @description this method will subscribe
     * event from parent component and subbmit address
     * @date 2018-07-20
     * @memberof AddressComponent
     */
    submitAddress(): void {
        this.addressComponentSettings.submitAddressSubscription = this._appMessageService
            .getSubmitAddress().subscribe((isSubmit: boolean) => {
                this.addressComponentSettings.showAddressVerification = isSubmit;
                if (!this.addressComponentSettings.addressSubmitted) {
                    const element = this.elementRef.nativeElement.getElementsByClassName('verify-address');
                    if (element && element[0]) {
                        element[0].click();
                    }
                } else {
                    this.emitEnteredAddress(this.addressComponentSettings.address);
                }

            });
    }

    /**
     * @description this method will get status of form
     * @date 2018-10-10
     * @memberof AddressNewComponent
     */
    liveFormDataIsValid(formStatus: boolean): void {
        this.addressComponentSettings.liveFormStatus = formStatus;
    }

    /**
    * @description this method will mask phone number based on country format
    * @date 2018-11-13
    * @private
    * @memberof AddressNewComponent
    */
    private maskPhoneNumber(phone: string): string {
        if (phone) {
            return this._maskPipe
                .transform(phone, '(000) 000-0000');
        }
    }

    /**
     *Suffixes the Zipcode required for tax calculation
     *
     * @param {Address} address
     * @returns {Address}
     * @memberof AddressNewComponent
     */
    transformAddressZipCode(address: Address): Address {
        if (address && address.countryId === CountrySuffixZipCodes.USACountrySuffixZipCode.countryId) {
            address.zip = (address.zip && address.zip.length === CountrySuffixZipCodes.USACountrySuffixZipCode.zipCodeLength)
                ? (address.zip + '-' + CountrySuffixZipCodes.USACountrySuffixZipCode.defaultSuffixZipCode) : address.zip;
            address.postalCode = (address.postalCode && address.postalCode.length ===
                CountrySuffixZipCodes.USACountrySuffixZipCode.zipCodeLength) ? (address.postalCode + '-' +
                    CountrySuffixZipCodes.USACountrySuffixZipCode.defaultSuffixZipCode) : address.postalCode;
        }
        return address;
    }

    /**
     * To avoid MemoryLeaks need to unsubscribe.
     */
    ngOnDestroy() {
        this.chRef.detach();
        if (this.addressComponentSettings.editSubscription) {
            this.addressComponentSettings.editSubscription.unsubscribe();
        }
        if (this.addressComponentSettings.submitAddressSubscription) {
            this.addressComponentSettings.submitAddressSubscription.unsubscribe();
        }
    }
}
