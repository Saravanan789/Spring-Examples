import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { SponsorSearchResponse, SponsorSearchRequest, SponsorInformation } from '../interfaces';
import { Address } from '../../common/interfaces';



@Injectable()
export class SponsorService {
  constructor(private _http: Http) { }


  /**
   * Sponsor Search
   * @param  {any} sponsorSearchRequest
   * @param  {number} limit?
   * @returns Observable
   */
  searchSponsors(sponsorSearchRequest: SponsorSearchRequest, limit?: number)
    : Observable<SponsorSearchResponse> {
    const _searchSponsorUrl = ApiUrlConstants.accountApiUrl +
      '/sponsor-search';
    return this._http
      .post(_searchSponsorUrl, sponsorSearchRequest)
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  sponsorOptions(): Observable<SponsorInformation> {
    const _searchSponsorUrl = ApiUrlConstants.accountApiUrl +
      // will be uncommented once options are avilable for all countries
      // '/countries/' + countryCode + '/sponsor-search-options';
      '/countries/usa/sponsor-search-options';
    return this._http
      .get(_searchSponsorUrl)
      // .get('/assets/test/sponsor-option.json')
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description this method will  get sponsor by uuid
   * @date 2019-03-18
   * @returns {Observable<SponsorInformation>}
   * @memberof SponsorService
   */
  getSearchSponsorsByUUID(sponsorSearchResponse: SponsorSearchResponse): Observable<SponsorSearchResponse> {
    const _searchSponsorUrl = sponsorSearchResponse.location;
    return this._http
      .get(decodeURIComponent(encodeURIComponent(_searchSponsorUrl)))
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description
   * @date 2018-12-12
   * @param {string} sponsorId
   * @param {string} sponsorCountry
   * @returns {Observable<any>}
   * @memberof SponsorService
   */
  sponsorEligibilityCheck(sponsorId: string, sponsorCountry: string): Observable<any> {
    const _searchSponsorUrl = ApiUrlConstants.accountApiUrl +
      // will be uncommented once options are avilable for all countries
      // '/countries/' + countryCode + '/sponsor-search-options';
      '/sponsor-eligibility-check/' + sponsorId + '/' + sponsorCountry;
    return this._http
      .get(_searchSponsorUrl)
      // .get('/assets/test/sponsor-option.json')
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  getSponsorEligibility(selectedSponsor: SponsorInformation): Observable<any> {
    const _sponsorEligibityUrl =
      ApiUrlConstants.accountApiUrl +
      '/enrollment/member/sponsor-eligibility?sponsorId=' +
      selectedSponsor.sponsorId +
      '&countryId=' +
      selectedSponsor.sponsorCountryId +
      '&sponsorCountry=' +
      selectedSponsor.sponsorCountryCode;
    return this._http
      .get(_sponsorEligibityUrl)
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description
   * @date 2018-10-16
   * @param {string} sponsorId
   * @returns {Observable<SponsorSearchResponse>}
   * @memberof SponsorService
   */
  searchSponsorById(sponsorId: string): Observable<SponsorSearchResponse> {
    const _searchSponsorUrl =
      ApiUrlConstants.accountApiUrl +
      '/enrollment/member/sponsor-search?searchType=BY-SPONSOR&searchBy=sponsorId&sponsorId=' +
      sponsorId;
    return this._http
      .get(decodeURIComponent(encodeURIComponent(_searchSponsorUrl)))
      .map((res: Response) => res.json())
      .catch(this.handleErrorObservable);
  }

  /**
   * @description this method will map addess
   * of sponsor
   * @date 2018-10-16
   * @param {*} sponsor
   * @returns {Address}
   * @memberof SponsorSelectionComponentNew
   */
  mapAddressModel(sponsor: SponsorInformation): Address {
    // creating a address object to be added to sponsor info
    const address = {
      id: null,
      memberId: null,
      addressLine1: sponsor.sponsorAddressLine1,
      addressLine2: null,
      addressLine3: null,
      addressLine4: null,
      city: sponsor.sponsorCity,
      stateId: sponsor.sponsorStateId,
      countryId: sponsor.sponsorCountryId,
      postalCode: sponsor.sponsorPostalCode,
      addressVerificationStatus: false,
      addressType: null,
      state: sponsor.sponsorStateCode,
      stateCode: sponsor.sponsorStateCode,
      countryCode: sponsor.sponsorCountryCode,
      country: sponsor.sponsorCountryCode,
      latitude: null,
      longitude: null,
      defaultAddress: null,
      county: null,
      name: null,
      company: null,
      errorCodes: null,
      formattedAddress: null,
      organization: null,
      countryFullName: null,
      phone: null,
      countryCodeTwo: null,
      residential: false,
      validAddress: false
    };
    return address;
  }

  /**
   * To handle the obervable error response
   * @param  {Response|any} error
   */
  private handleErrorObservable(error: Response | any) {
    return Observable.throw(error.message || error);
  }
}
