import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  /**
   * @param  {Array<any>} items
   * @param  {predicate} filterOptions
   * @returns Array<any>
   */
  transform(items: any, filterOptions: any): any {
    if (filterOptions && Array.isArray(items)) {
      const filterKeys = Object.keys(filterOptions);
      return items.filter(item =>
        filterKeys.reduce((memo, keyName) => (memo && new RegExp(filterOptions[keyName], 'gi')
                  .test(item[keyName])) || filterOptions[keyName] === '', true));
    } else {
      return items;
    }
  }
}
