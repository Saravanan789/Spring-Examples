import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
// declare var $: any;
import * as $ from 'jquery';
@Pipe({
  name: 'safeHtml',
  pure: true
})
export class SafeHtmlPipe implements PipeTransform {
  constructor(private domSanitizer: DomSanitizer) { }
  handleExternalScriptsInHtmlString(con: string) {
    const results = [];
    if (con) {
      const that = this;
      const parser = new DOMParser();
      let scripts = null;
      if (parser.parseFromString(con, 'text/html') && parser.parseFromString(con, 'text/html').getElementsByTagName('script')) {
        scripts = parser.parseFromString(con, 'text/html').getElementsByTagName('script');
      }
      for (let i = 0; i < scripts.length; i++) {
        const src = scripts[i].getAttribute('src');
        if (src && src.length && results.indexOf(src) === -1) {
          results.push(src);
          that.addScript(src);
        } else {
          // With a blob:
          const blob = new Blob([scripts[i].innerHTML], { type: 'text/javascript' });
          const urlCreator = window.URL;
          const blobUrl = urlCreator.createObjectURL(blob);
          that.loadScript(blobUrl);
        }
      }
    }
    return results;
  }

  loadScript(blobUrl: any) {
    // Add a the script tag to the head
    const head = document.getElementsByTagName('head')[0];
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = blobUrl;

    // Bind the callback (depends on browser compatibility).
    // script.onreadystatechange = callback;
    // script.onload = callback;
    // Load the script
    head.appendChild(script);
  }

  addScript(src: string) {
    const script = document.createElement('script');
    script.setAttribute('src', src);
    document.body.appendChild(script);
  }


  transform(htmlContent: any) {
    const sanitizeHtmlContent = this.domSanitizer.bypassSecurityTrustHtml(htmlContent);
    this.handleExternalScriptsInHtmlString(htmlContent);
    return sanitizeHtmlContent;
  }
}
