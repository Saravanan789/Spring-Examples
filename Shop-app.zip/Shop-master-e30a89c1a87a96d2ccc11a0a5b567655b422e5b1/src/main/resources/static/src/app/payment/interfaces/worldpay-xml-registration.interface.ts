import { PayvisionRegistrationRequest } from './payvision-registration-request.interface';
import { PaymentCallBackUrl } from './payment-callback-url.interface';
import { Address } from '../../common/interfaces';
import { WorldpayXMLPaymentService } from './worldpay-xml-payment-service.interface';

export interface WorldpayXMLRegistration {
    countryCode: string;
    paymentMethodType: string;
    customerId: number;
    storeId: number;
    orderTypeId?: number;
    orderReferenceId?: number;
    paymentRequestModel: PayvisionRegistrationRequest;
    paymentCallBackUrlModel: PaymentCallBackUrl;
    currencyCode: string;
    billingAddress: Address;
    paymentServiceModel: WorldpayXMLPaymentService;
}
