export enum TaxType {
    GST_TAX = 'GSTTAX',
    PST_TAX = 'PSTTAX'
}
