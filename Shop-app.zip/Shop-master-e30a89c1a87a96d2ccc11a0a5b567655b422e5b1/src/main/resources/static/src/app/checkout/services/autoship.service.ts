import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import {
    Autoship, AutoshipFrequencyResponse,
    CheckoutInformation, AutoshipShippingInformation, OrderShipping, AutoshipProduct
} from '../interfaces';
import { CacheService, ConfigurationService } from '../../shared/services';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { AutoshipStatus, ShippingType, DeliveryOptionType, AutoshipFrequency } from '../enums';
import { StoreConfig, Country, Member } from '../../shared/interfaces';
import { Item, Cart } from '../../shared/models';
import { OrderService } from './order.service';
import { CheckoutComponentSettings } from '../component-settings';

/**
 * @description this service will handle all
 * autoship request and response
 * @date 2018-07-31
 * @export
 * @class AutoshipService
 */
@Injectable()
export class AutoshipService {
    constructor(
        private _http: Http,
        private _cacheService: CacheService,
        private _configurationService: ConfigurationService) { }


    /**
     * @description get Frequency Types for Autoship
     * @date 2018-07-31
     * @returns {Observable<AutoshipFrequencyResponse>}
     * @memberof AutoshipService
     */
    getFrequencyTypes(): Observable<AutoshipFrequencyResponse[]> {
        return this._http
            .get(ApiUrlConstants.orderApiUrl + '/frequencyTypes')
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * Create Autoship profile
     * @param autoshipRequest
     */
    createAutoshipProfile(autoshipRequest: Autoship): Observable<Autoship> {
        return this._http.post(ApiUrlConstants.orderApiUrl + '/autoships', JSON.stringify(autoshipRequest))
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
 * update autoship profile
 * @param{autoshipItem} AutoshipPreferenceModal
 * @returns {any} Observable
 */
    updateAutoShipProfileById(autoshipItem: Autoship): Observable<Autoship> {
        const updateAutoShipItemUrl = ApiUrlConstants.orderApiUrl + '/autoships/' + autoshipItem.id;
        return this._http.put(updateAutoShipItemUrl, autoshipItem).map(response => {
            return response.json();
        }).catch(this.handleErrorObservable);
    }


    /**
     * @description  this method will create autoshi
     * request
     * @date 2018-07-31
     * @param {StoreConfig} store
     * @param {Country} selectedCountry
     * @returns {Autoship}
     * @memberof AutoshipService
     */
    createAutoshipRequest(checkoutComponentSettings: CheckoutComponentSettings): Autoship {
        const autoshipCartSession = this._cacheService.get(CacheKey.AutoshipCart);
        const autoshipDate = this._cacheService.get(CacheKey.AutoshipDate);
        const currentDate = new Date();
        const nextMonthdate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 5);
        if (autoshipCartSession && autoshipCartSession.items && checkoutComponentSettings) {
            const autoshipPreference: Autoship = Object.assign({}, checkoutComponentSettings.autoshipPreference);
            const autoshipRequest: Autoship = {
                id: autoshipPreference.id,
                autoshipStatusId: autoshipPreference.autoshipStatusId || AutoshipStatus.INCOMPLETE,
                name: autoshipPreference.name || 'My Autoship 1',
                emailId: this.getUserEmailInfo(checkoutComponentSettings),
                memberId: checkoutComponentSettings.userInfo ? checkoutComponentSettings.userInfo.memberId : null,
                countryId: this.getCountryId(checkoutComponentSettings),
                storeId: checkoutComponentSettings.store.id,
                frequencyTypeId: autoshipPreference.frequencyTypeId || AutoshipFrequency.Monthly,
                startDate: this.dateFormatConversion(autoshipDate || autoshipPreference.startDate || nextMonthdate),
                createdBy: autoshipPreference.createdBy,
                autoshipProducts: this.getAutoshipProducts(checkoutComponentSettings),
                autoshipShippingInformations: this.getShippingInformationDetails(autoshipPreference.autoshipShippingInformations,
                    checkoutComponentSettings),
                autoshipPayments: autoshipPreference.autoshipPayments,
            };
            return autoshipRequest;
        } else {
            return null;
        }
    }

    /**
 * @description date conversion yyyy-mm-dd
 * @date 2018-12-17
 * @param {Date} date
 * @returns {string}
 * @memberof AutoshipPreferenceComponent
 */
    dateFormatConversion(date: Date): string {
        if (date) {
            const autoshipDate = new Date(date);
            let month = '' + (autoshipDate.getMonth() + 1);
            let day = '' + autoshipDate.getDate();
            if (month.length < 2) {
                month = '0' + month;
            }
            if (day.length < 2) {
                day = '0' + day;
            }
            return autoshipDate.getFullYear() + '-' + month + '-' + day;
        }
    }

    /**
 * @description get Shipping Information
 * @date 2018-10-15
 * @param {AutoshipShippingInformation[]} autoshipShippingInformations
 * @param {CheckoutComponentSettings} checkoutComponentSettings
 * @returns {AutoshipShippingInformation[]}
 * @memberof OrderService
 */
    getShippingInformationDetails(autoshipShippingInformations: AutoshipShippingInformation[],
        checkoutComponentSettings: CheckoutComponentSettings): AutoshipShippingInformation[] {
        if (autoshipShippingInformations && autoshipShippingInformations.length > 0) {
            return autoshipShippingInformations;
        } else {
            const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
            let shippingInformations: AutoshipShippingInformation[] = [];
            if (checkoutInformation.shippingInformation && checkoutInformation.autoshipShippingMethodInformation
                && checkoutInformation.autoshipShippingMethodInformation.shippingMethod
                && (checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery)) {
                const shippingInformation: AutoshipShippingInformation = {
                    deliverypreferenceId: ShippingType.DELIVERY,
                    shipMethodId: checkoutInformation.autoshipShippingMethodInformation.shippingMethod.shippingMethodId,
                    shippingAddressId: this.getShippingAddressId(checkoutInformation),
                    createdBy: checkoutComponentSettings.userInfo && checkoutComponentSettings.userInfo.memberId
                        ? checkoutComponentSettings.userInfo.memberId : null,
                    updatedBy: checkoutComponentSettings.userInfo && checkoutComponentSettings.userInfo.memberId
                        ? checkoutComponentSettings.userInfo.memberId : null,
                };
                shippingInformations.push(shippingInformation);
            } else {
                shippingInformations = null;
            }
            return shippingInformations;
        }
    }

    /**
 * @description get country id
 * @date 2018-09-07
 * @param {CheckoutComponentSettings} checkoutComponentSettings
 * @returns {number}
 * @memberof OrderService
 */
    getCountryId(checkoutComponentSettings: CheckoutComponentSettings): number {
        if (checkoutComponentSettings.countries) {
            return checkoutComponentSettings.countries.find(x => x.isocodeThree.toLocaleLowerCase()
                === checkoutComponentSettings.isoCountryCode.toLocaleLowerCase()).countryId;
        } else {
            return null;
        }
    }

    /**
     * @description To get the email address
     * @date 2018-09-07
     * @param {CheckoutComponentSettings} checkoutComponentSettings
     * @returns {string}
     * @memberof OrderService
     */
    getUserEmailInfo(checkoutComponentSettings: CheckoutComponentSettings): string {
        if (checkoutComponentSettings.userInfo && checkoutComponentSettings.userInfo.email) {
            return checkoutComponentSettings.userInfo.email;
        } else if (checkoutComponentSettings.checkoutInformation &&
            checkoutComponentSettings.checkoutInformation.paymentInformation) {
            return checkoutComponentSettings.checkoutInformation.personalInformation.email;
        } else {
            return '';
        }
    }
    /**
    * @description this method is used to
    * prepare autoship product items
   * @date 2018-08-31
   * @returns {AutoshipProduct[]}
   * @memberof OrderService
   */
    getAutoshipProducts(checkoutComponentSettings: CheckoutComponentSettings): AutoshipProduct[] {
        const autoshipProducts: AutoshipProduct[] = [];
        let autoshipCartSession: Cart = Object.assign({});
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (!isAutoshipEnabled) {
            autoshipCartSession = this.mergeAutoshipItemsWithExisting(checkoutComponentSettings);
        } else {
            autoshipCartSession = this._cacheService.get(CacheKey.AutoshipCart);
        }
        if (autoshipCartSession && autoshipCartSession.items && autoshipCartSession.items.length > 0) {
            autoshipCartSession.items.forEach(x => {
                x.id = null;
            });
            const autoshipItems = autoshipCartSession.items;
            autoshipItems.forEach((x: Item) => {
                if (!x.isPromotionalProduct) {
                    const autoshipProduct: AutoshipProduct = {
                        id: x.id ? x.id : null,
                        productId: x.productId,
                        quantity: x.quantity,
                        createdBy: checkoutComponentSettings.userInfo && checkoutComponentSettings.userInfo.memberId
                            ? checkoutComponentSettings.userInfo.memberId : null
                    };
                    autoshipProducts.push(autoshipProduct);
                }

            });
        }
        if (!isAutoshipEnabled) {
            if (checkoutComponentSettings && checkoutComponentSettings.autoshipPreference &&
                checkoutComponentSettings.autoshipPreference.autoshipProducts
                && checkoutComponentSettings.autoshipPreference.autoshipProducts.length > 0) {
                checkoutComponentSettings.autoshipPreference.autoshipProducts.forEach(x => {
                    if (!autoshipProducts.find(y => y.productId === x.productId)) {
                        autoshipProducts.push(x);
                    }
                });
            }
        }
        return autoshipProducts;
    }


    /**
     * @description Merge the Items with the Existing profile Items
     * @date 2018-09-28
     * @memberof CheckoutNewComponent
     */
    mergeAutoshipItemsWithExisting(checkoutComponentSettings: CheckoutComponentSettings): Cart {
        const autoshipCartSession = this._cacheService.get(CacheKey.AutoshipCart);
        if (autoshipCartSession && checkoutComponentSettings.autoshipPreference &&
            checkoutComponentSettings.autoshipPreference.autoshipProducts &&
            checkoutComponentSettings.autoshipPreference.autoshipProducts.length > 0) {
            autoshipCartSession.items.forEach(x => {
                const item = checkoutComponentSettings.autoshipPreference.autoshipProducts.find(y => y.productId === x.productId);
                if (item) {
                    x.quantity = x.quantity + item.quantity;
                    x.id = item.id;
                }
            });
        }
        return autoshipCartSession;
    }

    /**
     * @description this method will return single order
     * shipping
     * @date 2018-07-31
     * @private
     * @returns {OrderShipping}
     * @memberof AutoshipService
     */
    getOrderShippingInfo(): OrderShipping {
        const orderShippings: OrderShipping[] = this.getOrderShippings();
        if (orderShippings && orderShippings.length > 0) {
            const orderShipping = orderShippings[0];
            return orderShipping;
        }
    }

    /**
     * @description
     * @date 2018-08-01
     * @returns {OrderShipping[]}
     * @memberof AutoshipService
     */
    getOrderShippings(): OrderShipping[] {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const orderShippings: OrderShipping[] = [];
        if (checkoutInformation.shippingInformation && checkoutInformation.shippingMethodInformation
            && checkoutInformation.shippingMethodInformation.shippingMethod) {
            const orderShipping: OrderShipping = {
                deliveryPreferenceId: checkoutInformation.shippingInformation.deliveryOptionType
                    === DeliveryOptionType.Delivery ? ShippingType.DELIVERY : ShippingType.PICKUP,
                shipMethodId: checkoutInformation.shippingMethodInformation.shippingMethod.shippingMethodId,
                shippingAddressId: this.getShippingAddressId(checkoutInformation),
                billingAddressId: null,
                shortCode: checkoutInformation.shippingMethodInformation.shippingMethod.shortCode,
                preferredTime: null,
                notes: null,
                shipmentDate: null,
                distributionCenter: checkoutInformation.shippingMethodInformation.shippingMethod.distributionCenterName
            };
            orderShippings.push(orderShipping);
        }
        return orderShippings;
    }

    /**
   * @description this method will return saved shipping
   * address id
   * @date 2018-07-31
   * @private
   * @param {CheckoutInformation} checkoutInformation
   * @memberof AutoshipService
   */
    private getShippingAddressId(checkoutInformation: CheckoutInformation): number {
        return (checkoutInformation.shippingInformation && checkoutInformation.shippingInformation.deliveryOptionType
            === DeliveryOptionType.Delivery && checkoutInformation.shippingInformation.shippingAddress)
            ? checkoutInformation.shippingInformation.shippingAddress.id : 0;
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response) {
        return Observable.throw(error);
    }
}
