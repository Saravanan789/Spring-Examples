import {Directive, AfterViewInit, OnDestroy, ElementRef  } from '@angular/core';


@Directive({
  selector: '[appStaggerAnimation]'
})
export class StaggerDirective implements AfterViewInit, OnDestroy {
  constructor(private elementRef: ElementRef) {
    // setTimeout(() => {
      this.elementRef.nativeElement.classList.add('entering');
    // }, 100);
    this.removeClass('entering');
  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      this.elementRef.nativeElement.classList.add('enter');
    }, 500);
    // this.removeClass('enter');
  }
  ngOnDestroy(): void {
    this.elementRef.nativeElement.classList.add('leave');
  }
  removeClass(className: string): void {
    setTimeout(() => {
      this.elementRef.nativeElement.classList.remove(className);
    }, 1000);
  }
}
