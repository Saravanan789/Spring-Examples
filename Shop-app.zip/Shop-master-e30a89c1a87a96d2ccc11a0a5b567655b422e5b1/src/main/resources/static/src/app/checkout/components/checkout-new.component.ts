import { Component, OnInit, OnDestroy } from '@angular/core';
import { CacheService, CommonService, ConfigurationService, ActiveSessionService } from '../../shared/services';
import {
    CheckoutMessageService, OrderService, AutoshipService,
    EnrollService,
    SponsorService
} from '../services';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { CheckoutComponentSettings, CartSummaryComponentSettings } from '../component-settings';
import { ResponseStatus, CheckoutConstants, DefaultSponsors } from '../constants';
import {
    Order, CheckoutInformation, EnrollSession,
    MemberContact, PersonalInformation, EnrollInfo, SponsorInformation,
    SponsorSearchResponse,
    SponsorSearchRequest,
    AutoshipShippingInformation,
    OrderShipping,
    MemberIdentification,
    TaxValidationMessage
} from '../interfaces';
import { Router, NavigationEnd, RouteConfigLoadEnd } from '@angular/router';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { MemberType, UserTitleType, MemberLevel } from '../../shared/enums';
import { Country, State, Language } from '../../shared/interfaces';
import {
    DeliveryOptionType, MemberPreferenceType,
    BreadcrumbStep, SponsorSearchOption, MemeberCommunicationPreferenceValue, ShippingType, IdentificationType, ContactTypeValue
} from '../enums';
import { PersonalInfo } from '../interfaces/personal-info.interface';
import { MemberPreference } from '../interfaces/member-preference.interface';
import { AddressType } from '../../common/enums';
import { WizardStep } from '../enums/wizard-step.enum';
import { LoaderService } from '../../shared/services/loader.service';
import { Address } from '../../common/interfaces';
import { MemberTypeValue } from '../../shared/enums/member-type-value.enum';
import { DocumentLibrary } from '../../payment/interfaces';
import { DatePipe } from '@angular/common';
import { AppMessageService } from '../../app-message.service';
import { environment } from '../../../environments/environment';

/**
 * @description this component will handle the
 * all checkout flow functionalities and processing orders
 * @date 2018-07-31
 * @export
 * @class CheckoutNewComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-checkout',
    templateUrl: './../templates/template3/views/checkout-new.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/checkout-new.component.less'
    ],
    providers: [DatePipe]
})

export class CheckoutNewComponent implements OnInit, OnDestroy {
    checkoutComponentSettings: CheckoutComponentSettings = new CheckoutComponentSettings();

    constructor(
        private _router: Router,
        private _cacheService: CacheService,
        private _commonService: CommonService,
        private _sponsorService: SponsorService,
        private _configurationService: ConfigurationService,
        private _appMessageService: AppMessageService,
        private _datePipe: DatePipe,
        private _checkoutMessageService: CheckoutMessageService,
        private _orderService: OrderService,
        private _autoshipService: AutoshipService,
        private _enrollService: EnrollService,
        private _loaderService: LoaderService) {
    }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Used to load default Cart summary
     * Configuration for the user
     * @date 2018-07-20
     * @memberof CheckoutNewComponent
     */
    loadDefaultSettings() {
        if (environment.dataLayer && environment.dataLayer.length > 0) {
            environment.dataLayer[0].pageCategory = 'shop-checkout';
        }
        this.checkoutComponentSettings.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        this.checkoutComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.checkoutComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.checkoutComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.checkoutComponentSettings.store = this._configurationService.getStoreData();
        this.checkoutComponentSettings.fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        if (this.checkoutComponentSettings.userInfo &&
            this.checkoutComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER) {
            this.checkoutComponentSettings.isPreferredCustomer = true;
        }
        this.getCountriesLookup();
        this.loadMemberType();
        this.shippingMethodSubscription();
        this.loadCheckoutInformation();
        this.routeChangeEvent();
        this.checkoutComponentSettings.autoshipPreference = this._cacheService.get(CacheKey.AutoshipDetails);
    }

    /**
    * @description this method is used
    * load stored information while refreshing the page
    * @date 2018-07-21
    * @memberof ShippingAddressNewComponent
    */
    private loadCheckoutInformation(): void {
        this.checkoutComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    }

    /**
     * @description this method wil subscribe
     * route change event
     * @date 2018-08-17
     * @private
     * @memberof CheckoutNewComponent
     */
    private routeChangeEvent(): void {
        this.checkoutComponentSettings.currentStep = this.getBreadcrumbStep(window.location.pathname);
        this.checkoutComponentSettings.routeChangeEventSubscription = this._router.events
            .subscribe((event: any) => {
                if (event instanceof NavigationEnd || event instanceof RouteConfigLoadEnd) {
                    this.checkoutComponentSettings.fieldErrors = null;
                    this.checkoutComponentSettings.currentStep = this.getBreadcrumbStep(window.location.pathname);
                }
            });
    }

    /**
     *
     * @description To recongnize the Current activated step
     * @param {string} locationPath
     * @returns {BreadcrumbStep}
     * @memberof CheckoutNewComponent
     */
    getBreadcrumbStep(locationPath: string): BreadcrumbStep {
        let result: BreadcrumbStep;
        if (locationPath.indexOf(BreadcrumbStep.SHIPPING.toLowerCase()) > -1) {
            result = BreadcrumbStep.SHIPPING;
        } else if (locationPath.indexOf(BreadcrumbStep.DELIVERY.toLowerCase()) > -1) {
            result = BreadcrumbStep.DELIVERY;
        } else if (locationPath.indexOf(BreadcrumbStep.PAYMENT.toLowerCase()) > -1) {
            result = BreadcrumbStep.PAYMENT;
        }
        return result;
    }

    /**
    *
    * @description To recongnize the Current activated step
    * @param {string} locationPath
    * @returns {BreadcrumbStep}
    * @memberof CheckoutNewComponent
    */
    getBreadcrumbURL(step: BreadcrumbStep): string {
        let result: string;
        switch (step) {
            case BreadcrumbStep.SHIPPING:
                result = '/checkout/shipping';
                break;
            case BreadcrumbStep.DELIVERY:
                result = '/checkout/delivery';
                break;
            case BreadcrumbStep.PAYMENT:
                result = '/checkout/payment';
        }
        return result;
    }
    /**
     * shipping Mthodtype subscription
     * for progressbar status change
     * @memberof CheckoutNewComponent
     */
    shippingMethodSubscription(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.shippingInformation) {
            this.checkoutComponentSettings.deliveryOptionType = checkoutInformation.shippingInformation.deliveryOptionType;
        }
        this.checkoutComponentSettings.shippingMethodSubscription =
            this._checkoutMessageService.getShipmethodTypeSelected().subscribe((deliveryOptionType: DeliveryOptionType) => {
                this.checkoutComponentSettings.deliveryOptionType = deliveryOptionType;
            });
    }

    /**
     * @description this method will load member type
     * or logeed in member information
     * @date 2018-07-25
     * @private
     * @memberof CheckoutNewComponent
     */
    private loadMemberType(): void {
        this.checkoutComponentSettings.registerMemberType = this.checkoutComponentSettings.userInfo
            && this.checkoutComponentSettings.userInfo.memberTypeId
            ? this.checkoutComponentSettings.userInfo.memberTypeId : this._cacheService.get(CacheKey.RegisterMemberType);
    }

    /**
     * @description Get Countries
     * @date 2018-07-19
     * @private
     * @memberof CheckoutNewComponent
     */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.checkoutComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            this.checkoutComponentSettings.selectedCountry =
                this.checkoutComponentSettings.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
                    this.checkoutComponentSettings.isoCountryCode.toLowerCase());
            if (this.checkoutComponentSettings.selectedCountry && this.checkoutComponentSettings.selectedCountry.countryId) {
                this.getStatesLookup(this.checkoutComponentSettings.selectedCountry.countryId);
            }
        } else {
            this._commonService.getCountries().subscribe((res: Country[]) => {
                if (res && res.length > 0) {
                    this.checkoutComponentSettings.countries = res;
                    this._cacheService.set(CacheKey.Countries, this.checkoutComponentSettings.countries);
                    this.checkoutComponentSettings.selectedCountry = this.checkoutComponentSettings.countries.
                        find((x: Country) => x.isocodeThree.toLowerCase() === this.checkoutComponentSettings.isoCountryCode.toLowerCase());
                    if (this.checkoutComponentSettings.selectedCountry && this.checkoutComponentSettings.selectedCountry.countryId) {
                        this.getStatesLookup(this.checkoutComponentSettings.selectedCountry.countryId);
                    }
                }
            });
        }
    }

    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof CheckoutNewComponent
     */
    private getStatesLookup(countryId: number) {
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            this.checkoutComponentSettings.states = storedStates;
        } else if (countryId) {
            this._commonService.getStatesByCountry(countryId).subscribe((res: State[]) => {
                this.checkoutComponentSettings.states = res;
            }, (err: any) => {
            });
        }
    }

    /**
     * @description this method will retrive cart info
     * when we place order from cart component
     * @date 2018-07-31
     * @param {CartSummaryComponentSettings} cartSummaryComponentSettings
     * @memberof CheckoutNewComponent
     */
    getCartSummaryInfo(cartSummaryComponentSettings: CartSummaryComponentSettings): void {
        this.checkoutComponentSettings.cartSummaryComponentSettings = cartSummaryComponentSettings;
        this.loadCheckoutInformation();
        this.placeOrder();
    }

    /**
     * @description
     * @date 2018-07-31
     * @memberof CheckoutNewComponent
     */
    placeOrder(): void {
        this.checkoutComponentSettings.fieldErrors = null;
        if (this._cacheService.get(CacheKey.FPCOptIn)) {
            this.checkoutComponentSettings.fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        }
        if ((!this.checkoutComponentSettings.userInfo
            && this.checkoutComponentSettings.checkoutInformation
            && !this.checkoutComponentSettings.checkoutInformation.retuningGuestUser)
            || ((this.checkoutComponentSettings.userInfo &&
                this.checkoutComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER)
                && this.checkoutComponentSettings.fpcOptIn)) {
            this.processEnrollMember();
        } else if (this.checkoutComponentSettings.isAutoshipEnabled) {
            // If Autoship is enabled redirecting the user to Order Sumamry
            this.placeAutoshipOrder();

        } else {
            this.processCreateOrder();
        }

    }

    /**
     * @description Prepare Autoship Order
     * @date 2018-10-01
     * @memberof CheckoutNewComponent
     */
    placeAutoshipOrder(): void {
        if (this.checkoutComponentSettings && this.checkoutComponentSettings.checkoutInformation
            && this.checkoutComponentSettings.checkoutInformation.shippingInformation
            && this.checkoutComponentSettings.checkoutInformation.shippingMethodInformation) {
            if (this.checkoutComponentSettings.autoshipPreference) {
                this.checkoutComponentSettings
                    .autoshipPreference.autoshipShippingInformations = this.getAutoshipShippingInfo();
            } else {
                this.checkoutComponentSettings.autoshipPreference = Object.assign({});
                this.checkoutComponentSettings
                    .autoshipPreference.autoshipShippingInformations = this.getAutoshipShippingInfo();
            }
        }
        const autoshipRequest = this._autoshipService.createAutoshipRequest(this.checkoutComponentSettings);
        this._cacheService.set(CacheKey.AutoshipDetails, autoshipRequest);
        this.navigateToPayment();
    }

    /**
     * @description get Autoship shipping Information Id
     * @date 2018-10-01
     * @returns {number}
     * @memberof CheckoutNewComponent
     */
    getAutoshipShippingId(): number {
        if (this.checkoutComponentSettings.autoshipPreference &&
            this.checkoutComponentSettings.autoshipPreference.autoshipShippingInformations &&
            this.checkoutComponentSettings.autoshipPreference.autoshipShippingInformations.length > 0) {
            return this.checkoutComponentSettings.autoshipPreference.autoshipShippingInformations[0].id;
        }
    }

    /**
     * @description this method will return order shipping info
     * @date 2018-07-31
     * @param {Member} userInfo
     * @returns {AutoshipShippingInformation[]}
     * @memberof AutoshipService
     */
    getAutoshipShippingInfo(): AutoshipShippingInformation[] {
        const autoshipShippings: AutoshipShippingInformation[] = [];
        const orderShipping: OrderShipping = this._autoshipService.getOrderShippingInfo();
        if (orderShipping && orderShipping.deliveryPreferenceId === ShippingType.DELIVERY) {
            const autoshipShipping: AutoshipShippingInformation = {
                id: this.getAutoshipShippingId(),
                deliverypreferenceId: ShippingType.DELIVERY,
                shipMethodId: orderShipping.shipMethodId,
                shippingAddressId: orderShipping.shippingAddressId,
                createdBy: this.checkoutComponentSettings.userInfo ? this.checkoutComponentSettings.userInfo.memberId : null,
                updatedBy: null
            };
            autoshipShippings.push(autoshipShipping);
            return autoshipShippings;
        } else {
            return null;
        }
    }

    /**
     * @description this method will process
     * create order
     * @date 2018-07-31
     * @private
     * @param {string} [url]
     * @memberof CheckoutNewComponent
     */
    private processCreateOrder(url?: string): void {
        this._loaderService.start();
        const orderRequest: Order = this._orderService.prepareOrderRequest(this.checkoutComponentSettings);
        // If uuid not available then use the default url to create order
        // First call to place order will have blank parameter
        const requestUrl = url ? url : ApiUrlConstants.orderApiUrl + '/orders';
        this._orderService.createNewOrder(orderRequest, requestUrl).subscribe(
            (response: any) => {
                if (response) {
                    if (response.json().status === ResponseStatus.COMPLETED
                        && response.json().responseModel && response.json().responseModel.webOrderId) {
                        this.orderSuccess(response.json().responseModel);
                    } else {
                        this.orderPending(response);
                    }
                } else if (response.validations) {
                    this.closeProgressBar(response);
                    this.checkoutComponentSettings.fieldErrors = response.validations;
                }
            },
            (errResponse: any) => {
                const errorRes = errResponse.json();
                this.closeProgressBar(errorRes);
                this.checkoutComponentSettings.fieldErrors = errorRes.fieldErrors;
            });
    }

    /**
     * Description:
     * This method is called when the status in Completed for order
     * It goes with the normal flow
     * @param responseModel
     */
    orderSuccess(responseModel: Order) {
        this.checkoutComponentSettings.pollCount = 0;
        this.checkoutComponentSettings.orderResponse = responseModel;
        this._cacheService.remove(CacheKey.AutoPopulate);
        if (this.checkoutComponentSettings.orderResponse &&
            this.checkoutComponentSettings.orderResponse.webOrderId) {
            this.storeOrderInfoAndNavigateToPayment(responseModel);
        } else {
            this.closeProgressBar(null);
        }
    }

    /**
     * @description this method helps to
     * navigate to payment
     * @date 2018-08-10
     * @private
     * @memberof CheckoutNewComponent
     */
    private navigateToPayment(): void {
        this._loaderService.stop();
        if (this.checkoutComponentSettings.cartSummaryComponentSettings
            && this.checkoutComponentSettings.cartSummaryComponentSettings.recreateOrder) {
            this._appMessageService.setReCreateOrder(true);
        }
        this._router.navigate([this.checkoutComponentSettings.isoCountryCode + '/'
            + this.checkoutComponentSettings.languageCode.toLowerCase() + '/checkout/payment']);
        const wizardStep = this._cacheService.get(CacheKey.WizardSteps);
        if (wizardStep <= WizardStep.DELIVERY) {
            this._cacheService.set(CacheKey.WizardSteps, WizardStep.DELIVERY);
        }
    }

    /**
     * Description:
     * This method is called the the order is not completed
     * This method recursively calls placeOrder()
     * for a specified number of max poll time.
     * @param response
     */
    orderPending(response: any) {
        if ((response.json().status === ResponseStatus.IN_PROGRESS) || (response.json().status === ResponseStatus.QUEUED)) {
            if (this.checkoutComponentSettings.pollCount < this.checkoutComponentSettings.maxPollCount) {
                this.checkoutComponentSettings.pollCount = this.checkoutComponentSettings.pollCount + 1;
                this.processCreateOrder(response.json().location);
            }
        } else if (response.json().status === ResponseStatus.VALIDATION_ERROR) {
            this.closeProgressBar(response.json().responseModel);
        } else {
            this.closeProgressBar(response.json().responseModel);
        }
    }

    /**
     * @description this method will identify based
     * on selection of Guest and Retail
     * @date 2018-07-31
     * @memberof CheckoutNewComponent
     */
    processEnrollMember(): void {
        this._loaderService.start();
        if (this.checkoutComponentSettings.registerMemberType === MemberType.RETAILCUSTOMER
            && this.checkoutComponentSettings.checkoutInformation
            && this.checkoutComponentSettings.checkoutInformation.sponsorInformation) {
            this.saveEnrollSession();
        } else if (this.checkoutComponentSettings.userInfo
            && this.checkoutComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER
            && this.checkoutComponentSettings.fpcOptIn) {
            this.saveEnrollSession();
        } else if (this.checkoutComponentSettings.checkoutInformation
            && this.checkoutComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER) {
            if (this.checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
                this.getSponsorInfoByReferralOrAutoSuggest(this.checkoutComponentSettings.checkoutInformation.retuningGuestUser.sponsorId);
            } else {
                const referralId: string = this._cacheService.getSessionValue(CacheKey.RepSiteReferralId)
                    || this._cacheService.get(CacheKey.ShareFBOID);
                this.getSponsorInfoByReferralOrAutoSuggest(referralId ? referralId : null);
            }
        }
    }

    /**
     * @description
     * @date 2018-07-31
     * @private
     * @returns {EnrollSession}
     * @memberof CheckoutNewComponent
     */
    private prepareEnrollSessionRequest(): EnrollSession {
        const enrollSession: EnrollSession = {
            enrollInfo: {
                personalInfo: this.preparePersonalInfo(),
                orderInfo: this._orderService.prepareOrderRequest(this.checkoutComponentSettings),
                shoppingCartInfo: this._cacheService.get(CacheKey.CartSessionInfo),
                sponsorId: this.getSelectedSponsorId(),
                sponsorInfo: this.getSponsorInformation()
            },
            sponsorId: this.getSelectedSponsorId(),
        };
        return enrollSession;
    }

    /**
     * @description this method will return default sponsor info
     * @date 2018-08-09
     * @returns {string}
     * @memberof CheckoutNewComponent
     */
    getSelectedSponsorId(): string {
        const sponsorInformation: SponsorInformation = this.getSponsorInformation();
        return sponsorInformation ? sponsorInformation.sponsorId : '';
    }

    /**
     * @description this method will load selected sponsor
     * details
     * @date 2018-08-02
     * @private
     * @memberof CheckoutNewComponent
     */
    private getSponsorInformation(): SponsorInformation {
        if (this.checkoutComponentSettings.checkoutInformation
            && this.checkoutComponentSettings.checkoutInformation.sponsorInformation) {
            return this.checkoutComponentSettings.checkoutInformation.sponsorInformation;
        } else {
            return this.checkoutComponentSettings.defaultOrReferalSponsor;
        }
    }

    /**
     * @description this method will load sponsor
     * based on sponsorid if we don't have sponsor info
     * @date 2018-07-31
     * @param {string} sponsorId
     * @memberof CheckoutNewComponent
     */
    getSponsorInfoByReferralOrAutoSuggest(sponsorId: string): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.personalInformation) {
            this.checkoutComponentSettings.isSponsorFound = false;
            const sponsorSearchRequest: SponsorSearchRequest = this.searchSponsorRequest(sponsorId, checkoutInformation);
            if (sponsorSearchRequest) {
                this.checkoutComponentSettings.sponsorPollCount = 0;
                this._sponsorService
                    .searchSponsors(sponsorSearchRequest)
                    .subscribe((sponsorSearchResponse: SponsorSearchResponse) => {
                        if (this.checkoutComponentSettings.sponsorPollCount < this.checkoutComponentSettings.sponsorMaxPollCount) {
                            this.checkoutComponentSettings.sponsorPollCount = this.checkoutComponentSettings.sponsorPollCount + 1;
                            if (sponsorSearchResponse.requestStatus === ResponseStatus.COMPLETED) {
                                this.processSearchSponsorResponse(sponsorSearchResponse, sponsorId);
                            } else if (sponsorSearchResponse.requestStatus === ResponseStatus.QUEUED ||
                                sponsorSearchResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
                                this.searchSponsorByPolling(sponsorSearchResponse, sponsorId);
                            } else {
                                this.closeProgressBar(null);
                                this.checkoutComponentSettings.isSponsorFound = false;
                                // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                                this.setDefaultSuggestSponsor(environment.defaultFBOID);
                            }
                        } else {
                            this.closeProgressBar(null);
                            this.checkoutComponentSettings.isSponsorFound = false;
                            // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                            this.setDefaultSuggestSponsor(environment.defaultFBOID);
                        }
                    }, (errResponse) => {
                        const errorRes = errResponse.json();
                        this.closeProgressBar(errorRes);
                        this.checkoutComponentSettings.isSponsorFound = false;
                        // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                        this.setDefaultSuggestSponsor(environment.defaultFBOID);
                    });
            } else {
                this.closeProgressBar(null);
                this.checkoutComponentSettings.isSponsorFound = false;
            }
        } else {
            this.closeProgressBar(null);
            this.checkoutComponentSettings.isSponsorFound = false;
        }
    }

    /**
   * @description we will load sponsor by pooling mechanism
   * @date 2019-03-18
   * @private
   * @param {SponsorSearchRequest} sponsorSearchRequest
   * @param {number} [searchOption]
   * @memberof SponsorSelectionComponentNew
   */
    private searchSponsorByPolling(
        searchResponse: SponsorSearchResponse, sponsorId: string): void {
        this._sponsorService
            .getSearchSponsorsByUUID(searchResponse)
            .subscribe((sponsorSearchResponse: SponsorSearchResponse) => {
                if (sponsorSearchResponse) {
                    if (this.checkoutComponentSettings.sponsorPollCount < this.checkoutComponentSettings.sponsorMaxPollCount) {
                        this.checkoutComponentSettings.sponsorPollCount = this.checkoutComponentSettings.sponsorPollCount + 1;
                        if (sponsorSearchResponse.requestStatus === ResponseStatus.COMPLETED) {
                            this.processSearchSponsorResponse(sponsorSearchResponse, sponsorId);
                        } else if (sponsorSearchResponse.requestStatus === ResponseStatus.QUEUED ||
                            sponsorSearchResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
                            this.searchSponsorByPolling(sponsorSearchResponse, sponsorId);
                        } else {
                            this.closeProgressBar(null);
                            this.checkoutComponentSettings.isSponsorFound = false;
                            // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                            this.setDefaultSuggestSponsor(environment.defaultFBOID);
                        }
                    } else {
                        this.closeProgressBar(null);
                        this.checkoutComponentSettings.isSponsorFound = false;
                        // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                        this.setDefaultSuggestSponsor(environment.defaultFBOID);
                    }
                }
            }, (error) => {
                this.closeProgressBar(error.json());
                this.checkoutComponentSettings.isSponsorFound = false;
                // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
                this.setDefaultSuggestSponsor(environment.defaultFBOID);
            });
    }

    /**
     * @description this method will process sponsor response
     * @date 2019-03-18
     * @private
     * @param {SponsorSearchResponse} sponsorSearchResponse
     * @memberof CheckoutNewComponent
     */
    private processSearchSponsorResponse(sponsorSearchResponse: SponsorSearchResponse, sponsorId: string): void {
        if (sponsorSearchResponse && sponsorSearchResponse.sponsorSearchResultModels
            && sponsorSearchResponse.sponsorSearchResultModels.length > 0) {
            if (sponsorId) {
                this.checkoutComponentSettings.defaultOrReferalSponsor = sponsorSearchResponse.sponsorSearchResultModels
                    .find((x: SponsorInformation) => x.sponsorId === sponsorId);
            } else {
                this.checkoutComponentSettings.defaultOrReferalSponsor = sponsorSearchResponse.sponsorSearchResultModels[0];
            }
            this.checkoutComponentSettings.defaultOrReferalSponsor
                .sponsorAssignedOptionId = SponsorSearchOption.SearchBySuggestSponsor;
            // Display 'sponsor not found' sponsorid is not empty and corresponding sponsor not found.
            if (this.checkoutComponentSettings.defaultOrReferalSponsor) {
                this.checkoutComponentSettings.defaultOrReferalSponsor.address = this._sponsorService
                    .mapAddressModel(this.checkoutComponentSettings.defaultOrReferalSponsor);
                this.checkoutComponentSettings.isSponsorFound = true;
                this.saveEnrollSession();
            } else {
                this.closeProgressBar(sponsorSearchResponse.sponsorSearchResultModels);
                this.checkoutComponentSettings.isSponsorFound = false;
            }
        } else {
            this.closeProgressBar(null);
            this.checkoutComponentSettings.isSponsorFound = false;
            // TODO:7178 need to remove once the valence is configured for GBR, LUX, BEL, NLD
            this.setDefaultSuggestSponsor(environment.defaultFBOID);
        }
    }

    /**
     * Set default sponsor by sponsorID
     * @param {string} sponsorID
     * @memberof CheckoutNewComponent
     */
    setDefaultSuggestSponsor(sponsorID: string): void {
        // only applicable for GBR, LUX, BEL, NLD
        if (this.checkoutComponentSettings.configuredCountries
            .indexOf(this.checkoutComponentSettings.isoCountryCode.toUpperCase()) > -1) {
            const defaultSponsor: any = DefaultSponsors.sponsors.find((x: any) => x.sponsorId === sponsorID);
            this.checkoutComponentSettings.defaultOrReferalSponsor = defaultSponsor;
            this.checkoutComponentSettings.defaultOrReferalSponsor
                .sponsorAssignedOptionId = SponsorSearchOption.SearchBySuggestSponsor;
            // Display 'sponsor not found' sponsorid is not empty and corresponding sponsor not found.
            if (this.checkoutComponentSettings.defaultOrReferalSponsor) {
                this.checkoutComponentSettings.defaultOrReferalSponsor.address = this._sponsorService
                    .mapAddressModel(this.checkoutComponentSettings.defaultOrReferalSponsor);
                this.checkoutComponentSettings.isSponsorFound = true;
                this.saveEnrollSession();
            }
        }
    }
    /**
     *  Generate Request for sponsor request
     *  generateSponsorRequest
     * @param {string} sponsorId
     * @memberof CheckoutNewComponent
     */
    searchSponsorRequest(sponsorId: string, checkoutInformation: CheckoutInformation): SponsorSearchRequest {
        let sponsorSearchRequest: SponsorSearchRequest;
        if (sponsorId) {
            sponsorId = sponsorId.indexOf('@') > -1 ? sponsorId : sponsorId.split('-').join('');
            sponsorSearchRequest = {
                UserName: sponsorId.indexOf('@') > -1 ? '' : sponsorId.trim(),
                Email: sponsorId.indexOf('@') > -1 ? sponsorId.trim() : '',
                FirstName: '',
                LastName: '',
                CountryId: '',
                PreferenceValue: '',
                PostalCode: '',
                StateId: '',
                City: '',
                Option: SponsorSearchOption.SearchByIKnowSponsor,
                EnableLongPoll: environment.enableLongPoll
            };
        } else if (checkoutInformation && checkoutInformation.shippingInformation
            && checkoutInformation.shippingInformation.shippingAddress) {
            const shippingAddress: Address = checkoutInformation.shippingInformation.shippingAddress;
            const language: Language = this.checkoutComponentSettings.store.languages.find(x => x.cultureName.toLowerCase()
                === this.checkoutComponentSettings.languageCode.toLowerCase());
            sponsorSearchRequest = {
                UserName: '',
                Email: '',
                FirstName: '',
                LastName: '',
                StateId: shippingAddress && shippingAddress.stateId ? String(shippingAddress.stateId) : '',
                City: '',
                CountryId: String(shippingAddress.countryId),
                CountryCode: shippingAddress.countryCode ? shippingAddress.countryCode : shippingAddress.country,
                PreferenceValue: language ? String(language.languageId) : '',
                PostalCode: shippingAddress.postalCode,
                Option: SponsorSearchOption.SearchByIDontHaveSponsor,
                EnableLongPoll: environment.enableLongPoll
            };
        }
        return sponsorSearchRequest;
    }

    /**
     * @description this method will retain user
     * personal information
     * @date 2018-07-31
     * @returns {PersonalInfo}
     * @memberof CheckoutNewComponent
     */
    preparePersonalInfo(): PersonalInfo {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const sponsorInformation: SponsorInformation = checkoutInformation.sponsorInformation;
        const personalInformation: PersonalInformation = checkoutInformation.personalInformation;
        const fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        const language: Language = this.checkoutComponentSettings.store.languages.find(x => x.cultureName.toLowerCase()
            === this.checkoutComponentSettings.languageCode.toLowerCase());
        if (checkoutInformation.personalInformation) {
            if (this.checkoutComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER
                && checkoutInformation.shippingInformation && checkoutInformation.shippingInformation.shippingAddress) {
                personalInformation.address = checkoutInformation.shippingInformation.shippingAddress;
            }
            if (personalInformation.address) {
                personalInformation.address.addressType = AddressType.MAILING;
            }
            const personalInfo: PersonalInfo = Object.assign({} as any, personalInformation);
            personalInfo.storeId = this.checkoutComponentSettings.store.id;
            personalInfo.memberContacts = this.getMemberContacts(personalInformation);
            personalInfo.memberType = this.getEnrollMemberType();
            personalInfo.countryCode = this.checkoutComponentSettings.isoCountryCode;
            personalInfo.homeCountryCode = this.checkoutComponentSettings.store.homeIsocodeThree;
            personalInfo.countryId = this.checkoutComponentSettings.selectedCountry.countryId;
            personalInfo.memberMetadataModels = sponsorInformation ? sponsorInformation.memberMetadataModels : null;
            personalInfo.languagePreference = language ? language.languageId + '' : '';
            personalInfo.memberPreferences = language ? this.getMemberPreferences(language, sponsorInformation, personalInformation) : null;
            personalInfo.sponsorId = this.getSelectedSponsorId();
            personalInfo.documents = this.getAcceptedDocuments();
            personalInfo.currentMemberType = this.getCurrentMemberType();
            if (fpcOptIn) {
                personalInfo.dateOfBirth = personalInformation.dateOfBirth;
                personalInfo.identifications = this.getMemberIdentifications(personalInformation);
            }
            return personalInfo;
        }
    }


    /**
     * @description get member identifications
     * @date 2019-02-25
     * @param {PersonalInformation} personalInformation
     * @returns {MemberIdentification[]}
     * @memberof CheckoutNewComponent
     */
    getMemberIdentifications(personalInformation: PersonalInformation): MemberIdentification[] {
        const identifications: MemberIdentification[] = [
            {
                value: personalInformation.governmentId,
                identificationId: this.getIdentificationType()
            }
        ];
        return identifications;
    }

    /**
     * @description this methos will give country
     * identificationType
     * @date 2019-02-25
     * @private
     * @returns {number}
     * @memberof CheckoutNewComponent
     */
    private getIdentificationType(): number {
        let identificationType: number;
        switch (this.checkoutComponentSettings.isoCountryCode.toUpperCase()) {
            case 'USA':
                identificationType = IdentificationType.USA;
                break;
            case 'CAN':
                identificationType = IdentificationType.CAN;
                break;
            default:
                identificationType = IdentificationType.USA;
                break;
        }
        return identificationType;
    }

    /**
      * This method used for getting current member type
      * getCurrentMemberType
      * @returns
      * @memberof CheckoutNewComponent
      */
    getCurrentMemberType() {
        let currentMemberType;
        const memberTypeId = this.checkoutComponentSettings.userInfo ? this.checkoutComponentSettings.userInfo.memberTypeId : null;
        if (memberTypeId) {
            currentMemberType = this._commonService.getMemberTypeValue(memberTypeId);
        } else if (this.checkoutComponentSettings.checkoutInformation
            && this.checkoutComponentSettings.checkoutInformation.guestToRetailUser) {
            currentMemberType = this._commonService
                .getMemberTypeValue(this.checkoutComponentSettings.checkoutInformation.guestToRetailUser.memberTypeId);
        }
        return currentMemberType;
    }

    /**
     * @description this method will load member type base on user selection
     * @date 2018-09-18
     * @private
     * @returns {string}
     * @memberof CheckoutNewComponent
     */
    private getEnrollMemberType(): string {
        let memberType = '';
        if (this.checkoutComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER) {
            memberType = UserTitleType.GUEST;
        } else if (this.checkoutComponentSettings.registerMemberType === MemberType.PREFERREDCUSTOMER
            && this.checkoutComponentSettings.fpcOptIn) {
            memberType = MemberTypeValue.DISTRIBUTOR;
        } else {
            memberType = UserTitleType.RETAIL;
        }
        return memberType;
    }

    /**
     * @description this method will load personalinfomation of
     * fpc to fbo optin user
     * @date 2018-09-18
     * @memberof CheckoutNewComponent
     */
    getOptInInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        checkoutInformation.personalInformation = this.checkoutComponentSettings.checkoutInformation.personalInformation;
        checkoutInformation.sponsorInformation = this.checkoutComponentSettings.checkoutInformation.sponsorInformation;
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
    }

    /**
     * @description To get Member contacts
     * @param {PersonalInformation} personalInformation
     * @returns {MemberContact[]}
     * @memberof CheckoutNewComponent
     */
    getMemberContacts(personalInformation: PersonalInformation): MemberContact[] {
        return [{
            contactTypeID: ContactTypeValue.EMAIL,
            value: personalInformation.email
        }, {
            contactTypeID: personalInformation.phoneType,
            value: personalInformation.phoneNumber
        }];
    }

    /**
     * @description get member preferences
     * @date 2018-07-31
     * @param {Language} language
     * @returns {MemberPreference[]}
     * @memberof CheckoutNewComponent
     */
    getMemberPreferences(language: Language, sponsorInformation: SponsorInformation,
        personalInformation: PersonalInformation): MemberPreference[] {
        let memberPreferences: MemberPreference[] = [{
            preferenceType: MemberPreferenceType.PREFERRED_LANGUAGE,
            preferenceValue: language ? String(language.languageId) : ''
        }, {
            preferenceType: MemberPreferenceType.PREFERRED_COMMUNICATION_LANGUAGE,
            preferenceValue: language ? String(language.languageId) : ''
        }, {
            preferenceType: MemberPreferenceType.SEND_ME_ANNOUNCEMENTS_TO_MY_MAIL,
            preferenceValue: MemeberCommunicationPreferenceValue.YES + ''
        }, {
            preferenceType: MemberPreferenceType.PRIVACY_PREFERENCE,
            preferenceValue: MemeberCommunicationPreferenceValue.YES + ''
        }];
        const memberCommunicationPreferences = this.getMemberCommunicationPreferences(sponsorInformation);
        if (memberCommunicationPreferences && memberCommunicationPreferences.length > 0) {
            memberPreferences = memberPreferences.concat(memberCommunicationPreferences);
        }
        const notifyMemberPreferences: MemberPreference = {
            preferenceType: MemberPreferenceType.NOTIFY_ABOUT_PROMOTIONS_AND_UPDATES,
            preferenceValue: (sponsorInformation && sponsorInformation.notifyMeAboutUpdates ?
                MemeberCommunicationPreferenceValue.YES : MemeberCommunicationPreferenceValue.NO) + ''
        };
        memberPreferences.push(notifyMemberPreferences);
        return memberPreferences;
    }

    /**
    * @description get member preferences
    * @date 2018-07-31
    * @param {Language} language
    * @returns {MemberPreference[]}
    * @memberof CheckoutNewComponent
    */
    getMemberCommunicationPreferences(sponsorInformation: SponsorInformation): MemberPreference[] {
        let memberCommunicationPreferences: MemberPreference[];
        if (sponsorInformation && sponsorInformation.memberCommunicationPreferences) {
            memberCommunicationPreferences = [{
                preferenceType: MemberPreferenceType.TO_BE_CONTACTED_BY_SPONSOR_BY_EMAIL,
                preferenceValue: (sponsorInformation.memberCommunicationPreferences.email
                    ? MemeberCommunicationPreferenceValue.YES : MemeberCommunicationPreferenceValue.NO) + ''
            }, {
                preferenceType: MemberPreferenceType.TO_BE_CONTACTED_BY_SPONSOR_BY_PHONE,
                preferenceValue: (sponsorInformation.memberCommunicationPreferences.phone
                    ? MemeberCommunicationPreferenceValue.YES : MemeberCommunicationPreferenceValue.NO) + ''
            }];

        } else if (this.checkoutComponentSettings.registerMemberType
            === MemberType.GUESTCUSTOMER) {
            memberCommunicationPreferences = [{
                preferenceType: MemberPreferenceType.TO_BE_CONTACTED_BY_SPONSOR_BY_EMAIL,
                preferenceValue: MemeberCommunicationPreferenceValue.YES + ''
            }, {
                preferenceType: MemberPreferenceType.TO_BE_CONTACTED_BY_SPONSOR_BY_PHONE,
                preferenceValue: MemeberCommunicationPreferenceValue.YES + ''
            }];
        }
        return memberCommunicationPreferences;
    }

    /**
     * @description
     * @date 2018-09-18
     * @returns {DocumentLibrary[]}
     * @memberof CheckoutNewComponent
     */
    getAcceptedDocuments(): DocumentLibrary[] {
        const documents = [];
        if (this.checkoutComponentSettings.registerMemberType === MemberType.PREFERREDCUSTOMER
            && this.checkoutComponentSettings.fpcOptIn) {
            const fboDocuments = this._cacheService.get(CacheKey.FBOTerms);
            if (fboDocuments) {
                fboDocuments.fboOptInDocuments.forEach((x) => {
                    x.currentDate = this._datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
                    documents.push(this.prepareDocumentInformation(x));
                });
            }
        } else if (this.checkoutComponentSettings.registerMemberType === MemberType.RETAILCUSTOMER
            || this.checkoutComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER) {
            const fboDocuments = this._cacheService.get(CacheKey.FBOTerms);
            if (fboDocuments) {
                fboDocuments.paymentPolicies.forEach((x) => {
                    x.currentDate = this._datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
                    documents.push(this.prepareDocumentInformation(x));
                });
            }
        }
        return documents;
    }

    /**
     * @description
     * @date 2018-09-18
     * @param {DocumentLibrary} document
     * @returns {DocumentLibrary}
     * @memberof CheckoutNewComponent
     */
    prepareDocumentInformation(document: DocumentLibrary): DocumentLibrary {
        const documentInfo = {
            documentLibraryId: document.documentLibraryId,
            documentLibraryVersionId: document.documentLibraryVersionId,
            currentDate: document.currentDate,
            customerType: document.customerType,
            documentCategoryName: document.documentCategoryName,
            documentCategoryId: document.documentCategoryId,
            version: document.version,
            languageCulture: document.languageCulture,
            countryCode: document.countryCode,
            title: document.title,
            displayName: document.displayName,
            url: document.documentUrl,
            isAcknowledged: true,
            countryId: this.getCountryId(document.countryCode),
            customerTypeId: this.getCustomerLevel()
        };
        return documentInfo;
    }

    /**
     * @description This methos used for getting meber level during upgrade flow
     * @date 2018-09-18
     * @param {DocumentLibrary} document
     * @returns {DocumentLibrary}
     * @memberof CheckoutNewComponent
     */
    getCustomerLevel(): number {
        if (this.checkoutComponentSettings.registerMemberType === MemberType.RETAILCUSTOMER) {
            return MemberType.RETAILCUSTOMER;
        } else if (this.checkoutComponentSettings.registerMemberType === MemberType.GUESTCUSTOMER) {
            return MemberType.GUESTCUSTOMER;
        } else {
            return MemberLevel.ASSISTANTSUPERVISOR;
        }
    }

    /**
     * @description
     * @date 2018-09-18
     * @private
     * @param {string} countryCode
     * @returns {number}
     * @memberof CheckoutNewComponent
     */
    private getCountryId(countryCode: string): number {
        if (this.checkoutComponentSettings.countries && this.checkoutComponentSettings.countries.length > 0) {
            const country: Country = this.checkoutComponentSettings.countries
                .find(x => x.isocodeThree.toLowerCase() === countryCode.toLowerCase());
            return country ? country.countryId : null;
        }
    }

    /**
     * @description this methods will save enroll user
     * session while joining into system
     * @date 2018-07-31
     * @param {EnrollSession} enrollSession
     * @memberof CheckoutNewComponent
     */
    saveEnrollSession(): void {
        const enrollSession: EnrollSession = this.prepareEnrollSessionRequest();
        this._enrollService.saveEnrollSession(enrollSession)
            .subscribe((response: EnrollSession) => {
                if (response && response.sessionGUID) {
                    this._cacheService.set(CacheKey.EnrollSessionGuid, response.sessionGUID);
                    response.enrollInfo = enrollSession.enrollInfo;
                    this.placeEnrollRequest(response);
                }
            }, (errResponse: any) => {
                this.closeProgressBar(errResponse.json());
            });
    }

    /**
     * @description this method will process meber
     * enrollment request
     * @date 2018-07-31
     * @param {EnrollInfo} enrollRequest
     * @memberof CheckoutNewComponent
     */
    placeEnrollRequest(enrollRequest: EnrollSession): void {
        const enrollInformation: EnrollInfo = this.checkoutComponentSettings.checkoutInformation.enrollInformation;
        if (this.checkoutComponentSettings.checkoutInformation
            && !this.checkoutComponentSettings.checkoutInformation.retuningGuestUser
            && !this.checkoutComponentSettings.checkoutInformation.guestToRetailUser
            && !this.checkoutComponentSettings.fpcOptIn
            && !enrollInformation) {
            this._enrollService.createEnrollRequest(enrollRequest.enrollInfo).subscribe(
                (retailResponse: EnrollInfo) => {
                    if (retailResponse) {
                        this.updateEnrollSession(enrollRequest, retailResponse);
                    } else {
                        this.closeProgressBar(retailResponse);
                    }
                }, (errResponse: any) => {
                    this.closeProgressBar(errResponse.json());
                });
        } else if (this.checkoutComponentSettings.checkoutInformation.retuningGuestUser ||
            this.checkoutComponentSettings.checkoutInformation.guestToRetailUser ||
            (this.checkoutComponentSettings.fpcOptIn && this.checkoutComponentSettings.userInfo
                && this.checkoutComponentSettings.userInfo.memberTypeId === MemberType.PREFERREDCUSTOMER) ||
            (enrollInformation && enrollInformation.personalInfo && enrollInformation.personalInfo.memberId)) {
            this._enrollService.updateEnrollment(enrollRequest.enrollInfo,
                this.getMemberIDforEnrollmentUpdate(enrollInformation)).subscribe(
                    (retailResponse: EnrollInfo) => {
                        if (retailResponse) {
                            this.updateEnrollSession(enrollRequest, retailResponse);
                        } else {
                            this.closeProgressBar(retailResponse);
                        }
                    },
                    (errResponse: any) => {
                        this.closeProgressBar(errResponse.json());
                    });
        }
    }

    /**
     * @description this mehtod will check and return memebrid
     * @date 2018-08-14
     * @private
     * @param {EnrollInfo} enrollInformation
     * @returns {number}
     * @memberof CheckoutNewComponent
     */
    private getMemberIDforEnrollmentUpdate(enrollInformation: EnrollInfo): number {
        let memberId: number;
        if (this.checkoutComponentSettings.checkoutInformation.retuningGuestUser) {
            memberId = this.checkoutComponentSettings.checkoutInformation.retuningGuestUser.memberId;
        } else if (enrollInformation && enrollInformation.personalInfo) {
            memberId = enrollInformation.personalInfo.memberId;
        } else if (this.checkoutComponentSettings.checkoutInformation.guestToRetailUser) {
            memberId = this.checkoutComponentSettings.checkoutInformation.guestToRetailUser.memberId;
        } else if (this.checkoutComponentSettings.userInfo && this.checkoutComponentSettings.fpcOptIn) {
            memberId = this.checkoutComponentSettings.userInfo.memberId;
        }
        return memberId;
    }

    /**
     * @description this method will used to update enrollsession
     * @date 2018-07-31
     * @private
     * @param {EnrollSession} enrollSession
     * @param {EnrollInfo} retailResponse
     * @memberof CheckoutNewComponent
     */
    private updateEnrollSession(enrollSession: EnrollSession, retailResponse: EnrollInfo): void {
        if (enrollSession && retailResponse && retailResponse.orderInfo.webOrderId) {
            enrollSession.enrollInfo.orderInfo.webOrderId = retailResponse.orderInfo.webOrderId;
        }
        this._enrollService.updateEnrollSession(enrollSession.sessionGUID, enrollSession)
            .subscribe((response: EnrollSession) => {
                this._cacheService.remove(CacheKey.OptInSelection);
                if (retailResponse && retailResponse.orderInfo && retailResponse.orderInfo.webOrderId) {
                    this.storeEnrollMemberInfoAndNavigateToPayment(retailResponse);
                } else {
                    this.closeProgressBar(retailResponse);
                }
            }, (err: any) => {
                this.closeProgressBar(err.json());
            });
    }

    /**
     * @description this method will help
     * to close progress bar once done with request
     * @date 2018-08-17
     * @private
     * @memberof CheckoutNewComponent
     */
    private closeProgressBar(errResponse: any): void {
        if (errResponse && (errResponse.validations && errResponse.validations.length > 0
            || errResponse.length > 0)) {
            this.checkoutComponentSettings.fieldErrors = errResponse.validations || errResponse;
        }
        if (this.checkoutComponentSettings.cartSummaryComponentSettings
            && this.checkoutComponentSettings.cartSummaryComponentSettings.recreateOrder
            && this.checkoutComponentSettings.fieldErrors &&
            this.checkoutComponentSettings.fieldErrors.length > 0) {
            this._appMessageService.setReCreateOrder(this.checkoutComponentSettings.fieldErrors);
        } else {
            this._checkoutMessageService.setDisablePlaceOrderBtn(this.constructTaxValidation(false, null));
        }
        // this._ngProgress.done();
        this._loaderService.stop();
    }

    /**
     * @description map tax validation error changes
     * @date 2019-03-14
     * @param {boolean} isDisablePlaceOrderBtn
     * @returns {TaxValidationMessages}
     * @memberof CheckoutNewComponent
     */
    constructTaxValidation(isDisablePlaceOrderBtn: boolean, validationMessages: string): TaxValidationMessage {
        const taxValidationErrors: TaxValidationMessage = {
            isDisablePlaceOrderBtn: isDisablePlaceOrderBtn,
            validations: validationMessages
        };
        return taxValidationErrors;
    }


    /**
     * @description
     * @date 2018-08-10
     * @private
     * @param {EnrollInfo} retailResponse
     * @memberof CheckoutNewComponent
     */
    private storeEnrollMemberInfoAndNavigateToPayment(retailResponse: EnrollInfo): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        checkoutInformation.enrollInformation = retailResponse;
        checkoutInformation.orderDetails = retailResponse.orderInfo;
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
        // Saving the Shipping Address Id for Updating the Address in Update Enrollment Flow
        if (retailResponse.orderInfo) {
            const shippingAddress = retailResponse.orderInfo
                .addresses.find(item => item.addressType === AddressType.SHIPPING);
            if (shippingAddress && checkoutInformation
                && checkoutInformation.shippingInformation
                && checkoutInformation.shippingInformation.shippingAddress) {
                checkoutInformation.shippingInformation.shippingAddress.id = shippingAddress.id;
                this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
            }
        }
        this._loaderService.stop();
        this.navigateToPayment();
    }

    /**
     * @description
     * @date 2018-08-10
     * @private
     * @param {EnrollInfo} retailResponse
     * @memberof CheckoutNewComponent
     */
    private storeOrderInfoAndNavigateToPayment(orderResponse: Order): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        checkoutInformation.orderDetails = orderResponse;
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
        this.navigateToPayment();
    }
    /**
     * @description Validate the current step
     * while navigating to other steps
     * @param {BreadcrumbStep} step
     * @memberof CheckoutNewComponent
     */
    validateCurrentStep(currentStep: BreadcrumbStep, navigateStep: number): void {
        if (this.checkoutComponentSettings.deliveryOptionType === DeliveryOptionType.Pickup && currentStep === BreadcrumbStep.DELIVERY) {
            currentStep = BreadcrumbStep.PAYMENT;
        }
        this.validateWizardStep(currentStep, navigateStep);
    }
    /**
     * @description navigation for back and forth
     * in a wizard flow
     * @param {BreadcrumbStep} step
     * @param {number} navigateStep
     * @memberof CheckoutNewComponent
     */
    validateWizardStep(step: BreadcrumbStep, navigateStep: number): void {
        const wizardSteps = this._cacheService.get(CacheKey.WizardSteps);
        if (navigateStep <= wizardSteps && navigateStep < WizardStep[this.checkoutComponentSettings.currentStep + '']) {
            const redirectUrl = this.getBreadcrumbURL(step);
            this._router.navigate([this.checkoutComponentSettings.isoCountryCode + '/'
                + this.checkoutComponentSettings.languageCode.toLowerCase() + redirectUrl]);
        } else if (navigateStep <= wizardSteps && navigateStep > WizardStep[this.checkoutComponentSettings.currentStep + '']) {
            this._checkoutMessageService.setValidateCurrentStep(step);
        }
    }

    ngOnDestroy(): void {
        if (this.checkoutComponentSettings.routeChangeEventSubscription) {
            this.checkoutComponentSettings.routeChangeEventSubscription.unsubscribe();
        }
        if (this.checkoutComponentSettings.shippingMethodSubscription) {
            this.checkoutComponentSettings.shippingMethodSubscription.unsubscribe();
        }
    }
}
