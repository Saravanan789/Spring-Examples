export interface WholesaleQualifiedResponse {
    balance: string;
    cutOffTime: string;
    distributorId: string;
    error: string;
    response: string;
    wholesaleQualified: boolean;
}
