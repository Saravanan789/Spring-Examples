export enum PurchaseFlowType {
    Retail = 7,
    WholeSale = 8,
    Enrollment = 9
}

