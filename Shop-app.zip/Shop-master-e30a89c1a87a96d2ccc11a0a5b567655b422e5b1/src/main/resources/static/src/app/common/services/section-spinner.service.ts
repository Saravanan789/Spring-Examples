import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';

@Injectable()
export class AppSectionSpinnerService {
  constructor() { }

  private spinnerListeners: { [id: string]: Subject<any> } = {};
  /**
   * @description For each Spinner
   * register a observable Listener
   * @param {string} sectionName
   * @returns {Observable<boolean>}
   * @memberof AppSectionSpinnerService
   */
  listenLoader(sectionName: string): Observable<boolean> {
    if (sectionName) {
      return this.getListener(sectionName);
    }
  }
  /**
   * @description trigger a loader to show
   * @private
   * @param {string} sectionName
   * @param {boolean} show
   * @memberof AppSectionSpinnerService
   */
  private show(sectionName: string, show: boolean, timeout?: number): void {
    if (sectionName && this.spinnerListeners[sectionName]) {
      this.spinnerListeners[sectionName].next(show);
      // if (timeout && timeout > 0) {
      //  setTimeout(() => {
      //     this.hide(sectionName, false);
      //   }, timeout);
      // }
    }

  }
  /**
   * @description trigger a loader to hide
   * @private
   * @param {string} sectionName
   * @param {boolean} show
   * @memberof AppSectionSpinnerService
   */
  private hide(sectionName: string, show: boolean): void {
    if (sectionName  && this.spinnerListeners[sectionName]) {
      this.spinnerListeners[sectionName].next(show);
    }
  }
  /**
   * @description start the loader
  *  whenever needed
   * @param {string} sectionName
   * @memberof AppSectionSpinnerService
   */
  public start(sectionName: string, timeout?: number): void {
    this.show(sectionName, true, timeout);
  }
  /**
   * @description stop the loader
    *  whenever needed
   * @param {string} sectionName
   * @memberof AppSectionSpinnerService
   */
  public stop(sectionName: string): void {
    this.hide(sectionName, false);
  }
/**
 * @description get a singleton Subject
 * @param {string} sectionName
 * @returns {Observable<boolean>}
 * @memberof AppSectionSpinnerService
 */
getListener(sectionName: string): Observable<boolean> {
    if (!this.spinnerListeners[sectionName]) {
      this.spinnerListeners[sectionName] = new Subject<any>();
    }
    return this.spinnerListeners[sectionName];
  }
/**
 * @description unsubscribe the particular listener
 * @param {string} sectionName
 * @memberof AppSectionSpinnerService
 */
public unsubscribeListener(sectionName: string) {
    if (sectionName) {
      this.spinnerListeners[sectionName].unsubscribe();
      this.spinnerListeners[sectionName] = null;
    }
  }
  /**
   * @description unsubscribe ALL the listeners
   * @memberof AppSectionSpinnerService
   */
  public unsubscribeAll(): void {
    const _subscribers = Object.keys(this.spinnerListeners);
    for (let sectionName = 0; sectionName < _subscribers.length; sectionName++) {
      this.spinnerListeners[sectionName].unsubscribe();
    }
  }
}
