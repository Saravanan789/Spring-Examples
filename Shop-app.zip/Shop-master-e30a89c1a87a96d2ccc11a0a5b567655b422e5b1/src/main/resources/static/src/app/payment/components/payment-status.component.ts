import { Component, OnInit } from '@angular/core';
import { PaymentStatusComponentSettings } from '../component-settings';
import { CacheService, ConfigurationService, CommonService } from '../../shared/services';
import { PaymentService } from '../services';
import { ActivatedRoute, Params, Router } from '../../../../node_modules/@angular/router';
import { StoreConfig } from '../../shared/interfaces';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { PaymentStatus, PaymentProcessorAlias, PaymentProcessor } from '../enums';
import { CheckoutInformation, Order, EnrollInfo, Autoship, AutoshipPayment } from '../../checkout/interfaces';

@Component({
    selector: 'app-payment-status',
    templateUrl: '../templates/template3/views/payment-status.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/payment-status.component.less'
    ]
})

export class PaymentStatusComponent implements OnInit {
    psComponentSettings: PaymentStatusComponentSettings = new PaymentStatusComponentSettings();

    constructor(
        private _cacheService: CacheService,
        private _router: Router,
        private _configurationService: ConfigurationService,
        private _activatedRoute: ActivatedRoute,
        private _paymentService: PaymentService) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof PaymentComponent
     */
    loadDefaultSettings() {
        this.psComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.psComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.getStoreData();
        this.loadMemberType();
        this.loadCheckoutInformation();
        this._activatedRoute.params.subscribe(params => {
            const queryParams: Params = this._activatedRoute.snapshot.queryParams;
            if (queryParams) {
                this.mapPaymentTokenToAutoship(queryParams);
            }
            this.navigateBasedOnStatus(params);
        });
    }


    /**
     * @description Mapping Payment Instrument id to autoship payment
     * @date 2018-10-30
     * @param {number} paymentInstrumentId
     * @memberof PaymentStatusComponent
     */
    mapPaymentTokenToAutoship(queryParams: Params): void {
        const isAutoshipEnabled: boolean = this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled);
        const autoshipRequest: Autoship = this._cacheService.get(CacheKey.AutoshipDetails);
        if (isAutoshipEnabled && autoshipRequest) {
            const paymentInstrumentId = queryParams['customerTokenId'];
            if (paymentInstrumentId && paymentInstrumentId !== 'null') {
                const autoshipPayment: AutoshipPayment[] = this.getAutoshipPaymentInfo(queryParams, autoshipRequest);
                autoshipRequest.autoshipPayments = autoshipPayment;
                this._cacheService.set(CacheKey.AutoshipDetails, autoshipRequest);
            }
        }
    }

    /**
     * @description COnstruct Autoship Payment Request
     * @date 2018-10-17
     * @returns {AutoshipPayment[]}
     * @memberof PaymentComponent
     */
    getAutoshipPaymentInfo(queryParams: Params, autoshipRequest: Autoship): AutoshipPayment[] {
        const autoshipPayments: AutoshipPayment[] = [];
        const autoshipPayment: AutoshipPayment = {
            id: autoshipRequest ? autoshipRequest.id : null,
            paymentInstrumentId: queryParams['customerTokenId'],
            sortOrder: 1,
            shippingAddressId: queryParams['billingAddressId'],
        };
        autoshipPayments.push(autoshipPayment);
        return autoshipPayments;
    }


    /**
     * @description this method will help to navigate
     * to payment section or order summary section based on payment status
     * @date 2018-08-13
     * @private
     * @param {Params} params
     * @memberof PaymentStatusComponent
     */
    private navigateBasedOnStatus(params: Params) {
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        const processor: PaymentProcessorAlias = params['paymentProcessor'];
        this.getPaymentProcessor(processor);
        this.psComponentSettings.paymentStatus = params['paymentStatus'];
        const checkoutInformation: CheckoutInformation = this.psComponentSettings.checkoutInformation;
        if (checkoutInformation) {
            const orderDetails: Order = checkoutInformation.orderDetails;
            if ((orderDetails && orderDetails.webOrderId) || isAutoshipEnabled) {
                if (this.psComponentSettings.paymentStatus.toUpperCase() === PaymentStatus.SUCCESS) {
                    this.routeNavigation(checkoutInformation);
                } else {
                    const paymentFailResposne = this._paymentService.mapPaymentFailResponse(params);
                    if (paymentFailResposne && paymentFailResposne.errorCode) {
                        this._router.navigateByUrl('/' + this.psComponentSettings.isoCountryCode.toLowerCase() + '/'
                            + this.psComponentSettings.languageCode.toLowerCase() + '/checkout/payment'
                            + window.location.search + '&processor=' + PaymentProcessorAlias.PAYVISION);
                    } else if (processor.toLowerCase() === PaymentProcessorAlias.WORLDPAYXML.toLowerCase()) {
                        this._router.navigateByUrl('/' + this.psComponentSettings.isoCountryCode.toLowerCase() + '/'
                            + this.psComponentSettings.languageCode.toLowerCase() + '/checkout/payment?processor='
                            + PaymentProcessorAlias.WORLDPAYXML + '&errorReason=cancelled');
                    } else {
                        this._router.navigateByUrl('/' + this.psComponentSettings.isoCountryCode.toLowerCase() + '/'
                            + this.psComponentSettings.languageCode.toLowerCase() + '/checkout/payment');
                    }
                }
            }
        }
    }

    /**
     * @description this method will give payment processor
     * @date 2018-08-23
     * @private
     * @param {string} processor
     * @memberof PaymentStatusComponent
     */
    private getPaymentProcessor(processor: string): void {
        if (processor && processor.toLowerCase() === PaymentProcessorAlias.PAYVISION.toLowerCase()) {
            this.psComponentSettings.paymentProcessor = PaymentProcessor.PAYVISION;
        }
        if (processor && processor.toLowerCase() === PaymentProcessorAlias.WORLDPAYXML.toLowerCase()) {
            this.psComponentSettings.paymentProcessor = PaymentProcessor.WORLDPAYXML;
        }
        if (processor && processor.toLowerCase() === PaymentProcessorAlias.PAYVISIONPAYPAL.toLowerCase()) {
            this.psComponentSettings.paymentProcessor = PaymentProcessor.PAYVISION;
        }
    }

    /**
     * @description this method will navigate
     * @date 2018-08-14
     * @private
     * @param {CheckoutInformation} checkoutInformation
     * @memberof PaymentStatusComponent
     */
    private routeNavigation(checkoutInformation: CheckoutInformation): void {
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        const orderDetails: Order = checkoutInformation.orderDetails;
        const enrollInfo: EnrollInfo = checkoutInformation.enrollInformation;
        let routerUrl = '';
        if (this.psComponentSettings.userInfo ||
            (checkoutInformation && checkoutInformation.retuningGuestUser)) {
            if (isAutoshipEnabled) {
                routerUrl = '/checkout/ordersummary/';
            } else {
                routerUrl = '/checkout/ordersummary/' + orderDetails.webOrderId;
            }
        } else if (enrollInfo && enrollInfo.personalInfo && enrollInfo.personalInfo.memberId) {
            routerUrl = '/checkout/member/ordersummary/' + enrollInfo.personalInfo.memberId;
        }
        this._router.navigateByUrl('/' + this.psComponentSettings.isoCountryCode.toLowerCase() + '/'
            + this.psComponentSettings.languageCode.toLowerCase() + routerUrl);
    }


    /**
     * @description this method will load member type
     * or logeed in member information
     * @date 2018-07-25
     * @private
     * @memberof PaymentComponent
     */
    private loadMemberType(): void {
        this.psComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.psComponentSettings.registerMemberType = this.psComponentSettings.userInfo
            && this.psComponentSettings.userInfo.memberTypeId
            ? this.psComponentSettings.userInfo.memberTypeId : this._cacheService.get(CacheKey.RegisterMemberType);
    }


    /**
    * @description this method retives
    * store information from cache service
    * @date 2018-07-19
    * @memberof PaymentComponent
    */
    private getStoreData(): void {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.psComponentSettings.store = result;
        }
    }


    /**
    * @description this method is used
    * load stored information while refreshing the page
    * @date 2018-07-21
    * @memberof PaymentComponent
    */
    private loadCheckoutInformation(): void {
        this.psComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
    }
}
