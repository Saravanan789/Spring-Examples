export interface PaymentResponseModel {
    token: string;
    transactionID: string;
    orderID: string;
    paymentStatus: string;
    paymentStatusId: number;
    paymentStatusReason: string;
    amount: number;
    paymentProfileId: string;
    authCode: string;
    cardNumber: string;
    expirationDate: string;
    cardHoldername: string;
    authorizationDate: Date;
    authExpirationDate: Date;
    memberPaymentInstrumentId: number;
    billingAddressId: number;
    cardType: string;
}
