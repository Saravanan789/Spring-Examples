import { ImageModel } from '../../products/interfaces/image-model.interface';
import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ImageType } from '../../products/enums/image-type.enum';
import * as _ from 'lodash';
import { ChildImage } from '../../products/interfaces/child-image.interface';

@Pipe({
  name: 'imageTypeFilter'
})
export class ImageTypeFilterPipe implements PipeTransform {
  transform(imagesList: Array<ImageModel>, imageType: string, imageTypeVideo: string): string[] {
    if (imagesList && imagesList.length > 0) {
      let productImages: any[] = [];
      imagesList.forEach(x => {
        let images: any[] = [];
        if (imageType && imageType === ImageType.ZoomedImage) {
          images = imagesList.filter(y => y.type === imageType && y.display);
        } else if (imageType && x.type !== ImageType.Video) {
          const icon = x.details.filter(item => item.type === imageType);
          if (icon && icon[0]) {
            icon[0].sortOrder = x.sortOrder;
            icon[0].id = x.id;
          } else {
            icon[0] = this.getIconFallback(x, imageType);
          }
          images = icon;
        }
        if (imageType && imageType === ImageType.ZoomedImage && imageTypeVideo === ImageType.Video) {
          const thumbnailImages = imagesList.filter(y => y.type === imageTypeVideo && y.display);
          if (thumbnailImages && thumbnailImages.length > 0) {
            thumbnailImages.forEach(z => {
              const video = {
                id: z.id,
                videoUrl: z.url,
                type: imageTypeVideo,
                sortOrder: z.sortOrder,
                videoSource: z.videoSource,
                thumbnailImage: z.details && z.details.length > 0
                 && z.details[0].url.indexOf('http') === -1 ? environment.cdnURL + '/' + z.details[0].url : z.details[0].url,
              };
              images.push(video);
            });
          }
        }
        if (x.type === imageTypeVideo && imageType !== ImageType.ZoomedImage && x.display) {
          const video = {
            id: x.id,
            videoUrl: x.url,
            type: imageTypeVideo,
            sortOrder: x.sortOrder,
            videoSource: x.videoSource,
            thumbnailImage: x.details && x.details.length > 0
            && x.details[0].url.indexOf('http') === -1 ? environment.cdnURL + '/' + x.details[0].url : x.details[0].url,
          };
          images.push(video);
        }
        if (images && images.length > 0) {
          productImages = productImages.concat(images);
        }
      });
      if (productImages && productImages.length > 0) {
        productImages = productImages.map((x: any) => {
          if (x.url && x.url.length > 0 && x.url.indexOf('http') === -1) {
            x.url = (environment.cdnURL + '/' + x.url);
          }
          return x;
        });
      }
      productImages = _.chain(productImages).uniqBy('id').sortBy('sortOrder').value();
      return productImages;
    } else {
      return [];
    }
  }
  getIconFallback(parent: any, imageType: string): ChildImage {
    return {
      id: parent.id,
      type: imageType,
      url: parent.url,
      parentId: parent.id,
      sortOrder: parent.id,
    };
  }
}
