export enum AccountType {
    Checking = 'CHECKING',
    Savings = 'SAVINGS'
}
