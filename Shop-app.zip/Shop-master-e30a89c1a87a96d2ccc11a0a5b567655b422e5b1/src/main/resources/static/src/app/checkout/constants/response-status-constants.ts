export class ResponseStatus {
  public static COMPLETED = 'COMPLETED';
  public static QUEUED = 'QUEUED';
  public static IN_PROGRESS = 'IN-PROGRESS';
  public static FAILED = 'FAILED';
  public static VALIDATION_ERROR = 'VALIDATION-ERROR';
}
