export interface FieldValidations {
    minLength?: number;
    maxLength?: number;
    required?: boolean;
}
