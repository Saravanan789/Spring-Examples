import { EnrollInfo } from './enroll-info.interface';

export interface EnrollSession {
    id?: number;
    sessionGUID?: string;
    enrollInfo: EnrollInfo;
    sponsorId?: string;
}

