import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { PaymentComponentSettings } from '../component-settings';
import { CommonService, CacheService, ConfigurationService, CartService } from '../../shared/services';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { CheckoutInformation, PaymentInformation, Autoship, AutoshipPayment } from '../../checkout/interfaces';
import { Country, State, StoreConfig, Member } from '../../shared/interfaces';
import { PaymentService, PaymentMessageService } from '../services';
import { StorePaymentMethod, ProcessorConfigResponse } from '../interfaces';
import { PaymentMethodTypes, PaymentStatus, PaymentProcessorAlias, PaymentResultCodes } from '../enums';
import { PaymentResponseModel } from '../interfaces/payment-response-model.interface';
import { TranslateService } from '../../../../node_modules/@ngx-translate/core';
import { Cart } from '../../shared/models';
import { AppMessageService } from '../../app-message.service';
import { LoaderService } from '../../shared/services/loader.service';
import { Portal } from '../enums/payment-type.enum';
import { MemberLevel, MemberType } from '../../shared/enums';
import { DocumentCategoryId } from '../../common/enums';
import { DefaultPayment } from '../interfaces/default-payment.interface';
import { Location } from '@angular/common';
import { PaymentConstants } from '../constants';
import { environment } from '../../../environments/environment';
import { TranslateParam } from '../../common/interfaces/index';

/**
 * @description this component will load
 * configured payment mehtods based on store
 * configuration
 * @date 2018-07-26
 * @export
 * @class PaymentComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-payment',
    templateUrl: '../templates/template3/views/payment.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/payment.component.less'
    ]
})

export class PaymentComponent implements OnInit, OnDestroy {
    paymentComponentSettings: PaymentComponentSettings = new PaymentComponentSettings();
    translateParams: TranslateParam;
    constructor(private _formBuilder: FormBuilder,
        private _commonService: CommonService,
        private _cacheService: CacheService,
        private _paymentService: PaymentService,
        private _configurationService: ConfigurationService,
        private _router: Router,
        private _translatePipe: TranslateService,
        private _appMessageService: AppMessageService,
        private _cartService: CartService,
        private _activatedRoute: ActivatedRoute,
        private _location: Location,
        private _loaderService: LoaderService,
        private _paymentMessageService: PaymentMessageService) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof PaymentComponent
     */
    loadDefaultSettings() {
        if (environment.dataLayer && environment.dataLayer.length > 0) {
            environment.dataLayer[0].pageCategory = 'shop-payment';
        }
        this.paymentComponentSettings.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        this.paymentComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.paymentComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this._activatedRoute.params.subscribe(params => {
            this.paymentComponentSettings.paymentFailResponse = this._paymentService.getPaymentFailResponse(params);
            if (this.paymentComponentSettings.paymentFailResponse) {
                this.getErrorMessages();
            }
        });

        this.getStoreData();
        this.loadMemberType();
        this.getCountriesLookup();
        this.loadCheckoutInformation();
        this.getCartSessionInfo();
        this.getReCreateOrderEvent();
    }

    /**
     * @description
     * @date 2019-02-13
     * @private
     * @memberof PaymentComponent
     */
    private getErrorMessages(): void {
        if (new RegExp(PaymentResultCodes.COMMUNICATION).test(this.paymentComponentSettings.paymentFailResponse.errorCode)) {
            this.paymentComponentSettings.paymentFailResponse.errorMessage
                = PaymentConstants.CommunationError;
        } else if (new RegExp(PaymentResultCodes.SECURE).test(this.paymentComponentSettings.paymentFailResponse.errorCode)) {
            this.paymentComponentSettings.paymentFailResponse.errorMessage
                = PaymentConstants.SecureError;
        } else if (new RegExp(PaymentResultCodes.RISKCHECK).test(this.paymentComponentSettings.paymentFailResponse.errorCode)) {
            this.paymentComponentSettings.paymentFailResponse.errorMessage
                = PaymentConstants.SecureError;
        } else if (new RegExp(PaymentResultCodes.EXTERNALBANK).test(this.paymentComponentSettings.paymentFailResponse.errorCode)) {
            this.paymentComponentSettings.paymentFailResponse.errorMessage
                = PaymentConstants.ExternalBankError;
        } else {
            this.paymentComponentSettings.paymentFailResponse.errorMessage
                = PaymentConstants.OtherError;
        }
    }

    /**
     * @description this method will triggrer when loading of
     * cart items done from service
     * @date 2018-08-01
     * @private
     * @memberof ShippingMethodsNewComponent
     */
    private getCartSessionInfo(): void {
        this.paymentComponentSettings.shoppingCartSubscription = this._appMessageService
            .getCartItemsChanges()
            .subscribe((response) => {
                if (!this.paymentComponentSettings.storePaymentMethods) {
                    this.loadCheckoutInformation();
                }
            });
    }

    /**
    * @description this method will triggrer when loading of
    * cart items done from service
    * @date 2018-08-01
    * @private
    * @memberof ShippingMethodsNewComponent
    */
    private getReCreateOrderEvent(): void {
        this.paymentComponentSettings.reCreateOrderSubscription = this._appMessageService
            .getReCreateOrder()
            .subscribe((response) => {
                this.paymentComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
                this.reLoadPaymentMethod(true);
                this.paymentComponentSettings.isInitialize = response;
                this.paymentComponentSettings.paymentFailResponse = null;
                this._paymentService.setPaymentFailResponse(null);
            });
    }

    /**
     * @description this method will load after recreting order
     * @date 2018-11-29
     * @memberof PaymentComponent
     */
    reLoadPaymentMethod(orderCreated: boolean): void {
        const selectPaymentMethod = this.paymentComponentSettings.paymentFailPaymentMethod ||
            this.paymentComponentSettings.storePaymentMethods
                .find(x => x.paymentMethodName === PaymentMethodTypes.Credit_Card);
        this.selectPaymentMethodType(selectPaymentMethod, orderCreated);
    }

    /**
     * @description this method will load member type
     * or logeed in member information
     * @date 2018-07-25
     * @private
     * @memberof PaymentComponent
     */
    private loadMemberType(): void {
        this.paymentComponentSettings.userInfo = this._cacheService.get(CacheKey.UserInfo);
        this.paymentComponentSettings.registerMemberType = this.paymentComponentSettings.userInfo
            && this.paymentComponentSettings.userInfo.memberTypeId
            ? this.paymentComponentSettings.userInfo.memberTypeId : this._cacheService.get(CacheKey.RegisterMemberType);
    }


    /**
     * @description Creating the delivery options form
     * @date 2018-07-20
     * @memberof PaymentComponent
     */
    private createPaymentMethodTypeForm(): void {
        this.paymentComponentSettings.paymentMethodTypeForm = this._formBuilder.group({
            paymentMethodType: ['']
        });
    }

    /**
     * @description this method retives
     * store information from cache service
     * @date 2018-07-19
     * @memberof PaymentComponent
     */
    private getStoreData(): void {
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.paymentComponentSettings.store = result;
        }
    }

    /**
     * @description Get Countries
     * @date 2018-07-19
     * @private
     * @memberof PaymentComponent
     */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.paymentComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            const selectedCountry =
                this.paymentComponentSettings.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
                    this.paymentComponentSettings.isoCountryCode.toLowerCase());
            if (selectedCountry && selectedCountry.countryId) {
                this.paymentComponentSettings.isoTwoletterCountryCode = selectedCountry.isocodeTwo;
                this.getStatesLookup(selectedCountry.countryId);
            }
        } else {
            this._commonService.getCountries().subscribe((countries: Country[]) => {
                if (countries && countries.length > 0) {
                    this.paymentComponentSettings.countries = countries;
                    this._cacheService.set(CacheKey.Countries, this.paymentComponentSettings.countries);
                    const selectedCountry = this.paymentComponentSettings.countries.
                        find((x: Country) => x.isocodeThree.toLowerCase() === this.paymentComponentSettings.isoCountryCode.toLowerCase());
                    if (selectedCountry && selectedCountry.countryId) {
                        this.paymentComponentSettings.isoTwoletterCountryCode = selectedCountry.isocodeTwo;
                        this.getStatesLookup(selectedCountry.countryId);
                    }
                }
            });
        }
    }

    /**
    * @description get States
    * @date 2018-07-19
    * @param {number} countryId
    * @memberof PaymentComponent
    */
    private getStatesLookup(countryId: number) {
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            this.paymentComponentSettings.states = storedStates;
        } else {
            if (countryId) {
                this._commonService.getStatesByCountry(countryId).subscribe((states: State[]) => {
                    this.paymentComponentSettings.states = states;
                }, (err: any) => {
                });
            }
        }
    }


    /**
     * @description it will retrive all payemnt mehtods
     * what we have configured for the store
     * @date 2018-07-26
     * @memberof PaymentComponent
     */
    getPaymentMethodsByStore(isAutoshipEnabled?: boolean): void {
        if (this.paymentComponentSettings.store && this.paymentComponentSettings.store.id
            && this.paymentComponentSettings.isoCountryCode) {
            this._paymentService.getPaymentMethodsByStore(this.paymentComponentSettings.store.id,
                this.paymentComponentSettings.isoCountryCode, isAutoshipEnabled)
                .subscribe((response: StorePaymentMethod[]) => {
                    this.paymentComponentSettings.storePaymentMethods = response;
                    if (!this.paymentComponentSettings.paymentFailResponse
                        || (this.paymentComponentSettings.paymentFailResponse
                            && !this.paymentComponentSettings.paymentFailResponse.displayRetryBtn)) {
                        this.getMemberDefaultPaymentMethod();
                    } else {
                        this.selectFailedPaymentMethod();
                    }
                }, (error: any) => {
                    this.translateParams = this._commonService.handleError(error);
                });
        }
    }

    /**
     * @description it will retrive all payemnt mehtods
     * what we have configured for the store
     * @date 2018-07-26
     * @memberof PaymentComponent
     */
    getProcessorConfig(defaultLoad: boolean, isFailedPayment?: boolean) {
        if (!isFailedPayment) {
            this.paymentComponentSettings.paymentMethodTypeForm.disable();
        }
        if (this.paymentComponentSettings.store && this.paymentComponentSettings.store.id) {
            this._paymentService.getProcessorConfig(this.paymentComponentSettings.store.id)
                .subscribe((processorConfigResponse: ProcessorConfigResponse) => {
                    this.paymentComponentSettings.paymentProcessorConfig = processorConfigResponse.paymentMethodModels[0];
                    if (defaultLoad) {
                        this.paymentComponentSettings.selectedPaymentMethod.paymentMethodName =
                            this.paymentComponentSettings.paymentMethodTypes.Credit_Card;
                    }
                }, (err: any) => {
                    this.paymentComponentSettings.paymentMethodTypeForm.enable();
                });
        }
    }

    /**
     * @description to get default payment method from service
     * @date 2018-08-01
     * @memberof PaymentComponent
     */
    getMemberDefaultPaymentMethod() {
        if (this.paymentComponentSettings.userInfo && this.paymentComponentSettings.userInfo.memberId
            && this.paymentComponentSettings.store && this.paymentComponentSettings.store.id) {
            this._paymentService
                .getMemberDefaultPaymentMethod(this.paymentComponentSettings.userInfo.memberId, this.paymentComponentSettings.store.id)
                .subscribe((defaultPaymentMethodResponse: DefaultPayment) => {
                    if (defaultPaymentMethodResponse && defaultPaymentMethodResponse.value
                        && defaultPaymentMethodResponse.value.toLowerCase() !== PaymentMethodTypes.None.toLowerCase()) {
                        this.paymentComponentSettings.selectedPaymentMethod = this.paymentComponentSettings.storePaymentMethods
                            .find(x => x.paymentMethodName === defaultPaymentMethodResponse.value);
                    }
                    this.selectDefaultPaymentMethod();
                }, (err: any) => {
                    this.selectDefaultPaymentMethod();
                    this.translateParams = this._commonService.handleError(err);
                });
        } else {
            this.selectDefaultPaymentMethod();
        }
    }

    /**
     * get default payment methods when user is not logged in
     */
    selectDefaultPaymentMethod() {
        if (!this.paymentComponentSettings.selectedPaymentMethod
            && this.paymentComponentSettings.storePaymentMethods
                .find(x => x.paymentMethodName === PaymentMethodTypes.Credit_Card)) {
            this.paymentComponentSettings.selectedPaymentMethod = this.paymentComponentSettings.storePaymentMethods
                .find(x => x.paymentMethodName === PaymentMethodTypes.Credit_Card);
        } else if (!this.paymentComponentSettings.selectedPaymentMethod) {
            this.paymentComponentSettings.selectedPaymentMethod = this.paymentComponentSettings.storePaymentMethods[0];
        }
        this.loadDefaultPaymentConfig();
    }

    /**
     * @description this method will load when payment failed
     * and pre select the failed payment option
     * @date 2018-11-28
     * @memberof PaymentComponent
     */
    selectFailedPaymentMethod(): void {
        // TODO: we have implemented the failurre use cases for credit card payment
        this.paymentComponentSettings.selectedPaymentMethod = this.paymentComponentSettings.storePaymentMethods
            .find(x => x.paymentMethodName === PaymentMethodTypes.Credit_Card);
        this.loadDefaultPaymentConfig(true);
    }

    /**
     * @description this method will laod payment form and payment processor
     * @memberof PaymentComponent
     */
    loadDefaultPaymentConfig(isFailedPayment?: boolean): void {
        this.createPaymentMethodTypeForm();
        if (this.paymentComponentSettings.selectedPaymentMethod
            && this.paymentComponentSettings.selectedPaymentMethod.paymentMethodName
            === PaymentMethodTypes.Credit_Card) {
            this.getProcessorConfig(true, isFailedPayment);
        }
    }

    /**
     * @description used to select the payment method
     * and get the configured payment processor
     * @date 2018-07-26
     * @memberof PaymentComponent
     */
    selectPaymentMethodType(paymentMethod: StorePaymentMethod, orderCreated?: boolean): void {
        this.paymentComponentSettings.paymentFailPaymentMethod = null;
        if (!orderCreated && paymentMethod && paymentMethod.paymentMethodName &&
            (paymentMethod.paymentMethodName.toLowerCase() === PaymentMethodTypes.Credit_Card.toLowerCase() ||
                paymentMethod.paymentMethodName.toLowerCase() === PaymentMethodTypes.PayPal.toLowerCase())
            && this.paymentComponentSettings.paymentFailResponse
            && this.paymentComponentSettings.paymentFailResponse.displayRetryBtn
            && (paymentMethod.paymentMethodName !== this.paymentComponentSettings.selectedPaymentMethod.paymentMethodName
                || this.paymentComponentSettings.isInitialize)) {
            this.paymentComponentSettings.paymentFailPaymentMethod = paymentMethod;
            this.recreateOrder();
        } else {
            if (paymentMethod && paymentMethod.paymentMethodName && (this.paymentComponentSettings.selectedPaymentMethod
                && (paymentMethod.paymentMethodName !== this.paymentComponentSettings.selectedPaymentMethod.paymentMethodName
                    || this.paymentComponentSettings.isInitialize) || !this.paymentComponentSettings.selectedPaymentMethod)) {
                this.paymentComponentSettings.errorMessage = '';
                const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
                checkoutInformation.paymentInformation = this.getPaymentInformation(paymentMethod);
                this.paymentComponentSettings.selectedPaymentMethod = paymentMethod;
                if (paymentMethod.paymentMethodName === PaymentMethodTypes.Credit_Card
                    || paymentMethod.paymentMethodName === PaymentMethodTypes.PayPal) {
                    if (!this.paymentComponentSettings.paymentProcessorConfig) {
                        this.getProcessorConfig(false);
                    }
                    this._paymentMessageService.setPayPalOrCCSection(paymentMethod);
                } else {
                    this.paymentComponentSettings.enablePaymentOptions = true;
                    this.paymentComponentSettings.enablePlaceOrder = true;
                }
            }
        }
    }

    /**
     * @description get Paymemnt Information
     * @date 2018-08-02
     * @param {StorePaymentMethod} paymentMethod
     * @returns {PaymentInformation}
     * @memberof PaymentComponent
     */
    getPaymentInformation(paymentMethod: StorePaymentMethod): PaymentInformation {
        const paymentInformation: PaymentInformation = {
            payvisionInformation: {
                payvisionRegistrationResponse: null
            },
            paymentToken: null,
            billingAddress: null,
            isEnrollment: false,
            selectedPaymentMethod: paymentMethod,
            isCompleteRedirection: false,
        };
        return paymentInformation;
    }

    /**
    * @description this method is used
    * load stored information while refreshing the page
    * @date 2018-07-21
    * @memberof PaymentComponent
    */
    private loadCheckoutInformation(): void {
        this.paymentComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (this.paymentComponentSettings.isAutoshipEnabled) {
            const cartSession: Cart = this._cacheService.get(CacheKey.AutoshipCart);
            if (cartSession && cartSession.items && cartSession.items.length > 0) {
                this.paymentComponentSettings.shoppingCart = new Cart(cartSession, this.paymentComponentSettings.store);
                this.getPaymentMethodsByStore(this.paymentComponentSettings.isAutoshipEnabled);
            }
        } else {
            const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
            if (cartSession && cartSession.items && cartSession.items.length > 0) {
                this.paymentComponentSettings.shoppingCart = new Cart(cartSession, this.paymentComponentSettings.store);
                this.getPaymentMethodsByStore();
            }
        }

    }

    /**
     * @description this method will retrive cart info
     * when we place order from other payment component
     * @date 2018-08-10
     * @param {PaymentInformation} paymentInformation
     * @memberof PaymentComponent
     */
    submitPaymentInformation(paymentInformation: PaymentInformation): void {
        this.paymentComponentSettings.enablePlaceOrder = false;
        this.submitSelectedPayment(paymentInformation);
    }

    /**
     * @description submits selected payment
     * @private
     * @param {PaymentInformation} paymentInformation
     * @memberof PaymentComponent
     */
    private submitSelectedPayment(paymentInformation: PaymentInformation): void {
        const selectedPayment = this.paymentComponentSettings.selectedPaymentMethod;
        switch (selectedPayment.paymentMethodName) {
            case PaymentMethodTypes.Credit_Card:
                this.submitPaymentInfo(selectedPayment.paymentMethodName, paymentInformation);
                break;
            case PaymentMethodTypes.eCheck:
                this.submitPaymentInfo(selectedPayment.paymentMethodName, paymentInformation);
                break;
            case PaymentMethodTypes.Money_order:
                this.submitPaymentInfo(selectedPayment.paymentMethodName, paymentInformation);
                break;
            case PaymentMethodTypes.Cash:
                // code
                break;
            case PaymentMethodTypes.Ideal:
                // code
                break;
            case PaymentMethodTypes.PayPal:
                break;
        }
    }

    /**
     * submit payment information
     *
     * @private
     * @param {string} paymentMethod
     * @param {PaymentInformation} paymentInformation
     * @memberof PaymentComponent
     */
    private submitPaymentInfo(paymentMethod: string, paymentInformation: PaymentInformation): void {
        this._loaderService.start();
        const checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.orderDetails) {
            this.paymentComponentSettings.checkoutInformation.orderDetails = checkoutInformation.orderDetails;
        }
        if (this.paymentComponentSettings.isAutoshipEnabled) {
            const autoshipPayment: AutoshipPayment[] = this.getAutoshipPaymentInfo(paymentInformation);
            const autoshipDetails: Autoship = this._cacheService.get(CacheKey.AutoshipDetails);
            autoshipDetails.autoshipPayments = autoshipPayment;
            this._cacheService.set(CacheKey.AutoshipDetails, autoshipDetails);
            this.navigateToOrderSummary('', true);
        } else {
            this._paymentService.submitPayment(paymentMethod, paymentInformation, this.paymentComponentSettings)
                .subscribe((response: PaymentResponseModel) => {
                    this.processPaymentResponse(response);
                }, (error: any) => {
                    this.translateParams = this._commonService.handleError(error);
                });
        }
    }

    /**
     * @description COnstruct Autoship Payment Request
     * @date 2018-10-17
     * @returns {AutoshipPayment[]}
     * @memberof PaymentComponent
     */
    getAutoshipPaymentInfo(paymentInformation: PaymentInformation): AutoshipPayment[] {
        const autoshipPayments: AutoshipPayment[] = [];
        const autoshipPayment: AutoshipPayment = {
            paymentInstrumentId: atob(paymentInformation.paymentToken),
            sortOrder: 1,
            shippingAddressId: paymentInformation.billingAddress.id,
        };
        autoshipPayments.push(autoshipPayment);
        return autoshipPayments;
    }

    /**
     *
     *
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    processPaymentResponse(response: PaymentResponseModel): void {
        if (response) {
            if (this.paymentComponentSettings.selectedPaymentMethod.completeRedirect) {
                // complete redirection
            } else {
                this.processSelectedPaymentResponse(response);
            }
        } else {
            this._loaderService.stop();
        }
    }

    /**
     * @description process selected payment response.
     *
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    processSelectedPaymentResponse(response: PaymentResponseModel): void {
        const selectedPayment = this.paymentComponentSettings.selectedPaymentMethod;
        const paymentTypes = this.paymentComponentSettings.paymentMethodTypes;
        if (selectedPayment.paymentMethodName === paymentTypes.eCheck) {
            this.processEcheckResponse(response);
        } else if (selectedPayment.paymentMethodName === paymentTypes.Money_order) {
            this.processMoneyOrderResponse(response);
        } else if (selectedPayment.paymentMethodName === paymentTypes.Credit_Card) {
            this.processCreditCardResponse(response);
        }
    }

    /**
     * @description process response - without complete redirection.
     *
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    processEcheckResponse(response: PaymentResponseModel): void {
        if (response.paymentStatus === PaymentStatus.SUCCESS) {
            this.navigateToOrderSummary(response.orderID);
        } else {
            this.displayErrorMessage(response);
        }
    }

    /**
     * @description process moneyorder response.
     *
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    processMoneyOrderResponse(response: PaymentResponseModel): void {
        if (response.paymentStatus === PaymentStatus.PEND) {
            this.navigateToOrderSummary(response.orderID);
        } else {
            this.displayErrorMessage(response);
        }
    }

    /**
     *@description  process moneyorder response.
     *
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    processCreditCardResponse(response: PaymentResponseModel): void {
        if (response.paymentStatus === PaymentStatus.AUTH
            || response.paymentStatus === PaymentStatus.AUTHORISED) {
            this.navigateToOrderSummary(response.orderID);
        } else {
            this.displayErrorMessage(response);
        }
    }

    /**
     * @description displays error message
     *
     * @private
     * @param {PaymentResponseModel} response
     * @memberof PaymentComponent
     */
    private displayErrorMessage(response: PaymentResponseModel): void {
        this._loaderService.stop();
        this.paymentComponentSettings.enablePlaceOrder = true;
        this.paymentComponentSettings.paymentFailResponse = this._paymentService.getPaymentFailResponse(response);
        this._paymentService.scrollToTop(10);
        const translatedText = this._translatePipe.get('checkout.Please check below error');
        this.paymentComponentSettings.errorMessage = translatedText['value'];
        if (!response.paymentStatusReason) {
            response.paymentStatusReason = 'Please select a valid card';
        }
        this.paymentComponentSettings.errorMessage += ': <br> ' + response.paymentStatusReason;
    }

    /**
     * @description navigates to ordersummary page
     *
     * @param {string} webOrderId
     * @memberof PaymentComponent
     */
    navigateToOrderSummary(webOrderId: string, isAutoship?: boolean): void {
        if (isAutoship) {
            this._router.navigate(['./' + this.paymentComponentSettings.isoCountryCode.toLowerCase() +
                '/' + this.paymentComponentSettings.languageCode.toLowerCase()
                + '/checkout/ordersummary']);
        } else {
            this._router.navigate(['./' + this.paymentComponentSettings.isoCountryCode.toLowerCase() +
                '/' + this.paymentComponentSettings.languageCode.toLowerCase()
                + '/checkout/ordersummary/' + webOrderId]);
        }
    }


    /**
     * @description get Terms and Conditions Document
     * fetchTermsConditionDocument
     * @memberof PaymentComponent
     */
    fetchTermsConditionDocument(): void {
        const documents = this._cacheService.get(CacheKey.FBOTerms);
        const customerTypeId = MemberLevel.ASSISTANTSUPERVISOR;
        this._cartService.getDocuments(Portal.Join,
            customerTypeId, DocumentCategoryId.Checkout_Policy)
            .subscribe((response) => {
                if (response && response.length > 0 && response[0].body && response[0].body.length > 0) {
                    this.paymentComponentSettings.placeOrderTAndC = response[0].body;
                    if (documents) {
                        documents.paymentPolicies = response[0].body;
                        this._cacheService.set(CacheKey.FBOTerms, documents);
                    }
                }
            }, (error: any) => {
                this.translateParams = this._commonService.handleError(error);
            });
    }

    /**
     * @description this method will recreate order when payment giot failed
     * @date 2018-11-28
     * @memberof PaymentComponent
     */
    recreateOrder(): void {
        const paymentProcessor = this.paymentComponentSettings.paymentFailResponse.paymentProcessor;
        this.removeQueryParamFromCurrentUrl();
        if ((paymentProcessor &&
            (paymentProcessor.toLowerCase() === PaymentProcessorAlias.WORLDPAYXML.toLowerCase()
                || paymentProcessor.toLowerCase() === PaymentProcessorAlias.PAYVISION.toLowerCase()))
            || (this.paymentComponentSettings.paymentFailResponse
                && this.paymentComponentSettings.paymentFailResponse.paymentStatus === PaymentStatus.FAILED)) {
            this._appMessageService.setProcessOrder(true);
        } else {
            this.reLoadPaymentMethod(true);
        }
    }

    /**
     * Removes the Query Parameters from URL
     */
    removeQueryParamFromCurrentUrl(): void {
        if (window.location.href.indexOf('?') > -1) {
            this._location.replaceState('/' + this.paymentComponentSettings.isoCountryCode
                + '/' + this.paymentComponentSettings.languageCode + '/checkout/payment');
        }
    }

    /**
     * @description
     * @date 2018-09-18
     * @returns {number}
     * @memberof PaymentComponent
     */
    getCustomerTypeId(): number {
        const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
        const registerMemberType = this._cacheService.get(CacheKey.RegisterMemberType);
        if (userInfo && userInfo.memberTitleId) {
            return userInfo.memberTitleId;
        } else if (registerMemberType && registerMemberType === MemberType.RETAILCUSTOMER) {
            return MemberLevel.RETAIL;
        } else {
            return MemberLevel.GUEST;
        }
    }

    /**
     * @description thie method will capture the page reload events
     * @date 2019-06-17
     * @param {*} $event
     * @memberof PaymentComponent
     */
    @HostListener('window:beforeunload', ['$event'])
    onbeforeunload($event) {
        if ($event) {
            this._loaderService.start();
        }
    }

    ngOnDestroy(): void {
        if (this.paymentComponentSettings.shoppingCartSubscription) {
            this.paymentComponentSettings.shoppingCartSubscription.unsubscribe();
        }
        if (this.paymentComponentSettings.reCreateOrderSubscription) {
            this.paymentComponentSettings.reCreateOrderSubscription.unsubscribe();
        }
    }
}
