export enum AutoshipStatus {
    ACTIVE = 1,
    PENDING = 2,
    SUSPENDED = 3,
    TERMINATED = 4,
    INCOMPLETE = 5
}
