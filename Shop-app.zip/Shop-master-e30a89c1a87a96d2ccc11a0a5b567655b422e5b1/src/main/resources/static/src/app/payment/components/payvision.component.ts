import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActiveSessionService, ConfigurationService, CacheService } from '../../shared/services';
import { PayvisionService, PaymentService, PaymentMessageService } from '../services';
import { PayvisionComponentSettings, PaymentComponentSettings } from '../component-settings';
import {
    PayvisionRegistration, PaymentRegistrationResponse,
    PayvisionBillingAddress, PayvisionMandatoryBillingAddressFields,
    PayvisionSavedCardResponse, PayvisionSavedCard, StorePaymentMethod
} from '../interfaces';
import { PaymentConstants } from '../constants';
import { Country } from '../../shared/interfaces';
import { CheckoutInformation, PaymentInformation } from '../../checkout/interfaces';
import { Address } from '../../common/interfaces';
import { PaymentStatus, PaymentProcessorAlias, PaymentMethodTypes } from '../enums';
import { Validators, FormBuilder } from '@angular/forms';
import { MemberType } from '../../shared/enums';
import { TranslateService } from '@ngx-translate/core';
import { TranslateKey } from '../../common/pipes/translate-key.pipe';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { AppSectionSpinnerService } from '../../common/services/section-spinner.service';
import { DeliveryOptionType } from '../../checkout/enums';


/**
 * @description this component provides payment functionality
 * with payvision provider and will load base settings from parent
 * payment component like store and countries
 * @date 2018-07-26
 * @export
 * @class PayvisionComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-payvision',
    templateUrl: '../templates/template3/views/payvision.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/payvision.component.less'
    ]
})

export class PayvisionComponent implements OnInit {
    payvisionComponentSettings: PayvisionComponentSettings = new PayvisionComponentSettings();

    // Input variables
    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;
    // tslint:disable-next-line:no-input-rename
    @Input('enablePlaceOrder') enablePlaceOrder: boolean;
    // Output variables
    @Output() submitPayment = new EventEmitter<any>();

    constructor(
        private _payvisionService: PayvisionService,
        private _activeSessionService: ActiveSessionService,
        private _paymentService: PaymentService,
        private _translatePipe: TranslateService,
        private _translateKey: TranslateKey,
        private _cacheService: CacheService,
        private _sectionSpinnerService: AppSectionSpinnerService,
        private _configurationService: ConfigurationService,
        private _formBuilder: FormBuilder,
        private _paymentMessageService: PaymentMessageService) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description Load Default shipping Settings
     * for the current user
     * @date 2018-07-20
     * @memberof PayvisionComponent
     */
    loadDefaultSettings() {
        this.payvisionComponentSettings = Object.assign(this.payvisionComponentSettings, this.paymentComponentSettings);
        this.payvisionComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        this.getTranslations();
        this.displayPayPalOrCCSection();
        this.getCCOrPaypalConfig();
    }

    /**
     * @description this method will get pay config based payment method selection
     * @date 2019-01-31
     * @memberof PayvisionComponent
     */
    private getCCOrPaypalConfig(): void {
        if (this.payvisionComponentSettings.userInfo &&
            this.payvisionComponentSettings.selectedPaymentMethod &&
            this.payvisionComponentSettings.selectedPaymentMethod.paymentMethodName === PaymentMethodTypes.Credit_Card) {
            this.loadSavedPayvisonCardsForMemberId();
        } else {
            this.getPavisionPaymentForm();
        }
    }

    /**
     * @description this method will diplay paypal or cc
     * based on payment method selection
     * @date 2019-01-31
     * @private
     * @memberof PayvisionComponent
     */
    private displayPayPalOrCCSection(): void {
        this._paymentMessageService.getPayPalOrCCSection()
            .subscribe((paymentMethod: StorePaymentMethod) => {
                this.payvisionComponentSettings = Object.assign(this.payvisionComponentSettings, this.paymentComponentSettings);
                this.paymentComponentSettings.paymentFailResponse = null;
                this.getCCOrPaypalConfig();
            });
    }

    /**
     * @description this method will swap between paypal and cc
     * @date 2019-01-31
     * @private
     * @memberof PaymentComponent
     */
    private pyapalChannelDispatchCCorPaypal(paymentMethod: StorePaymentMethod): void {
        if (paymentMethod.paymentMethodName === PaymentMethodTypes.Credit_Card) {
            $('[id^=wrap_card_]').removeClass('hide');
            $('[id^=wrap_virtualAccount-PAYPAL_]').addClass('hide');
            $('.wpwl-control-cardNumber ').val('');
            $('.wpwl-control-expiry ').val('');
            $('.wpwl-control-cardHolder').val('');
            $('.wpwl-control-cvv').val('');
        } else if (paymentMethod.paymentMethodName === PaymentMethodTypes.PayPal) {
            $('[id^=wrap_virtualAccount-PAYPAL_]').removeClass('hide');
            $('[id^=wrap_card_]').addClass('hide');
        }
    }

    /**
     * @description Method to get translations
     * @date 2018-10-23
     * @memberof PayvisionComponent
     */
    getTranslations(): void {
        this.payvisionComponentSettings.paymentTexts = {
            placeOrder: this._translateKey.transform(this._translatePipe.get('checkout.Place Order')['value'], false),
            saveAutoship: this._translateKey.transform(this._translatePipe.get('checkout.Save Autoship')['value'], false),
            billingAddress: this._translateKey.transform(this._translatePipe.get('checkout.Billing Address')['value'], false),
            savePaymentDetails: this._translateKey.transform(this._translatePipe.get('checkout.Save payment details')['value'], false),
            edit: this._translateKey.transform(this._translatePipe.get('checkout.edit')['value'], false),
            cardHolder: this._translateKey.transform(this._translatePipe.get('checkout.Cardholder')['value'], false),
            expirationDate: this._translateKey.transform(this._translatePipe.get('checkout.Expiration Date')['value'], false),
            cardNumber: this._translateKey.transform(this._translatePipe.get('checkout.Card Number')['value'], false),
            cvv: this._translateKey.transform(this._translatePipe.get('checkout.cvv')['value'], false),
            cardRequiredErrorKey: this._translateKey.transform(this._translatePipe.get('checkout.Cardholder is required')['value'], false),
            expirationRequiredErrorKey:
                this._translateKey.transform(this._translatePipe.get('checkout.Expiry Date is required')['value'], false),
            streetError: this._translateKey.transform(this._translatePipe.get('checkout.Address Line 1 is required')['value'], false),
            cityError: this._translateKey.transform(this._translatePipe.get('checkout.City is required')['value'], false),
            stateError: this._translateKey.transform(this._translatePipe.get('checkout.State is required')['value'], false),
            countryError: this._translateKey.transform(this._translatePipe.get('checkout.Country is required')['value'], false),
            postalError: this._translateKey.transform(this._translatePipe.get('checkout.Postal Code is required')['value'], false),
            communicationError: this._translateKey.transform
                (this._translatePipe.get('checkout.Your session has timed out. Please click')['value'], false),
            clickHere: this._translateKey.transform(this._translatePipe.get('checkout.here')['value'], false),
            refreshPage: this._translateKey.transform(this._translatePipe.get('checkout.to refresh the page')['value'], false)
        };

    }

    /**
     * @description load saved payvision cards
     * @date 2018-08-14
     * @memberof PayvisionComponent
     */
    loadSavedPayvisonCardsForMemberId(): void {
        if (!this.payvisionComponentSettings.savedCards) {
            this._payvisionService.
                getSavedPayvisonCards(this.payvisionComponentSettings.userInfo.memberId,
                    this.payvisionComponentSettings.isoCountryCode)
                .subscribe((payvisionSavedCardResponse: PayvisionSavedCardResponse) => {
                    if (payvisionSavedCardResponse && payvisionSavedCardResponse.savedCards
                        && payvisionSavedCardResponse.savedCards.length > 0) {
                        this.payvisionComponentSettings.savedCards = payvisionSavedCardResponse.savedCards;
                        this.paymentComponentSettings.paymentMethodTypeForm.enable();
                        this.preloadDefaultSavedCard();
                    } else {
                        this.getPavisionPaymentForm();
                    }
                }, (error: Response) => {
                    this.getPavisionPaymentForm();
                });
        } else if (this.payvisionComponentSettings.savedCards
            && this.payvisionComponentSettings.savedCards.length > 0) {
            this.preloadDefaultSavedCard();
        }
    }

    /**
     * @description this method will preselct the
     * default saved card
     * @date 2018-08-14
     * @private
     * @memberof PayvisionComponent
     */
    private preloadDefaultSavedCard(): void {
        this.paymentComponentSettings.enablePaymentOptions = true;
        this.payvisionComponentSettings.payvisionFormLoaded = false;
        this.payvisionComponentSettings.paymentWithSavedCard = true;
        this.payvisionComponentSettings.selectedPayvisionSavedCard = this.payvisionComponentSettings.
            savedCards.find(x => x.defaultCard) || this.payvisionComponentSettings.savedCards[0];
        this.createSavedPayvisionCardForm(this.payvisionComponentSettings.selectedPayvisionSavedCard.id);
    }

    /**
     * @description this method select payvision card
     * @date 2018-08-14
     * @memberof PayvisionComponent
     */
    selectPayvisionSavedCard(savedCard: PayvisionSavedCard): void {
        this.payvisionComponentSettings.selectedPayvisionSavedCard = savedCard;
    }

    /**
     * @description this method will process payment with saved card
     * @date 2018-08-14
     * @memberof PayvisionComponent
     */
    processPaymentWithSavedCard() {
        this.payvisionComponentSettings.paymentInformation = this.getPaymentInformation();
        this.submitPayment.emit(this.payvisionComponentSettings.paymentInformation);
    }

    /**
     * @description back to saved Address
     * @date 2018-12-11
     * @memberof PayvisionComponent
     */
    backToSavedCards(): void {
        this.payvisionComponentSettings.paymentWithSavedCard = !this.payvisionComponentSettings.paymentWithSavedCard;
        this.payvisionComponentSettings.errorMessage = '';
        if (this.payvisionComponentSettings && this.payvisionComponentSettings.savedCards
            && this.payvisionComponentSettings.savedCards.length > 0) {
            this.payvisionComponentSettings.selectedPayvisionSavedCard = this.payvisionComponentSettings.
                savedCards.find(x => x.defaultCard) || this.payvisionComponentSettings.savedCards[0];
        }
    }

    /**
    * @description
    * @date 2018-08-08
    * @private
    * @param {PayvisionRegistrationResponse} payvisionRegistrationResponse
    * @returns {PaymentInformation}
    * @memberof PayvisionComponent
    */
    private getPaymentInformation(): PaymentInformation {
        const paymentInformation: PaymentInformation = {
            paymentToken: this.payvisionComponentSettings.selectedPayvisionSavedCard.token,
            billingAddress: this.constructBillingAddress(),
            isEnrollment: false,
            selectedPaymentMethod: this.payvisionComponentSettings.selectedPaymentMethod,
            isCompleteRedirection: false,
        };
        return paymentInformation;
    }


    /**
     * @description this method will load new payvison form
     * @date 2018-08-14
     * @memberof PayvisionComponent
     */
    addNewPayvisionCard(): void {
        this.payvisionComponentSettings.paymentWithSavedCard = false;
        this.payvisionComponentSettings.selectedPayvisionSavedCard = null;
        this.getPavisionPaymentForm();
    }

    /**
    * @description creating a form for
    * shipping method information
    * @date 2018-07-19
    * @memberof PayvisionComponent
    */
    private createSavedPayvisionCardForm(savedCardId: number): void {
        this.payvisionComponentSettings.savedPayvisionCardForm = this._formBuilder.group({
            savedCardId: [savedCardId, Validators.required]
        });
    }

    /**
     * @description preparing the Payvision Registration
     * checkout form request
     * @date 2018-07-27
     * @returns {PayvisionRegistration}
     * @memberof PayvisionComponent
     */
    payvisionRegistrationFormRequest(): PayvisionRegistration {
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (isAutoshipEnabled) {
            return this.payvisionRegistrationForm();
        } else {
            return this.payvisionRegistrationFormWithWebOrder();
        }
    }

    /**
     * @description Payment form for Order Payment
     * @date 2018-10-16
     * @returns {PayvisionRegistration}
     * @memberof PayvisionComponent
     */
    payvisionRegistrationFormWithWebOrder(): PayvisionRegistration {
        const checkoutInformation = this.payvisionComponentSettings.checkoutInformation;
        if (checkoutInformation && checkoutInformation.orderDetails) {
            const payvisionRegistration: PayvisionRegistration = {
                countryCode: this.payvisionComponentSettings.isoCountryCode.toUpperCase(),
                customerId: this._paymentService.getCustomerId(),
                storeId: this.payvisionComponentSettings.store.id,
                orderTypeId: this._activeSessionService.getOrderTypeId(),
                paymentMethodType: this.payvisionComponentSettings.paymentMethodTypes.Credit_Card,
                currencyCode: this.payvisionComponentSettings.store.currencyCode,
                orderReferenceId: checkoutInformation.orderDetails.id,
                paymentRequestModel: {
                    createRegistartion: false,
                    webOrderId: checkoutInformation.orderDetails.webOrderId
                },
                paymentCallBackUrlModel: {
                    webOrderId: checkoutInformation.orderDetails.webOrderId,
                    cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
                    failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
                    successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
                }
            };
            return payvisionRegistration;
        }
    }

    /**
     * @description payment form to register the card details
     * @date 2018-10-16
     * @returns {PayvisionRegistration}
     * @memberof PayvisionComponent
     */
    payvisionRegistrationForm(): PayvisionRegistration {
        const payvisionRegistration: PayvisionRegistration = {
            countryCode: this.payvisionComponentSettings.isoCountryCode.toUpperCase(),
            customerId: this.payvisionComponentSettings.userInfo ? this.payvisionComponentSettings.userInfo.memberId : 0,
            storeId: this.payvisionComponentSettings.store.id,
            orderTypeId: this.payvisionComponentSettings.userInfo.memberTypeId,
            paymentMethodType: this.payvisionComponentSettings.paymentMethodTypes.Credit_Card,
            currencyCode: this.payvisionComponentSettings.store.currencyCode,
            paymentRequestModel: {
                createRegistartion: true
            },
            paymentCallBackUrlModel: {
                cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
                failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
                successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
            }
        };
        return payvisionRegistration;
    }

    /**
     * @description this method will return current window url
     * @date 2018-08-13
     * @private
     * @returns {string}
     * @memberof PayvisionComponent
     */
    private getCurrentWindowUrl(): string {
        const currentWindowURL: string = window.location.origin + '/' + this.payvisionComponentSettings.isoCountryCode +
            '/' + this.payvisionComponentSettings.languageCode + '/checkout/payment/'
            + PaymentProcessorAlias.PAYVISION.toLowerCase() + '/';

        return currentWindowURL;
    }


    /**
     * @description to load the Payvision Merchant Determined
     * Registration Checkout form
     * @date 2018-07-27
     * @param {string} checkoutId
     * @memberof PayvisionComponent
     */
    loadPayvisionForm(registrationResponse: PaymentRegistrationResponse): void {
        if (this.payvisionComponentSettings.checkoutInformation) {
            const payVisionComponent = this;
            if (registrationResponse && registrationResponse.id) {
                const scriptSrc = registrationResponse.formUrl;
                window['wpwlOptions'] = this.getPayvisionOptions();
                window['wpwlOptions'].onError = function (error) {
                    // check if shopper payed after 30 minutes aka checkoutid is invalid
                    if (error.name === PaymentConstants.InvalidCheckoutIdError || error.name === PaymentConstants.PciIframeSubmitError) {
                        $('.wpwl-has-error').css('border', 'none');
                        const reloadHtml = '<a class="error link--light" href=' + window.location.href + '>' +
                            payVisionComponent.payvisionComponentSettings.paymentTexts.clickHere + '</a>';
                        const errorHtml = payVisionComponent.payvisionComponentSettings.paymentTexts.communicationError
                            + ' ' + reloadHtml + ' ' + payVisionComponent.payvisionComponentSettings.paymentTexts.refreshPage;
                        $('.wpwl-message.wpwl-has-error').
                            html(errorHtml);
                        $('.wpwl-message.wpwl-has-error').addClass('error');
                    }
                };
                $('#' + PaymentConstants.PayVisionScriptID).remove();
                const wpwl = window['wpwl'];
                if (wpwl && wpwl.checkout && wpwl.checkout.config
                    && wpwl.checkout.config.environmentConfig) {
                    const envConfig = wpwl.checkout.config.environmentConfig;
                    // tslint:disable-next-line:quotemark
                    if (document.querySelector("script[src*='" + envConfig.cacheVersion + "']")) {
                        // tslint:disable-next-line:quotemark
                        document.querySelector("script[src*='" + envConfig.cacheVersion + "']").remove();
                    }
                }
                const payvisionScript = document.createElement('script');
                payvisionScript.id = PaymentConstants.PayVisionScriptID;
                payvisionScript.src = scriptSrc + '?checkoutId=' + registrationResponse.id;
                payvisionScript.type = 'text/javascript';
                document.head.appendChild(payvisionScript);
                const payvisionForm = document.createElement('form');
                payvisionForm.setAttribute('action', registrationResponse.paymentUrl);
                payvisionForm.setAttribute('class', 'paymentWidgets');
                payvisionForm.setAttribute('data-brands',
                    registrationResponse.cardBrands ? registrationResponse.cardBrands : 'VISA MASTER DISCOVER PAYPAL');
                if (document.getElementById('pvForm')) {
                    document.getElementById('pvForm').appendChild(payvisionForm);
                }
                window['wpwlOptions'] = window['wpwlOptions'] || {};
                jQuery('form.paymentWidgets').appendTo('#pvscript');
            }
        }
        setTimeout(() => {
            this.paymentComponentSettings.paymentMethodTypeForm.enable();
            this.payvisionComponentSettings.payvisionFormLoaded = true;
            this._sectionSpinnerService.stop('creditCard');
        }, 2000);
    }

    /**
     * @description mapping payvision options
     * here we used any type
     * @date 2018-07-27
     * @memberof PayvisionComponent
     */
    private getPayvisionOptions(): any {
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        const payVisionComponent = this;
        if (this.payvisionComponentSettings.checkoutInformation.shippingInformation) {
            // Reason we any Type here is we dont have chance
            // to write to interface for payvison object
            const payvisionOptions: any = {
                maskCvv: true,
                locale: this.payvisionComponentSettings.languageCode.substring(0, 2),
                billingAddress: this.mapBillingAddress(),
                mandatoryBillingFields: this.getBillingAddressManadatoryFields()
            };
            window['wrapElement'] = function (element) {
                const id = $(element).attr('id');
                const paymentMethodName = payVisionComponent.paymentComponentSettings.selectedPaymentMethod.paymentMethodName;
                const wrapId = 'wrap_' + id;
                if (wrapId.indexOf('wrap_card_') > -1 && paymentMethodName === PaymentMethodTypes.Credit_Card
                    || wrapId.indexOf('wrap_virtualAccount-PAYPAL_') > -1 && paymentMethodName === PaymentMethodTypes.PayPal) {
                    $(element).wrap('<div class="" id="' + wrapId + '"></div>"');
                } else {
                    $(element).wrap('<div class="hide" id="' + wrapId + '"></div>"');
                }
                if (wrapId.indexOf('wrap_virtualAccount-PAYPAL_') > -1) {
                    $('#payPalScript').empty();
                    $('#' + wrapId).detach().appendTo('#payPalScript');
                }
                return $('#' + wrapId);
            };
            const registerMemberType = this.payvisionComponentSettings.registerMemberType;
            payvisionOptions['onReady'] = function () {
                if (registerMemberType !== MemberType.GUESTCUSTOMER) {
                    // tslint:disable-next-line:max-line-length
                    const createRegistrationHtml = `<div class="mb-2"><div class="form-check pl-0">
                                                    <label tabindex="0">
                                                        <input type="checkbox" name="createRegistration" value="true" />
                                                        <span class="label-text customLabel">`
                        + payVisionComponent.payvisionComponentSettings.
                            paymentTexts.savePaymentDetails + `?</span>
                                                    </label>
                                                </div></div>`;
                    if (!isAutoshipEnabled) {
                        $('form.wpwl-form-card').find('.wpwl-button').before(createRegistrationHtml);
                    }
                }
                const createCardImageHtml = `<div class="mb-2 card-brand-content">
                <span class="card-brand ml-auto"></span></div>`;
                // re ordering the payment form fields
                $('.wpwl-group-cardHolder').before(createCardImageHtml);
                $('.wpwl-group-cardHolder').after($('.wpwl-group-cardNumber'));
                $('.wpwl-group-cardNumber').after($('.wpwl-group-expiry'));
                $('.wpwl-group-expiry').after($('.wpwl-group-cvv'));

                $('.wpwl-sup-wrapper-street1').after($('.wpwl-sup-wrapper-street2'));
                $('.wpwl-sup-wrapper-street2').after($('.wpwl-sup-wrapper-city'));
                $('.wpwl-sup-wrapper-city').after($('.wpwl-sup-wrapper-state'));
                $('.wpwl-sup-wrapper-state').after($('.wpwl-sup-wrapper-postcode'));
                $('.wpwl-sup-wrapper-postcode').after($('.wpwl-sup-wrapper-country'));

                $('.wpwl-label-cardHolder').html(payVisionComponent.payvisionComponentSettings.
                    paymentTexts.cardHolder);
                $('.wpwl-control-cardHolder').attr('placeholder', payVisionComponent.payvisionComponentSettings.
                    paymentTexts.cardHolder);
                $('.wpwl-label-expiry').html(payVisionComponent.payvisionComponentSettings.
                    paymentTexts.expirationDate);
                $('.wpwl-text-billing').contents().filter(function () { return this.nodeType === 3; }).first()
                    .replaceWith(payVisionComponent.constructBillingAddressSection(payvisionOptions.billingAddress));
                $('.wpwl-label-billing').html(payVisionComponent.payvisionComponentSettings.
                    paymentTexts.billingAddress);
                $('.editbilling').html('(' + payVisionComponent.payvisionComponentSettings.
                    paymentTexts.edit + ')');
                if (isAutoshipEnabled) {
                    $('.wpwl-button-pay').html(payVisionComponent.payvisionComponentSettings.
                        paymentTexts.saveAutoship).addClass('btn btn-primary col col-sm-auto');
                } else {
                    $('.wpwl-button-pay').html(payVisionComponent.payvisionComponentSettings.
                        paymentTexts.placeOrder).addClass('btn btn-primary col col-sm-auto');
                }

                // tslint:disable-next-line:max-line-length
                $('iframe').attr('sandbox', 'allow-forms allow-popups allow-pointer-lock allow-same-origin allow-scripts allow-top-navigation-by-user-activation allow-top-navigation');
                $('.wpwl-container').each(function () {
                    window['wrapElement']((this));
                    $(this);
                });
            };

            payvisionOptions['validateCard'] = function (event) {
                let cardHolderValid = true;
                let expiryValid = true;
                let streetNameValid = true;
                let cityValid = true;
                let stateValid = true;
                let countryValid = true;
                let postcodeValid = true;

                cardHolderValid = payVisionComponent.validateInputFields('.wpwl-control-cardHolder', 'wpwl-has-error',
                    'cardHolderError', payVisionComponent.payvisionComponentSettings.paymentTexts.cardRequiredErrorKey);
                expiryValid = payVisionComponent.validateInputFields('.wpwl-control-expiry', 'wpwl-has-error',
                    'expiryError', payVisionComponent.payvisionComponentSettings.paymentTexts.expirationRequiredErrorKey);
                streetNameValid = payVisionComponent.validateInputFields('.wpwl-control-street1',
                    'wpwl-has-error', 'billingStreetError', payVisionComponent.payvisionComponentSettings.paymentTexts.streetError);
                cityValid = payVisionComponent.validateInputFields('.wpwl-control-city', 'wpwl-has-error',
                    'billingCityError', payVisionComponent.payvisionComponentSettings.paymentTexts.cityError);
                stateValid = payVisionComponent.validateStateInputFields('.wpwl-control-stateText', 'wpwl-has-error',
                    'billingStateError', payVisionComponent.payvisionComponentSettings.paymentTexts.stateError);
                countryValid = payVisionComponent.validateInputFields('.wpwl-control-country', 'wpwl-has-error',
                    'billingCountryError', payVisionComponent.payvisionComponentSettings.paymentTexts.countryError);
                postcodeValid = payVisionComponent.validateInputFields('.wpwl-control-postcode', 'wpwl-has-error',
                    'billingPostCodeError', payVisionComponent.payvisionComponentSettings.paymentTexts.postalError);
                return (cardHolderValid && expiryValid && streetNameValid && cityValid && stateValid && countryValid && postcodeValid);
            };
            // TODO: need to remove once ie issue resloved from payvision
            payvisionOptions['onBeforeSubmitCard'] = function (event) {
                $(this.elements).each(function (i, obj) {
                    // tslint:disable-next-line:quotemark
                    if (obj.name === "") {
                        $(obj).remove();
                    }
                });
                return true;
            };
            return payvisionOptions;
        }
    }

    /**
     * @description
     * Handling internal form validations for state fields
     * State can be input element/ select element
     * @date 2019-02-05
     * @private
     * @param {string} selector
     * @param {string} errorClass
     * @param {string} errorName
     * @param {string} errorMessage
     * @returns {boolean}
     * @memberof PayvisionComponent
     */
    private validateStateInputFields(selector: string, errorClass: string, errorName: string, errorMessage: string): boolean {
        let isStateText: boolean;
        let isStateSelect: boolean;
        if (!$('.wpwl-control-stateText').val()
            && $('.wpwl-control-stateText')[0].style['display'] !== 'none') {
            $('.wpwl-control-stateText').addClass(errorClass);
            const expiryError = '<div class="wpwl-hint wpwl-hint-' + errorName + '">' + errorMessage + '</div>';
            $('.wpwl-control-stateText').after(expiryError);
            isStateText = false;
        } else {
            $('.wpwl-control-stateText').removeClass(errorClass);
            // $('.wpwl-hint-' + errorName).html('');
            isStateText = true;
        }
        if (!$('.wpwl-control-stateSelect').val()
            && $('.wpwl-control-stateSelect')[0].style['display'] !== 'none') {
            $('.wpwl-control-stateSelect').addClass(errorClass);
            const expiryError = '<div class="wpwl-hint wpwl-hint-' + errorName + '">' + errorMessage + '</div>';
            $('.wpwl-control-stateSelect').after(expiryError);
            isStateSelect = false;
        } else {
            $('.wpwl-control-stateSelect').removeClass(errorClass);
            // $('.wpwl-hint-' + errorName).html('');
            isStateSelect = true;
        }

        return isStateText && isStateSelect;
    }

    /**
     * @description
     * Handling internal form validations for Billing address fields
     * @date 2019-02-05
     * @private
     * @param {string} selector
     * @param {string} errorClass
     * @param {string} errorName
     * @param {string} errorMessage
     * @returns {boolean}
     * @memberof PayvisionComponent
     */
    private validateInputFields(selector: string, errorClass: string, errorName: string, errorMessage: string): boolean {
        if (!$(selector).val()) {
            $(selector).addClass(errorClass);
            const expiryError = '<div class="wpwl-hint wpwl-hint-' + errorName + '">' + errorMessage + '</div>';
            $(selector).after(expiryError);
            return false;
        } else {
            $(selector).removeClass(errorClass);
            $('.wpwl-hint-' + errorName).html('');
            return true;
        }
    }

    /**
     * @description
     * Construct string to be displayed in Billing address section
     * @date 2018-10-16
     * @param {*} billingAddress
     * @returns {string}
     * @memberof PayvisionComponent
     */
    constructBillingAddressSection(billingAddress): string {
        let address = '';
        const size = Object.keys(billingAddress).length;
        Object.keys(billingAddress).forEach(function (key, index) {
            if (billingAddress[key] && billingAddress[key] !== '') {
                if (index + 1 === size) {
                    address += billingAddress[key] + ' ';
                } else {
                    address += billingAddress[key] + ', ';
                }
            }
        });
        return address;
    }

    /**
     * @description mapping the billing address in the
     * payvision payment form
     * @date 2018-07-27
     * @private
     * @returns {PayvisionBillingAddress}
     * @memberof PayvisionComponent
     */
    private mapBillingAddress(): PayvisionBillingAddress {
        const shippingAddress = this.payvisionComponentSettings.checkoutInformation.shippingInformation.shippingAddress;
        const shippingCountry = this._configurationService.getShippingCountryCode();
        let country: Country;
        if (shippingAddress && (shippingAddress.state === PaymentConstants.PuertoRico || shippingAddress.state === PaymentConstants.MarshallIslands || shippingAddress.state === PaymentConstants.VirginIslands)) {
            if (this.payvisionComponentSettings.countries && this.payvisionComponentSettings.countries.length > 0) {
                if (shippingAddress.state === PaymentConstants.MarshallIslands) {
                    country = this.payvisionComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                    === shippingAddress.state.toLowerCase());
                } else {
                    country = this.payvisionComponentSettings.countries.find(x => x.isocodeTwo.toLowerCase()
                    === shippingAddress.state.toLowerCase());
                }
            }
        } else if (this.payvisionComponentSettings.checkoutInformation
            && this.payvisionComponentSettings.checkoutInformation.shippingInformation
            && this.payvisionComponentSettings.checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup
            && this.payvisionComponentSettings.checkoutInformation.mailingAddress
            && this.payvisionComponentSettings.countries && this.payvisionComponentSettings.countries.length > 0
            && (this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.PuertoRico
                ||  this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.MarshallIslands
                || this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.VirginIslands)) {
            if (this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.MarshallIslands) {
                country = this.payvisionComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                === this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode.toLowerCase());
            } else {
                country = this.payvisionComponentSettings.countries.find(x => x.isocodeTwo.toLowerCase()
                === this.payvisionComponentSettings.checkoutInformation.mailingAddress.stateCode.toLowerCase());
            }
        } else {
            if (this.payvisionComponentSettings.countries && this.payvisionComponentSettings.countries.length > 0) {
                country = this.payvisionComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                    === shippingCountry.toLowerCase());
            }
        }
        

        const billingAddress: PayvisionBillingAddress = {
            street1: shippingAddress ? shippingAddress.addressLine1 : '',
            street2: shippingAddress ? shippingAddress.addressLine2 : '',
            city: shippingAddress ? shippingAddress.city : '',
            state: shippingAddress ? shippingAddress.state : '',
            country: country ? country.isocodeTwo : '',
            postcode: shippingAddress ? shippingAddress.postalCode : ''
        };
        return billingAddress;
    }

    /**
     * @description to get payvision mandatory fields
     *  in payment form
     * @date 2018-07-27
     * @private
     * @returns {PayvisionMandatoryBillingAddressFields}
     * @memberof PayvisionComponent
     */
    private getBillingAddressManadatoryFields(): PayvisionMandatoryBillingAddressFields {
        const mandatoryBillingFields: PayvisionMandatoryBillingAddressFields = {
            country: true,
            state: true,
            city: true,
            postcode: true,
            street1: true,
            street2: false
        };
        return mandatoryBillingFields;
    }

    /**
     * @description to get the Payment form
     * @date 2018-07-27
     * @memberof PayvisionComponent
     */
    getPavisionPaymentForm(): void {
        const paymentMethod = this.payvisionComponentSettings.selectedPaymentMethod;
        if (!this.paymentComponentSettings.paymentFailResponse && paymentMethod
            && (paymentMethod.paymentMethodName === PaymentMethodTypes.Credit_Card
                || paymentMethod.paymentMethodName === PaymentMethodTypes.PayPal)) {
            if ($('[id^=wrap_card_]').length === 0) {
                setTimeout(() => {
                    this._sectionSpinnerService.start('creditCard');
                }, 0);
                if (this.payvisionComponentSettings.store && this.payvisionComponentSettings.store.id) {
                    this._payvisionService
                        .getPayvisionForm(this.payvisionComponentSettings.store.id, this.payvisionRegistrationFormRequest())
                        .subscribe((response: PaymentRegistrationResponse) => {
                            this.loadPayvisionForm(response);
                        });
                }
            } else {
                this.pyapalChannelDispatchCCorPaypal(this.payvisionComponentSettings.selectedPaymentMethod);
            }
        }
    }

    /**
     * @description constructing billing address
     * @date 2018-07-31
     * @returns {Address}
     * @memberof PayvisionComponent
     */
    constructBillingAddress(): Address {
        const checkoutInformation: CheckoutInformation = this.payvisionComponentSettings.checkoutInformation;
        let billingAddress: Address;
        if (checkoutInformation && checkoutInformation.shippingInformation &&
            checkoutInformation.shippingInformation.shippingAddress) {
            const shippingAddress: Address = checkoutInformation.shippingInformation.shippingAddress;
            billingAddress = {
                firstName: shippingAddress.firstName,
                lastName: shippingAddress.lastName,
                name: shippingAddress.name,
                addressLine1: shippingAddress.addressLine1,
                addressLine2: shippingAddress.addressLine2,
                city: shippingAddress.city,
                country: shippingAddress.country,
                countryCode: shippingAddress.country,
                state: shippingAddress.state,
                zip: shippingAddress.zip,
                phone: shippingAddress.phone,
            };
        }
        return billingAddress;
    }
}
