import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
@Directive({ selector: '[appHasPrivilege]'})
export class HasPrivilegeDirective {
    constructor(private _templateRef: TemplateRef<any>,
        private _viewContainerRef: ViewContainerRef) {

    }

    // authorize directive for checking the user is allowed to access the content
    @Input() set hasPrivilege(privilege: string) {
        if (privilege) {
            // If condition is true add template to DOM
            this._viewContainerRef.createEmbeddedView(this._templateRef);
        } else {
            // Else remove template from DOM
            this._viewContainerRef.clear();
        }
    }

    /**
     * @param  {string} privilege
     * @returns void
     */
    private validatePrivilege(privilege: string): void {

    }
}
