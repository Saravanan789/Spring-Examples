export interface CreditCardModel {
  paymentToken: string;
  paymentMethodType: string;
  maskedCreditCardNumber: string;
  cardHolderName: string;
  expMonth: string;
  expYear: string;
  currencyCode: string;
}
