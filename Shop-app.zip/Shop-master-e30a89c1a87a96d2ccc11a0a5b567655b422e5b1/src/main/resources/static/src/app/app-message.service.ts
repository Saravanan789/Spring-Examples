import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AppMessageService {
    private openCartSubject: Subject<any> = new Subject<any>();
    private openSearchSubject: Subject<any> = new Subject<any>();
    private cartItemsChangesSubject: Subject<any> = new Subject<any>();
    private miniCartSubject: Subject<any> = new Subject<any>();
    private miniCartViewSubject: Subject<any> = new Subject<any>();
    private resetHeaderSubject: Subject<any> = new Subject<any>();
    private cartItemsCountSubject: Subject<any> = new Subject<any>();
    private wishListSubject: Subject<any> = new Subject<any>();
    private notifyLoginSubject: Subject<any> = new Subject<any>();
    private cookieBannerContent: Subject<any> = new Subject<any>();
    private cookieBannerResponse: Subject<any> = new Subject<any>();
    private collapseMenu: Subject<boolean> = new Subject<boolean>();
    private showSearchBox: Subject<boolean> = new Subject<boolean>();
    private showProductBanner: Subject<boolean> = new Subject<boolean>();
    private categoriesAndCatalogsSubject: Subject<any> = new Subject<any>();
    private userInfoSubject: Subject<any> = new Subject<any>();
    private categoryTreeIndex: Subject<number> = new Subject<number>();

    private processOrder: Subject<boolean> = new Subject<boolean>();
    private reCreateOrder: Subject<any> = new Subject<any>();
    private submitAddress: Subject<any> = new Subject<any>();
    private memberUpgradeNotification: Subject<any> = new Subject<any>();

    private openMenuFn: Function;
    // intimate whether the body is scrolling automatically
    isBodyScrolling: boolean;
    constructor() { }
    /**
     * Assign method to call
     * @param {Function} fn
     * @memberof AppMessageService
     */
    listenOpenPushMenuFn(fn: Function): void {
        this.openMenuFn = fn;
    }

    /**
     * To get definition of assigned method
     * @returns {Function}
     * @memberof AppMessageService
     */
    getOpenPushMenuFn(): Function {
        return this.openMenuFn;
    }

    setCookieBannerResponseData(data: any): void {
        this.cookieBannerResponse.next(data);
    }

    getCookieBannerResponseData(): Observable<any> {
        return this.cookieBannerResponse.asObservable();
    }

    /**
     * @param  {number} index
     * @returns void
     */
    setCategoryTreeOpenIndex(index: number): void {
        this.categoryTreeIndex.next(index);
    }

    /**
     * @returns Observable
     */
    getCategoryTreeOpenIndex(): Observable<number> {
        return this.categoryTreeIndex.asObservable();
    }

    /**
     * @param  {any} data
     * @returns void
     */
    setCategoriesAndCatalogsSubject(): void {
        this.categoriesAndCatalogsSubject.next();
    }

    /**
     * @returns Observable
     */
    getCategoriesAndCatalogsSubject(): Observable<any> {
        return this.categoriesAndCatalogsSubject.asObservable();
    }

    /**
     * subject to show/hide search box
     */
    setSearchBoxVisibility(canShow: boolean): void {
        this.showSearchBox.next(canShow);
    }

    isSearchBoxVisibile(): Observable<boolean> {
        return this.showSearchBox;
    }
    setShowProductBanner(canShow: boolean) {
        this.showProductBanner.next(canShow);
    }

    getShowProductBanner(): Observable<boolean> {
        return this.showProductBanner.asObservable();
    }

    setCollapseMenu(isOpen: any): void {
        this.collapseMenu.next(isOpen);
    }

    getCollapseMenu(): Observable<boolean> {
        return this.collapseMenu.asObservable();
    }
    /**
     * Data for cookie banner
     */
    setCookieBannerData(data: any): void {
        this.cookieBannerContent.next(data);
    }

    getCookieBannerData(): Observable<any> {
        return this.cookieBannerContent.asObservable();
    }
    /**
     * subject to notify the Login event
     */
    getNotifyLoginStatus(): Observable<any> {
        return this.notifyLoginSubject.asObservable();
    }

    setNotifyLoginStatus(isLogin: boolean): void {
        this.notifyLoginSubject.next(isLogin);
    }

    /**
     * subject to emit isOpen property
     */
    setOpenCart(isOpen: any) {
        this.openCartSubject.next(isOpen);
    }

    /**
     * subject to get isOpen property
     */
    getOpenCart(): Observable<any> {
        return this.openCartSubject.asObservable();
    }

    /**
     * subject to emit isOpen property
     */
    setOpenSearch(isOpen: any) {
        this.openSearchSubject.next(isOpen);
    }

    /**
     * subject to get isOpen property
     */
    getOpenSearch(): Observable<any> {
        return this.openSearchSubject.asObservable();
    }


    /**
    * subject to emit CartItems Changes
    */
    setCartItemsChanges(cartItemDetails: any) {
        this.cartItemsChangesSubject.next(cartItemDetails);
    }

    /**
     * subject to notify when CartItems Changes
     */
    getCartItemsChanges(): Observable<any> {
        return this.cartItemsChangesSubject.asObservable();
    }

    /**
    * set minicart sessionInfo
    */
    setMiniCart(sessionInfo: any) {
        this.miniCartSubject.next(sessionInfo);
    }

    /**
     * get minicart sessionInfo
     */
    getMiniCart(): Observable<any> {
        return this.miniCartSubject.asObservable();
    }
    /**
    * set minicart sessionInfo
    */
    showMiniCartView(val: any) {
        this.miniCartViewSubject.next(val);
    }

    /**
     * get minicart sessionInfo
     */
    getMiniCartView(): Observable<any> {
        return this.miniCartViewSubject.asObservable();
    }

    /**
    * set HeaderData to reset
    */
    setHeaderDataReset() {
        this.resetHeaderSubject.next();
    }

    /**
     *  get HeaderData Reset
     */
    getHeaderDataReset(): Observable<any> {
        return this.resetHeaderSubject.asObservable();
    }

    /**
     * set HeaderData to reset
     */
    setCartItemsCount(cart: any) {
        this.cartItemsCountSubject.next(cart);
    }

    /**
     *  get HeaderData Reset
     */
    getCartItemsCount(): Observable<any> {
        return this.cartItemsCountSubject.asObservable();
    }

    /**
     * set HeaderData to reset
     */
    setWishListItems() {
        this.wishListSubject.next();
    }

    /**
     *  get HeaderData Reset
     */
    getWishListItems(): Observable<any> {
        return this.wishListSubject.asObservable();
    }

    /**
     * set Updated Userinfo on level up
     */
    setUpdatedUserInfo(userInfo: any) {
        this.userInfoSubject.next(userInfo);
    }

    /**
     *  get Updated Userinfo on level up
     */
    getUpdatedUserInfo(): Observable<any> {
        return this.userInfoSubject.asObservable();
    }

    getProcessOrder(): Observable<boolean> {
        return this.processOrder.asObservable();
    }

    setProcessOrder(recreateOrder?: boolean): void {
        this.processOrder.next(recreateOrder);
    }

    getSubmitAddress(): Observable<any> {
        return this.submitAddress.asObservable();
    }

    setSubmitAddress(isSubmit: boolean): void {
        this.submitAddress.next(isSubmit);
    }

    getReCreateOrder(): Observable<any> {
        return this.reCreateOrder.asObservable();
    }

    setReCreateOrder(orderResponse: any): void {
        this.reCreateOrder.next(orderResponse);
    }

    /**
     * get Member upgrade notification
     */
    getMemberUpgradeNotification(): Observable<boolean> {
        return this.memberUpgradeNotification.asObservable();
    }

    /**
     * set Member upgrade notification
     */
    setMemberUpgradeNotification(memberUpgradeNotification: boolean): void {
        this.memberUpgradeNotification.next(memberUpgradeNotification);
    }

}
