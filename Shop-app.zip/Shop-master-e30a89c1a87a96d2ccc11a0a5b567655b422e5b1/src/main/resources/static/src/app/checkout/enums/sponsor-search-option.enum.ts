export enum SponsorSearchOption	{
    SearchByFBOID = 8,
    SearchByFBOName = 2,
    SearchBySuggestSponsor = 7,
    SocialMedia = 4,
    WebSearch = 5,
    Other = 6,
    SearchByIKnowSponsor = 1,
    SearchByIDontHaveSponsor = 3
  }
