export class DateConstants {
    public static Object = 'object';
    public static String = 'string';
    public static DateFormat = 'DD-MMM-YYYY';
    public static InvalidDate = 'Invalid date';
    public static DOBFormat = 'YYYY-MM-DD';
    public static DOBConvertFormat = 'DD-MM-YYYY';
    public static MMDDFormat = 'MM-DD-YYYY';
}
