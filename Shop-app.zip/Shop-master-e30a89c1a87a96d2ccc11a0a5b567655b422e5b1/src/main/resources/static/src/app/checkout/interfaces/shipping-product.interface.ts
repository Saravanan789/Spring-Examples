export interface ShippingProductModel {
  productID: number;
  productWeight: number;
  productHeight: number;
  productWidth: number;
  productQuantity: number;
  productLength: number;
  sellingPrice: number;
  wholesalePrice: number;
  retailPrice: number;
  weightMetricId: number;
  isOrderLiteratureOnly: boolean;
  isShippable: boolean;
  itemNumber: string;
}

