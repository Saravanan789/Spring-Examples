export enum NotificationType {
    ERROR = 'ERROR',
    SUCCESS = 'SUCCESS',
    WARN = 'WARN',
    CANCEL = 'CANCEL',
    MESSAGE = 'MESSAGE'
}
