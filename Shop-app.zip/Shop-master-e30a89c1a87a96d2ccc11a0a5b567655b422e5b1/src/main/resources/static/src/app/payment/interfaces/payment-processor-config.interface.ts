export interface PaymentProcessorConfig {
    cardTypes: string[];
    paymentMethodCode: string;
    description: string;
    paymentMethodName: string;
    templateForm: boolean;
    paymentProcessor: string;
    cvvRequired: boolean;
    redirect: boolean;
    redirectInstallationID: number;
    completeRedirect: boolean;
}
