export enum ProductType {
    Simple = 1,
    Variable = 2,
    Kit = 3,
    Configurable_Kit = 4
}
