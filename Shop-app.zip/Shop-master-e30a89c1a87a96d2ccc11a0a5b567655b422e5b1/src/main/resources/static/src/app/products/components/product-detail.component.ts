import { ImageModel } from '../interfaces/image-model.interface';
import { ChildImage } from '../interfaces/child-image.interface';
import { CartService } from '../../shared/services/cart.service';
import { Options } from '../interfaces/options.interface';
import { ProductType } from '../enums/product-types.enum';
import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import {
  SwiperConfigInterface,
  SwiperComponent
} from 'ngx-swiper-wrapper';
import * as _ from 'lodash';

import { Product } from '../interfaces/product.interface';
import { ProductService } from '../services/product.service';
import { CommonService } from '../../shared/services/common.service';
import { CacheService } from '../../shared/services/cache.service';
import { ProductDetailService } from '../services/product-detail.service';
import { ImageType } from '../enums/image-type.enum';
import { AppMessageService } from '../../app-message.service';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { ImageTypeFilterPipe } from '../../common/pipes/image-type-filter.pipe';
import { TranslateService } from '@ngx-translate/core';
import { PurchaseFlow } from '../../shared/enums/purchase-flow.enum';
import { StoreConfig, StorePurchaseFlow } from '../../shared/interfaces/StoreConfig.interface';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Cart } from '../../shared/models/cart.model';
import { Item } from '../../shared/models/item.model';
import { ProductDetailsForBots } from '../interfaces/productDetailsForBots.interface';
import { OnDestroy, AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { environment } from '../../../environments/environment';
import { Categories } from '../interfaces/categories.interface';
import { AppModalDirective } from '../../common/directives/app-modal.directive';
import { VgAPI } from 'videogular2/core';
import { NotificationService } from '../../shared/services/notification.service';
import { NotificationType } from '../../common/enums/notification-type.enum';
import { CardType } from '../../shared/enums/card-types.enum';
import { ProductMessageService } from '../services/product-message.service';
import { VideoSource } from '../enums/video-type.enum';
import { Ng2DeviceService } from 'ng2-device-detector';
import { Attribute } from '../../shared/enums/attribute-types.enum';
import { Location } from '@angular/common';
import { MemberType, MemberLevel } from '../../shared/enums';
import { DataShareService, ActiveSessionService } from '../../shared/services';
import { CardContent, Card, ReviewCount } from '../interfaces';
import { Autoship } from '../../checkout/interfaces';
import { Meta, Title } from '@angular/platform-browser';
import { TranslateParam } from '../../common/interfaces';
import { ProductMetatDataValue } from '../enums/product-metatdata.enum';
import { MetaTagConstants } from '../../shared/constants/meta-tag.constants';
@Component({
  selector: 'app-product-detail',
  templateUrl:
    '../templates/template3/views/product-detail.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/product-detail.component.less'
  ],
  providers: [ImageTypeFilterPipe]
})

export class ProductDetailComponent implements OnInit, OnDestroy, AfterViewInit {
  isPersonalPurchaseFlow = false;
  personalPurchaseFlow: string = PurchaseFlow.PERSONAL;
  purchaseFlows: StorePurchaseFlow[] = [];
  store: StoreConfig;
  activeImageIndex = 0;
  productDetail: Product;
  loadWishListToMember = false;
  showProductReview = true;
  showProductAssociation = true;
  productId: number;
  productName: string;
  productSlug: string;
  quantity: number;
  swiperInit = false;
  productContents = [];
  imageTypes = ImageType;
  languageCode: string;
  storeId: number;
  options: Options[];
  productType = ProductType;
  selectedFilter: any = {};
  showOptions = false;
  productItemNumber: string;
  prodReviewCount: any;
  userLoggedIn: any;
  disableDecrement: boolean;
  reviewTranslated: any;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  showContinueShopping = false;
  newrating = 3.6;
  wishListSubscription: Subscription;
  productCategoriesAndCatalogsSubject: Subscription;
  disableIncrement = false;
  productUrl: string;
  @ViewChild('topSlider') topSlider: SwiperComponent;
  @ViewChild('thumbsSlider') thumbsSlider: SwiperComponent;
  ingredientsList = '';
  hasIngredients = false;
  hasCertificates = false;
  hasKeyIngredients = false;
  carouselImage = '';
  imageIconList: string[];
  isoCountryCode: string;
  selectedCategoryState: Categories;
  shareUrl: string;
  shareUrlForBots: string;
  productDetailsForBots: ProductDetailsForBots;
  showFavMessage = false;
  categories: Categories[] = [];
  catalogs: Categories[];
  products = [];
  imageActiveIndex = 0;
  showMore = false;
  readyUrl = false;
  imageUrlForPinterest: string;
  descriptionForPinterest = '';
  readMoreContent = 1200;
  s3BucketUrl = environment.cdnURL;
  videoSource: string;
  videoSourceTypes: any = VideoSource;
  itemNo: string;
  accessDeviceInfo: any;
  blogCardContent: string;
  isAutoshipEnabled: boolean;
  @ViewChild('autoShownModal') public autoShownModal: AppModalDirective;
  showShareIcon = false;
  shareHovered = false;
  public isModalShown = false;
  isVideoUrl: boolean;
  isEnableWishList: boolean;
  isImageload: boolean;
  displayAddToCartBtn: boolean;
  public thumbsConfig: SwiperConfigInterface = {
    // centeredSlides: true,
    slidesPerView: 3,
    touchRatio: 0.2,
    shortSwipes: false,
    longSwipesRatio: 0.2,
    slideToClickedSlide: true,
    navigation: true,
    breakpoints: {
      1200: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      1199: {
        slidesPerView: 1,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 1,
        spaceBetween: 10
      },
      0: {
        slidesPerView: 1,
        spaceBetween: 10
      }
    }
  };

  public shopImageConfig: SwiperConfigInterface = {
    centeredSlides: false,
    slidesPerView: 1,
    touchRatio: 0.2,
    slideToClickedSlide: true,
    navigation: true
  };
  playerApi: VgAPI;
  translateParams: TranslateParam;

  constructor(
    private route: ActivatedRoute,
    private _router: Router,
    private _productService: ProductService,
    private _cartService: CartService,
    private _commonService: CommonService,
    private _productDetailervice: ProductDetailService,
    private _cacheService: CacheService,
    private _appMessageService: AppMessageService,
    private _configurationService: ConfigurationService,
    private _imageTypeFilterPipe: ImageTypeFilterPipe,
    private _translatePipe: TranslateService,
    private _notificationService: NotificationService,
    private _deviceService: Ng2DeviceService,
    private _productMessageService: ProductMessageService,
    private _location: Location,
    private _dataService: DataShareService,
    private _activeSessionService: ActiveSessionService,
    private meta: Meta,
    private title: Title
  ) { }

  ngOnInit() {
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    document.getElementById('mainContent').focus();
    this.getDeviceSpecification();
    this.getStoreData();
    this.userLoggedIn = this._cacheService.get(CacheKey.UserInfo);
    this.languageCode = this._commonService.getLanguageCode();
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.route.params.subscribe(params => {
      this.productSlug = params['productslug'];
      this.isImageload = false;
      this.getProductDetailBySlug(this.productSlug);
      this.selectedCategoryState = this._cacheService.get(CacheKey.SelectedCategoryState);
      this.getCategoriesAndCatalogsFromStorage();
    });
    this.getWishListSubject();
    this.selectedCategoryState = this._cacheService.get(CacheKey.SelectedCategoryState);
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.getCategoriesAndCatalogsSubject();
    this.removeQueryParamFromCurrentUrl();
    this._commonService.scrollTo('mainContent', 0);
    this.getAutoshipCart();
  }

  ngAfterViewInit(): void {
    if (document.getElementById('categorieBreadCrumb')) {
      document.getElementById('categorieBreadCrumb').focus();
    }
  }

  /**
   * @description
   * @date 2018-08-24
   * @memberof ProductDetailComponent
   */
  clearCertificatesAndIngredients(): void {
    const ingredient: Element = document.querySelector('div[data-t-ingredient]');
    const certificate: Element = document.querySelector('div[data-t-certificate]');
    if (certificate) {
      certificate.innerHTML = '';
    }
    if (ingredient) {
      ingredient.innerHTML = '';
    }
    this.hasKeyIngredients = false;
    this.hasIngredients = false;
    this.hasCertificates = false;
    this.ingredientsList = '';
  }

  getIngredientsandcertificatesFromCMS(): void {
    this._commonService.getIngredientsandcertificatesFromCMS()
      .subscribe((response: any) => {
        if (response) {
          let count = 0;
          let keys = 0;
          let certificatecards = 0;
          const ingredient: Element = document.querySelector('div[data-t-ingredient]');
          const certificate: Element = document.querySelector('div[data-t-certificate]');
          let ingredients: any[] = [];
          let certificates: any[] = [];
          this.productDetail.attributes.forEach(attribute => {
            if (attribute.attributeType.toLowerCase() === Attribute.INGREDIENT) {
              ingredients.push(attribute);
            } else if (attribute.attributeType.toLowerCase() === Attribute.CERTIFICATE) {
              certificates.push(attribute);
            }
          });
          ingredients = _.sortBy(ingredients, 'orderBy');
          certificates = _.sortBy(certificates, 'orderBy');
          if (response.ingredients && response.ingredients.length > 0) {
            ingredients.forEach(element => {
              response.ingredients.forEach(ing => {
                if (ing.id === element.productAttributeId) {
                  if (element.keyIngredient.toLowerCase() === 'false') {
                    if (count === 0) {
                      this.ingredientsList = ing.name;
                      this.hasIngredients = true;
                      count++;
                    } else { this.ingredientsList = this.ingredientsList + ', ' + ing.name; }
                  }
                  if (keys < 3) {
                    if (element.keyIngredient.toLowerCase() === 'true') {
                      if (ing.cards.length > 0) {
                        ingredient.insertAdjacentHTML('beforeend', ing.cards[0].cardContent);
                        this.hasKeyIngredients = true;
                        keys++;
                      }
                    }
                  }
                }
              });
            });
          }
          if (response.certificates && response.certificates.length > 0) {
            certificates.forEach(element => {
              response.certificates.forEach(cert => {
                if (certificatecards < 6) {
                  if (cert.id === element.productAttributeId) {
                    if (cert.cards.length > 0) {
                      this.hasCertificates = true;
                      certificate.insertAdjacentHTML('beforeend', cert.cards[0].cardContent);
                      certificatecards++;
                    }
                  }
                }
              });
            });
          }
        }
      }, (error: any) => {
        this.translateParams = this._commonService.handleError(error);
      });
  }

  getDeviceSpecification() {
    this.accessDeviceInfo = this._deviceService.getDeviceInfo();
  }

  /**
  * To show quick view popup
  * @returns void
  */
  showModal(url: string, isVideoUrl: boolean, videoSource?: string): void {
    if (url && url.length > 0 && url.indexOf('http') === -1) {
      if (url.indexOf('//') > -1) {
        this.productUrl = url;
      } else {
        this.productUrl = environment.cdnURL + '/' + url;
      }
    } else {
      this.productUrl = url;
    }
    if (videoSource === this.videoSourceTypes.Youtube) {
      this.productUrl = this.productUrl + '?rel=0&autoplay=0&modestbranding=1&showinfo=0&playsinline=1';
    } else if (videoSource === this.videoSourceTypes.Vimeo) {
      if (this.productUrl.indexOf('?') > -1) {
        this.productUrl = this.productUrl + '&loop=1&autoplay=0';
      } else {
        this.productUrl = this.productUrl + '?loop=1&autoplay=0';
      }
    }
    this.videoSource = videoSource;
    this.isVideoUrl = isVideoUrl;
    this.isModalShown = true;
    this.autoShownModal.show();
  }


  /**
   * @param  {VgAPI} api
   */
  onPlayerReady(api: VgAPI) {
    this.playerApi = api;
  }

  /**
 * @returns void
 */
  onHidden(): void {
    this.autoShownModal.hide();
    this.isModalShown = false;
  }

  hideModal(): void {
    this.autoShownModal.hide();
    this.isModalShown = false;
  }

  /**
 * @returns void
 */
  getCategoriesAndCatalogsSubject(): void {
    this.productCategoriesAndCatalogsSubject = this._appMessageService
      .getCategoriesAndCatalogsSubject().subscribe(res => {
        if (this.categories && this.categories.length === 0) {
          this.getCategoriesAndCatalogsFromStorage();
        }
      });
  }
  /**
   * @returns void
   */
  private getCategoriesAndCatalogsFromStorage(): void {
    const categoriesTree: Categories[] = this._cacheService.get(CacheKey.CategoriesTree);
    if (categoriesTree && categoriesTree.length > 0) {
      this.catalogs = categoriesTree.filter(x => x.isCustomCatalog);
      this.categories = categoriesTree.filter(x => !x.isCustomCatalog);
      if (this.catalogs && this.catalogs.length > 0) {
        this.categories = this.catalogs.concat(this.categories);
      }
      if (!this.selectedCategoryState && this.categories && this.categories.length > 0) {
        this.selectedCategoryState = this.categories[0];
        this._cacheService.set(CacheKey.SelectedCategoryState, this.selectedCategoryState);
      } else if (this.selectedCategoryState && this.selectedCategoryState.productCategoryId
        && this.categories && this.categories.length > 0) {
        this.selectedCategoryState = this.categories
          .find(x => x.productCategoryId === this.selectedCategoryState.productCategoryId
            && (x.isCustomCatalog === this.selectedCategoryState.isCustomCatalog));
        this._cacheService.set(CacheKey.SelectedCategoryState, this.selectedCategoryState);
      }
      if (this.selectedCategoryState) {
        if (this.selectedCategoryState.isCustomCatalog) {
          this.getProductsByCatalogId(this.selectedCategoryState);
        } else {
          this.getProductsByCategoryId(this.selectedCategoryState);
        }
      }
    }
  }

  /**
   * @param  {Categories} category
   * @returns any
   */
  private mapCategory(category: Categories): any {
    return {
      productCategoryId: category.id,
      id: category.id,
      parentCategoryConfigId: null,
      categoryName: category.categoryName,
      storeId: category.storeId
    };
  }

  /**
     * To store the product data for bots
     * @param  {any} slug
     */
  postToBots(): any {
    if (this.productDetail) {
      if (this.productDetail.imageModelList &&
        this.productDetail.imageModelList.length > 0) {
        const imageModel = this.productDetail.imageModelList.filter(z => z.type === ImageType.ZoomedImage)[0];
        if (imageModel && imageModel.details && imageModel.details.length > 0) {
          this.imageUrlForPinterest = imageModel.details.find(x => x.type === ImageType.Thumbnail).url;
        }
      }
      if (this.productDetail.shortDescription) {
        this.descriptionForPinterest = this.productDetail.shortDescription.replace(/<[^>]*>/g, '');
      }
      const memberTitleId = this._activeSessionService.getMemberTitleId();
      if (this.userLoggedIn && this.userLoggedIn.distributorId && this.userLoggedIn.memberTypeId === MemberType.DISTRIBUTOR) {
        this.shareUrlForBots = window.location.href + '?purchaseFlowType=' + PurchaseFlow.PERSONAL
          + '&languageCode=' + this.languageCode + '&fboId=' + this.userLoggedIn.distributorId
          + '&memberTitleId=' + memberTitleId + '&storeId=' + this.storeId + '&productId=' + this.productDetail.id
          + '&countryCode=' + this.isoCountryCode + '&isBots=' + true;
      } else {
        this.shareUrlForBots = window.location.href + '?purchaseFlowType=' + PurchaseFlow.PERSONAL
          + '&languageCode=' + this.languageCode + '&memberTitleId=' + memberTitleId + '&storeId='
          + this.storeId + '&productId=' + this.productDetail.id
          + '&countryCode=' + this.isoCountryCode + '&isBots=' + true;
      }
      this.shareUrl = this.shareUrlForBots;
    }
  }

  swiperIndexChange(i: any) {
    this.imageActiveIndex = i;
  }
  @HostListener('document:click') shareOutsideClick() {
    if (this.showShareIcon) {
      this.showShareIcon = false;
    }
  }

  toggleShareIcon(event: any): void {
    this.showShareIcon = !this.showShareIcon;
    event.stopPropagation();
  }

  hoverShareIcon(isOpen: boolean): void {
    if (this._commonService.isMobileDevice()) {
      return;
    } else {
      if (!isOpen) {
        setTimeout(() => {
          this.showShareIcon = this.shareHovered ? true : false;
        }, 500);
        this.shareHovered = false;
      } else {
        this.showShareIcon = isOpen;
        this.shareHovered = true;
      }
    }
  }
  /**
  * redirect to sso login url
  * @param  {boolean} isLogin
  * @param  {boolean} reviewPrompt
  * @returns void
  */
  gotoLogin(isLogin: boolean, reviewPrompt?: boolean): void {
    if (reviewPrompt) {
      this.writeReview('');
      this._cacheService.setCookieValue(CacheKey.WriteReview, 'true');
      this._appMessageService.setNotifyLoginStatus(isLogin);
    } else {
      this._cacheService.set(CacheKey.AddToFavoritesProduct, this.productDetail.id);
      this._appMessageService.setNotifyLoginStatus(isLogin);
    }
  }

  /**
   * Load Products By catalog Id
   * @param  {number} catalogId
   * @param  {number} pageSize?
   * @param  {boolean} isSort?
   * @returns void
   */
  getProductsByCatalogId(catalog: any): void {
    const catalogId = catalog.productCategoryId;
    const pageNumber = 1;
    const pageSize = 20;
    if (this.storeId && catalogId) {
      this._productService.getProductsByCatalogId(this.storeId, catalogId, this.languageCode, pageSize, pageNumber, 'FEATURED')
        .subscribe((products: any) => {
          if (products.body) {
            this.products = products.body;
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }

  /**
  * get all Products based on category on (mouseover|click)
  * @param  {any} category
  * @param  {boolean} isLoadCategoryProducts?
  * @returns void
  */
  getProductsByCategoryId(category: Categories, isLoadCategoryProducts?: boolean): void {
    const categoryId = category.productCategoryId || category.id;
    const pageNumber = 1;
    const pageSize = 20;
    if (this.storeId) {
      // load catalog products when hover
      if (category.isCustomCatalog) {
        this._productService
          .getProductsByCatalogId(this.storeId, categoryId, this.languageCode, pageSize, pageNumber, '')
          .subscribe((response: any) => {
            this.products = [];
            if (response.body && response.body.length > 0) {
              this.products = response.body;
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      } else {
        // load category products when hover
        this._productService
          .getProductByCategoryId(categoryId, this.storeId, this.languageCode, pageSize, pageNumber, '')
          .subscribe((response: any) => {
            this.products = [];
            if (response.body && response.body.length > 0) {
              this.products = response.body;
            }
          }, (error: any) => {
            this.translateParams = this._commonService.handleError(error);
          });
      }
    }
  }


  navigateToProductCategory(category: Categories): void {
    this._cacheService.set(CacheKey.SelectedCategoryState, category);
    if (category.slug) {
      this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/' + category.slug]);
    } else {
      this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products']);
    }
  }

  navigateToProduct(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = product.categories[0];
    }
    if (selectedCategory && selectedCategory.slug) {
      this._router.navigate
        (['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' +
          selectedCategory.slug + '/' + product.slug]);
    } else {
      this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() +
        '/products/' + product.slug]);
    }
  }

  /**
   * Get all the products.
   * @param  {number} productid
   * @returns void
   */
  getProductDetailBySlug(productSlug: string): void {
    this.showProductReview = false;
    this.showProductAssociation = false;
    // to recreate the swiper carousel
    if (this.productDetail) {
      this.productDetail.imageModelList = [];
      this.thumbsConfig.navigation = false;
      this.imageActiveIndex = 0;
    }
    if (this.storeId) {
      this._productDetailervice
        .getProductDetailBySlug(productSlug, this.storeId, this.languageCode)
        .subscribe((response: any) => {
          if (response) {
            // temp logic
            this.readMoreContent = 1200;
            this.productDetail = response.filter((product: any) => product.slug === productSlug)[0];
            if (this.productDetail) {
              this.productDetail.commissionableVolume = !this.productDetail.literature ? this.productDetail.commissionableVolume : 0;
              // Free Product check
              if (this.productDetail.productMetaData) {
                const freeProduct = this.productDetail.productMetaData.find(x => x.metaTitle === ProductMetatDataValue.FREE_PRODUCT_ELIGIBLE);
                if (freeProduct) {
                  this.productDetail.display.freeProduct = freeProduct.metaKeyWords === '1';
                }
              }
            }
            this.clearCertificatesAndIngredients();
            if (this.productDetail.attributes && this.productDetail.attributes.length > 0) {
              this.getIngredientsandcertificatesFromCMS();
            }
            // Will be removed once videoSource is added in Service
            for (let i = 0; i < this.productDetail.imageModelList.length; i++) {
              if (this.productDetail.imageModelList[i].url.indexOf('youtube') > -1) {
                this.productDetail.imageModelList[i].videoSource = this.videoSourceTypes.Youtube;
              } else if (this.productDetail.imageModelList[i].url.indexOf('vimeo') > -1) {
                this.productDetail.imageModelList[i].videoSource = this.videoSourceTypes.Vimeo;
              } else {
                this.productDetail.imageModelList[i].videoSource = this.videoSourceTypes.MediaCloud;
              }
            }
            if (response[0] && response[0].meta) {
              const metaTitle = response[0].meta.title || MetaTagConstants.metaTitle;
              const description = response[0].meta.description || MetaTagConstants.metaDescription;
              this.title.setTitle(metaTitle);
              this.meta.updateTag({ name: 'description', content: description });
            }
            // getting product cards content
            this.getCardsContentByProduct(this.productDetail.itemNumber);
            if (!this.productDetail) {
              this.productDetail = response[0];
            }
            if (!(this.productDetail.backOrderAllowed || (this.productDetail.manageStock && this.productDetail.stockQuantity > 0))) {
              this.quantity = 0;
            } else {
              this.quantity = 1;
            }
            if ((!this.selectedCategoryState || (this.selectedCategoryState && !this.selectedCategoryState.categoryName)
              || (this.selectedCategoryState && this.selectedCategoryState.id && this.productDetail.categories
                && this.productDetail.categories.length > 0 && this.selectedCategoryState.id !== this.productDetail.categories[0].id))
              && this.productDetail.categories && this.productDetail.categories.length > 0) {
              this.selectedCategoryState = this.mapCategory(this.productDetail.categories[0]);
              this.getCategoriesAndCatalogsFromStorage();
            }
            this.imageIconList = this._imageTypeFilterPipe.transform(this.productDetail.imageModelList, ImageType.Thumbnail, ImageType.Video);
            if (this.imageIconList && this.imageIconList.length > 0) {
              if (this.imageIconList.length > 3) {
                this.thumbsConfig.navigation = true;
              }
            }
            this.productId = this.productDetail.productTypeMasterId === ProductType.Variable ?
              +this.productDetail.optionCombinationValues[0].productId : this.productDetail.id;
            this.disableDecrement = this.productDetail.productQuantity === 1 ? false : true;
            // Free Product check
            if (!this.productDetail.display.freeProduct) {
              this.addProductToRecentlyViewed();
              this.addToRecentlyViewedProducts(this.productDetail);
            }
            this.productItemNumber = this.productDetail.itemNumber;
            this.productDetail.noOfReviews = this.productDetail.noOfReviews ? this.productDetail.noOfReviews : 0;
            this.productName = this.productDetail.name;
            this.productName = this.productDetail.displayName;
            this.updateReviewCount();
            if (this.productDetail.options && this.productDetail.options.length > 0
              && ProductType.Variable === this.productDetail.productTypeMasterId) {
              this.showProductReview = false;
              this.displayAddToCartBtn = false;
              this.options = this.productDetail.options.filter(
                x => x.name != null && x.productOptionValueMasterId != null
              );
              this.productDetail.options[0].isPrimary = true;
              this.productDetail.options[0].selected = this._dataService.variableProductOption
                || this.productDetail.options[0].values[0].name;
              this._dataService.variableProductOption = '';
              this.optionsChange(this.productDetail, this.productDetail.options[0].selected, this.options[0], true);
            } else {
              this.showProductReview = true;
              this.displayAddToCartBtn = true;
            }
            this.postToBots();
            this.loadWishListProducts();
            if (ProductType.Variable === this.productDetail.productTypeMasterId) {
              this.showOptions = true;
            } else { this.showOptions = false; }
            this.showProductReview = true;
            this.showProductAssociation = true;
            if (this.loadWishListToMember) {
              this.addProductToWishlistAfterLogin();
            }
          } else {
            // need to show 404
            this._router.navigate(['/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/notfound']);
          }
          this.isImageload = true;
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }


  /**
   * This method used for Getting product card content
   * getCardsContentByProduct
   * @param {string} itemNo
   * @memberof ProductDetailComponent
   */
  getCardsContentByProduct(itemNo: string): void {
    this._productService.getCardsContentByProduct(itemNo)
      .subscribe((response: CardContent) => {
        if (response && response.cards && response.cards.length > 0) {
          this.blogCardContent = null;
          let blogCards: Card[] = response.cards.filter((item) => {
            if (item.type && item.type.toLowerCase() === CardType.Blog.toLowerCase()) {
              return item;
            }
          });
          if (blogCards && blogCards.length > 0 && blogCards[0].cardContent) {
            blogCards = _.orderBy(blogCards, ['sortOrder'], ['asc']);
            this.blogCardContent = blogCards[0].cardContent;
          }
        }
      });
  }
  /**
   * @description Add Product to recently viewed section
   * @date 2018-08-14
   * @param {Product} product
   * @memberof ProductDetailComponent
   */
  addProductToRecentlyViewed(): void {
    const recentViewProdId = {
      productId: this.productDetail.id, category: this.selectedCategoryState
    };
    const storedRecentViewProductIds = this._cacheService.get(CacheKey.RecentlyViewedProductsIds);
    if (storedRecentViewProductIds) {
      if (storedRecentViewProductIds.map(x => x.productId).indexOf(this.productDetail.id) === -1) {
        storedRecentViewProductIds.push(recentViewProdId);
        this._cacheService.set(CacheKey.RecentlyViewedProductsIds, storedRecentViewProductIds);
      }
    } else {
      const recentViewProductIdsArray = [];
      recentViewProductIdsArray.push(recentViewProdId);
      this._cacheService.set(CacheKey.RecentlyViewedProductsIds, recentViewProductIdsArray);
    }
  }

  /**
 * verifying whether the product is shippable to the selected shipping address or not
 * @returns Address
 */
  getShippingRestrictedProducts(): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (this.productDetail && this.productDetail.itemNumber && userDefaultAddressDetails) {
      this._commonService.getShippingRestrictedProducts(this.productDetail.itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            this._notificationService.createNotification('', response.productModels[0].errorDescription, NotificationType.ERROR);
          }
        });
    }
  }

  /*
    * @returns void
    */
  private addProductToWishlistAfterLogin(): void {
    const addToFavProdId = this._cacheService.get(CacheKey.AddToFavoritesProduct);
    if (this.userLoggedIn && this.productDetail && addToFavProdId
      && addToFavProdId === this.productDetail.id) {
      this._cacheService.remove(CacheKey.AddToFavoritesProduct);
      this.productDetail.wishListItem = false;
      this.addToWishList(this.productDetail);
      if (this.loadWishListToMember) {
        this.loadWishListToMember = false;
      }
    } else if (!this.productDetail) {
      this.loadWishListToMember = true;
    }
  }

  /**
   * for updating review count
   * @returns void
   */
  private updateReviewCount(): void {
    this._translatePipe.get('productreviews.Reviews').subscribe(res => {
      this.reviewTranslated = res;
      this.prodReviewCount = (this.reviewTranslated || 'Reviews') + ' (' + this.productDetail.noOfReviews + ')';
    });
  }

  /**
 * navigate back to shop
 * @returns void
 */
  continueShopping(): void {
    this._router.navigateByUrl('/' + this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products');
  }

  /**
   * @param  {any} childImage
   * @returns void
   */
  public findParentImageUrl(childImage: ChildImage): void {
    if (childImage) {
      const parentImage: ImageModel = this.productDetail.imageModelList.find(x => x.id === childImage.parentId);
      if (parentImage.url && parentImage.url.length > 0 && parentImage.url.indexOf('http') === -1) {
        this.carouselImage = environment.cdnURL + '/' + parentImage.url;
      } else {
        this.carouselImage = parentImage.url;
      }
    }
  }

  /**
    * To add an item
    * @param  {Product} product
    * @param  {number} quantity
    */
  addToQuickOrderList(product: Product): void {
    const itemAddedNotification: any = this._translatePipe.get('quickview.Item added to Quick Order List');
    if (this.quantity > 0) {
      product.productQuantity = this.quantity;
      const item: Item = this._cartService.convertProductToItemMappper(product);
      let quickOrderList: Cart = this._cacheService.get(CacheKey.QuickOrderList);
      if (quickOrderList && quickOrderList.items && quickOrderList.items.length > 0) {
        const cartItem: Item = quickOrderList.items.find(x => x.productId === product.id);
        if (cartItem) {
          item.quantity = cartItem.quantity + item.quantity;
        }
        const mergeCartSession: Cart = JSON.parse(JSON.stringify(quickOrderList));
        quickOrderList.items = _.remove(quickOrderList.items, function (n) {
          return n.productId !== product.id;
        });
        this._cartService
          .updateCart([item], CartTypes.QuickOrder, quickOrderList)
          .subscribe((response: Cart) => {
            if (response) {
              this._commonService.createNotification('', itemAddedNotification.value, 'success');
              quickOrderList = this._cartService.mergeCartSession(item, response, mergeCartSession);
              this._cacheService.set(CacheKey.QuickOrderList, quickOrderList);
            }
          });
      } else {
        this._cartService
          .saveCart([item], CartTypes.QuickOrder)
          .subscribe((response: Cart) => {
            if (response) {
              this._commonService.createNotification('', itemAddedNotification.value, 'success');
              quickOrderList = this._cartService.mergeCartSession(item, response, quickOrderList);
              this._cacheService.set(CacheKey.QuickOrderList, quickOrderList);
            }
          });
      }
    }
  }

  /**
  * save browsedproducts into session
  * @param  {number} productId
  */
  addToRecentlyViewedProducts(product: Product): void {
    product.productQuantity = 1;
    let cartItem;
    const recentlyViewedProducts: Cart = this._cacheService.get(CacheKey.RecentlyViewedProducts);
    const item: Item = this._cartService.convertProductToItemMappper(product);
    if (recentlyViewedProducts && recentlyViewedProducts.items &&
      recentlyViewedProducts.items.length > 0) {
      cartItem = recentlyViewedProducts.items.find(x => x.productId === product.id);
    }
    if (!cartItem && !recentlyViewedProducts) {
      this._cartService
        .saveCart([item], CartTypes.RecentlyViewed, recentlyViewedProducts)
        .subscribe((res: any) => {
          if (res) {
            this._cartService.reloadRecentlyViewed(res.sessionGuid);
          }
        });
    } else if (!cartItem && this._cacheService.get(CacheKey.RecentlyViewedProducts)) {
      this._cartService
        .updateCart([item], CartTypes.RecentlyViewed, recentlyViewedProducts)
        .subscribe((response: any) => {
          this._cartService.reloadRecentlyViewed(response.sessionGuid);
        });
    }
  }

  /**
   * Increment the product Quantity
   * @returns void
   */
  incrementQuantity(): void {
    if (!this.productDetail.display.freeProduct) {
      this.quantity = +this.quantity + 1;
      const quantityFieldLength = this.quantity ? this.quantity.toString().length : 0;
      this.disableIncrement = false;
      // Condition to check whether quantity has no.of digits more than 3 digits , hence disabling increment
      if (quantityFieldLength > 3) {
        this.disableIncrement = true;
        this.quantity = this.quantity - 1;
        return;
      }
      this.disableDecrement = false;
      if (this.quantity > this.productDetail.stockQuantity && !this.productDetail.backOrderAllowed) {
        this.disableIncrement = true;
        setTimeout(() => {
          this.disableIncrement = false;
        }, 2000);
        this.quantity = this.quantity - 1;
        // show outofstock notification
        this.outofStockNotification();
      }
    }
  }

  outofStockNotification() {
    this._notificationService.createNotification('', 'Available Stock: <span class="helvetica-bold">'
      + this.productDetail.stockQuantity + '</span>', NotificationType.ERROR);
  }
  /**
   * Decrement the product Quantity
   * @returns void
   */
  decrementQuantity(): void {
    if (!this.productDetail.display.freeProduct) {
      if (this.quantity > 1) {
        this.quantity = +this.quantity - 1;
      }
      if (this.quantity === 1) {
        this.disableDecrement = true;
      }
      this.disableIncrement = false;
    }
  }
  /**
   * to update product quantity
   */
  updateQuantity(quantity: string) {
    const qty = parseInt(quantity, 10);
    if (qty > this.productDetail.stockQuantity && !this.productDetail.backOrderAllowed) {
      this.disableIncrement = true;
      setTimeout(() => {
        this.disableIncrement = false;
      }, 2000);
      this.quantity = this.productDetail.stockQuantity;
      this.outofStockNotification();
    } else {
      this.quantity = qty || null;
    }
    this.disableDecrement = this.quantity > 1 ? false : true;
  }

  /**
   * Adding a Single Product to the Cart
   * @param  {Product} product
   * @returns void
   */
  addToCart(product: Product, cartType: number): void {
    if (!product.addingToCart && !product.display.freeProduct) {
      product['productQuantity'] = +this.quantity;
      this.getShippingRestrictedProducts();
      this.manageShoppingCart(product, cartType);
    }
  }

  /**
  * To add an item
  * @param  {Product} product
  */
  addToWishList(product: Product): void {
    if (!this.userLoggedIn) {
      this.showFavMessage = !this.showFavMessage;
      return;
    }
    // quickview.Item added to Wish List
    const itemAddedNotification: any = this._translatePipe.get('Item added to Favorites');
    // quickview.Item removed from Wish List
    const itemDeletedNotification: any = this._translatePipe.get('Item removed from Favorites');
    product.wishListItem = !product.wishListItem ? true : false;
    product.productQuantity = 1;
    const item: Item = this._cartService.convertProductToItemMappper(product);
    let wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (product.wishListItem && wishListCart && wishListCart.items && wishListCart.items.length >= 0 && wishListCart.sessionGuid) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .updateCart([item], CartTypes.WishlistCart, wishListCart)
        .subscribe((response: Cart) => {
          if (response) {
            // this._commonService.createNotification('', itemAddedNotification.value, 'success');
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    } else if (product.wishListItem) {
      this._cartService
        .saveCart([item], CartTypes.WishlistCart)
        .subscribe((response: Cart) => {
          if (response) {
            // this._commonService.createNotification('', itemAddedNotification.value, 'success');
            wishListCart = this._cartService.mergeCartSession(item, response, wishListCart);
            this._cacheService.set(CacheKey.WishListSession, wishListCart);
            this._appMessageService.setWishListItems();
          }
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    } else if (!product.wishListItem) {
      const cartItem: Item = wishListCart.items.find(x => x.productId === product.id);
      wishListCart.items = _.remove(wishListCart.items, function (n) {
        return n.productId !== product.id;
      });
      this._cartService
        .removeCartItem(wishListCart.sessionGuid, cartItem.id)
        .subscribe(response => {
          //    this._commonService.createNotification('', itemDeletedNotification.value, 'success');
          wishListCart = new Cart(wishListCart, this.store);
          this._cacheService.set(CacheKey.WishListSession, wishListCart);
          this._appMessageService.setWishListItems();
        }, (error: any) => {
          this.translateParams = this._commonService.handleError(error);
        });
    }
  }


  /**
   * @returns void
   */
  getWishListSubject(): void {
    this.wishListSubscription = this._appMessageService.getWishListItems().subscribe(response => {
      this.loadWishListProducts();
      this.addProductToWishlistAfterLogin();
    });
  }

  /**
   * load wishlist
   */
  loadWishListProducts(): void {
    const wishListCart: Cart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart && wishListCart.items.length > 0) {
      wishListCart.items.forEach(y => {
        if (y.productId === this.productDetail.id) {
          this.productDetail.wishListItem = true;
        }
      });
    }
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(product: Product, cartType: CartTypes) {
    this.showContinueShopping = true;
    // quickview.Item added to cart
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('Item added to cart');
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    const item: Item = this._cartService.convertProductToItemMappper(product, cartSessionInfo);
    if (cartSessionInfo) {
      const cartItem = cartSessionInfo.items.filter(x => x.productId === item.productId)[0];
      if (cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > product.stockQuantity && product.manageStock && !product.backOrderAllowed) {
          item.quantity = cartItem.quantity;
          this.disableIncrement = true;
          setTimeout(() => {
            this.disableIncrement = false;
          }, 2000);
          this.outofStockNotification();
          return;
        }
      }
    }
    // product is going to add in the cart
    product.addingToCart = true;
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      product.addingToCart = false;
      this._appMessageService.setMiniCart(cartSession);
      this._appMessageService.showMiniCartView(product.id);
      this._commonService.focusTargetElement('minicart-shop-msg');
    } else if (cartSessionInfo) {
      // cartSessionInfo.items = _.remove(cartSessionInfo.items, function (n) {
      //   return n.productId !== product.id;
      // });
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          // this._commonService.createNotification('', itemAddedNotification.value, NotificationTypes.success);
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: any) => {
        product.addingToCart = false;
        if (response) {
          // this._commonService.createNotification('', itemAddedNotification.value, NotificationTypes.success);
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(product.id);
          this._commonService.focusTargetElement('minicart-shop-msg');
        }
      }, (error) => {
        product.addingToCart = false;
        this.translateParams = this._commonService.handleError(error);
      });
    }
  }

  /**
   * @param  {string} optType
   * @param  {string} optValue
   */
  optionsChange(productDetail: Product, optValue: string, option: Options, defaultValue: boolean): void {
    this.selectedFilter.selectedOption = option.productOptionValueMasterId;
    this.selectedFilter.selectedValue = optValue;
    let selectedProd: any = [];
    this._commonService.scrollByValue(0, 0, 0);
    const oneOption = this.options.filter(x => x.productOptionValueMasterId !== option.productOptionValueMasterId);
    if (oneOption && oneOption.length > 0) {
      this.options.filter(x => x.productOptionValueMasterId !== option.productOptionValueMasterId).forEach(x => {
        x.selected = '';
        x.values.forEach(val => {
          if (selectedProd && selectedProd.length === 0) {
            selectedProd = productDetail.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue
              && z[x.name] === val.name);
            selectedProd = selectedProd && selectedProd.length === 0 && (!val.hide) ? selectedProd : selectedProd;
          }
          if (defaultValue) {
            val.hide = true;
          } else {
            val.hide = productDetail.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue
              && z[x.name] === val.name).length <= 0;
            x.selected = x.selected.length === 0 && (!val.hide) ? val.name : x.selected;
          }
        });
      });
    } else {
      selectedProd = productDetail.optionCombinationValues.filter(z => z['' + option.name] === this.selectedFilter.selectedValue);
    }
    if (selectedProd && selectedProd[0]) {
      this.getProductByOptions(selectedProd[0].productId);
    } else {
      this.displayAddToCartBtn = true;
    }
  }

  /**
   * Get Products by options selections
   * @param  {number} productId
   */
  getProductByOptions(productId: number): void {
    this.showProductReview = false;
    this.showProductAssociation = false;
    this._productDetailervice
      .getProductDetailById(productId, this.storeId, this.languageCode)
      .subscribe((response: Product[]) => {
        if (response) {
          const prodDetail = response[0];
          prodDetail.optionCombinationValues = this.productDetail.optionCombinationValues;
          prodDetail.options = this.productDetail.options;
          prodDetail.parentProductSlug = this.productDetail.parentProductSlug || this.productDetail.slug;
          prodDetail.selectedOption = this.selectedFilter.selectedValue;
          if (response[0] && response[0].meta) {
            const metaTitle = response[0].meta.title || MetaTagConstants.metaTitle;
            const description = response[0].meta.description || MetaTagConstants.metaDescription;
            this.title.setTitle(metaTitle);
            this.meta.updateTag({ name: 'description', content: description });
          }
          this.showProductReview = true;
          this.showProductAssociation = true;
          this.displayAddToCartBtn = true;
          this.productDetail = prodDetail;
          this.productId = this.productDetail.id;
          if ((!this.selectedCategoryState || (this.selectedCategoryState && !this.selectedCategoryState.categoryName)
            || (this.selectedCategoryState && this.selectedCategoryState.id && this.productDetail.categories
              && this.productDetail.categories.length > 0 && this.selectedCategoryState.id !== this.productDetail.categories[0].id))
            && this.productDetail.categories && this.productDetail.categories.length > 0) {
            this.selectedCategoryState = this.mapCategory(this.productDetail.categories[0]);
            this.getCategoriesAndCatalogsFromStorage();
          }
          this.filterParentImage();
          this.updateReviewCount();
          this.addProductToWishlistAfterLogin();
          this.loadWishListProducts();
        }
      }, (error: any) => {
        this.displayAddToCartBtn = true;
        this.translateParams = this._commonService.handleError(error);
      });
  }

  /**
 * find parent image of product
 * @returns void
 */
  private filterParentImage(): void {
    if (this.productDetail.imageModelList && this.productDetail.imageModelList.length > 0) {
      this.imageIconList = this._imageTypeFilterPipe.transform(this.productDetail.imageModelList, ImageType.Thumbnail, ImageType.Video);
    }
  }

  /**
 * Discount price Calculation for Price
 * @param  {number} price
 * @param  {number} discount
 */
  discountPriceCalc(retailPrice: number, applicablePrice: number) {
    return this._productService.discountPriceCalc(retailPrice, applicablePrice);
  }

  /**
   * navigate back to shop by category id
   * @returns void
   */
  navigateBackToShopByCategory(removeCategoryState: boolean): void {
    if (removeCategoryState) {
      this._cacheService.remove(CacheKey.SelectedCategoryState);
    }
    if (this.productDetail && this.productDetail.categories[0]) {
      this._router.navigate(['/' + this.isoCountryCode + '/' + 'shop']);
    }
  }


  gotoReview(): void {
    window.scroll(0, (this.elementPosition(document.getElementById('reviewBlock')) - 104));
  }

  gotoSection(elementId: string): void {
    this._commonService.scrollTo(elementId, 1000);
  }

  gotoAttibuteSection(attributeName: string, index: number): void {

    this.gotoSection(attributeName + index);
  }
  elementPosition(element: any) {
    let curtop = 0;
    if (element.offsetParent) {
      do {
        curtop += element.offsetTop;
      } while (element = element.offsetParent);
      return curtop;
    }
  }

  /**
   * store
   * @returns void
   */
  getStoreData(): void {
    const storeConfig: StoreConfig = this._configurationService.getStoreData();
    if (storeConfig) {
      this.store = storeConfig;
      this.storeId = this.store.id;
      this.isEnableWishList = this.store.enableWishlist;
      this.purchaseFlows = storeConfig.purchaseFlows;
      this.hasPurchaseFlow();
    }
  }

  /**
   * @description
   * @date 2018-11-05
   * @memberof ProductDetailComponent
   */
  hasPurchaseFlow(): void {
    if (this.purchaseFlows && this.purchaseFlows.length > 0 && (this.store.purchaseFlows !== null && this.store.purchaseFlows.length > 0)) {
      this.purchaseFlows.forEach(flow => {
        this.store.purchaseFlows.forEach((storeFlow: any) => {
          if (flow.id === storeFlow.id && flow.name === this.personalPurchaseFlow) {
            this.isPersonalPurchaseFlow = true;
          }
        });
      });
    }
  }

  /**
   * show long description with read more / read less option
   */
  showDetailedDescription() {
    this.gotoSection('longDescription');
    if (this.readMoreContent === 1200) {
      this.resizeBlock('longDescription', '#product-description-readmore');
    }
  }

  /** resize the review block section height
    * {param} index
   */
  resizeBlock(attributeName: string, subAttributeName: string) {
    const reviewBlckEl = <HTMLElement>document.getElementById(attributeName);
    const element = document.getElementById('product-detail-long-descption');
    if (element) {
      element.focus();
      event.preventDefault();
    }
    if (reviewBlckEl) {
      const prodEllipsisVal = this.readMoreContent;
      const descEl = <HTMLElement>reviewBlckEl.querySelector(subAttributeName);
      if (prodEllipsisVal === 1200) {
        reviewBlckEl.style.height = 'auto';
        descEl.style.height = 'auto';
        this.readMoreContent = this.productDetail.longDescription.length + 2;
        reviewBlckEl.style.paddingBottom = '2.3rem !important';
      } else {
        //  reviewBlckEl.style.height = '500px';
        descEl.style.height = '1200px';
        this.readMoreContent = 1200;
        reviewBlckEl.style.paddingBottom = '1.5rem !important';
      }
    }
  }
  /**
   * ADA -- Move focus to product detail descrption
   * @param  {any} event
   */
  onFocusOutReview(event: any): void {
    const element = document.getElementById('product-detail-description');
    const readMoreElement: any = document.querySelector('.scroll-links #read-more');
    const keyIncredientsElement: any = document.querySelector('.scroll-links #product-key-incredients');
    if (element) {
      element.focus();
      event.preventDefault();
    } else if (readMoreElement) {
      readMoreElement.focus();
      event.preventDefault();
    } else if (keyIncredientsElement) {
      keyIncredientsElement.focus();
      event.preventDefault();
    }
  }
  /**ADA -- On focus product description
   * @param  {any} event
   */
  onFocusProductDescription(event: any): void {
    const element = document.getElementById('product-detail-reviews');
    if (element) {
      element.focus();
      event.preventDefault();
    }
  }


  /** ADA -- Focus element to product long description
   * @param  {any} event
   */
  onTabReadMore(event: any): void {
    const element = document.getElementById('product-detail-long-descption');
    if (element) {
      element.focus();
      event.preventDefault();
    }
  }

  /**
   * @description get product review details when user
   * modify the review info
   * @date 2018-10-23
   * @param {ReviewCount} re
   * @memberof ProductDetailComponent
   */
  getProductReviewCount(reviewInfo: ReviewCount): void {
    if (this.productDetail && reviewInfo) {
      this.productDetail.noOfReviews = reviewInfo.reviewCount;
      this.productDetail.overAllRating = reviewInfo.overAllRating;
    }
  }

  /**
   * set review form open
   */
  writeReview(elementId) {
    this._productMessageService.setWriteReviewSubject(true);
  }

  /**
  * Removes the Query Parameters from URL
  */
  removeQueryParamFromCurrentUrl(): void {
    if (window.location.href.indexOf('?') > -1) {
      this._location.replaceState(window.location.pathname);
    }
  }

  /**
   * @description
   * @date 2018-10-03
   * @param {string} route
   * @memberof ProductComponent
   */
  navigateToPortal(route: string): void {
    if (route) {
      window.location.href = route;
    }
  }

  /**
   * @description get Autoship Cart Details
   * @date 2018-11-01
   * @memberof ProductDetailComponent
   */
  getAutoshipCart(): void {
    const autoshipCart: Autoship = this._cacheService.get(CacheKey.AutoshipCart);
    if (this.isAutoshipEnabled && autoshipCart) {
      this._appMessageService.setMiniCart(autoshipCart);
    }
  }

  ngOnDestroy(): void {
    // unsubscribe to avoid memory leaks
    if (this.wishListSubscription) {
      this.wishListSubscription.unsubscribe();
    }
    if (this.productCategoriesAndCatalogsSubject) {
      this.productCategoriesAndCatalogsSubject.unsubscribe();
    }
  }
}
