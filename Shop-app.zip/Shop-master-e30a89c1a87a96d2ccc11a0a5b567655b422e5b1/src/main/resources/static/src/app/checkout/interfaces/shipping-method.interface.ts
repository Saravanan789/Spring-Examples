import { PickupLoaction } from './pickup-location.interface';

export interface ShippingMethod {
    importFeeEnabled: boolean;
    shippingMethodId: number;
    shippingCarrier: string;
    shippingMethod: string;
    shippingMethodDisplayName: string;
    shippingCharge: number;
    dbZId: number;
    shippingPaymentMethodIds: any;
    shippingChargeForPaymentMethods: any;
    estimatedDelivery: string;
    shipmethodDescription: string;
    shortCode: string;
    fuelAmountSurcharge: number;
    fuelPercentSurcharge: number;
    shippingThresholdValue1: number;
    shippingThresholdValue2: number;
    importFeeValue: number;
    pickUpLocation: PickupLoaction;
    calculateFuelAndSurcharge: boolean;
    default: boolean;
    maximumEstimatedDays?: number;
    minimumEstimatedDays?: number;
    distributionCenterName?: string;
}
