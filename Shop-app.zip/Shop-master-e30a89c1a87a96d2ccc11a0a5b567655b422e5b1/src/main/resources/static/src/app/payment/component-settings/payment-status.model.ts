import { BaseSettings } from '../../common/component-settings';
import { PaymentStatus } from '../enums';
import { CheckoutInformation } from '../../checkout/interfaces';

export class PaymentStatusComponentSettings extends BaseSettings {
    paymentProcessor: string;
    paymentStatus: PaymentStatus;
    checkoutId: string;
    checkoutInformation: CheckoutInformation;
}
