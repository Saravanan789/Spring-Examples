import { AppMessageService } from './app-message.service';
import { NgModule } from '@angular/core';
import { BrowserXhr } from '@angular/http';

import { AppService } from './app.service';
import { AppComponent } from './app.component';
import { AppModuleConstants } from './app-module.constants';
import { RouteReuseStrategy } from '@angular/router';
import { AppRouteReuseStrategy } from './app-route-reuse.strategy';

@NgModule({
    imports: AppModuleConstants.MODULE_IMPORTS,
    declarations: AppModuleConstants.MODULE_DECLARATIONS,
    providers: [AppService, AppMessageService,
        {provide: RouteReuseStrategy, useClass: AppRouteReuseStrategy}
    ],
    bootstrap: [AppComponent]
})
export class AppModule {

}
