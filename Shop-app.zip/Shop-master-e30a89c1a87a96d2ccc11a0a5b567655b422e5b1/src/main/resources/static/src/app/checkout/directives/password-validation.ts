import { AbstractControl } from '@angular/forms';
export class PasswordValidation {

    static MatchPassword(AC: AbstractControl): any {
        AC.get('confirmPassword').setErrors(null);
        const password = AC.get('pass_word').value;
        const confirmPassword = AC.get('confirmPassword').value;
        if (!confirmPassword) {
            AC.get('confirmPassword').setErrors({ required: true });
        }
        if (confirmPassword && password !== confirmPassword) {
            AC.get('confirmPassword').setErrors({ MatchPassword: true });
        }
    }
}
