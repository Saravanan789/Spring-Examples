import { Component, OnInit, ElementRef, Input, ViewChild, Output, EventEmitter, OnDestroy } from '@angular/core';
import { GuestPersonalInfoComponentSettings } from '../component-settings';
import { MemberType } from '../../shared/enums';
import { CacheService, ConfigurationService, CommonService } from '../../shared/services';
import { FormBuilder, Validators } from '@angular/forms';
import { CheckoutMessageService, EnrollService } from '../services';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import {
    ControlsConfig, CheckoutInformation,
    VerifyAccountResponse, PersonalInformation, CountryLevelValidations
} from '../interfaces';
import { StoreConfig } from '../../shared/interfaces';
import { PersonalInfoFormConstants, ResponseStatus } from '../constants';
import { MaskPipe } from 'ngx-mask';
import { ContactTypeValue } from '../enums';
/**
 * @description  Used to Save Enroll
 * User Information and Edit User information
 * @date 2018-07-24
 * @export
 * @class GuestPersonalInfoComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-guest-personalinfo',
    templateUrl: '../templates/template3/views/guest-personal-info.component.html',
    styleUrls: ['../templates/template3/themes/default/less/guest-personal-info.component.less']
})

export class GuestPersonalInfoComponent implements OnInit, OnDestroy {
    gpiComponentSettings: GuestPersonalInfoComponentSettings = new GuestPersonalInfoComponentSettings();
    // Input varibles
    // tslint:disable-next-line:no-input-rename
    @Input('registerMemberType') registerMemberType: MemberType;

    @Output() guestPersonalInfo = new EventEmitter<any>();

    @Output() verifyEmailAccountStatus = new EventEmitter<boolean>();

    // ViewChild Attrbutes
    @ViewChild('personalInfoFormBtn') personalInfoFormBtn: ElementRef;

    constructor(
        private _cacheService: CacheService,
        private _formBuilder: FormBuilder,
        private _enrollService: EnrollService,
        private _configurationService: ConfigurationService,
        private _checkoutMessageService: CheckoutMessageService,
        private _commonService: CommonService,
        private _maskPipe: MaskPipe
    ) {
    }

    ngOnInit() {
        this.loadDefaultSettings();
    }

    /**
    * @description it used to load default configuration
    * of the current component based on user
    * @date 2018-07-19
    * @private
    * @memberof GuestPersonalInfoComponent
    */
    private loadDefaultSettings(): void {
        this.gpiComponentSettings.memberType = MemberType;
        this.registerMemberType = this.registerMemberType ? this.registerMemberType : MemberType.RETAILCUSTOMER;
        this.gpiComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.gpiComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.getStoreData();
        this.getFormValidationsJSON();
    }

    /**
     * @description Get json form validations
     * @date 2018-11-06
     * @memberof GuestPersonalInfoComponent
     */
    getFormValidationsJSON(): void {
        this._commonService.getFormValidationsJSON()
            .subscribe((response: any) => {
                this.getCountrySpecificValidations(response);
                this.createGuestPersonalInfoForm();
            });
    }


    /**
     * @description Get country specific validations
     * @date 2018-11-06
     * @param {CountryLevelValidations[]} validations
     * @memberof GuestPersonalInfoComponent
     */
    getCountrySpecificValidations(validations: CountryLevelValidations[]): void {
        if (validations) {
            const filterCountryLevlValidations = validations
                .find(x => x.countryCode === this.gpiComponentSettings.isoCountryCode.toUpperCase());
            this.gpiComponentSettings.personalInfoFormFields = filterCountryLevlValidations.validations;
        }

    }

    /**
     * @description this method retives
     * store information from cache service
     * @date 2018-07-19
     * @memberof GuestPersonalInfoComponent
     */
    private getStoreData(): void {
        this.gpiComponentSettings.phoneNumberFormat =
            this._commonService.getPhoneNumberFormatByCountryCode(this.gpiComponentSettings.isoCountryCode);
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.gpiComponentSettings.store = result;
        }
    }

    /**
     * @description creating a form for
     * user information
     * @date 2018-07-19
     * @memberof GuestPersonalInfoComponent
     */
    private createGuestPersonalInfoForm(): void {
        this.gpiComponentSettings.guestPersonalInformationForm = this._formBuilder.group(
            this.addFieldsBasedOnRetailOrGuest()
        );
        this.subscribeGuestPersonalInfoFormChanges();
        this.rebindGuestPersonalInformation();
        this.guestPersonalInfoSubject();

    }

    /**
     * @description this method used
     * subscribe changes of form submit
     * event
     * @date 2018-07-24
     * @private
     * @memberof GuestPersonalInfoComponent
     */
    private guestPersonalInfoSubject(): void {
        this.gpiComponentSettings.guestPersonalInfoSubscription = this
            ._checkoutMessageService.getSubmitGuestForm().subscribe(isSubmit => {
                this.submitGuestPersonalInfo();
            });
    }


    /**
     * this function allows to add controle to
     * peersonal information form based on retail or guest
     * @description
     * @date 2018-07-19
     * @returns {ControlsConfig}
     * @memberof GuestPersonalInfoComponent
     */
    private addFieldsBasedOnRetailOrGuest(): ControlsConfig {
        const formControls: ControlsConfig = {
            firstName: ['', this.getValidations(PersonalInfoFormConstants.FIRSTNAME)],
            lastName: ['', this.getValidations(PersonalInfoFormConstants.LASTNAME)],
            middleName: ['', this.getValidations(PersonalInfoFormConstants.MIDDLENAME)],
            email: ['', this.getValidations(PersonalInfoFormConstants.EMAIL)],
            phoneNumber: ['', this.getValidations(PersonalInfoFormConstants.PHONENUMBER)],
            phoneType: [ContactTypeValue.MOBILE]
        };
        return formControls;
    }

    /**
     * @description this method will subscribe
     * the changes for form
     * @date 2018-07-20
     * @private
     * @memberof GuestPersonalInfoComponent
     */
    private subscribeGuestPersonalInfoFormChanges(): void {
        this.gpiComponentSettings.guestPersonalInformationForm
            .valueChanges.
            subscribe(form => {
                if (this.gpiComponentSettings.guestPersonalInfoFormValidated) {
                    this.gpiComponentSettings.guestPersonalInfoFormValidated = false;
                }
            });
    }

    /**
     * @description validates personal information for usa and canada
     * @param fieldName
     */
    private getValidations(fieldName: string): any[] {
        const fieldValidations = [];
        const formControlName = this.gpiComponentSettings.personalInfoFormFields
            ? this.gpiComponentSettings.personalInfoFormFields[fieldName]
            : {};
        if (formControlName) {
            if (formControlName[PersonalInfoFormConstants.MINLENGTH]) {
                fieldValidations.push(Validators.minLength(formControlName[PersonalInfoFormConstants.MINLENGTH]));
            }
            if (formControlName[PersonalInfoFormConstants.MAXLENGTH]) {
                fieldValidations.push(Validators.maxLength(formControlName[PersonalInfoFormConstants.MAXLENGTH]));
            }
            if (formControlName[PersonalInfoFormConstants.PATTERN]) {
                fieldValidations.push(Validators.pattern(formControlName[PersonalInfoFormConstants.PATTERN]));
            }
        }

        // regular expression which allows only latin characterset including accent marks
        // tslint:disable-next-line:quotemark
        const nameReg = "^[a-zA-Z0-9~`\\!@#\\$%\\^&*\\(\\)_\\+\\-\\=\\{\\}\\|\"\\:<>\\?,/\\\\.\\[\\];'\\s]*$";
        if (fieldName === PersonalInfoFormConstants.MIDDLENAME || fieldName === PersonalInfoFormConstants.FIRSTNAME
            || fieldName === PersonalInfoFormConstants.LASTNAME || fieldName === PersonalInfoFormConstants.EMAIL) {
            if (this.gpiComponentSettings.isoCountryCode.toLowerCase() === 'usa'
                || this.gpiComponentSettings.isoCountryCode.toLowerCase() === 'can') {
                fieldValidations.push(Validators.pattern(nameReg));
            }
        }
        if (fieldName === PersonalInfoFormConstants.FIRSTNAME || fieldName === PersonalInfoFormConstants.LASTNAME
            || fieldName === PersonalInfoFormConstants.EMAIL || fieldName === PersonalInfoFormConstants.PHONENUMBER) {
            fieldValidations.push(Validators.required);
        }
        return fieldValidations;
    }

    /**
     * @description this metod is used
     *  to rebind personal information from local storage
     * @date 2018-07-21
     * @private
     * @memberof GuestPersonalInfoComponent
     */
    private rebindGuestPersonalInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.personalInformation) {
            this.gpiComponentSettings.personalInformation = checkoutInformation.personalInformation;
            if (this.gpiComponentSettings.personalInformation.phoneNumber) {
                this.gpiComponentSettings.personalInformation.phoneNumber = this._maskPipe
                    .transform(this.gpiComponentSettings
                        .personalInformation.phoneNumber, this.gpiComponentSettings.phoneNumberFormat);
            }
            this.gpiComponentSettings.guestPersonalInformationForm.patchValue({
                firstName: this.gpiComponentSettings.personalInformation.firstName,
                middleName: this.gpiComponentSettings.personalInformation.middleName,
                lastName: this.gpiComponentSettings.personalInformation.lastName,
                email: this.gpiComponentSettings.personalInformation.email,
                phoneNumber: this.gpiComponentSettings.personalInformation.phoneNumber,
                phoneType: this.gpiComponentSettings.personalInformation.phoneType
            });
        }
    }

    /**
     * validates emailId
     * @param  {any} emailId
     * @param  {boolean} isValid
     * @returns void
     */
    verifyEmailAccountExists(emailId: string, isValid: boolean): void {
        if (isValid) {
            this.emitVerifyEmailAccountStatus(true);
            this.gpiComponentSettings.userInfo = null;
            this.gpiComponentSettings.isShowLoader = true;
            this._enrollService.verifyEmailAccountExists(emailId)
                .subscribe((verifyAccountResponse: VerifyAccountResponse) => {
                        if (verifyAccountResponse.requestStatus === ResponseStatus.COMPLETED
                            || !verifyAccountResponse.requestStatus) {
                            this.gpiComponentSettings.isShowLoader = false;
                            this.processVerifyEmailAccountExists(verifyAccountResponse);
                        }  else if (verifyAccountResponse.requestStatus === ResponseStatus.QUEUED ||
                            verifyAccountResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
                               this.processEmailCheckPoll(verifyAccountResponse);
                        }
                }, (err: any) => {
                    this.gpiComponentSettings.mailAlreadyExist = false;
                    this.gpiComponentSettings.isShowLoader = false;
                    this.emitVerifyEmailAccountStatus(false);
                });
        }
    }

    /**
     * @description this method will emit the
     * status of verify account email exists or not
     * @date 2018-08-27
     * @memberof GuestPersonalInfoComponent
     */
    emitVerifyEmailAccountStatus(verifyAccountInProgess: boolean): void {
        this.gpiComponentSettings.verifyEmailAccountInProgess = verifyAccountInProgess;
        this.verifyEmailAccountStatus.emit(this.gpiComponentSettings.verifyEmailAccountInProgess);
    }

    /**
     * @description this method process
     * response of VerifyEmailAccountExists Method
     * @date 2018-07-19
     * @memberof GuestPersonalInfoComponent
     */
    private processVerifyEmailAccountExists(verifyAccountResponse: VerifyAccountResponse): void {
        this.gpiComponentSettings.isLegacyUser = false;
        if (verifyAccountResponse) {
            if (verifyAccountResponse.memberTypeId === MemberType.GUESTCUSTOMER) {
                this.gpiComponentSettings.mailAlreadyExist = false;
                this.gpiComponentSettings.guestUser = true;
                this.gpiComponentSettings.userInfo = this._enrollService.mapAccountResponseToUserInfo(verifyAccountResponse);
            } else if (verifyAccountResponse.distributorId && !verifyAccountResponse.memberId) {
                this.gpiComponentSettings.mailAlreadyExist = true;
                this.gpiComponentSettings.isLegacyUser = true;
            } else {
                this.gpiComponentSettings.mailAlreadyExist = true;
            }
            this.emitVerifyEmailAccountStatus(false);
        } else {
            this.gpiComponentSettings.mailAlreadyExist = false;
            this.emitVerifyEmailAccountStatus(false);
        }
    }

    /**
     * @description this method will subscribe changes
     * when we need to submit guest info
     * @date 2018-07-24
     * @memberof GuestPersonalInfoComponent
     */
    submitGuestPersonalInfo(): void {
        // submiting personal information
        if (this.personalInfoFormBtn
            && !this.gpiComponentSettings.guestPersonalInfoFormValidated) {
            this.personalInfoFormBtn.nativeElement.click();
        }
    }

    /**
     * save personal info for user
     * @param  {any} personalInfoForm
     * @param  {boolean} isValid
     * @returns void
     */
    saveGuestPersonalInfo(personalInformation: PersonalInformation, isValid: boolean): void {
        this.gpiComponentSettings.formSubmitted = true;
        if (this.gpiComponentSettings.formSubmitted && isValid
            && !this.gpiComponentSettings.mailAlreadyExist && !this.gpiComponentSettings.isShowLoader) {
            this.gpiComponentSettings.personalInformation = personalInformation;
            this.gpiComponentSettings.guestPersonalInfoFormValidated = true;
            this.saveCheckoutInformation();
        } else {
            this.gpiComponentSettings.guestPersonalInfoFormValidated = false;
        }
        this.gpiComponentSettings.autoPopulate = false;
        // emit component information to parent
        this.guestPersonalInfo.emit(this.gpiComponentSettings);
    }

    /**
     * @description Saving Checkout Information
     * @date 2018-07-20
     * @memberof GuestPersonalInfoComponent
     */
    private saveCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        if (this.gpiComponentSettings.personalInformation) {
            if (this.gpiComponentSettings.personalInformation.phoneNumber) {
                this.gpiComponentSettings.personalInformation.phoneNumber = this.gpiComponentSettings
                    .personalInformation.phoneNumber.replace(/[^a-zA-Z0-9]/g, '');
            } else {
                this.gpiComponentSettings.personalInformation.phoneNumber = null;
            }
        }
        checkoutInformation.personalInformation = this.gpiComponentSettings.personalInformation;
        if (this.gpiComponentSettings.userInfo) {
            checkoutInformation.retuningGuestUser = this.gpiComponentSettings.userInfo;
        }
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
    }


    /**
     * @description this method will navigate user to
     * login page
     * @date 2018-08-01
     * @memberof PersonalInfoComponent
     */
    memberLogin(): void {
        const email = this.gpiComponentSettings.guestPersonalInformationForm.controls['email'];
        if (email && email.value) {
            this._cacheService.setCookieValue(CacheKey.SSO_Username, email.value);
        }
        this._commonService.navigateToLogin(false);
    }

    /**
     * @description this method will be used
     * set auto populate data
     * @date 2018-08-08
     * @memberof PersonalInfoComponent
     */
    autoPopulate(): void {
        this.gpiComponentSettings.autoPopulate = true;
        this.gpiComponentSettings.personalInformation = this._enrollService
            .getAutoPopulateInformation(this.gpiComponentSettings.isoCountryCode.toLowerCase());
        this.saveCheckoutInformation();
        this.rebindGuestPersonalInformation();
        this.guestPersonalInfo.emit(this.gpiComponentSettings);
    }

    /**
* validates emailId
* @param  {any} emailId
* @param  {boolean} isValid
* @returns void
*/
    verifyPhoneNumberAccountExists(phoneNumber: string, isValid: boolean): void {
        if (isValid) {
            this.gpiComponentSettings.userInfo = null;
            this.gpiComponentSettings.isShowPhoneNumberLoader = true;
            this._enrollService.verifyPhoneNumberAccountExists(phoneNumber)
                .subscribe((verifyAccountResponse: boolean) => {
                    this.gpiComponentSettings.isShowPhoneNumberLoader = false;
                    this.gpiComponentSettings.phoneNumberAlreadyExists = verifyAccountResponse;
                }, (err: any) => {
                    this.gpiComponentSettings.isShowPhoneNumberLoader = false;
                    this.gpiComponentSettings.phoneNumberAlreadyExists = false;
                });
        }
    }

      /**
   * @description
   * @date 2018-09-17
   * @memberof PersonalInfoComponent
   */
  processEmailCheckPoll(verifyAccountResponse: VerifyAccountResponse) {
    if (this.gpiComponentSettings.intialPollCount < this.gpiComponentSettings.maxPollCount) {
    this._enrollService.processPollRequest(verifyAccountResponse.location)
        .subscribe(responseObj => {
            if (responseObj.requestStatus === ResponseStatus.COMPLETED) {
                this.gpiComponentSettings.isShowLoader = false;
                this.processVerifyEmailAccountExists(responseObj);
            } else {
                this.processEmailCheckPoll(responseObj);
            }
        }, errorResponse => {
            this.gpiComponentSettings.mailAlreadyExist = false;
            this.gpiComponentSettings.isShowLoader = false;
            this.emitVerifyEmailAccountStatus(false);
        });
    }
}

    ngOnDestroy(): void {
        if (this.gpiComponentSettings.guestPersonalInfoSubscription) {
            this.gpiComponentSettings.guestPersonalInfoSubscription.unsubscribe();
        }
    }
}
