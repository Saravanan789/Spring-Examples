export interface ValidationMessage {
    message: string;
    name: string;
}
