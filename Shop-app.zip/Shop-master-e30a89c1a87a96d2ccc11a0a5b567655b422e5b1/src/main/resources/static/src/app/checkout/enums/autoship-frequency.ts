export enum AutoshipFrequency {
    Monthly= 3,
    Quarterly = 4,
    AlternativeMonth = 7
}
