import { Pipe, PipeTransform } from '@angular/core';
/**
 *Pipes which converts the FboId in the Application to xxx-xxx-xxx-xxx format
 *
 * @export
 * @class DistributorIdFormat
 * @implements {PipeTransform}
 */
@Pipe({
    name: 'distributorIdFormat'
})

export class DistributorIdFormat implements PipeTransform {
    /**
   * @param  {string} distributorId
   */
    transform(input: string): string {
        if (!input) {
            return '';
        } else {
            return input.match(/.{1,3}/g).join('-');
        }
    }
}
