export enum PaymentProcessorAlias {
    WORLDPAYXML = 'WPXML',
    PAYVISION = 'PV',
    PAYVISIONPAYPAL = 'PVPP',
    WPAY = 'WP',
}
