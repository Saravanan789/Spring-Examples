export enum BreadcrumbStep {
    SHIPPING = 'SHIPPING',
    DELIVERY = 'DELIVERY',
    PAYMENT = 'PAYMENT'
}
