import { ValidationDetail } from './validation-details.interface';

export interface ValidateEcheckResponse {
    success: boolean;
    validations: ValidationDetail[];
}
