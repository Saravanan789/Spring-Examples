export interface OrderLineItem {
  orderLineNumber: number;
  orderId?: number;
  productId: number;
  itemNumber: string;
  productName: string;
  unitRetailPrice: number;
  unitWholeSalePrice: number;
  unitPaidPrice: number;
  unitTaxablePrice?: number;
  unitTax: number;
  unitQualificationValue: number;
  unitCommissionablePrice?: number;
  totalAmount: number;
  quantity: number;
  freeshipping?: boolean;
  downloadActivated?: boolean;
  weight: number;
  totalTax?: number;
  taxLineId?: number;
  taxRate?: number;
  height: number;
  width: number;
  length: number;
  importedMeasurementUnit?: string;
  revisionNumber?: string;
  discountPercentage?: number;
  literature?: boolean;
  discountAmount: number;
  fboEligible?:boolean;
  personalDiscount?: number;
}

