import { FieldValidations } from './validation-fields.interface';

export interface PersonalInfoFormFields {
    firstName: FieldValidations;
    middleName: FieldValidations;
    lastName: FieldValidations;
    email: FieldValidations;
    phoneNumber: FieldValidations;
    pass_word: FieldValidations;
    confirmPassword: FieldValidations;
}
