export interface StorePaymentMethod {
    paymentMethodId: number;
    paymentMethodName: string;
    displayName: string;
    imagePath: string;
    description: string;
    billingAddressRequired: boolean;
    completeRedirect: boolean;
}
