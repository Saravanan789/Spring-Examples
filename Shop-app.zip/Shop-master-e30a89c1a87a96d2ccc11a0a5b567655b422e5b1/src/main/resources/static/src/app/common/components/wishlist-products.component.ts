import { UserTitleType } from '../../shared/enums/user-title-type.enum';
import { CommonService } from '../../shared/services/common.service';
import { CartService } from '../../shared/services/cart.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CacheService } from '../../shared/services/cache.service';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { StoreConfig } from '../../shared/interfaces/StoreConfig.interface';
import { Cart } from '../../shared/models/cart.model';
import { ImageType } from '../../products/enums/image-type.enum';
import { Item } from '../../shared/models/item.model';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import { CartTypes } from '../../shared/enums/cart-types.enum';
import { AppMessageService } from '../../app-message.service';
import { Subscription } from 'rxjs/Subscription';
import { NotificationService } from '../../shared/services/notification.service';
import { NotificationType } from '../enums/notification-type.enum';
import { Product } from '../../products/interfaces/product.interface';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { QuickviewComponent } from '../../products/components/quickview.component';
import { DataShareService, ActiveSessionService } from '../../shared/services';
import { Autoship } from '../../checkout/interfaces';
import { MemberLevel } from '../../shared/enums';
@Component({
  selector: 'app-wishlist-products',
  templateUrl:
    '../templates/template3/views/wishlist-products.component.html',
  styleUrls: [
    '../templates/template3/themes/default/less/wishlist-products.component.less'
  ]
})
export class WishlistProductsComponent implements OnInit, OnDestroy {
  store: StoreConfig;
  languageCode: string;
  imageTypes: any = ImageType;
  storeId: number;
  memberTitle = MemberLevel;
  memberTitleId: number = MemberLevel.RETAIL;
  isoCountryCode: string;
  wishListCart: Cart;
  wishListCartSubscription: Subscription;

  selectedIndex = -1;
  isAddAllItems = false;
  isAutoshipEnabled: boolean;
  bsModalRef: BsModalRef;
  quantityCheck = false;

  constructor(
    private _cacheService: CacheService,
    private _cartService: CartService,
    private _router: Router,
    private _commonService: CommonService,
    private _configurationService: ConfigurationService,
    private _translatePipe: TranslateService,
    private modalService: BsModalService,
    private _appMessageService: AppMessageService,
    private _notificationService: NotificationService,
    private _dataService: DataShareService,
    private _activeSessionService: ActiveSessionService
  ) { }

  ngOnInit() {
    this.isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
    this.getStoreData();
    this.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
    this.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
    this.memberTitleId = this._activeSessionService.getMemberTitleId();
    this.getWishlistProducts();
    this.getWishListSubject();
    this.getAutoshipCart();
  }


  /**
 * @description To display wishlist products
 * @param  {number} productId
 * @param  {number} storeid
 */
  getWishlistProducts() {
    const productIds: number[] = [];
    const wishListCart = this._cacheService.get(CacheKey.WishListSession);
    if (wishListCart) {
      this.wishListCart = new Cart(wishListCart, this.store);
      this.wishListCart.items.forEach(item => {
        item['wishListItem'] = true;
        item['disableDecrement'] = item['quantity'] === 1 ? true : false;
        if (!(item.backOrderAllowed || (item.manageStock && item.stockQuantity > 0))) {
          item['quantity'] = 0;
        }
      });
    }
  }

  /**
   * @description To get wishlist
   * @memberof WishlistProductsComponent
   */
  getWishListSubject(): void {
    this.wishListCartSubscription = this._appMessageService.getWishListItems().subscribe(response => {
      this.getWishlistProducts();
    });
  }

  /**
  * @description Show Modal popup
  * @param product
  */
  showModalPopup(product: Product) {
    const initialState = {
      productDetails: product
    };
    this.bsModalRef = this.modalService.show(QuickviewComponent, { initialState });
    this.bsModalRef.content.product = product;
  }

  /**
   * Trackby will change the DOM
   *  for only added or removed element(not entire DOM Collection)
   * @param  {number} index
   * @returns number
   */
  trackItem(index: number, item: any): number {
    return item;
  }


  /**
   * @description get Store Data
   */
  getStoreData() {
    const result: StoreConfig = this._configurationService.getStoreData();
    if (result != null) {
      this.store = result;
      this.storeId = this.store.id;
    }
  }

  /**
   * @param  {Product} product
   * @returns void
   */
  navigateToProductDetail(product: Product): void {
    let selectedCategory;
    if (product.categories) {
      selectedCategory = this._commonService.getCategoryFromProduct(product);
    }
    if (product.customCatalogName && !selectedCategory.categoryName) {
      selectedCategory = {
        productCategoryId: product.customCatalogId,
        categoryName: product.customCatalogName,
      };
    }
    if (product.parentProductSlug) {
      product.slug = product.parentProductSlug;
      this._dataService.variableProductOption = product.selectedOption;
    }
    if (selectedCategory) {
      this._cacheService.set(CacheKey.SelectedCategoryState, selectedCategory);
      if (selectedCategory.slug) {
        this._router.navigate([this.isoCountryCode.toLowerCase() + '/'
          + this.languageCode.toLowerCase() + '/products/' + selectedCategory.slug + '/' + product.slug]);
      } else {
        this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + product.slug]);
      }
    } else {
      this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/products/' + product.slug]);
    }
  }

  /**
   * @description on click of wishlist icon
   * @param index
   */
  selectedWishList(prod: any, index: number) {
    this._commonService.scrollTo('fav_section_' + index, 500);
    setTimeout(() => { this.selectedIndex = index; }, 100);
    this.wishListCart.items[index]['wishListItem'] = false;
    const elementId = '#confirmDeleteItem' + index;
    const element = $(elementId);
    setTimeout(() => { element.focus(); }, 500);
  }

  /**
   * remove focus // called on focusout event
   */
  removeOverlayedStyle(): void {
    if (this.selectedIndex > -1) {
      this.wishListCart.items[this.selectedIndex]['wishListItem'] = true;
      setTimeout(() => { this.selectedIndex = -1; }, 300);
    }
  }

  /**
 * Remove the Cart Item from the minicart.
 * @param  {number} productId
 */
  confirm(productId: number) {
    if (productId) {
      this.selectedIndex = -1;
      this.removeWishListItem(productId, true);
    }
  }
  /**
   * Adding a Single Product to the Cart
   * @param  {productId} any
   * @returns void
   */
  addToCart(item: Item, cartType: number): void {
    if (!item.addingToCart) {
      this.getShippingRestrictedProducts(item.itemNumber);
      this.manageShoppingCart(Object.assign({}, item), cartType, true, function (addingToCart: boolean) {
        item.addingToCart = addingToCart;
      });
    }
  }

  /**
* verifying whether the product is shippable to the selected shipping address or not
* @returns Address
*/
  getShippingRestrictedProducts(itemNumber: string): any {
    const userDefaultAddressDetails = this._cacheService.get(CacheKey.UserDefaultAddress);
    if (userDefaultAddressDetails) {
      const getShippingRestrictedProductsData = this._commonService.getShippingRestrictedProducts(itemNumber)
        .subscribe((response: any) => {
          if (response && response.productModels && response.productModels.length > 0) {
            // this.shippingRestrictedProductError = response.productModels[0].errorDescription;
            // this.itemNo = response.productModels[0].itemNumber;
          }
        });
    }
  }

  /**
   * @param  {Product} product
   * @param  {CartTypes} cartType
   */
  private manageShoppingCart(item: Item, cartType: CartTypes, wishListItem: boolean = false, addingToCartCallback?: Function) {
    let cartSessionInfo: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      this._notificationService.createNotification('', 'Item added to Autoship Cart', NotificationType.SUCCESS);
      cartSessionInfo = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      const itemAddedNotification: any = this._translatePipe.get('quickview.Item added to cart');
      cartSessionInfo = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    if (cartSessionInfo) {
      const cartItem: Item = cartSessionInfo.items.find(x => x.productId === item.productId);
      if (wishListItem && cartItem) {
        let total: Number;
        total = cartItem.quantity + item.quantity;
        if (total > 999) {
          const cookieBannerDiscription: any = this._translatePipe.get('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
          this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
          return;
        } else {
          item.quantity = cartItem.quantity + item.quantity;
        }
        if (item.quantity > item.stockQuantity && item.manageStock && !item.backOrderAllowed) {
          item.quantity = cartItem.quantity;
          item.errorMessage = true;
          setTimeout(() => {
            item.errorMessage = false;
          }, 2000);
          const cartStockErrorForItem: any = this._translatePipe.get('stockError.No Stock Available for Item Number');
          // this._commonService.createNotification('', cartStockErrorForItem.value +' '+ product.itemNumber, 'error');
          return;
        }
      }
    }
    addingToCartCallback(true);
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(cartSessionInfo));
    if (cartType === CartTypes.AutoshipCart) {
      if (mergeCartSession) {
        cartSessionInfo = this._cartService.mergeCartSession(item, '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(item);
        const cartResponse = {
          items: autoShipProducts
        };
        cartSessionInfo = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
      this._cacheService.set(CacheKey.AutoshipCart, cartSessionInfo);
      const cartSession = {
        reloadMemberCart: false
      };
      const autoshipCart = new Cart(cartSessionInfo, this.store);
      const cartItemDetails = {
        count: autoshipCart.itemsCount,
        cartType: cartType
      };
      addingToCartCallback(false);
      this._appMessageService.setMiniCart(cartSession);
      this._appMessageService.setCartItemsChanges(cartItemDetails);
      this._commonService.scrollTo('cart-component', 500);
      this._commonService.focusTargetElement('minicart-shop-msg');
    } else if (cartSessionInfo) {
      this._cartService.updateCart([item], cartType, cartSessionInfo).subscribe((response: any) => {
        addingToCartCallback(false);
        if (response) {
          // this.removeWishListItem(item.productId, false);
          cartSessionInfo = this._cartService.mergeCartSession(item, response, mergeCartSession);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(item.productId);
          if (this.wishListCart && this.wishListCart.items && this.wishListCart.items.length > 0) {
            this.wishListCart.items.forEach(x => {
              x.quantity = 1;
            });
          }
        }
      }, (error) => {
        addingToCartCallback(false);
      });
    } else {
      this._cartService.saveCart([item], cartType).subscribe((response: any) => {
        addingToCartCallback(false);
        if (response) {
          cartSessionInfo = this._cartService.mergeCartSession(item, response, cartSessionInfo);
          this._cacheService.set(CacheKey.CartSessionInfo, cartSessionInfo);
          const cartSession = {
            sessionInfo: response.sessionGuid,
            reloadMemberCart: false
          };
          this._appMessageService.setMiniCart(cartSession);
          this._appMessageService.showMiniCartView(item.productId);
          if (this.wishListCart && this.wishListCart.items && this.wishListCart.items.length > 0) {
            this.wishListCart.items.forEach(x => {
              x.quantity = 1;
            });
          }
        }
      }, (error) => {
        addingToCartCallback(false);
      });
    }
  }


  /**
 * add item to wishlist
 * @param  {Product} product
 */
  removeWishListItem(productId: any, showNotification: boolean): void {
    const itemDeletedNotification: any = this._translatePipe.get('quickview.Item removed from Favorites');
    const cartItem: Item = this.wishListCart.items.find(x => x.productId === productId);
    this.wishListCart.items = _.remove(this.wishListCart.items, function (n) {
      return n.productId !== productId;
    });
    if (this.wishListCart && this.wishListCart.sessionGuid && cartItem && cartItem.id) {
      this._cartService.removeCartItem(this.wishListCart.sessionGuid, cartItem.id)
        .subscribe(response => {
          this.wishListCart = new Cart(this.wishListCart, this.store);
          this._cacheService.set(CacheKey.WishListSession, this.wishListCart);
          this._appMessageService.setWishListItems();
        });
    }
  }

  /**
  * update order cart with list quick order items
  * @returns void
  */
  addQuickOrderListItemsToCart(cartType: number): void {
    if (this.wishListCart && this.wishListCart.items && this.wishListCart.items.length > 0) {
      let orderCart: Cart;
      if (cartType === CartTypes.AutoshipCart) {
        this._notificationService.createNotification('', 'Item added to Autoship Cart', NotificationType.SUCCESS);
        orderCart = this._cacheService.get(CacheKey.AutoshipCart);
      } else {
        orderCart = this._cacheService.get(CacheKey.CartSessionInfo);
      }
      let quickOrderListItems: Item[] = JSON.parse(JSON.stringify(this.wishListCart.items.filter(x => x.quantity > 0)));
      if (quickOrderListItems && quickOrderListItems.length > 0) {
        if (orderCart) {
          this.quantityCheck = false;
          orderCart.items.forEach(item => {
            const product = quickOrderListItems.filter(y => y.productId === item.productId)[0];
            if (product) {
              if (product.quantity + item.quantity > 999) {
                this.quantityCheck = true;

              }
            }
          });
          //  showing notification, when the items crosses the limit(999)
          if (this.quantityCheck) {
            const cookieBannerDiscription: any = this._translatePipe.get('cookieBanner.We are sorry. You may not be able to order more than 1,000 units of an individual product at a time');
            this._notificationService.createNotification('', cookieBannerDiscription.value, NotificationType.ERROR, 5000);
            return;
          }
          quickOrderListItems.map(x => {
            if (orderCart && orderCart.items
              && orderCart.items.length > 0) {
              const orderItem = orderCart.items.find(y => y.productId === x.productId);
              if (orderItem) {
                x.quantity = parseInt(orderItem.quantity.toString(), 10) + parseInt(x.quantity.toString(), 10);
                if (x.quantity > x.stockQuantity && !x.backOrderAllowed) {
                  x.quantity = x.stockQuantity;
                  return;
                }
              }
              if (!(x.backOrderAllowed || (x.manageStock && x.stockQuantity > 0))) {
                quickOrderListItems = quickOrderListItems.filter(y => y.productId !== x.productId);
              } else if (x.quantity > x.stockQuantity && !x.backOrderAllowed) {
                x.quantity = x.stockQuantity;
                return;
              }
            }
            return x;
          });
          if (cartType === CartTypes.AutoshipCart) {
            this.addAllAutoshipItems(orderCart, quickOrderListItems, cartType);
          } else {
            this._cartService.updateCartItems(quickOrderListItems, cartType, orderCart.items, orderCart)
              .subscribe(response => {
                this.updateOrderCart(response, quickOrderListItems, cartType);
              }, error => {
              });
          }
        } else {
          this._cartService.saveCartItems(quickOrderListItems, cartType)
            .subscribe(response => {
              this.updateOrderCart(response, quickOrderListItems, cartType);
            }, error => {
            });
        }
      } else {
      }
    } else {
    }
    this.isAddAllItems = false;
  }

  /**
   * @param  {} cartResponse
   * @returns void
   */
  private updateOrderCart(cartResponse: any, quickOrderListItems: Item[], cartType: number): void {
    const itemAddedNotification: any = this._translatePipe.get('quickorder.Items added to Cart');
    let orderCart: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      orderCart = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      orderCart = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    quickOrderListItems.forEach(item => {
      orderCart = this._cartService.mergeCartSession(item, JSON.parse(JSON.stringify(cartResponse)), orderCart);
    });
    let cartSession: Cart;
    if (cartType === CartTypes.AutoshipCart) {
      this._cacheService.set(CacheKey.AutoshipCart, orderCart);
      cartSession = this._cacheService.get(CacheKey.AutoshipCart);
    } else {
      this._cacheService.set(CacheKey.CartSessionInfo, orderCart);
      cartSession = this._cacheService.get(CacheKey.CartSessionInfo);
    }
    if (cartSession && cartSession.items) {
      this.wishListCart = new Cart(cartSession, this.store);
      this._appMessageService.setCartItemsCount(this.wishListCart);
    }
    const loadCartSession = {
      sessionInfo: orderCart.sessionGuid,
      reloadMemberCart: false
    };
    this._appMessageService.setMiniCart(loadCartSession);
    // this.removeWishlistItems(); // updating wishlish items
    this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/cart']);
  }

  /**
    * @description
    * @date 2018-12-05
    * @private
    * @param {Cart} orderCart
    * @param {Item[]} quickOrderListItems
    * @param {number} cartType
    * @memberof WishlistProductsComponent
    */
  private addAllAutoshipItems(orderCart: Cart, quickOrderListItems: Item[], cartType: number) {
    const mergeCartSession: Cart = JSON.parse(JSON.stringify(orderCart));
    for (let i = 0; i < quickOrderListItems.length; i++) {
      if (mergeCartSession) {
        orderCart = this._cartService.mergeCartSession(quickOrderListItems[i], '', mergeCartSession);
      } else {
        const autoShipProducts: Item[] = [];
        autoShipProducts.push(quickOrderListItems[i]);
        const cartResponse = {
          items: autoShipProducts
        };
        orderCart = this._cartService.mergeCartSession(Object.assign({}), cartResponse, Object.assign({}), true);
      }
    }
    this._cacheService.set(CacheKey.AutoshipCart, orderCart);
    const cartSession = {
      reloadMemberCart: false
    };
    const autoshipCart = new Cart(orderCart, this.store);
    const cartItemDetails = {
      count: autoshipCart.itemsCount,
      cartType: cartType
    };
    this._appMessageService.setMiniCart(cartSession);
    this._appMessageService.setCartItemsChanges(cartItemDetails);
    this._commonService.scrollTo('cart-component', 500);
    this._commonService.focusTargetElement('minicart-shop-msg');
    this._router.navigate([this.isoCountryCode.toLowerCase() + '/' + this.languageCode.toLowerCase() + '/cart']);
  }

  /**
   * removing wishlist items.....
   */
  private removeWishlistItems() {
    const itemDeletedNotification: any = this._translatePipe.get('quickview.Item(s) removed from Favorites');
    this._cartService.removeCart(this.wishListCart.sessionGuid).subscribe(response => {
      // this._commonService.createNotification('', itemDeletedNotification.value, 'success');
      // this._cacheService.remove(CacheKey.CartSessionInfo);
      // this._cacheService.remove(CacheKey.RecentlyViewedProducts);
      this._cacheService.remove(CacheKey.WishListSession);
      this.getWishlistProducts();
      this._appMessageService.setWishListItems();
    });
  }

  /**
   * Increment the item Quantity
   * @returns void
   */
  incrementQuantity(item: Item): void {
    if (+item.quantity < 999) {
      item.quantity = +item.quantity + 1;
      item.disableDecrement = false;
    }
    if (item.quantity > item.stockQuantity && !item.backOrderAllowed) {
      item.errorMessage = true;
      setTimeout(() => {
        item.errorMessage = false;
      }, 2000);
      item.disableDecrement = false;
      item.quantity = item.quantity - 1;
    }
  }

  /**
   * Decrement the item Quantity
   * @returns void
   */
  decrementQuantity(item: Item): void {
    if (item.quantity > 1) { // item quantity count should be atleast 1
      item.quantity = +item.quantity - 1;
    }
    if (item.quantity === 1) {
      item.disableDecrement = true;
    }
  }

  /**
   * to update item quantity
   */
  updateQuantity(cartItem: Item, $evt: any): void {
    if ($evt && $evt.currentTarget.value) {
      cartItem.quantity = parseInt($evt.currentTarget.value, 10);
      cartItem.disableDecrement = false;
    }
    if (cartItem.quantity > cartItem.stockQuantity && !cartItem.backOrderAllowed) {
      cartItem.quantity = cartItem.stockQuantity;
      $evt.currentTarget.value = cartItem.quantity;
      cartItem.errorMessage = true;
      setTimeout(() => {
        cartItem.errorMessage = false;
      }, 2000);
      const cartStockError: any = this._translatePipe.get('stockError.No Stock Available');
      // this._commonService.createNotification('', cartStockError.value, 'error');
    }
  }

  /**
   * @description get Autoship Cart
   * @date 2018-11-01
   * @memberof WishlistProductsComponent
   */
  getAutoshipCart(): void {
    const autoshipCart: Autoship = this._cacheService.get(CacheKey.AutoshipCart);
    if (this.isAutoshipEnabled && autoshipCart) {
      this._appMessageService.setMiniCart(autoshipCart);
    }
  }

  ngOnDestroy(): void {
    if (this.wishListCartSubscription) {
      this.wishListCartSubscription.unsubscribe();
    }
  }
}
