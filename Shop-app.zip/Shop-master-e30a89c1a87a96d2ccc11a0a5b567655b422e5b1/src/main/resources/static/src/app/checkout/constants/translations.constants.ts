export class Translations {
    public static AutoShipProfileName = 'AutoShip Profile Name Already exists.';
}