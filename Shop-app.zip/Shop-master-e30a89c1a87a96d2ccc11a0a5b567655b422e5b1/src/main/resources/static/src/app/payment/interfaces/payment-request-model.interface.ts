import { Address } from '../../common/interfaces';
import { PaymentEcheck, PayvisionRequestModel } from '.';

/**
 * Payment Request -- validating payments
 *
 * @export
 * @interface PaymentRequestModel
 */
export interface PaymentRequestModel {
    token: string;
    orderReferenceId: number;
    orderDescription: string;
    amount: number;
    storeId: number;
    countryCode: string;
    currencyCode: string;
    paymentMethodType: string;
    customerId: number;
    orderTypeId: number;
    billingAddress: Address;
    paymentCheck?: PaymentEcheck;
    paymentRequestModel: PayvisionRequestModel;
}
