import { Address } from '../../common/interfaces';
import { DocumentLibrary } from '../../shared/interfaces';

export interface PersonalInformation {
  sponserId: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  email: string;
  phoneNumber: string;
  pass_word: string;
  confirmPassword: string;
  address: Address;
  documents?: DocumentLibrary[];
  governmentId?: string;
  dateOfBirth?: string;
  phoneType?: number;
}
