import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Observable } from 'rxjs/Observable';
import * as crypto from 'crypto-js';
import {
    PayvisionRegistration,
    PaymentRegistrationResponse,
    PayvisionSavedCardResponse
} from '../interfaces';
import { environment } from '../../../environments/environment';

/**
 * @description this service help comunicate with payment service
 * when provider is payvison
 * @date 2018-08-08
 * @export
 * @class PayvisionService
 */
@Injectable()
export class PayvisionService {

    constructor(private _http: Http) { }


    /**
     * @description to get the payvision checkout
     *  registration form
     * @date 2018-07-27
     * @param {number} storeId
     * @param {PayvisionRegistrationRequest} payvisionRegistrationRequest
     * @returns {Observable<any>}
     * @memberof PayvisionService
     */
    getPayvisionForm(storeId: number, payvisionRegistrationRequest: PayvisionRegistration)
        : Observable<PaymentRegistrationResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .post(ApiUrlConstants.paymentApiUrl + '/payments/store/' + storeId +
                '/payment-checkout-form ', payvisionRegistrationRequest, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description to get the Registration status
     * @date 2018-07-31
     * @param {number} storeId
     * @param {string} checkoutOutId
     * @returns {Observable<PayvisionRegistrationResponse>}
     * @memberof PayvisionService
     */
    getPayvisionRegistrationStatus(storeId: number, checkoutOutId: string): Observable<PaymentRegistrationResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/payments/store/' + storeId +
                '/checkout-payvision/' + checkoutOutId + '/registration-status', { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this method will retrive ssaved payvison cards
     * for logged in user
     * @date 2018-08-14
     * @returns {void}
     * @memberof PayvisionService
     */
    getSavedPayvisonCards(memberId: number, isoCountryCode: string)
        : Observable<PayvisionSavedCardResponse> {
        const headers = this.getPaymentHeaders();
        return this._http
            .get(ApiUrlConstants.paymentApiUrl + '/members/' + memberId +
                '/cards?countryCode=' + isoCountryCode, { headers: headers })
            .map((res: Response) => res.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this is used to get
     * payment headers
     * @date 2018-07-26
     * @returns {Headers}
     * @memberof PayvisionService
     */
    getPaymentHeaders(): Headers {
        const headers = new Headers();
        const authHeader = 'PAY ' + environment.paymentApiKey + ':' + this.getHashedValue();
        headers.append('authorization', authHeader);
        return headers;
    }

    /**
     * @description this method is used to
     * get payment crypto hashed value
     * @date 2018-07-26
     * @returns {string}
     * @memberof PayvisionService
     */
    getHashedValue(): string {
        const shavalue = crypto.HmacSHA1(environment.paymentSecurityKey, environment.paymentServiceKey);
        return crypto.enc.Base64.stringify(shavalue);
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error);
    }

}
