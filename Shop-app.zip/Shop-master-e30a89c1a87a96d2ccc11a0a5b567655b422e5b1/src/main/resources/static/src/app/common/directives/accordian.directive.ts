
import { Directive, Input, ElementRef, OnInit } from '@angular/core';

@Directive({
    selector: '[appAccordian]'
})
export class AccordianDirective implements OnInit {
    _isActive: boolean;
    @Input()
    public get active(): boolean {
        return this._isActive;
    }
    public set active(val: boolean) {
        this._isActive = val;
        this.toggleAccordian(this._isActive);
    }
    constructor(private _elementRef: ElementRef) { }
    ngOnInit() {
        this.toggleAccordian(this._isActive);
    }
    toggleAccordian(isActive: boolean) {
        if (isActive) {
            const eleHgt = this._elementRef.nativeElement.scrollHeight;
            this._elementRef.nativeElement.style.maxHeight = eleHgt + 'px';
        } else {
            this._elementRef.nativeElement.style.maxHeight = '0px';
        }
    }
}
