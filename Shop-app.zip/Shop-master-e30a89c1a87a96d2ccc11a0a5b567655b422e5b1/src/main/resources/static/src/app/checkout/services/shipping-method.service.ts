import { Injectable } from '@angular/core';
import {
    ShippingOptionsRequest, ShippingOptionsResponse,
    ShippingMethod, CheckoutInformation, DeliveryOptionTypeResponse, DeliveryOptionTypeRequest
} from '../interfaces';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { CacheService, CommonService } from '../../shared/services';
import { State, Member, Country } from '../../shared/interfaces';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Address } from '../../common/interfaces';
import { AddressType } from '../../common/enums';
import { ShippingAddressComponentSettings } from '../component-settings';


/**
 * @description this service will
 * excecute all methods those are required
 * for shipping methods
 * @date 2018-07-21
 * @export
 * @class ShippingMethodService
 */
@Injectable()
export class ShippingMethodService {

    constructor(
        private _http: Http,
        private _cacheService: CacheService,
        private _commonService: CommonService
    ) { }


    /**
     * @description this method used
     * get sshipping methods based on delivery option type
     * @date 2018-07-21
     * @param {ShippingOptionsRequest} shipMethodRequest
     * @returns {Observable<ShippingOptionsResponse>}
     * @memberof ShippingMethodService
     */
    getShippingOptions(shipMethodRequest: ShippingOptionsRequest): Observable<ShippingOptionsResponse> {
        return this._http
            .post(ApiUrlConstants.shippingApiUrl + '/shipping-options', shipMethodRequest)
            .map((response: Response) => response.json())
            .catch(this.handleErrorObservable);
    }


    /**
     * @description this method will give
     * mapped pickup address with valid information
     * when delivery option is pickup
     * @date 2018-07-23
     * @memberof ShippingMethodService
     */
    getPickupAddress(shippingMethod: ShippingMethod, states: State[], countries: Country[]): Address {
        shippingMethod.pickUpLocation.addressType = AddressType.PICKUP;
        if (states && states.length > 0) {
            const stateTemp: State = states.find((stateObj: State) =>
                stateObj.stateCode.toLowerCase() === shippingMethod.pickUpLocation.stateCode.toLowerCase());
            if (stateTemp) {
                shippingMethod.pickUpLocation.stateId = stateTemp.id;
            }
        }
        if (countries && countries.length > 0) {
            const countryObj = countries.find((country: Country) =>
                country.isocodeThree.toLowerCase() === shippingMethod.pickUpLocation.countryCode.toLowerCase());
            if (countryObj) {
                shippingMethod.pickUpLocation.countryId = countryObj.countryId;
            }
        }
        shippingMethod.pickUpLocation.name = shippingMethod.shippingMethodDisplayName;
        shippingMethod.pickUpLocation.postalCode = shippingMethod.pickUpLocation.zip;
        return shippingMethod.pickUpLocation;
    }

    /**
     * @description this method will give
     * mapped pickup address with valid information
     * when delivery option is pickup
     * @date 2018-07-23
     * @memberof ShippingMethodService
     */
    getShippingAddress(states: State[]): Address {
        const checkoutInfo: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const personalInformation = checkoutInfo.personalInformation;
        let shippingInfo: Address = null;
        if (checkoutInfo && checkoutInfo.shippingInformation
            && checkoutInfo.shippingInformation.shippingAddress) {
            const shippingAddress: Address = checkoutInfo.shippingInformation.shippingAddress;
            let stateId: number;
            if (states && states.length > 0) {
                const stateTemp = states.filter((stateObj: State) => stateObj.stateCode === shippingAddress.state);
                if (stateTemp && stateTemp.length > 0) {
                    stateId = stateTemp[0].id;
                }
            }
            const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
            shippingInfo = {
                id: shippingAddress.id,
                firstName: shippingAddress.firstName ? shippingAddress.firstName : userInfo ?
                    userInfo.firstName
                    : personalInformation ? personalInformation.firstName : '',
                middleName: shippingAddress.middleName ? shippingAddress.middleName : userInfo ?
                    userInfo.middleName
                    : personalInformation ? personalInformation.middleName : '',
                lastName: shippingAddress.lastName ? shippingAddress.lastName : userInfo ?
                    userInfo.lastName
                    : personalInformation ? personalInformation.lastName : '',
                name: shippingAddress.name ? shippingAddress.name : userInfo ?
                    userInfo.fullName
                    : personalInformation ? (personalInformation.firstName + ' ' + personalInformation.lastName) : '',
                phone: shippingAddress.phone ? shippingAddress.phone : null,
                addressLine1: shippingAddress.addressLine1,
                addressLine2: shippingAddress.addressLine2,
                city: shippingAddress.city,
                countryCode: shippingAddress && shippingAddress.country ? shippingAddress.country.toLocaleUpperCase() : '',
                country: shippingAddress.country,
                countryId: shippingAddress.countryId || this._cacheService.get(CacheKey.CountryId),
                state: shippingAddress.state,
                stateCode: shippingAddress.state,
                stateId: shippingAddress.stateId || stateId,
                postalCode: shippingAddress.postalCode || shippingAddress.zip,
                zip: shippingAddress.postalCode,
                residential: false,
                validAddress: shippingAddress.validAddress,
                addressType: AddressType.SHIPPING,
                phoneType: shippingAddress.phoneType
            };
        }
        return shippingInfo;
    }

    /**
 * @description To get the shipping Method details
 * @date 2018-09-07
 * @param {number} storeId
 * @param {number} shippingMethodId
 * @returns {Observable<ShippingMethod>}
 * @memberof ShippingMethodService
 */
    getShippinMethodDetailsById(storeId: number, shippingMethodId: number): Observable<ShippingMethod> {
        return this._http
            .get(ApiUrlConstants.shippingApiUrl + '/stores/' + storeId + '/shipping-methods/' + shippingMethodId)
            .map((res) => res.json())
            .catch(this.handleErrorObservable);
    }


    /**
     * @description this method used
     * get delivery types based on member type
     * @date 2018-07-21
     * @param {DeliveryTypeRequest} shipMethodRequest
     * @returns {Observable<DeliveryTypeResponse>}
     * @memberof ShippingMethodService
     */
    getDeliveryOptionTypes(sAddressComponentSettings: ShippingAddressComponentSettings)
        : Observable<DeliveryOptionTypeResponse[]> {
        const deliveryTypeRequest = this.prepareDeliveryOptionTypeRequest(sAddressComponentSettings);
        return this._http
            .post(ApiUrlConstants.shippingApiUrl + '/' + deliveryTypeRequest.countryCode
                + '/delivery-options ', deliveryTypeRequest)
            .map((response: Response) => response.json())
            .catch(this.handleErrorObservable);
    }

    /**
     * @description this method will prepare request for getting
     * delivery options
     * @date 2018-09-14
     * @private
     * @returns {DeliveryOptionTypeRequest}
     * @memberof ShippingMethodService
     */
    private prepareDeliveryOptionTypeRequest(sAddressComponentSettings: ShippingAddressComponentSettings): DeliveryOptionTypeRequest {
        const deliveryOptionTypeRequest: DeliveryOptionTypeRequest = {
            memberType: sAddressComponentSettings.registerMemberTypeValue,
            memberTypeId: sAddressComponentSettings.registerMemberType,
            purchaseFlow: this._commonService.getPurchaseFlowType(),
            countryCode: sAddressComponentSettings.store.homeIsocodeThree
        };
        return deliveryOptionTypeRequest;
    }

    /**
     * To handle the obervable error response
     * @param  {Response|any} error
     */
    private handleErrorObservable(error: Response | any) {
        return Observable.throw(error.message || error);
    }
}
