import {
    PaymentComponent, PayvisionComponent, WorldPayXMLComponent,
    EcheckComponent, PaymentStatusComponent, MoneyOrderComponent,
    PayvisionPaypalComponent,
    WorldPayXMLPaypalComponent
} from './components';

export class PaymentModuleConstants {
    static MODULE_COMPONENTS = [
        PaymentComponent,
        PayvisionComponent,
        WorldPayXMLComponent,
        EcheckComponent,
        PaymentStatusComponent,
        MoneyOrderComponent,
        PayvisionPaypalComponent,
        WorldPayXMLPaypalComponent
    ];
}
