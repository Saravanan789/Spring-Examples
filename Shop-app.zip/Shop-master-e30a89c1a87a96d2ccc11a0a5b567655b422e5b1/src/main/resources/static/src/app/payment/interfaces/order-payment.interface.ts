import { CreditCardModel } from './creditcard-model.interface';
import { PaymentEcheckRequest } from './payment-echeckrequest.interface';
import { CompleteRedirectRequest } from './complete-redirect-request.interface';

export interface OrderPayment {
    paymentAmount: number;
    memberPaymentMethodId: number;
    paymentStatusId?: number;
    creditCardModel: CreditCardModel;
    paymentECheck?: PaymentEcheckRequest;
    completeRedirectRequestModel?: CompleteRedirectRequest;
    redirect?: boolean;
}
