export class DefaultSponsors {
    
    public static sponsors = [{
        sponsorAddressLine1: '',
        sponsorAddressLine2: '',
        sponsorCity: 'SHOW LOW',
        sponsorCountryCode: 'USA',
        sponsorCountryId: '1',
        sponsorEmail: 'ROB@MAILINATOR.COM',
        sponsorEnrolledDate: null,
        sponsorFirstName: '',
        sponsorId: '001002575619',
        sponsorLanguageCode: 'EN',
        sponsorLanguageId: null,
        sponsorLastName: '',
        sponsorMiddleName: null,
        sponsorName: 'ROB FERGUSON',
        sponsorPhone: '6757567677',
        sponsorPostalCode: '85901-5206',
        sponsorStateCode: 'AZ',
        sponsorStateId: '76',
        wholesaleQualified: true
    },
    {
        sponsorAddressLine1: '',
        sponsorAddressLine2: '',
        sponsorCity: 'FAZEY',
        sponsorCountryCode: 'GBR',
        sponsorCountryId: '235',
        sponsorEmail: 'ADAM@MAILINATOR.COM',
        sponsorEnrolledDate: null,
        sponsorFirstName: '',
        sponsorId: '001000000003',
        sponsorLanguageCode: 'EN',
        sponsorLanguageId: null,
        sponsorLastName: '',
        sponsorMiddleName: null,
        sponsorName: 'NAVAZ D GHASWALA',
        sponsorPhone: '0000060299',
        sponsorPostalCode: 'B78 3YB',
        sponsorStateCode: 'FL',
        sponsorStateId: '373',
        wholesaleQualified: true
    }
    ]
}