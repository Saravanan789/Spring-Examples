import { Member, StoreConfig } from '../../shared/interfaces';
import { MemberType } from '../../shared/enums';
import { State, Country } from '../../shared/interfaces';
import { Cart } from '../../shared/models';

export class BaseSettings {
    userInfo: Member;
    isoCountryCode: string;
    languageCode: string;
    memberType = MemberType;
    store: StoreConfig;
    states: State[];
    countries: Country[];
    registerMemberType: MemberType;
    autoshipCart: Cart;
}
