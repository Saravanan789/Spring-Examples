export interface PaymentStatusRequest {
    paymentStatus: string;
    authorizedAmount: number;
    paymentTransactionNo: string;
    webOrderId: string;
}
