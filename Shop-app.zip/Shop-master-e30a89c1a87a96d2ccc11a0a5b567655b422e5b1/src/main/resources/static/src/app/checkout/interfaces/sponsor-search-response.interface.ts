import { SponsorInformation } from './sponsor-information.interface';

export interface SponsorSearchResponse {
    isSuccess: boolean;
    error: string;
    ipAddress: string;
    statusCode: string;
    validations: string[];
    sponsorSearchResultModels: SponsorInformation[];
    sponsors?: SponsorInformation[];
    success: boolean;
    responseMessage?: string;
    requestStatus?: string;
    uuid?: string;
    location?: string;
}
