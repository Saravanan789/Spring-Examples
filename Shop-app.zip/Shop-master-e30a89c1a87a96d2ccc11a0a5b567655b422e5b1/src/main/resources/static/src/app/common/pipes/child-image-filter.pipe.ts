import { ImageModel } from '../../products/interfaces/image-model.interface';
import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ImageType } from '../../products/enums/image-type.enum';

@Pipe({
  name: 'childImageFilter'
})
export class ChildImageFilterPipe implements PipeTransform {
  transform(imagesList: Array<ImageModel>, imageType: string): string {
    if (imagesList && imagesList.length > 0) {
      let productImage: any = {};
      imagesList.forEach(x => {
        if (x.type !== ImageType.Video && x.display &&
          (!productImage || productImage && !productImage.url) && x.isDefault) {
          productImage = x.details.find(item => item.type === imageType);
        }
      });
      if (productImage && productImage.url) {
        if (productImage.url.indexOf('http') === -1) {
          return (environment.cdnURL + '/' + productImage.url);
        } else {
          return productImage.url;
        }
      } else {
        return environment.uiTemplateBaseUrl + '/images/no_image.png';
      }
    } else {
      return environment.uiTemplateBaseUrl + '/images/no_image.png';
    }
  }
}
