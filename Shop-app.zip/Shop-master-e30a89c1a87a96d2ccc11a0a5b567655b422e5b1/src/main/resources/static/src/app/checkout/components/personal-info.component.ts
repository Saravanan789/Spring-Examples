import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { Validators, FormBuilder, AbstractControl } from '@angular/forms';
import { Location } from '@angular/common';
import { PasswordValidation } from '../directives/password-validation';
import {
    ControlsConfig, PersonalInformation, VerifyAccountResponse,
    SponsorInformation, CheckoutInformation, CountryLevelValidations
} from '../interfaces';
import { CheckoutMessageService, EnrollService, SponsorService } from '../services';
import { PersonalInfoComponentSettings } from '../component-settings';
import { MemberType } from '../../shared/enums';
import { CacheService, ConfigurationService, CommonService, ActiveSessionService } from '../../shared/services';
import { StoreConfig, Member, Country, State } from '../../shared/interfaces';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Router } from '@angular/router';
import { AddressComponentSettings } from '../../common/component-settings';
import { Address, TranslateParam } from '../../common/interfaces';
import { AppMessageService } from '../../app-message.service';
import { PersonalInfoFormConstants, DateConstants, ResponseStatus } from '../constants';
import { MaskPipe } from 'ngx-mask';
import { AppConstants } from '../../common/constants/app.constants';
import { DocumentCategoryId, DisplaySectionId, AddressType } from '../../common/enums';
import { Portal } from '../../payment/enums/payment-type.enum';
import * as moment from 'moment';
import { ValidateDateOfBirth } from '../directives/validate-dob';
import { AddressService } from '../../common/services/address.service';
import { ContactTypeValue } from '../enums';

/**
 * @description Used to Save Enroll
 * User Information and Edit User information
 * @author NextSphere Technologies
 * @date 2018-06-27
 * @export
 * @class PersonalInfoComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-personal-info',
    templateUrl: '../templates/template3/views/personal-info.component.html',
    styleUrls: ['../templates/template3/themes/default/less/personal-info.component.less']
})

export class PersonalInfoComponent implements OnInit {
    pInfoComponentSettings: PersonalInfoComponentSettings = new PersonalInfoComponentSettings();
    momentConstructor: (value?: any) => moment.Moment = (<any>moment).default || moment;
    // Input varibles
    registerMemberType: MemberType;

    // ViewChild Attrbutes
    @ViewChild('personalInfoFormBtn') personalInfoFormBtn: ElementRef;
    translateParams: TranslateParam;
    datePickerStartDateAt = new Date();
    constructor(
        private _cacheService: CacheService,
        private _commonService: CommonService,
        private _formBuilder: FormBuilder,
        private _configurationService: ConfigurationService,
        private _sponsorService: SponsorService,
        private _enrollService: EnrollService,
        private _checkoutMessageService: CheckoutMessageService,
        private _appMessageService: AppMessageService,
        private _router: Router,
        private _location: Location,
        private _chRef: ChangeDetectorRef,
        private _maskPipe: MaskPipe,
        private _activeSessionService: ActiveSessionService,
        private _addressService: AddressService,
    ) {
    }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
     * @description it used to load default configuration
     * of the current component based on user
     * @date 2018-07-19
     * @private
     * @memberof PersonalInfoComponent
     */
    private loadDefaultSettings(): void {
        this.setDefaultPickerDate();
        this.pInfoComponentSettings.isoCountryCode = this._cacheService.getCookieValue(CacheKey.countryCode);
        this.pInfoComponentSettings.languageCode = this._cacheService.getCookieValue(CacheKey.languageCode);
        this.removeQueryParamFromCurrentUrl();
        this.pInfoComponentSettings.memberType = MemberType;
        this.registerMemberType = this._cacheService.get(CacheKey.RegisterMemberType) || MemberType.RETAILCUSTOMER;
        this.getStoreData();
        this.pInfoComponentSettings.fpcOptIn = JSON.parse(this._cacheService.get(CacheKey.FPCOptIn));
        if (!this.pInfoComponentSettings.fpcOptIn) {
            this.pInfoComponentSettings.mailingSchemaUrl = this.pInfoComponentSettings.isoCountryCode.toLowerCase()
                + '-mailing-schema-form.json';
        }
        this.pInfoComponentSettings.userInfo = this._activeSessionService.getUserInfo();
        this.getFormValidationsJSON();
        this.fetchTermsConditionDocument();
    }
    /**
     * set default Picker date
     * @memberof PersonalInfoComponent
     */
    setDefaultPickerDate(): void {
        this.datePickerStartDateAt.setFullYear(new Date().getFullYear() - 18);
    }
    /**
     * @description Get member contact and bind data with personalinfo
     * @memberof PersonalInfoComponent
     */
    getMemberContacts(): void {
        if (this.pInfoComponentSettings.userInfo && this.pInfoComponentSettings.userInfo.memberId) {
            this._commonService.getMemberContacts(this.pInfoComponentSettings.userInfo.memberId)
                .subscribe(response => {
                    if (response && response.length) {
                        const memberContacts = response;
                        this.pInfoComponentSettings.memberContact = memberContacts.find(contactType =>
                            (contactType.contactTypeID === ContactTypeValue.PHONE || contactType.contactTypeID === ContactTypeValue.MOBILE));
                        this.rebindPersonalInformation();
                    } else {
                        this.rebindPersonalInformation();
                    }
                }, (error) => {
                    this.rebindPersonalInformation();
                });
        }
    }

    /**
     * @description Get json form validations
     * @memberof PersonalInfoComponent
     */
    getFormValidationsJSON(): void {
        this._commonService.getFormValidationsJSON()
            .subscribe((response: any) => {
                this.getCountrySpecificValidations(response);
                this.createPersonalInfoForm();
            });
    }

    /**
     * @description Get country specific validations
     *
     * @param {CountryLevelValidations[]} validations
     * @memberof PersonalInfoComponent
     */
    getCountrySpecificValidations(validations: CountryLevelValidations[]): void {
        if (validations) {
            const filterCountryLevlValidations = validations
                .find(x => x.countryCode === this.pInfoComponentSettings.isoCountryCode.toUpperCase());
            this.pInfoComponentSettings.personalInfoFormValidations = filterCountryLevlValidations.validations;
        }

    }

    /**
     * @description creating a form for
     * user information
     * @date 2018-07-19
     * @memberof PersonalInfoComponent
     */
    private createPersonalInfoForm(): void {
        this.pInfoComponentSettings.personalInformationForm = this._formBuilder.group(
            this.addCommonFormFields(), this.addValidationsBasedOnRetailOrGuest());
        this.subscribePersonalInfoFormChanges();
        if (this.pInfoComponentSettings.userInfo && this.pInfoComponentSettings.fpcOptIn) {
            this.getMemberContacts();
        } else {
            this.rebindPersonalInformation();
        }
    }

    /**
     * @description Add Common Form Fields
     * @date 2019-02-26
     * @private
     * @returns {ControlsConfig}
     * @memberof PersonalInfoComponent
     */
    private addCommonFormFields(): ControlsConfig {
        const formControls: ControlsConfig = {
            firstName: ['', this.getValidations(PersonalInfoFormConstants.FIRSTNAME)],
            middleName: ['', this.getValidations(PersonalInfoFormConstants.MIDDLENAME)],
            lastName: ['', this.getValidations(PersonalInfoFormConstants.LASTNAME)],
            email: ['', this.getValidations(PersonalInfoFormConstants.EMAIL)],
            phoneNumber: ['', this.getValidations(PersonalInfoFormConstants.PHONENUMBER)],
            phoneType: [ContactTypeValue.MOBILE]
        };
        if (this.pInfoComponentSettings.fpcOptIn) {
            formControls['dateOfBirth'] = ['', [Validators.required, ValidateDateOfBirth.DOBFormat]];
            formControls['governmentId'] = '';
        } else {
            formControls['pass_word'] = ['', this.getValidations(PersonalInfoFormConstants.PASSWORD)];
            formControls['confirmPassword'] = ['', this.getValidations(PersonalInfoFormConstants.CONFIRM_PASSWORD)];
        }
        return formControls;
    }

    /**
     * @description this method is used to
     * assign validations based on reigester member type
     * @date 2018-07-19
     * @private
     * @memberof PersonalInfoComponent
     */
    private addValidationsBasedOnRetailOrGuest(): ControlsConfig {
        if (this.registerMemberType === MemberType.RETAILCUSTOMER && !this.pInfoComponentSettings.fpcOptIn) {
            const formValidations: ControlsConfig = {
                validator: PasswordValidation.MatchPassword
            };
            return formValidations;
        } else {
            return {};
        }
    }

    /**
     * @description validates personal information for usa and canada
     * @private
     * @param {string} fieldName
     * @returns {any[]}
     * @memberof PersonalInfoComponent
     */
    private getValidations(fieldName: string): any[] {
        const fieldValidations = [];
        const formControlName = this.pInfoComponentSettings.personalInfoFormValidations
            ? this.pInfoComponentSettings.personalInfoFormValidations[fieldName]
            : {};
        if (formControlName) {
            if (formControlName[PersonalInfoFormConstants.MINLENGTH]) {
                fieldValidations.push(Validators.minLength(formControlName[PersonalInfoFormConstants.MINLENGTH]));
            }
            if (formControlName[PersonalInfoFormConstants.MAXLENGTH]) {
                fieldValidations.push(Validators.maxLength(formControlName[PersonalInfoFormConstants.MAXLENGTH]));
            }
            if (formControlName[PersonalInfoFormConstants.PATTERN]) {
                fieldValidations.push(Validators.pattern(formControlName[PersonalInfoFormConstants.PATTERN]));
            }
        }
        // regular expression which allows only latin characterset including accent marks
        // tslint:disable-next-line:quotemark
        const nameReg = "^[a-zA-Z0-9~`\\!@#\\$%\\^&*\\(\\)_\\+\\-\\=\\{\\}\\|\"\\:<>\\?,/\\\\.\\[\\];'\\s]*$";
        if (fieldName === PersonalInfoFormConstants.MIDDLENAME || fieldName === PersonalInfoFormConstants.FIRSTNAME
            || fieldName === PersonalInfoFormConstants.LASTNAME || fieldName === PersonalInfoFormConstants.EMAIL) {
            if (this.pInfoComponentSettings.isoCountryCode.toLowerCase() === 'usa'
                || this.pInfoComponentSettings.isoCountryCode.toLowerCase() === 'can') {
                fieldValidations.push(Validators.pattern(nameReg));
            }
        }
        if (fieldName === PersonalInfoFormConstants.FIRSTNAME || fieldName === PersonalInfoFormConstants.LASTNAME
            || fieldName === PersonalInfoFormConstants.EMAIL || fieldName === PersonalInfoFormConstants.PHONENUMBER
            || fieldName === PersonalInfoFormConstants.PASSWORD || fieldName === PersonalInfoFormConstants.CONFIRM_PASSWORD) {
            fieldValidations.push(Validators.required);
        }
        return fieldValidations;
    }

    /**
     * @description this metod is used
     *  to rebind personal information from local storage
     * @date 2018-07-21
     * @private
     * @memberof PersonalInfoComponent
     */
    private rebindPersonalInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        if (checkoutInformation && checkoutInformation.personalInformation && checkoutInformation.personalInformation.address) {
            this.pInfoComponentSettings.personalInformation = checkoutInformation.personalInformation;
            if (this.pInfoComponentSettings.personalInformation.phoneNumber) {
                this.pInfoComponentSettings.personalInformation.phoneNumber = this._maskPipe
                    .transform(this.pInfoComponentSettings
                        .personalInformation.phoneNumber, this._commonService
                            .getPhoneNumberFormatByCountryCode(this.pInfoComponentSettings.isoCountryCode));
            }
            if (this.pInfoComponentSettings.fpcOptIn) {
                this.mapPersonalInformation();
                this.mapFpcOptinPersonalInformation();
                this.getCountriesLookup();
            } else {
                this.mapPersonalInformation();
                this.pInfoComponentSettings.personalInformationForm.patchValue({
                    pass_word: this.pInfoComponentSettings.personalInformation.pass_word,
                    confirmPassword: this.pInfoComponentSettings.personalInformation.confirmPassword
                });
            }
            setTimeout(() => {
                this.getAddressOnInputChange(this.pInfoComponentSettings.personalInformation.address);
            }, 100);
        } else if (this.pInfoComponentSettings.userInfo && this.pInfoComponentSettings.fpcOptIn) {
            this.pInfoComponentSettings.personalInformation = this._enrollService
                .getOptInPersonalInfo(this.pInfoComponentSettings.memberContact);
            this.pInfoComponentSettings.personalInformation.address = null;
            this.mapPersonalInformation();
            this.mapFpcOptinPersonalInformation();
            this.getCountriesLookup();
        }
    }

    /**
     * @description Rebind the personal infomation data
     * @date 2019-02-25
     * @memberof PersonalInfoComponent
     */
    mapPersonalInformation(): void {
        this.pInfoComponentSettings.personalInformationForm.patchValue({
            firstName: this.pInfoComponentSettings.personalInformation.firstName,
            middleName: this.pInfoComponentSettings.personalInformation.middleName,
            lastName: this.pInfoComponentSettings.personalInformation.lastName,
            email: this.pInfoComponentSettings.personalInformation.email,
            phoneNumber: this.pInfoComponentSettings.personalInformation.phoneNumber,
            phoneType: this.pInfoComponentSettings.personalInformation.phoneType
        });
    }

    /**
     * @description Rebind the optin user data
     * @date 2019-02-25
     * @memberof PersonalInfoComponent
     */
    mapFpcOptinPersonalInformation(): void {
        let dateOfBirthValue = null;
        if (this.pInfoComponentSettings.personalInformation && this.pInfoComponentSettings.personalInformation.dateOfBirth) {
            dateOfBirthValue = moment(new Date(this.pInfoComponentSettings.personalInformation.dateOfBirth))
                .format(DateConstants.DateFormat);
        }
        this.pInfoComponentSettings.personalInformationForm.patchValue({
            dateOfBirth: dateOfBirthValue ? moment(dateOfBirthValue, 'DD-MMM-YYYY') : '',
            governmentId: this.pInfoComponentSettings.personalInformation.governmentId
                ? this.pInfoComponentSettings.personalInformation.governmentId : ''
        });
        this.pInfoComponentSettings.personalInformationForm.controls['dateOfBirth']
            .setValidators([Validators.required, ValidateDateOfBirth.DOBFormat]);
        this.pInfoComponentSettings.personalInformationForm.controls['firstName'].disable();
        this.pInfoComponentSettings.personalInformationForm.controls['middleName'].disable();
        this.pInfoComponentSettings.personalInformationForm.controls['lastName'].disable();
        this.pInfoComponentSettings.personalInformationForm.controls['email'].disable();
    }

    /**
 * @description formatting dob to the yyyy-mm-dd
 * @date 2019-01-02
 * @param {LegalRequirements} legalRequirements
 * @returns {LegalRequirements}
 * @memberof PersonalInfoComponent
 */
    dateOfBirthFormat(dateOfBirth: any) { // getting moment object
        const characterCheck = /[a-zA-z]/;
        if (typeof dateOfBirth._i === DateConstants.Object) {
            dateOfBirth = dateOfBirth._d;
            dateOfBirth = this.momentConstructor(new Date(dateOfBirth)).format(DateConstants.DOBFormat);
        }
        if (typeof dateOfBirth._i === DateConstants.String) {
            dateOfBirth = dateOfBirth._i;
            const dateParts = dateOfBirth.split('-');
            if (characterCheck.test(dateParts[1])) {
                dateOfBirth = moment((dateOfBirth), 'DD-MMM-YYYY')
                    .format(DateConstants.DOBFormat);
            } else {
                dateOfBirth = this.momentConstructor(new Date(+dateParts[2], +dateParts[1] - 1, +dateParts[0]))
                    .format(DateConstants.DOBFormat);
            }
        }
        return dateOfBirth;
    }

    /**
     * @description convert date to specific format
     * @date 2019-02-22
     * @param {*} dateMomentObj
     * @memberof PersonalInfoComponent
     */
    convertToSpecificDateFormat(dateMomentObj: any) {
        const characterCheck = /[a-zA-z]/;
        const dateInputPattern = /^[a-zA-Z0-9\-]*$/;
        if (dateMomentObj && dateMomentObj.value && typeof dateMomentObj._i === 'object') {
            dateMomentObj = dateMomentObj._d;
            this.pInfoComponentSettings.personalInformationForm.patchValue({
                dateOfBirth: moment(dateMomentObj, 'DD-MMM-YYYY')
            });
        }
        if (dateMomentObj && dateMomentObj.value && typeof dateMomentObj.value._i === DateConstants.String) {
            dateMomentObj = dateMomentObj.value._i;
            if (dateInputPattern.test(dateMomentObj)) {
                const dateParts = dateMomentObj.split('-');
                if (characterCheck.test(dateParts[1])) {
                    dateMomentObj = moment(dateMomentObj, DateConstants.DateFormat);
                } else {
                    dateMomentObj = moment(new Date(+dateParts[2], +dateParts[1] - 1, +dateParts[0]))
                        .format(DateConstants.DateFormat);
                }
                this.pInfoComponentSettings.personalInformationForm.patchValue({
                    dateOfBirth: moment(dateMomentObj, DateConstants.DateFormat)
                });
                this.datePickerStartDateAt = new Date(dateMomentObj);
            } else {
                this.datePickerStartDateAt = new Date();
            }
        }
    }

    /**
    * @description Get Countries
    * @date 2018-07-19
    * @private
    * @memberof ShippingAddressNewComponent
    */
    private getCountriesLookup(): void {
        if (this._cacheService.get(CacheKey.Countries)) {
            this.pInfoComponentSettings.countries = this._cacheService.get(CacheKey.Countries);
            const selectedCountry =
                this.pInfoComponentSettings.countries.find((x: Country) => x.isocodeThree.toLowerCase() ===
                    this.pInfoComponentSettings.isoCountryCode.toLowerCase());
            if (selectedCountry && selectedCountry.countryId) {
                this.getStatesLookup(selectedCountry.countryId);
            }
        } else {
            this._commonService.getCountries().subscribe((countries: Country[]) => {
                if (countries && countries.length > 0) {
                    this.pInfoComponentSettings.countries = countries;
                    this._cacheService.set(CacheKey.Countries, this.pInfoComponentSettings.countries);
                    const selectedCountry = this.pInfoComponentSettings.countries.
                        find((x: Country) => x.isocodeThree.toLowerCase() === this.pInfoComponentSettings.isoCountryCode.toLowerCase());
                    if (selectedCountry && selectedCountry.countryId) {
                        this.getStatesLookup(selectedCountry.countryId);
                    }
                }
            });
        }
    }

    /**
    * @description this method will load
    * member saved address based on country id
    * @date 2018-07-24
    * @memberof ShippingAddressNewComponent
    */
    getMemberSavedAddresses(): void {
        if (this.pInfoComponentSettings.userInfo && this.pInfoComponentSettings.countries) {
            this.pInfoComponentSettings.displayAddressForm = false;
            const countryId: number = this.pInfoComponentSettings.countries.find((z: Country) => z.isocodeThree.toUpperCase()
                === this.pInfoComponentSettings.isoCountryCode.toUpperCase()).countryId;
            this._addressService.getSavedAddress(this.pInfoComponentSettings.userInfo.memberId, null, AddressType.MAILING)
                .subscribe((memberAddresses: Address[]) => {
                    if (this.pInfoComponentSettings.fpcOptIn && memberAddresses
                        && memberAddresses.length > 0 && memberAddresses[0].countryId !== countryId) {
                        this.getStatesLookup(memberAddresses[0].countryId, memberAddresses);
                    } else {
                        this.processMemberSavedAddressResponse(memberAddresses);
                    }
                }, (error: any) => {
                    this.pInfoComponentSettings.displayAddressForm = true;
                });
        }
    }

    /**
    * @description this method used to process memeber saved
    * address response and set countyid and state codes
    * @date 2018-07-24
    * @param {Address[]} memberAddresses
    * @memberof ShippingAddressNewComponent
    */
    private processMemberSavedAddressResponse(memberAddresses: Address[]): void {
        if (memberAddresses && memberAddresses.length > 0) {
            const memberSavedAddresses: Address[] = [];
            memberAddresses.forEach((x: Address) => {
                x.name = x.shipToName;
                x.zip = x.postalCode;
                const country: Country = this.pInfoComponentSettings.countries.find((z: Country) => z.countryId === x.countryId);
                x.country = country ? country.isocodeThree : '';
                x.countryCode = country ? country.isocodeThree : '';
                const state: State = this.pInfoComponentSettings.states.find((z: State) => z.id === x.stateId);
                x.state = state ? state.stateCode : '';
                x.stateCode = state ? state.stateCode : '';
                memberSavedAddresses.push(x);
            });
            this.pInfoComponentSettings.personalInformation.address = memberSavedAddresses.find(x =>
                x.addressTypeId === AddressType.MAILING);
            if (this.pInfoComponentSettings.personalInformation && this.pInfoComponentSettings.personalInformation.address
                && this.pInfoComponentSettings.personalInformation.address.countryCode && this.pInfoComponentSettings.fpcOptIn) {
                this.pInfoComponentSettings.mailingSchemaUrl =
                    this.pInfoComponentSettings.personalInformation.address.countryCode.toLowerCase() + '-mailing-schema-form.json';
            }
            this.pInfoComponentSettings.displayAddressForm = true;
        } else {
            this.pInfoComponentSettings.displayAddressForm = true;
        }
    }

    /**
     * @description get States
     * @date 2018-07-19
     * @param {number} countryId
     * @memberof ShippingAddressNewComponent
     */
    private getStatesLookup(countryId: number, memberAddresses?: Address[]) {
        const storedStates = this._cacheService.get(
            decodeURIComponent(encodeURIComponent(CacheKey.StatesByCountryId + '_' + countryId)));
        if (storedStates && storedStates.length > 0) {
            this.pInfoComponentSettings.states = storedStates;
            this.getMemberSavedAddresses();
        } else if (countryId) {
            this._commonService.getStatesByCountry(countryId).subscribe((states: State[]) => {
                this.pInfoComponentSettings.states = states;
                if (memberAddresses && memberAddresses.length > 0) {
                    this.processMemberSavedAddressResponse(memberAddresses);
                } else {
                    this.getMemberSavedAddresses();
                }
            }, (err: any) => {
            });
        }
    }

    /**
     * @description this method retives
     * store information from cache service
     * @date 2018-07-19
     * @memberof PersonalInfoComponent
     */
    private getStoreData(): void {
        this.pInfoComponentSettings.phoneNumberFormat =
            this._commonService.getPhoneNumberFormatByCountryCode(this.pInfoComponentSettings.isoCountryCode);
        const result: StoreConfig = this._configurationService.getStoreData();
        if (result) {
            this.pInfoComponentSettings.store = result;
        }
    }

    /**
    * @description this method will validate government id
    * @date 2018-08-16
    * @param {string} governmentId
    * @memberof PersonalInfoComponent
    */
    validateGovernmentId(governmentId: string): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        this.pInfoComponentSettings.governmentIdExist = false;
        this.pInfoComponentSettings.invalidGovernmentId = false;
        if (governmentId && governmentId.length > 0 && governmentId[0] !== '') {
            let memberId = null;
            if (checkoutInformation && checkoutInformation.guestToRetailUser) {
                memberId = checkoutInformation.guestToRetailUser.memberId;
            } else if (this.pInfoComponentSettings.fpcOptIn && this.pInfoComponentSettings.userInfo) {
                memberId = this.pInfoComponentSettings.userInfo.memberId;
            }
            this.pInfoComponentSettings.governmentIdValidInProgress = true;
            this._enrollService.validateGovernmentId(governmentId,
                this.pInfoComponentSettings.isoCountryCode, this.pInfoComponentSettings.store.id, memberId)
                .subscribe((response: any) => {
                    this.pInfoComponentSettings.invalidGovernmentId = false;
                    if (response && response._body === 'false') {
                        this.pInfoComponentSettings.governmentIdExist = false;
                    } else {
                        this.pInfoComponentSettings.governmentIdExist = true;
                    }
                    this.pInfoComponentSettings.governmentIdValidInProgress = false;
                }, (errResponse: any) => {
                    const response = errResponse.json();
                    if (response && response.validations && !response.statusCode
                        && response.validations.length > 0) {
                        this.pInfoComponentSettings.governmentIdValidations = response.validations;
                        this.pInfoComponentSettings.invalidGovernmentId = true;
                    } else {
                        this.pInfoComponentSettings.invalidGovernmentId = false;
                    }
                    this.pInfoComponentSettings.governmentIdExist = false;
                    this.pInfoComponentSettings.governmentIdValidInProgress = false;
                });
        }
    }


    /**
     * @description
     * @param {string} emailId
     * @param {boolean} isValid
     * @memberof PersonalInfoComponent
     */
    verifyEmailAccountExists(emailId: string, isValid: boolean): void {
        if (isValid) {
            this.pInfoComponentSettings.userInfo = null;
            this.pInfoComponentSettings.isShowLoader = true;
            this._enrollService.verifyEmailAccountExists(emailId)
                .subscribe((verifyAccountResponse: VerifyAccountResponse) => {
                    if (verifyAccountResponse.requestStatus === ResponseStatus.COMPLETED
                        || !verifyAccountResponse.requestStatus) {
                        this.pInfoComponentSettings.isShowLoader = false;
                        this.processVerifyEmailAccountExists(verifyAccountResponse);
                    } else if (verifyAccountResponse.requestStatus === ResponseStatus.QUEUED ||
                        verifyAccountResponse.requestStatus === ResponseStatus.IN_PROGRESS) {
                        this.processEmailCheckPoll(verifyAccountResponse);
                    }
                }, (err: any) => {
                    this.pInfoComponentSettings.mailAlreadyExist = false;
                    this.pInfoComponentSettings.isShowLoader = false;
                });
        }
    }

    /**
     * @description this method process
     * response of VerifyEmailAccountExists Method
     * @date 2018-07-19
     * @memberof PersonalInfoComponent
     */
    private processVerifyEmailAccountExists(verifyAccountResponse: VerifyAccountResponse): void {
        this.pInfoComponentSettings.isLegacyUser = false;
        if (verifyAccountResponse) {
            if (verifyAccountResponse.memberTypeId === MemberType.GUESTCUSTOMER) {
                this.pInfoComponentSettings.mailAlreadyExist = false;
                this.pInfoComponentSettings.guestUser = true;
                this.pInfoComponentSettings.userInfo = this._enrollService.mapAccountResponseToUserInfo(verifyAccountResponse);
            } else if (verifyAccountResponse.distributorId && !verifyAccountResponse.memberId) {
                this.pInfoComponentSettings.mailAlreadyExist = true;
                this.pInfoComponentSettings.isLegacyUser = true;
            } else {
                this.pInfoComponentSettings.mailAlreadyExist = true;
            }
        } else {
            this.pInfoComponentSettings.mailAlreadyExist = false;
        }
    }


    /**
     * @description this method will subscribe
     * the changes for form
     * @date 2018-07-20
     * @private
     * @memberof PersonalInfoComponent
     */
    private subscribePersonalInfoFormChanges(): void {
        this.pInfoComponentSettings.personalInformationForm
            .valueChanges.
            subscribe(form => {
                if (this.pInfoComponentSettings.personalInfoFormValidated) {
                    this.pInfoComponentSettings.personalInfoFormValidated = false;
                }
            });
    }

    /**
     * @description this method will
     * process and validate personalinformation,
     * mailing address and sponsor information
     * @date 2018-07-20
     * @param {Event} $event
     * @memberof PersonalInfoComponent
     */
    submitPersonalInformation($event: Event): void {
        this.pInfoComponentSettings.isValidatingSignup = true;
        if (!this._chRef['destroyed']) {
            this._chRef.detectChanges();
        }
        // submiting personal information
        if (this.personalInfoFormBtn && !this.pInfoComponentSettings.governmentIdValidInProgress
            && !this.pInfoComponentSettings.personalInfoFormValidated && !this.pInfoComponentSettings.isShowLoader) {
            this.personalInfoFormBtn.nativeElement.click();
        } else {
            this.setMailingAddress(this.pInfoComponentSettings.personalInfoFormValidated);
        }
    }


    /**
     * @description
     * @param {PersonalInformation} personalInformation
     * @param {boolean} isValid
     * @memberof PersonalInfoComponent
     */
    savePersonalInfo(personalInformation: PersonalInformation, isValid: boolean): void {
        this.pInfoComponentSettings.formSubmitted = true;
        if (this.pInfoComponentSettings.formSubmitted && isValid
            && !this.pInfoComponentSettings.mailAlreadyExist
            && this.pInfoComponentSettings.agreementCheck
            && !this.pInfoComponentSettings.invalidGovernmentId
            && !this.pInfoComponentSettings.governmentIdExist) {
            if (!this.pInfoComponentSettings.fpcOptIn) {
                const retaildocuments = { paymentPolicies: [] };
                retaildocuments.paymentPolicies = this.pInfoComponentSettings.personalInfoTAndC;
                this._cacheService.set(CacheKey.FBOTerms, retaildocuments);
            }
            personalInformation.address = this.pInfoComponentSettings.mailingAddress;
            if (this.pInfoComponentSettings.fpcOptIn && personalInformation.dateOfBirth) {
                personalInformation.dateOfBirth = this.dateOfBirthFormat(personalInformation.dateOfBirth);
            }
            this.pInfoComponentSettings.personalInformation = personalInformation;
            this.pInfoComponentSettings.personalInfoFormValidated = true;
        } else {
            this.pInfoComponentSettings.personalInfoFormValidated = false;
            if (!this.pInfoComponentSettings.fpcOptIn) {
                this.passwordFocusout(this.pInfoComponentSettings.personalInformationForm.controls['pass_word']);
            }
        }
        this.setMailingAddress(isValid);
    }

    /**
     * @description  this method is used to
     * get the verified or sugggested address
     * @date 2018-07-20
     * @param {Address} mailingAddress
     * @memberof PersonalInfoComponent
     */
    getMailingAddressInfo(addressComponentSettings: AddressComponentSettings): void {
        if (addressComponentSettings && addressComponentSettings.addressSubmitted) {
            this.pInfoComponentSettings.personalInformation.address = addressComponentSettings.address;
            this.pInfoComponentSettings.mailingAddress = addressComponentSettings.address;
            this.pInfoComponentSettings.addressSubmitted = addressComponentSettings.addressSubmitted;
            this.setSponsorInformation(this.pInfoComponentSettings.personalInformation.address);
        } else {
            this.pInfoComponentSettings.addressSubmitted = addressComponentSettings.addressSubmitted;
            this.setSponsorInformation(this.pInfoComponentSettings.personalInformation.address);
        }
    }

    /**
     * @description this method will fire when we chaneg textbox value
     * in address block
     * @date 2018-08-20
     * @memberof PersonalInfoComponent
     */
    getAddressOnInputChange(address: Address): void {
        if (!this.pInfoComponentSettings.sponsorInformation) {
            this.pInfoComponentSettings.liveFormAddress = address;
            this._checkoutMessageService.setSponsorPreference(this.pInfoComponentSettings);
        }
    }
    /**
     * To notify Invalid address has Entered
     * @param {boolean} inValid
     * @memberof PersonalInfoComponent
     */
    notifyInvalidAddress(inValid: boolean): void {
        if (inValid) {
            this.pInfoComponentSettings.isValidatingSignup = false;
        }
    }

    /**
     * @description it used fire event in
     * address component to submit address
     * @date 2018-07-20
     * @private
     * @param {boolean} personalInfoFormSubmitted
     * @memberof PersonalInfoComponent
     */
    private setMailingAddress(personalInfoFormSubmitted: boolean): void {
        if (!this.pInfoComponentSettings.addressSubmitted) {
            this._appMessageService.setSubmitAddress(personalInfoFormSubmitted);
        } else {
            this.setSponsorInformation(this.pInfoComponentSettings.personalInformation.address);
        }
    }

    /**
     * @description it used fire event in
     * sponsor component to set spponsor info
     * @date 2018-07-20
     * @private
     * @param {Address} address
     * @memberof PersonalInfoComponent
     */
    private setSponsorInformation(address: Address): void {
        this.pInfoComponentSettings.personalInformation.address = address;
        this.pInfoComponentSettings.liveFormAddress = address;
        if (!this.pInfoComponentSettings.sponsorInformation) {
            this.pInfoComponentSettings.isValidatingSignup = false;
            this._checkoutMessageService.setSponsorPreference(this.pInfoComponentSettings);
        } else if (this.pInfoComponentSettings.addressSubmitted) {
            if (AppConstants.enableSponsorEligibilityCheck) {
                this._sponsorService.sponsorEligibilityCheck(this.pInfoComponentSettings.sponsorInformation.sponsorId,
                    this.pInfoComponentSettings.sponsorInformation.sponsorCountryCode).subscribe(res => {
                        if (res && res.isSuccess) {
                            this.navigateToShipping();
                        } else {
                            this.pInfoComponentSettings.isValidatingSignup = false;
                            this._checkoutMessageService.setSponsorEligibility(false);
                        }
                    });
            } else {
                this.navigateToShipping();
            }
        }
    }

    /**
     * @description this method is used
     * to get selected sponsorinfo from sposor component
     * @date 2018-07-20
     * @memberof PersonalInfoComponent
     */
    getSelectedSponserInfo(sponsorInformation: SponsorInformation): void {
        this.pInfoComponentSettings.sponsorInformation = sponsorInformation;
    }

    /**
     * @description it used to navigate from
     * personalinformation to shipping
     * @date 2018-07-20
     * @memberof PersonalInfoComponent
     */
    private navigateToShipping(): void {
        if (this.pInfoComponentSettings.personalInfoFormValidated
            && this.pInfoComponentSettings.addressSubmitted
            && this.pInfoComponentSettings.sponsorInformation) {
            this.saveCheckoutInformation();
            this._router.navigate([this.pInfoComponentSettings.isoCountryCode + '/'
                + this.pInfoComponentSettings.languageCode.toLowerCase() + '/checkout/shipping']);
        } else {
            // OnSubmit progressbar
            this.pInfoComponentSettings.isValidatingSignup = false;
        }
    }

    /**
     * @description Saving Checkout Information
     * @date 2018-07-20
     * @memberof PersonalInfoComponent
     */
    private saveCheckoutInformation(): void {
        const checkoutInformation: CheckoutInformation = this._cacheService.get(CacheKey.CheckoutInformation) || {};
        if (this.pInfoComponentSettings.personalInformation) {
            if (this.pInfoComponentSettings.personalInformation.phoneNumber) {
                this.pInfoComponentSettings.personalInformation.phoneNumber = this.pInfoComponentSettings
                    .personalInformation.phoneNumber.replace(/[^a-zA-Z0-9]/g, '');
            } else {
                this.pInfoComponentSettings.personalInformation.phoneNumber = null;
            }
        }
        checkoutInformation.personalInformation = this.pInfoComponentSettings.personalInformation;
        if (checkoutInformation.personalInformation && checkoutInformation.personalInformation.address) {
            checkoutInformation.personalInformation.address.phone = checkoutInformation.personalInformation.phoneNumber;
            checkoutInformation.personalInformation.address.phoneType = checkoutInformation.personalInformation.phoneType;
        }
        checkoutInformation.sponsorInformation = this.pInfoComponentSettings.sponsorInformation;
        checkoutInformation.guestToRetailUser = this.pInfoComponentSettings.userInfo || checkoutInformation.guestToRetailUser;
        if (this.pInfoComponentSettings.fpcOptIn && checkoutInformation.guestToRetailUser && checkoutInformation.personalInformation) {
            checkoutInformation.personalInformation.firstName = checkoutInformation.guestToRetailUser.firstName;
            checkoutInformation.personalInformation.middleName = checkoutInformation.guestToRetailUser.middleName;
            checkoutInformation.personalInformation.lastName = checkoutInformation.guestToRetailUser.lastName;
            checkoutInformation.personalInformation.email = checkoutInformation.guestToRetailUser.email;
        }
        this._cacheService.set(CacheKey.CheckoutInformation, checkoutInformation);
    }
    /**
     * Removes the Query Parameters from URL
     */
    removeQueryParamFromCurrentUrl(): void {
        if (window.location.href.indexOf('?') > -1) {
            this._location.replaceState('/' + this.pInfoComponentSettings.isoCountryCode
                + '/' + this.pInfoComponentSettings.languageCode + '/checkout/personalinfo');
        }
    }

    /**
     * @description this method will navigate user to
     * login page
     * @date 2018-08-01
     * @memberof PersonalInfoComponent
     */
    memberLogin(): void {
        const email = this.pInfoComponentSettings.personalInformationForm.controls['email'];
        if (email && email.value) {
            this._cacheService.setCookieValue(CacheKey.SSO_Username, email.value);
        }
        this._commonService.navigateToLogin(false);
    }

    /**
     * @description this method will be used to get addressverification info
     * if we get value true will hide the personalinfo and sponsor info section
     * if we get will display the personalinfo and sponsor info section
     * this processs will occur while browsing from mobile
     * @date 2018-08-03
     * @memberof PersonalInfoComponent
     */
    getAddressVerificationInfo(displayAddressVerification: boolean): void {
        this.pInfoComponentSettings.displayAddressVerification = displayAddressVerification;
    }

    /**
     * @description this method will be used
     * set auto populate data
     * @date 2018-08-08
     * @memberof PersonalInfoComponent
     */
    autoPopulate(): void {
        if (!this.pInfoComponentSettings.fpcOptIn) {
            this.pInfoComponentSettings.displayAddressForm = false;
            this.pInfoComponentSettings.isAutoPopulate = true;
            this.pInfoComponentSettings.personalInformation = this._enrollService
                .getAutoPopulateInformation(this.pInfoComponentSettings.isoCountryCode.toLowerCase());
            this.saveCheckoutInformation();
            this.rebindPersonalInformation();
            setTimeout(() => {
                this.pInfoComponentSettings.displayAddressForm = true;
            }, 100);
            setTimeout(() => {
                this.pInfoComponentSettings.isAutoPopulate = false;
            }, 2000);
        }
    }

    /**
     * @description
     * @param {string} phoneNumber
     * @param {boolean} isValid
     * @memberof PersonalInfoComponent
     */
    verifyPhoneNumberAccountExists(phoneNumber: string, isValid: boolean): void {
        if (isValid) {
            this.pInfoComponentSettings.userInfo = null;
            this.pInfoComponentSettings.isShowPhoneNumberLoader = true;
            this._enrollService.verifyPhoneNumberAccountExists(phoneNumber)
                .subscribe((verifyAccountResponse: boolean) => {
                    this.pInfoComponentSettings.isShowPhoneNumberLoader = false;
                    this.pInfoComponentSettings.phoneNumberAlreadyExists = verifyAccountResponse;
                }, (err: any) => {
                    this.pInfoComponentSettings.isShowPhoneNumberLoader = false;
                    this.pInfoComponentSettings.phoneNumberAlreadyExists = false;
                });
        }
    }

    passwordFocusout(control: AbstractControl): void {
        if (control.hasError('minlength') || control.hasError('patternValidator')) {
            this.pInfoComponentSettings.isPopoverOpen = true;
        } else {
            this.pInfoComponentSettings.isPopoverOpen = false;
        }
    }

    /**
     * @description get Terms and Conditions Document
     * fetchTermsConditionDocument
     * @memberof PaymentComponent
     */
    fetchTermsConditionDocument(): void {
        const userInfo: Member = this._cacheService.get(CacheKey.UserInfo);
        const registerMemberType = this._cacheService.get(CacheKey.RegisterMemberType);
        if (!userInfo && registerMemberType === MemberType.RETAILCUSTOMER) {
            const documents = this._cacheService.get(CacheKey.FBOTerms);
            const customerTypeId = this._commonService.getCustomerTypeId();
            const displaySectionId = DisplaySectionId.Sign_up;
            // const customerTypeId = MemberLevel.ASSISTANTSUPERVISOR;
            // const documentCategoryIds = DocumentCategoryId.TERMS_CONDITIONS + ',' + DocumentCategoryId.PRIVACY_NOTICE;
            this._commonService.getDocuments(Portal.Join,
                customerTypeId, displaySectionId)
                .subscribe((response) => {
                    if (response && response.length > 0 && response[0].body && response[0].body.length > 0) {
                        this.pInfoComponentSettings.personalInfoTAndC = response[0].body;
                        this.pInfoComponentSettings.personalInfoTAndC.forEach(agreement => {
                            agreement.isSelected = false;
                        });
                        if (documents && documents.paymentPolicies) {
                            const selectedDocuments = documents.paymentPolicies.filter(document => document.isSelected);
                            if (selectedDocuments && selectedDocuments.length) {
                                this.pInfoComponentSettings.personalInfoTAndC.forEach(agreement => {
                                    agreement.isSelected = true;
                                });
                                this.pInfoComponentSettings.agreementCheck = true;
                            }
                        } else {
                            if (!this.pInfoComponentSettings.fpcOptIn) {
                                const retaildocuments = { paymentPolicies: [] };
                                retaildocuments.paymentPolicies = response[0].body;
                                this._cacheService.set(CacheKey.FBOTerms, retaildocuments);
                            }
                        }
                    }
                }, (error: any) => {
                    this.translateParams = this._commonService.handleError(error);
                });
        } else {
            this.pInfoComponentSettings.agreementCheck = true;
        }
    }

    /**
   * @description
   * @date 2018-09-17
   * @memberof CartComponent
   */
    onChangeAgreements(index: number): void {
        this.pInfoComponentSettings.personalInfoTAndC[index].isSelected = !this.pInfoComponentSettings.personalInfoTAndC[index].isSelected;
        const unselectedAgreements = this.pInfoComponentSettings.personalInfoTAndC.filter(agreement => !agreement.isSelected);
        if (unselectedAgreements && unselectedAgreements.length > 0) {
            this.pInfoComponentSettings.agreementCheck = false;
            this.pInfoComponentSettings.agreementCheckError = true;
        } else {
            this.pInfoComponentSettings.agreementCheck = true;
        }
    }

    showFocus(e: any) {

        // e.currentTarget.nextElementSibling.nextElementSibling.style.outline = 'auto 2px #72a0ec';
    }
    removeFocus(e: any) {

        // e.currentTarget.nextElementSibling.nextElementSibling.style.outline = 'none';
    }

    /**
   * @description
   * @date 2018-09-17
   * @memberof PersonalInfoComponent
   */
    processEmailCheckPoll(verifyAccountResponse: VerifyAccountResponse) {
        if (this.pInfoComponentSettings.intialPollCount < this.pInfoComponentSettings.maxPollCount) {
            this._enrollService.processPollRequest(verifyAccountResponse.location)
                .subscribe(responseObj => {
                    if (responseObj.requestStatus === ResponseStatus.COMPLETED) {
                        this.pInfoComponentSettings.isShowLoader = false;
                        this.processVerifyEmailAccountExists(responseObj);
                    } else {
                        this.processEmailCheckPoll(responseObj);
                    }
                }, errorResponse => {
                    this.pInfoComponentSettings.mailAlreadyExist = false;
                    this.pInfoComponentSettings.isShowLoader = false;
                });
        }
    }
}
