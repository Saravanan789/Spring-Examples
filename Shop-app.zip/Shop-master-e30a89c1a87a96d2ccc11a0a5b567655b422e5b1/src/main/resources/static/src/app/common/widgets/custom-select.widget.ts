import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Http } from '@angular/http';
import { JsonSchemaFormService } from 'angular4-json-schema-form-updated';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import { CacheService } from '../../shared/services/cache.service';
import { environment } from '../../../environments/environment';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { ContactTypeConstants } from '../../checkout/constants';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'custom-select-widget',
  template: `  <!-- [class]="options?.htmlClass || ''"-->
  <div [class.floatLabelContainer]="true">
  <label *ngIf="options?.title"
    [attr.for]="'control' + layoutNode?._id"
    [class]="options?.labelHtmlClass"
    [style.display]="options?.notitle ? 'none' : ''"
    [innerHTML]="options?.title"></label>
  <select float-label [attr.data-placeholder]="options?.selectText"
    [formControl]="formControl"
    [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
    [attr.readonly]="options?.readonly ? 'readonly' : null"
    [attr.required]="options?.required"
    [class]="options?.fieldHtmlClass"
    [disabled]="controlDisabled"
    [id]="'control' + layoutNode?._id"
    [name]="controlName"
    (change)="updateValue($event)">
    <option *ngFor="let selectItem of list"
       [value]="selectItem.value"
       [selected]="selectItem.value === controlValue">{{selectItem.name}}</option>
  </select>
  </div>`,
})
export class CustomSelectWidgetComponent implements OnInit, OnDestroy {
  formControl: AbstractControl;
  controlName: string;
  controlValue: any;
  controlDisabled = false;
  boundControl = false;
  options: any;
  list: any[] = [];
  data: any[];
  optionsGetUrl: any;
  @Input() formID: number;
  @Input() layoutNode: any;
  @Input() layoutIndex: number[];
  @Input() dataIndex: number[];

  constructor(private jsf: JsonSchemaFormService, private _http: Http,
    private chRef: ChangeDetectorRef,
    private _cacheService: CacheService, ) {
  }

  ngOnInit() {
    this.options = this.layoutNode.options || {};
    if (this.options) {
      this.jsf.initializeControl(this);
      if (this.layoutNode && this.layoutNode.name === 'phoneType') {
        this.getContactTypes();
      } else {
        this.optionsGetUrl = environment.apiUrl + this.options.optionGetUrl;
        this.getServiceData();
      }
    }
  }

  /**
   * This method used for getting contact types for phone number
   * getContactTypes()
   */
  getContactTypes(): void {
    this.list = ContactTypeConstants.phoneTypes;
  }

  /**
   * @param  {any} event
   */
  updateValue(event: any) {
    this.jsf.updateValue(this, event.target.value);
  }

  /**
   * @returns Observable
   */
  getApiResponse(): Observable<any> {
    return this._http
      .get(this.optionsGetUrl)
      .map((response: any) => response.json());
  }

  /**
   * @returns void
   */
  getServiceData(): void {
    if (this.optionsGetUrl) {
      if (this.optionsGetUrl.indexOf('/states?countryID=') > 0 || this.optionsGetUrl.indexOf('/countries') > 0) {
        const countryID = this.getParameterByName('countryID', this.optionsGetUrl);
        let stateOrCountries: any[] = [];
        if (countryID) {
          stateOrCountries = this._cacheService.get(CacheKey.StatesByCountryId + '_' + countryID);
        } else {
          stateOrCountries = this._cacheService.get(CacheKey.Countries);
        }
        if (countryID && stateOrCountries && stateOrCountries.length > 0) {
          this.populateSelectBoxValues(this._cacheService.get(CacheKey.StatesByCountryId + '_' + countryID));
        } else if (this.optionsGetUrl.indexOf('/states?countryID=') > 0 && countryID) {
          this.getSelectApiResponse();
        } else if (!countryID && this.optionsGetUrl.indexOf('/countries') > 0 && stateOrCountries && stateOrCountries.length > 0) {
          this.populateSelectBoxValues(this._cacheService.get(CacheKey.Countries));
        } else {
          this.getSelectApiResponse();
        }
      } else {
        this.getSelectApiResponse();
      }
    }
  }

  /**
   * @returns void
   */
  private getSelectApiResponse(): void {
    this.getApiResponse()
      .subscribe((response: any[]) => {
        this.populateSelectBoxValues(response);
      },
        (err: HttpErrorResponse) => {
          if (err.error instanceof Error) {
          } else {
          }
        });
  }

  /**
   * @param  {string} name
   * @param  {string} url
   * @returns string
   */
  private getParameterByName(name: string, url: string): string {
    const match = RegExp('[?&]' + name + '=([^&]*)').exec(url);
    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
  }

  /**
   * @param  {any[]} response
   * @returns void
   */
  private populateSelectBoxValues(response: any[]): void {
    if (response) {
      this.data = response;
      if (this.data.length > 0) {
        let selectText = '';
        if (this.options.selectText && this.options.selectText.endsWith('*')) {
          selectText = this.options.selectText.slice(0, -1);
        } else {
          selectText = this.options.selectText;
        }
        const defaultOpt = {
          name: selectText || 'Select',
          value: ''
        };
        const schema = this.jsf.schema.properties['' + this.controlName];
        let defaultValue = null;
        if (this.options && this.options.nameField && this.options.valueField) {
          const nameField = this.options.nameField;
          const valueField = this.options.valueField;
          const ctx = this;
          // JSON.stringify(ctx.prepareListMap(x))
          const selectOptions = this.data.map(function (x) {
            return {
              name: x[nameField], value: x[valueField]
            };
          });
          if (this.options.default && this.options.filterField) {
            const defaultObj = this.data.find(x => x['' + this.options.filterField] === this.options.default);
            if (defaultObj) {
              defaultValue = defaultObj[this.options.filterField];
              this.controlValue = defaultValue;
            }
          }
          this.list = this.list.concat(selectOptions);
        } else {
          this.list = this.data;
        }
        this.list.splice(0, 0, defaultOpt);
        this.jsf.initializeControl(this);
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
        if (this.options.default && this.options.filterField) {
          this.controlValue = defaultValue;
          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        }
      }
    }
  }

  private prepareListMap(obj: any): any {
    const schema = this.jsf.schema.properties['' + this.controlName];
    const mapObj = {};
    Object.keys(schema.properties).forEach((x: any) => {
      mapObj['' + x] = obj['' + x];
    });
    return mapObj;
  }

  ngOnDestroy() {
    this.chRef.detach();
  }
}
