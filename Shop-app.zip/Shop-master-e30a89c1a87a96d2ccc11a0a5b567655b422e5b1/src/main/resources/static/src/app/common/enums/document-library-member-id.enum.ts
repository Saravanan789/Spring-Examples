export enum DocumentLibraryMemberId {
    Preferred_Customer = 17,
    Distributor = 3,
    Novus = 2,
    Retail = 1
}

export enum DocumentCategoryId {
    Company_Policy = 2,
    Checkout_Policy = 6,
    PRIVACY_NOTICE = 3,
    TERMS_CONDITIONS = 4
}
export enum DisplaySectionId {
    Shopping_Bag = 1,
    Sign_up = 2,
    Profile = 3,
    Payment = 4,
    MyAction_Center = 5

}

