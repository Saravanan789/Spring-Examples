import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonService, CacheService, ConfigurationService, ActiveSessionService } from '../../shared/services';
import { PaymentService, WorldpayXMLService } from '../services';
import { PaymentComponentSettings, WorldpayXMLComponentSettings } from '../component-settings';
import { CacheKey } from '../../shared/constants/cachekey.constants';
import { Country } from '../../shared/interfaces';
import { PaymentStatus, PaymentProcessorAlias } from '../enums';
import { Address } from '../../common/interfaces';
import {
    WorldpayXMLRegistration, PaymentRegistrationResponse,
    WorldpayXMLPaymentService, PaymentCallBackUrl, PayvisionSavedCardResponse, PayvisionSavedCard
} from '../interfaces';
import { CheckoutInformation, PaymentInformation } from '../../checkout/interfaces';
import { PaymentConstants } from '../constants';
import { ApiUrlConstants } from '../../common/constants/api.constants';
import { Cart } from '../../shared/models';
import { MemberType } from '../../shared/enums';
import { FormBuilder, Validators } from '@angular/forms';
import { DeliveryOptionType } from '../../checkout/enums';
import { AppSectionSpinnerService } from '../../common/services/section-spinner.service';
declare let WPCL: any;

/**
 * @description this component provides payment functionality
 * with worldpay provider and will load base settings from parent
 * payment component like store and countries
 * @date 2018-07-26
 * @export
 * @class WorldpayComponent
 * @implements {OnInit}
 */
@Component({
    selector: 'app-worldpay-xml',
    templateUrl: '../templates/template3/views/worldpay-xml.component.html',
    styleUrls: [
        '../templates/template3/themes/default/less/worldpay-xml.component.less'
    ]
})

export class WorldPayXMLComponent implements OnInit {
    wxmlComponentSettings: WorldpayXMLComponentSettings = new WorldpayXMLComponentSettings();

    // Input variables
    // tslint:disable-next-line:no-input-rename
    @Input('paymentComponentSettings') paymentComponentSettings: PaymentComponentSettings;
    // tslint:disable-next-line:no-input-rename
    @Input('enablePlaceOrder') enablePlaceOrder: boolean;
    // Output variables
    @Output() submitPayment = new EventEmitter<any>();

    constructor(
        private _commonService: CommonService,
        private _activeSessionService: ActiveSessionService,
        private _cacheService: CacheService,
        private _paymentService: PaymentService,
        private _worldpayXMLService: WorldpayXMLService,
        private _formBuilder: FormBuilder,
        private _sectionSpinnerService: AppSectionSpinnerService,
        private _configurationService: ConfigurationService) { }

    ngOnInit(): void {
        this.loadDefaultSettings();
    }

    /**
    * @description Load Default shipping Settings
    * for the current user
    * @date 2018-07-20
    * @memberof WorldPayComponent
    */
    loadDefaultSettings() {
        this.wxmlComponentSettings = Object.assign(this.wxmlComponentSettings, this.paymentComponentSettings);
        this.wxmlComponentSettings.checkoutInformation = this._cacheService.get(CacheKey.CheckoutInformation);
        const cartSession: Cart = this._cacheService.get(CacheKey.CartSessionInfo);
        if (cartSession && cartSession.items && cartSession.items.length > 0) {
            this.wxmlComponentSettings.shoppingCart = new Cart(cartSession, this.wxmlComponentSettings.store);
        }
        if (this.wxmlComponentSettings.userInfo) {
            this.loadSavedWorldPayCardsForMemberId();
        } else {
            this.getWorldplayXMLPaymentForm();
        }
    }

    /**
     * @description
     * @date 2018-08-14
     * @memberof WorldPayComponent
     */
    loadSavedWorldPayCardsForMemberId(): void {
        this._worldpayXMLService.
            getSavedWorldpayCards(this.wxmlComponentSettings.userInfo.memberId,
                this.wxmlComponentSettings.isoCountryCode)
            .subscribe((payvisionSavedCardResponse: PayvisionSavedCardResponse) => {
                if (payvisionSavedCardResponse && payvisionSavedCardResponse.savedCards
                    && payvisionSavedCardResponse.savedCards.length > 0) {
                    this.wxmlComponentSettings.savedCards = payvisionSavedCardResponse.savedCards;
                    this.paymentComponentSettings.paymentMethodTypeForm.enable();
                    this.preloadDefaultSavedCard();
                } else {
                    this.getWorldplayXMLPaymentForm();
                }
            }, (error: Response) => {
                this.getWorldplayXMLPaymentForm();
            });
    }

    /**
     * @description this method will preselct the
     * default saved card
     * @date 2018-08-14
     * @private
     * @memberof WorldPayComponent
     */
    private preloadDefaultSavedCard(): void {
        this.paymentComponentSettings.enablePaymentOptions = true;
        this.wxmlComponentSettings.worldpayFormLoaded = false;
        this.wxmlComponentSettings.paymentWithSavedCard = true;
        this.wxmlComponentSettings.selectedPayvisionSavedCard = this.wxmlComponentSettings.
            savedCards.find(x => x.defaultCard) || this.wxmlComponentSettings.savedCards[0];
        this.createSavedPayvisionCardForm(this.wxmlComponentSettings.selectedPayvisionSavedCard.id);
    }

    /**
     * @description this method will load new payvison form
     * @date 2018-08-14
     * @memberof WorldPayComponent
     */
    addNewCard(): void {
        this.wxmlComponentSettings.paymentWithSavedCard = false;
        this.wxmlComponentSettings.selectedPayvisionSavedCard = null;
        this.getWorldplayXMLPaymentForm();
    }

    /**
    * @description creating a form for
    * shipping method information
    * @date 2018-07-19
    * @memberof WorldPayComponent
    */
    private createSavedPayvisionCardForm(savedCardId: number): void {
        this.wxmlComponentSettings.savedPayvisionCardForm = this._formBuilder.group({
            savedCardId: [savedCardId, Validators.required]
        });
    }

    /**
         * @description this method select payvision card
         * @date 2018-08-14
         * @memberof WorldPayComponent
         */
    selectWorlpaySavedCard(savedCard: PayvisionSavedCard): void {
        this.wxmlComponentSettings.selectedPayvisionSavedCard = savedCard;
    }

    /**
     * @description this method will process payment with saved card
     * @date 2018-08-14
     * @memberof WorldPayComponent
     */
    processPaymentWithSavedCard() {
        this.wxmlComponentSettings.paymentInformation = this.getPaymentInformation();
        this.submitPayment.emit(this.wxmlComponentSettings.paymentInformation);
    }

    /**
    * @description
    * @date 2018-08-08
    * @private
    * @param {PayvisionRegistrationResponse} payvisionRegistrationResponse
    * @returns {PaymentInformation}
    * @memberof WorldPayComponent
    */
    private getPaymentInformation(): PaymentInformation {
        const paymentInformation: PaymentInformation = {
            paymentToken: this.wxmlComponentSettings.selectedPayvisionSavedCard.token,
            billingAddress: this.getBillingAddress(),
            isEnrollment: false,
            selectedPaymentMethod: this.wxmlComponentSettings.selectedPaymentMethod,
            isCompleteRedirection: false,
        };
        return paymentInformation;
    }

    /**
    * @description to get the Payment form
    * @date 2018-07-27
    * @memberof WorldPayComponent
    */
    getWorldplayXMLPaymentForm(): void {
        setTimeout(() => {
            this._sectionSpinnerService.start('creditCard-WP');
        }, 0);
        const isAutoshipEnabled = Boolean(this._cacheService.getCookieValue(CacheKey.IsAutoshipEnabled));
        if (isAutoshipEnabled) {
            this._worldpayXMLService
                .getWorldpayXMLForm(this.wxmlComponentSettings.store.id, this.getWorldpayXMLRegistrationRequest())
                .subscribe((response: PaymentRegistrationResponse) => {
                    this.loadWorldplayXMLForm(response);
                });
        } else {
            this._worldpayXMLService
                .getWorldpayXMLForm(this.wxmlComponentSettings.store.id, this.getWorldpayXMLRegistrationRequestWithWebOrder())
                .subscribe((response: PaymentRegistrationResponse) => {
                    this.loadWorldplayXMLForm(response);
                });
        }
    }

    /**
    * @description to load the Worldplay XML
    * Registration Checkout form
    * @date 2018-07-27
    * @memberof WorldPayComponent
    */
    loadWorldplayXMLForm(registrationResponse: PaymentRegistrationResponse): void {
        let language;
        if (this.paymentComponentSettings.languageCode) {
            language = this.paymentComponentSettings.languageCode.split('-')[0];
        }
        if (this.wxmlComponentSettings.checkoutInformation && WPCL
            && registrationResponse && registrationResponse.paymentUrl) {
            const customOptions = {
                iframeHelperURL: window.location.href,
                iframeBaseURL: window.location.origin,
                iframeIntegrationID: 'ifr',
                url: registrationResponse.paymentUrl,
                target: 'iframeRes',
                type: 'iframe',
                inject: 'immediate',
                language: language ? language : 'en'
            };
            const libraryObject = new WPCL.Library();
            if (libraryObject) {
                libraryObject.setup(customOptions);
            }
        }
        setTimeout(() => {
            this.paymentComponentSettings.paymentMethodTypeForm.enable();
            this.wxmlComponentSettings.worldpayFormLoaded = true;
            this._sectionSpinnerService.stop('creditCard-WP');
        }, 2000);
    }

    /**
     * @description preparing the WorldPay XML Registration with weborder
     * checkout form request
     * @date 2018-07-27
     * @returns {WorldpayXMLRegistration}
     * @memberof WorldPayComponent
     */
    getWorldpayXMLRegistrationRequestWithWebOrder(): WorldpayXMLRegistration {
        const checkoutInformation: CheckoutInformation = this.wxmlComponentSettings.checkoutInformation;
        if (checkoutInformation && checkoutInformation.orderDetails) {
            const worldpayXMLRegistration: WorldpayXMLRegistration = {
                countryCode: this.wxmlComponentSettings.isoCountryCode.toUpperCase(),
                customerId: this._paymentService.getCustomerId(),
                storeId: this.wxmlComponentSettings.store.id,
                orderTypeId: this._activeSessionService.getOrderTypeId(),
                paymentMethodType: this.wxmlComponentSettings.paymentMethodTypes.Credit_Card,
                currencyCode: this.wxmlComponentSettings.store.currencyCode,
                orderReferenceId: checkoutInformation.orderDetails.id,
                paymentRequestModel: {
                    createRegistartion: this.wxmlComponentSettings.registerMemberType !== MemberType.GUESTCUSTOMER ? true : false,
                    webOrderId: checkoutInformation.orderDetails.webOrderId
                },
                paymentCallBackUrlModel: this.getPaymentCallBackURLModel(checkoutInformation),
                billingAddress: this.getBillingAddress(),
                paymentServiceModel: this.getPaymentServiceModel(checkoutInformation)
            };
            return worldpayXMLRegistration;
        }
    }

    /**
     * @description preparing the WorldPay XML Registration Form
     * checkout form request
     * @date 2018-07-27
     * @returns {WorldpayXMLRegistration}
     * @memberof WorldPayComponent
     */
    getWorldpayXMLRegistrationRequest(): WorldpayXMLRegistration {
        const worldpayXMLRegistration: WorldpayXMLRegistration = {
            countryCode: this.wxmlComponentSettings.isoCountryCode.toUpperCase(),
            customerId: this._paymentService.getCustomerId(),
            storeId: this.wxmlComponentSettings.store.id,
            orderTypeId: this._activeSessionService.getOrderTypeId(),
            paymentMethodType: this.wxmlComponentSettings.paymentMethodTypes.Credit_Card,
            currencyCode: this.wxmlComponentSettings.store.currencyCode,
            paymentRequestModel: {
                createRegistartion: true,
            },
            paymentCallBackUrlModel: {
                cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
                failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
                successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
            },
            billingAddress: this.getBillingAddress(),
            paymentServiceModel: this.getPaymentServiceModelForAutoship()
        };
        return worldpayXMLRegistration;
    }

    /**
     * @description this method will return payment call urls
     * @date 2018-08-22
     * @private
     * @returns {PaymentCallBackUrl}
     * @memberof WorldPayXMLComponent
     */
    private getPaymentCallBackURLModel(checkoutInformation: CheckoutInformation): PaymentCallBackUrl {
        const paymentCallBackUrlModel: PaymentCallBackUrl = {
            webOrderId: checkoutInformation.orderDetails.webOrderId,
            cancelledUrl: this.getCurrentWindowUrl() + PaymentStatus.CANCELLED.toLowerCase(),
            failureUrl: this.getCurrentWindowUrl() + PaymentStatus.FAILED.toLowerCase(),
            successUrl: this.getCurrentWindowUrl() + PaymentStatus.SUCCESS.toLowerCase(),
        };
        return paymentCallBackUrlModel;
    }

    /**
     * @description this method will return world pay xml
     * request model
     * @date 2018-08-21
     * @private
     * @returns {WorldpayXMLPaymentService}
     * @memberof WorldPayXMLComponent
     */
    private getPaymentServiceModel(checkoutInformation: CheckoutInformation): WorldpayXMLPaymentService {
        const userEmail: string = this.wxmlComponentSettings.userInfo ? this.wxmlComponentSettings.userInfo.email :
            checkoutInformation && checkoutInformation.personalInformation
                ? checkoutInformation.personalInformation.email : '';
        let description = '';
        if (this.wxmlComponentSettings.shoppingCart && this.wxmlComponentSettings.shoppingCart.items
            && this.wxmlComponentSettings.shoppingCart.items.length > 0) {
            description = this.wxmlComponentSettings.shoppingCart.items[0].name;
        }
        const paymentServiceModel: WorldpayXMLPaymentService = {
            submit: {
                order: {
                    orderCode: checkoutInformation.orderDetails.webOrderId,
                    description: description,
                    amount: {
                        currencyCode: this.wxmlComponentSettings.store.currencyCode,
                        exponent: this.wxmlComponentSettings.store.numberDecimals
                    },
                    paymentMethodMask: {
                        include: {
                            code: PaymentConstants.paymentMethodMaskCode
                        }
                    },
                    shopper: {
                        shopperEmailAddress: userEmail
                    }
                }
            }
        };
        return paymentServiceModel;
    }

    /**
     * @description Payment Service model for autoship
     * @date 2018-10-30
     * @private
     * @returns {WorldpayXMLPaymentService}
     * @memberof WorldPayXMLComponent
     */
    private getPaymentServiceModelForAutoship(): WorldpayXMLPaymentService {
        const userEmail: string = this.wxmlComponentSettings.userInfo ? this.wxmlComponentSettings.userInfo.email : '';
        const description = PaymentProcessorAlias.WORLDPAYXML;
        const paymentServiceModel: WorldpayXMLPaymentService = {
            submit: {
                order: {
                    description: description,
                    amount: {
                        currencyCode: this.wxmlComponentSettings.store.currencyCode,
                        exponent: this.wxmlComponentSettings.store.numberDecimals
                    },
                    paymentMethodMask: {
                        include: {
                            code: PaymentConstants.paymentMethodMaskCode
                        }
                    },
                    shopper: {
                        shopperEmailAddress: userEmail
                    }
                }
            }
        };
        return paymentServiceModel;
    }

    /**
     * @description this method will return current window url
     * @date 2018-08-13
     * @private
     * @returns {string}
     * @memberof WorldPayComponent
     */
    private getCurrentWindowUrl(): string {
        const currentWindowURL: string = window.location.origin + '/' + this.wxmlComponentSettings.isoCountryCode +
            '/' + this.wxmlComponentSettings.languageCode + '/checkout/payment/'
            + PaymentProcessorAlias.WORLDPAYXML.toLowerCase() + '/';
        return currentWindowURL;
    }

    /**
    * @description mapping the billing address in the
    * WorldPay XML payment form
    * @date 2018-07-27
    * @private
    * @returns {WorldPay XMLBillingAddress}
    * @memberof WorldPayComponent
    */
    private getBillingAddress(): Address {
        const shippingInformation = this.wxmlComponentSettings.checkoutInformation.shippingInformation;
        let memberAddress: Address;
        if (shippingInformation && shippingInformation.shippingAddress
            && shippingInformation.deliveryOptionType === DeliveryOptionType.Delivery) {
            memberAddress = this.wxmlComponentSettings.checkoutInformation.shippingInformation.shippingAddress;
        } else if (this.wxmlComponentSettings.checkoutInformation
            && this.wxmlComponentSettings.checkoutInformation.mailingAddress) {
            memberAddress = this.wxmlComponentSettings.checkoutInformation.mailingAddress;
        }
        return this.constructBillingAddress(memberAddress);
    }


    /**
     * Construct billing address
     *
     * @param {*} shippingAddress
     * @returns {Address}
     * @memberof WorldPayXMLComponent
     */
    constructBillingAddress(shippingAddress): Address {
        let country: Country;
        if (this.wxmlComponentSettings.countries && this.wxmlComponentSettings.countries.length > 0) {
            if (shippingAddress && shippingAddress.countryCode) {
                if (shippingAddress.state === PaymentConstants.PuertoRico || shippingAddress.state === PaymentConstants.MarshallIslands
                    || shippingAddress.state === PaymentConstants.VirginIslands) {
                    if (shippingAddress.state === PaymentConstants.MarshallIslands) {
                        country = this.wxmlComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                            === shippingAddress.state.toLowerCase());
                    } else {
                        country = this.wxmlComponentSettings.countries.find(x => x.isocodeTwo.toLowerCase()
                            === shippingAddress.state.toLowerCase());
                    }
                } else {
                    country = this.wxmlComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                        === shippingAddress.countryCode.toLowerCase());
                }
            } else if (this.wxmlComponentSettings.checkoutInformation
                && this.wxmlComponentSettings.checkoutInformation.shippingInformation
                && this.wxmlComponentSettings.checkoutInformation.shippingInformation.deliveryOptionType === DeliveryOptionType.Pickup
                && this.wxmlComponentSettings.checkoutInformation.mailingAddress
                && (this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.PuertoRico
                    || this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.MarshallIslands
                    || this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.VirginIslands)) {
                if (this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode === PaymentConstants.MarshallIslands) {
                    country = this.wxmlComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                        === this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode.toLowerCase());
                } else {
                    country = this.wxmlComponentSettings.countries.find(x => x.isocodeTwo.toLowerCase()
                        === this.wxmlComponentSettings.checkoutInformation.mailingAddress.stateCode.toLowerCase());
                }
            } else {
                country = this.wxmlComponentSettings.countries.find(x => x.isocodeThree.toLowerCase()
                    === this.wxmlComponentSettings.isoCountryCode.toLowerCase());
            }
        }
        const billingAddress: Address = {
            country: country ? country.isocodeTwo : '',
            countryCodeTwo: country ? country.isocodeTwo : '',
            countryCode: country ? country.isocodeTwo : '',
            state: shippingAddress && shippingAddress.state ? shippingAddress.state : shippingAddress
                && shippingAddress.stateCode ? shippingAddress.stateCode : '',
            city: shippingAddress ? shippingAddress.city : '',
            postalCode: shippingAddress ? shippingAddress.postalCode : '',
            addressLine1: shippingAddress ? shippingAddress.addressLine1 : '',
            addressLine2: shippingAddress ? shippingAddress.addressLine2 : ''
        };
        return billingAddress;
    }

}
