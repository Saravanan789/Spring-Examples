import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { StorePaymentMethod } from '../interfaces';

@Injectable()
export class PaymentMessageService {
    private payPalOrCCSection: Subject<StorePaymentMethod> = new Subject<StorePaymentMethod>();
    constructor() { }

    /**
     * @description this subject used for
     * hide or show paypal or cc
     * @date 2018-08-17
     * @returns {Observable<any>}
     * @memberof CheckoutMessageService
     */
    getPayPalOrCCSection(): Observable<StorePaymentMethod> {
        return this.payPalOrCCSection.asObservable();
    }

    /**
     * @description this subject used for
     * hide or show paypal or cc
     * @date 2018-08-17
     * @returns {Observable<any>}
     * @memberof CheckoutMessageService
     */
    setPayPalOrCCSection(paymentMethod: StorePaymentMethod): void {
        this.payPalOrCCSection.next(paymentMethod);
    }
}