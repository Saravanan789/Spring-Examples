
import { PersonalInformation, SponsorInformation, PersonalInfoFormFields, MemberContact } from '../interfaces';
import { BaseSettings } from '../../common/component-settings/base-settings.model';
import { FormGroup } from '@angular/forms';
import { Address } from '../../common/interfaces';
import { DocumentLibrary } from '../../shared/interfaces';
import { ValidationMessage } from '../interfaces/validation-message.interface';
import { ContactTypeConstants } from '../constants';
import { environment } from '../../../environments/environment';

export class PersonalInfoComponentSettings extends BaseSettings {
    mailAlreadyExist: boolean;
    formSubmitted: boolean;
    personalInformationForm: FormGroup;
    personalInfoFormValidated: boolean;
    guestUser: boolean;
    mailingSchemaUrl: string;
    addressSubmitted: boolean;
    personalInformation: PersonalInformation;
    sponsorInformation: SponsorInformation;
    mailingAddress: Address;
    displayAddressVerification: boolean;
    displayAddressForm = true;
    liveFormAddress: Address;
    disableNextButton = false;
    isShowLoader = false;
    isAutoPopulate = false;
    phoneNumberAlreadyExists: boolean;
    isShowPhoneNumberLoader = false;
    isValidatingSignup: boolean;
    personalInfoFormValidations: PersonalInfoFormFields;
    phoneNumberFormat: string;
    isPopoverOpen: boolean;
    personalInfoTAndC: DocumentLibrary[];
    agreementCheck: boolean;
    agreementCheckError: boolean;
    fpcOptIn: boolean;
    governmentIdValidInProgress = false;
    governmentIdExist: boolean;
    invalidGovernmentId: boolean;
    governmentIdValidations: ValidationMessage[];
    dateOfBirth: any; // we are getting moment object
    governmentId: string;
    contactTypes = ContactTypeConstants.phoneTypes;
    memberContact: MemberContact;
    isLegacyUser = false;
    intialPollCount = 0;
    maxPollCount = environment.longPollCount;
    enableEasterEgg = environment.enableEasterEgg;
}
