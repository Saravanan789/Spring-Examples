export enum CommunicationPreferenceValues {
    yes = 37,
    no = 38
}
