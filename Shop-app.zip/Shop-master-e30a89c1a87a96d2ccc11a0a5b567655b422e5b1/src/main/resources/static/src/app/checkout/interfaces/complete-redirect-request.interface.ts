export interface CompleteRedirectRequest {
    exponent: number;
    code: string;
    shopperEmailAddress: string;
    paymentMethodType: string;
    successURL?: string;
    cancelURL?: string;
    failureURL?: string;
}
