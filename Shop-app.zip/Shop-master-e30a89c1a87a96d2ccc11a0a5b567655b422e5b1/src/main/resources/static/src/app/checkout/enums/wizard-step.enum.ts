export enum WizardStep {
    SHIPPING = 1,
    DELIVERY = 2,
    PAYMENT = 3
}
