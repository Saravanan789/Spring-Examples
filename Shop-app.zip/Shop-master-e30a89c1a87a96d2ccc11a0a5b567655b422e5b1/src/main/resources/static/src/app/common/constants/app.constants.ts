import { environment } from '../../../environments/environment';

export class AppConstants {
    public static fallbackLanguageCode = 'en-us';
    public static fallbackCountryCode = 'usa';
    public static fallbackPath = 'usa/en-us/products';
    public static fallbackCountryId = '1';
    public static DEFULT_PROFILEIMG = 'https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg';
    public static CERTIFICATE = 'CERTIFICATE';
    public static INGREDIENT = 'INGREDIENT';
    public static enableSponsorEligibilityCheck = environment.enableSponsorEligibilityCheck;
}
