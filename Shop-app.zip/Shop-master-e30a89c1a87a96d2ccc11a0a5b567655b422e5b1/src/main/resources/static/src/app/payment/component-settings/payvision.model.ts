import { PaymentComponentSettings } from './payment.model';
import { PayvisionSavedCard } from '../interfaces';
import { FormGroup } from '@angular/forms';
import { PaymentInformation } from '../../checkout/interfaces';


export class PayvisionComponentSettings extends PaymentComponentSettings {
    payvisionCheckoutId: string;
    paymentWithSavedCard: boolean;
    paymentTexts: any;
    savedCards: PayvisionSavedCard[];
    errorMessage: string;
    savedPayvisionCardForm: FormGroup;
    payvisionFormLoaded: boolean;
    selectedPayvisionSavedCard: PayvisionSavedCard;
    paymentInformation: PaymentInformation;
}

