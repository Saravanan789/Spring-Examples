export class OrderSource {
    public static WEB = 'WEB';
}
