import { MemberPreferenceType } from '../enums';

export interface MemberPreference {
    id?: number;
    memberId?: number;
    preferenceType: MemberPreferenceType;
    preferenceValue: string;
}

